package com.epam.beacons.scanner;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.inject.Singleton;

@Singleton
public class BluetoothHelperImpl implements BluetoothHelper {

    private       boolean      isScanning;
    @NonNull
    private final Context      context;
    @Nullable
    private       Callback     callback;
    @NonNull
    private final ScanSettings scanSettings;
    @NonNull
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    /* There must be only one common callback for startScan and stopScan
       methods to work properly
    */
    @NonNull
    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, @NonNull ScanResult result) {
            if (callback != null && result.getScanRecord() != null) {
                executor.execute(() -> callback.onResult(result.getScanRecord().getBytes(), result.getRssi()));
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            if (callback != null) {
                callback.onScanFailed(errorCode);
            }
        }
    };

    public BluetoothHelperImpl(@NonNull Context context, @NonNull ScanSettings scanSettings) {
        this.context = context;
        this.scanSettings = scanSettings;
    }

    @Override
    public boolean isScanning() {
        return isScanning;
    }

    @Override
    public final void startScan(@NonNull Callback callback) {
        if (isScanning) {
            callback.onStartScanFailed("Scanning is already started");
            return;
        }

        final BluetoothAdapter bluetoothAdapter;
        try {
            bluetoothAdapter = getBluetoothAdapter();
        } catch (IllegalStateException e) {
            callback.onStartScanFailed(e.getMessage());
            return;
        }

        if (!isBluetoothOn(bluetoothAdapter)) {
            callback.onBluetoothIsOff();
            return;
        }

        startScanInternal(bluetoothAdapter, callback);
        isScanning = true;
    }

    @Override
    public final void stopScan(@NonNull Callback callback) {
        if (isScanning) {
            final BluetoothAdapter bluetoothAdapter = getBluetoothAdapter();
            stopScanInternal(bluetoothAdapter, callback);
            isScanning = false;
        }
    }

    private void startScanInternal(@NonNull BluetoothAdapter bluetoothAdapter,
                                   @NonNull Callback callback) {
        this.callback = callback;
        bluetoothAdapter.getBluetoothLeScanner()
                        .startScan(null, scanSettings, scanCallback);
    }

    private void stopScanInternal(@NonNull BluetoothAdapter bluetoothAdapter,
                                  @NonNull Callback callback) {
        this.callback = callback;
        final BluetoothLeScanner scanner = bluetoothAdapter.getBluetoothLeScanner();
        if (scanner != null) {
            scanner.stopScan(scanCallback);
        }
        callback.onScanStopped();
    }

    private boolean isBluetoothOn(@NonNull BluetoothAdapter bluetoothAdapter) {
        return bluetoothAdapter.isEnabled();
    }

    @NonNull
    private BluetoothAdapter getBluetoothAdapter() {
        if (!isBLESupported()) {
            throw new IllegalStateException("BLE is not supported on this device");
        }

        final BluetoothManager manager = getManager();
        if (manager == null) {
            throw new IllegalStateException("Can not get BluetoothManager");
        }

        return manager.getAdapter();
    }

    private boolean isBLESupported() {
        return context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE);
    }

    @Nullable
    private BluetoothManager getManager() {
        return (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
    }
}
