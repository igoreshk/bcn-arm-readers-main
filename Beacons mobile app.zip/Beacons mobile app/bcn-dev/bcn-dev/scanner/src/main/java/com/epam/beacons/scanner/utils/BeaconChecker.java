package com.epam.beacons.scanner.utils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.epam.beacons.Beacon;

import java.util.Arrays;

public class BeaconChecker {
    @NonNull
    private static final char[]      hexArray                  = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
    @NonNull
    private static final byte[]      patternIbeaconAndEstimote = {0x4c, 0x00, 0x02, 0x15};
    @NonNull
    private static       BeaconTypes types                     = BeaconTypes.NONE;

    private BeaconChecker() { // private constructor to hide the implicit public one
    }

    @Nullable
    public static Beacon fromScanData(@NonNull byte[] scanData, int rssi) {
        int startByte = 0;
        boolean patternFound = false;

        final byte[] scanDataPart = new byte[4];
        while (startByte <= 5) {
            System.arraycopy(scanData, startByte, scanDataPart, 0, scanDataPart.length);

            if (Arrays.equals(scanDataPart, patternIbeaconAndEstimote)) {
                types = BeaconTypes.IBEACON_AND_ESTIMOTE;
                patternFound = true;
                break;
            }
            startByte++;
        }

        if (!patternFound) {
            types = BeaconTypes.NONE;
            return null;
        }

        final int major = (scanData[startByte + 20] & 0xff) * 0x100 + (scanData[startByte + 21] & 0xff);
        final int minor = (scanData[startByte + 22] & 0xff) * 0x100 + (scanData[startByte + 23] & 0xff);
        final int txPower = (int) scanData[startByte + 24]; // this one is signed

        // AirLocate:
        // 02 01 1a 1a ff 4c 00 02 15  # Apple's fixed beacon advertising prefix
        // e2 c5 6d b5 df fb 48 d2 b0 60 d0 f5 a7 10 96 e0 # beacon profile uuid
        // 00 00 # major
        // 00 00 # minor
        // c5 # The 2's complement of the calibrated Tx Power
        // Estimote:
        // 02 01 1a 11 07 2d 24 bf 16
        // 394b31ba3f486415ab376e5c0f09457374696d6f7465426561636f6e00000000000000000000000000000000000000000000000000

        final byte[] proximityUuidBytes = new byte[16];
        System.arraycopy(scanData, startByte + 4, proximityUuidBytes, 0, 16);
        final String hexString = bytesToHex(proximityUuidBytes);
        final String uuid = String.format(
                "%s-%s-%s-%s-%s",
                hexString.substring(0, 8),
                hexString.substring(8, 12),
                hexString.substring(12, 16),
                hexString.substring(16, 20),
                hexString.substring(20, 32)
        );

        return new Beacon(uuid, major, minor, txPower, rssi);
    }

    @NonNull
    private static String bytesToHex(@NonNull byte[] bytes) {
        final char[] hexChars = new char[bytes.length * 2];
        int v;
        for (int j = 0; j < bytes.length; j++) {
            v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }

    @NonNull
    public static BeaconTypes getTypes() {
        return types;
    }
}
