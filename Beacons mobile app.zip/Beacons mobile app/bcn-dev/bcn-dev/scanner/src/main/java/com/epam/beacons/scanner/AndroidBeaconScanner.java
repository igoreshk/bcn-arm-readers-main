package com.epam.beacons.scanner;

import androidx.annotation.NonNull;

import com.epam.beacons.Beacon;
import com.epam.beacons.tools.exception.BluetoothDisabledException;
import com.epam.beacons.scanner.utils.BeaconChecker;
import com.epam.beacons.tools.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Observable;
import io.reactivex.subjects.PublishSubject;
import io.reactivex.subjects.Subject;

@Singleton
public class AndroidBeaconScanner implements BeaconScanner, BluetoothHelper.Callback {

    @NonNull
    private static final String LOG_TAG = AndroidBeaconScanner.class.getSimpleName();

    @NonNull
    private final BluetoothHelper helper;
    @NonNull
    private final Logger          logger;

    @NonNull
    @SuppressWarnings("NullableProblems") // initialized in `initBeacons()` method
    private Subject<Beacon> beacons;

    @Inject
    AndroidBeaconScanner(@NonNull BluetoothHelper helper, @NonNull Logger logger) {
        this.helper = helper;
        this.logger = logger;
        initBeacons();
    }

    @NonNull
    @Override
    public Observable<Beacon> getScannerResults() {
        if (!helper.isScanning()) {
            initBeacons();
            helper.startScan(this);
        }
        return beacons;
    }

    @Override
    public void onResult(@NonNull byte[] scanRecord, int rssi) {
        if (!beacons.hasObservers()) {
            helper.stopScan(this);
        }

        final Beacon beacon = BeaconChecker.fromScanData(scanRecord, rssi);

        if (beacon == null) {
            return;
        }
        switch (BeaconChecker.getTypes()) {
            case NONE:
                break;
            case IBEACON_AND_ESTIMOTE:
                beacons.onNext(beacon);
                break;
            default:
                break;
        }
    }

    @Override
    public void onStartScanFailed(@NonNull String message) {
        logger.d(LOG_TAG, "On scan start failed: " + message);
    }

    @Override
    public void onBluetoothIsOff() {
        logger.d(LOG_TAG, "Bluetooth is off");
        beacons.onError(new BluetoothDisabledException());
    }

    @Override
    public void onScanFailed(int errorCode) {
        logger.e(LOG_TAG, "On scan failed. Error code: " + errorCode);
        beacons.onError(new Exception("Scan failed. Error code: " + errorCode));
    }

    @Override
    public void onScanStopped() {
        logger.d(LOG_TAG, "Scanning stopped");
        beacons.onComplete();
    }

    private void initBeacons() {
        beacons = PublishSubject.<Beacon>create().toSerialized();
    }
}
