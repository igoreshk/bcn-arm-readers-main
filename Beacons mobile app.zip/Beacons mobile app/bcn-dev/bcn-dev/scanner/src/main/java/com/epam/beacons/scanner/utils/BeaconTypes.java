package com.epam.beacons.scanner.utils;

public enum BeaconTypes {
    IBEACON_AND_ESTIMOTE, NONE
}
