package com.epam.beacons.scanner.utils;

import com.epam.beacons.Beacon;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class BeaconCheckerTest {

    private byte[] scanData;
    private int    rssi;

    private Beacon expectedBeacon;

    @Before
    public void setUp() {
        scanData = new byte[]{2, 1, 6, 26, -1, 76, 0, 2, 21, 1, 18, 35, 52, 69, 86, 103, 120, -119, -102, -85, -68, -51, -34, -17, -16, 39, 27, 39, 19, -59, 5, 9, 69, 80, 65, 77, 11, 22, 66, 82, 65, 41, -31, -36, -85, -45, -109, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
        rssi = -73;
        expectedBeacon = new Beacon("01122334-4556-6778-899a-abbccddeeff0", 10011, 10003, -59, -73);
    }

    @Test
    @SuppressWarnings("ConstantConditions")
    public void testBeaconChecker() {
        final Beacon beacon = BeaconChecker.fromScanData(scanData, rssi);
        assertEquals(expectedBeacon, beacon);

        /* we need to check txPower and rssi
            because equals() in Beacon compares only by uuid, major, minor */
        assertEquals(0, Double.compare(expectedBeacon.getTxPower(), beacon.getTxPower()));
        assertEquals(expectedBeacon.getRssi(), beacon.getRssi());
    }
}
