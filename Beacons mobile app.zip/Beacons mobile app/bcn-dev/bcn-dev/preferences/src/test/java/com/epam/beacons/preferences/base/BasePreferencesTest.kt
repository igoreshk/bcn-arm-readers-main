package com.epam.beacons.preferences.base

import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@Config(manifest = Config.NONE)
@RunWith(RobolectricTestRunner::class)
class BasePreferencesTest {

    private val basePreferences = BasePreferences(RuntimeEnvironment.application.applicationContext)

    private val testKey = "key"

    @Test
    fun testPutAndGetBoolean() {
        val testBoolean = false
        basePreferences.put(testKey, testBoolean)
                .andThen(basePreferences.getBoolean(testKey))
                .test()
                .assertComplete()
                .assertValue(testBoolean)
    }

    @Test
    fun testPutAndGetInt() {
        val testInt = 1
        basePreferences.put(testKey, testInt)
                .andThen(basePreferences.getInt(testKey))
                .test()
                .assertComplete()
                .assertValue(testInt)
    }

    @Test
    fun testPutAndGetFloat() {
        val testFloat = 1.0f
        basePreferences.put(testKey, testFloat)
                .andThen(basePreferences.getFloat(testKey))
                .test()
                .assertComplete()
                .assertValue(testFloat)
    }

    @Test
    fun testPutAndGetLong() {
        val testLong = 1L
        basePreferences.put(testKey, testLong)
                .andThen(basePreferences.getLong(testKey))
                .test()
                .assertComplete()
                .assertValue(testLong)
    }

    @Test
    fun testPutAndGetString() {
        val testString = "1"
        basePreferences.put(testKey, testString)
                .andThen(basePreferences.getString(testKey))
                .test()
                .assertComplete()
                .assertValue(testString)
    }
}
