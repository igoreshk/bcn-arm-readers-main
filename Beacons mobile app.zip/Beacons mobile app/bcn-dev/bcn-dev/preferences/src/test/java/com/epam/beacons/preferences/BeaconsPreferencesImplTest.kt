package com.epam.beacons.preferences

import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@Config(manifest = Config.NONE)
@RunWith(RobolectricTestRunner::class)
class BeaconsPreferencesImplTest {

    private val beaconsPreferencesImpl = BeaconsPreferencesImpl(RuntimeEnvironment.application.applicationContext)

    private val testBoolean = true
    private val defaultBoolean = false

    @Test
    fun testIsDebugDrawAllowed() {
        beaconsPreferencesImpl.saveDebugDrawPreference(testBoolean)
                .andThen(beaconsPreferencesImpl.isDebugDrawAllowed())
                .test()
                .assertValue(testBoolean)
    }

    @Test
    fun testIsSimpleLocationMode() {
        beaconsPreferencesImpl.saveLocationMode(testBoolean)
                .andThen(beaconsPreferencesImpl.isSimpleLocationMode())
                .test()
                .assertValue(testBoolean)
    }

    @Test
    fun testSaveDebugDrawPreference() {
        beaconsPreferencesImpl.saveDebugDrawPreference(testBoolean)
                .test()
                .assertComplete()
    }

    @Test
    fun testSaveLocationMode() {
        beaconsPreferencesImpl.saveLocationMode(testBoolean)
                .test()
                .assertComplete()
    }

    @Test
    fun testWhenPreferenceNewThenReturnDefaultDebugAllowance() {
        beaconsPreferencesImpl.isDebugDrawAllowed()
                .test()
                .assertValue(defaultBoolean)
    }
    @Test
    fun testWhenPreferenceNewThenReturnDefaultLocationMode() {
        beaconsPreferencesImpl.isSimpleLocationMode()
                .test()
                .assertValue(defaultBoolean)
    }
}
