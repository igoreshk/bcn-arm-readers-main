package com.epam.beacons.preferences

import android.content.Context
import com.epam.beacons.preferences.base.BasePreferences
import com.epam.beacons.repository.preferences.BeaconsPreferences
import io.reactivex.Completable
import io.reactivex.Maybe
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BeaconsPreferencesImpl @Inject constructor(context: Context) : BasePreferences(context), BeaconsPreferences {

    override fun isSimpleLocationMode(): Maybe<Boolean> = getBoolean(SIMPLE_MODE)

    override fun isDebugDrawAllowed(): Maybe<Boolean> = getBoolean(DEBUG_DRAW)

    override fun saveDebugDrawPreference(value: Boolean): Completable = put(DEBUG_DRAW, value)

    override fun saveLocationMode(value: Boolean): Completable = put(SIMPLE_MODE, value)

    companion object {
        private const val DEBUG_DRAW = "debugDraw"
        private const val SIMPLE_MODE = "simpleMode"
    }
}
