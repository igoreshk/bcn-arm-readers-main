package com.epam.beacons.preferences.base

import android.content.Context
import android.content.SharedPreferences
import io.reactivex.Completable
import io.reactivex.Maybe

open class BasePreferences(context: Context) {
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences(KEY, Context.MODE_PRIVATE)

    fun getBoolean(key: String): Maybe<Boolean> = Maybe.fromCallable { sharedPreferences.getBoolean(key, false) }

    fun put(key: String, value: Boolean): Completable =
            Completable.fromAction { sharedPreferences.edit().putBoolean(key, value).apply() }

    fun getInt(key: String): Maybe<Int> = Maybe.fromCallable { sharedPreferences.getInt(key, 0) }

    fun put(key: String, value: Int): Completable =
            Completable.fromAction { sharedPreferences.edit().putInt(key, value).apply() }

    fun getFloat(key: String): Maybe<Float> = Maybe.fromCallable { sharedPreferences.getFloat(key, 0f) }

    fun put(key: String, value: Float): Completable =
            Completable.fromAction { sharedPreferences.edit().putFloat(key, value).apply() }

    fun getLong(key: String): Maybe<Long> = Maybe.fromCallable { sharedPreferences.getLong(key, 0) }

    fun put(key: String, value: Long): Completable =
            Completable.fromAction { sharedPreferences.edit().putLong(key, value).apply() }

    fun getString(key: String): Maybe<String> = Maybe.fromCallable { sharedPreferences.getString(key, "") }

    fun put(key: String, value: String): Completable =
            Completable.fromAction { sharedPreferences.edit().putString(key, value).apply() }

    companion object {
        private const val KEY = "preferences"
    }
}
