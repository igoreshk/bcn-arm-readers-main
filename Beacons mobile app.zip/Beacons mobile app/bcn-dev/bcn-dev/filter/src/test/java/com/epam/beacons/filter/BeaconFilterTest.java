package com.epam.beacons.filter;

import com.epam.beacons.Beacon;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class BeaconFilterTest {

    @InjectMocks
    private BeaconFilter beaconFilter;

    private final List<Beacon> input;
    private final List<Beacon> expected;

    public BeaconFilterTest(List<Beacon> input, List<Beacon> expected) {
        this.input = input;
        this.expected = expected;
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        Collections.emptyList(),
                        Collections.emptyList()
                },
                {
                        Collections.singletonList(
                                new Beacon("1", 1, 1, -55, -55)
                        ),
                        Collections.singletonList(
                                new Beacon("1", 1, 1, -55, -55)
                        )
                },
                {
                        Arrays.asList(
                                new Beacon("1", 1, 1, -55, -60),
                                new Beacon("2", 2, 2, -55, -50)
                        ),
                        Arrays.asList(
                                new Beacon("2", 2, 2, -55, -50),
                                new Beacon("1", 1, 1, -55, -60)
                        )
                },
                {
                        Arrays.asList(
                                new Beacon("1", 1, 1, -55, -60),
                                new Beacon("2", 2, 2, -55, -55),
                                new Beacon("3", 3, 3, -55, -50)
                        ),
                        Arrays.asList(
                                new Beacon("1", 1, 1, -55, -60),
                                new Beacon("2", 2, 2, -55, -55),
                                new Beacon("3", 3, 3, -55, -50)
                        )
                },
                {
                        Arrays.asList(
                                new Beacon("1", 1, 1, -55, -100),
                                new Beacon("2", 2, 2, -55, -55),
                                new Beacon("3", 3, 3, -55, -50)
                        ),
                        Arrays.asList(
                                new Beacon("3", 3, 3, -55, -50),
                                new Beacon("2", 2, 2, -55, -55),
                                new Beacon("1", 1, 1, -55, -100)
                        )
                },
                {
                        Arrays.asList(
                                new Beacon("1", 1, 1, -55, -70),
                                new Beacon("2", 2, 2, -55, -55),
                                new Beacon("3", 3, 3, -55, -50),
                                new Beacon("4", 4, 4, -55, -60)
                        ),
                        Arrays.asList(
                                new Beacon("1", 1, 1, -55, -70),
                                new Beacon("2", 2, 2, -55, -55),
                                new Beacon("3", 3, 3, -55, -50),
                                new Beacon("4", 4, 4, -55, -60)
                        )
                },
                {
                        Arrays.asList(
                                new Beacon("1", 1, 1, -55, -100),
                                new Beacon("2", 2, 2, -55, -55),
                                new Beacon("3", 3, 3, -55, -50),
                                new Beacon("4", 4, 4, -55, -60)
                        ),
                        Arrays.asList(
                                new Beacon("2", 2, 2, -55, -55),
                                new Beacon("3", 3, 3, -55, -50),
                                new Beacon("4", 4, 4, -55, -60)
                        )
                },
                {
                        Arrays.asList(
                                new Beacon("1", 1, 1, -55, -100),
                                new Beacon("2", 2, 2, -55, -110),
                                new Beacon("3", 3, 3, -55, -50),
                                new Beacon("4", 4, 4, -55, -60)
                        ),
                        Arrays.asList(
                                new Beacon("3", 3, 3, -55, -50),
                                new Beacon("4", 4, 4, -55, -60),
                                new Beacon("1", 1, 1, -55, -100)
                        )
                },
                {
                        Arrays.asList(
                                new Beacon("1", 1, 1, -55, -100),
                                new Beacon("2", 2, 2, -55, -110),
                                new Beacon("3", 3, 3, -55, -50),
                                new Beacon("4", 4, 4, -55, -120)
                        ),
                        Arrays.asList(
                                new Beacon("3", 3, 3, -55, -50),
                                new Beacon("1", 1, 1, -55, -100),
                                new Beacon("2", 2, 2, -55, -110)
                        )
                },
                {
                        Arrays.asList(
                                new Beacon("1", 1, 1, -55, -50),
                                new Beacon("2", 2, 2, -55, -40),
                                new Beacon("3", 3, 3, -55, -60),
                                new Beacon("4", 4, 4, -55, -65),
                                new Beacon("5", 5, 5, -55, -55),
                                new Beacon("6", 6, 6, -55, -45),
                                new Beacon("7", 7, 7, -55, -80)
                        ),
                        Arrays.asList(
                                new Beacon("1", 1, 1, -55, -50),
                                new Beacon("2", 2, 2, -55, -40),
                                new Beacon("3", 3, 3, -55, -60),
                                new Beacon("4", 4, 4, -55, -65),
                                new Beacon("5", 5, 5, -55, -55),
                                new Beacon("6", 6, 6, -55, -45),
                                new Beacon("7", 7, 7, -55, -80)
                        )
                },
                {
                        Arrays.asList(
                                new Beacon("1", 1, 1, -55, -100),
                                new Beacon("2", 2, 2, -55, -40),
                                new Beacon("3", 3, 3, -55, -60),
                                new Beacon("4", 4, 4, -55, -110),
                                new Beacon("5", 5, 5, -55, -55),
                                new Beacon("6", 6, 6, -55, -45),
                                new Beacon("7", 7, 7, -55, -80)
                        ),
                        Arrays.asList(
                                new Beacon("2", 2, 2, -55, -40),
                                new Beacon("3", 3, 3, -55, -60),
                                new Beacon("5", 5, 5, -55, -55),
                                new Beacon("6", 6, 6, -55, -45),
                                new Beacon("7", 7, 7, -55, -80)
                        )
                },
                {
                        Arrays.asList(
                                new Beacon("1", 1, 1, -55, -100),
                                new Beacon("2", 2, 2, -55, -120),
                                new Beacon("3", 3, 3, -55, -60),
                                new Beacon("4", 4, 4, -55, -110),
                                new Beacon("5", 5, 5, -55, -55),
                                new Beacon("6", 6, 6, -55, -115),
                                new Beacon("7", 7, 7, -55, -80)
                        ),
                        Arrays.asList(
                                new Beacon("3", 3, 3, -55, -60),
                                new Beacon("5", 5, 5, -55, -55),
                                new Beacon("7", 7, 7, -55, -80)
                        )
                },
                {
                        Arrays.asList(
                                new Beacon("1", 1, 1, -55, -100),
                                new Beacon("2", 2, 2, -55, -120),
                                new Beacon("3", 3, 3, -55, -60),
                                new Beacon("4", 4, 4, -55, -110),
                                new Beacon("5", 5, 5, -55, -55),
                                new Beacon("6", 6, 6, -55, -115),
                                new Beacon("7", 7, 7, -55, -130)
                        ),
                        Arrays.asList(
                                new Beacon("5", 5, 5, -55, -55),
                                new Beacon("3", 3, 3, -55, -60),
                                new Beacon("1", 1, 1, -55, -100)
                        )
                }
        });
    }

    @Test
    public void testFilterBeacons() {
        beaconFilter.filterBeacons(input)
                    .test()
                    .assertValue(expected)
                    .assertValue(beacons -> {
                        for (int i = 0; i < beacons.size(); i++) {
                            // we need additional checks because equals() of Beacon compares only by uuid, major, minor
                            assertEquals(expected.get(i).getTxPower(), beacons.get(i).getTxPower(), 0);
                            assertEquals(expected.get(i).getRssi(), beacons.get(i).getRssi());
                            assertEquals(expected.get(i).getCoordinate(), beacons.get(i).getCoordinate());
                        }
                        return true;
                    });
    }
}
