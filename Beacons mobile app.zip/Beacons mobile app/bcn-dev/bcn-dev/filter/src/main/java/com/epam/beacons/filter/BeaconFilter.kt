package com.epam.beacons.filter

import com.epam.beacons.Beacon
import io.reactivex.Observable
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class
BeaconFilter @Inject constructor() {

    /**
     * After signals are filtered by threshold, if there are more than 3 values
     * all of them returns to determine current position.
     * Else another observable source is switched where signals are sorted by rssi
     * to take up to 3 most powerful values.
     */
    fun filterBeacons(beacons: List<Beacon>): Observable<List<Beacon>> = Observable.fromIterable(beacons)
            .filter { (_, _, _, txPower, rssi) -> rssi / txPower <= SIGNAL_THRESHOLD }
            .toList()
            .toObservable()
            .filter { list -> list.size >= BEACONS_THRESHOLD }
            .switchIfEmpty(Observable.fromIterable(beacons)
                    .sorted()
                    .take(BEACONS_THRESHOLD.toLong())
                    .toList()
                    .toObservable())

    companion object {
        private const val BEACONS_THRESHOLD = 3
        private const val SIGNAL_THRESHOLD = 1.5
    }
}
