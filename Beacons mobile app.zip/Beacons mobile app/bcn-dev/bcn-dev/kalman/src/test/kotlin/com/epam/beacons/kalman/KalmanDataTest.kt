package com.epam.beacons.kalman

import org.hamcrest.CoreMatchers.equalTo
import org.junit.Assert.assertThat
import org.junit.Test

class KalmanDataTest {

    private val kalmanData = KalmanData()

    private val valueToCompare = doubleArrayOf(3.0, 5.0)

    @Test
    fun testReset() {
        with(kalmanData) {
            x = 100.0
            y = 150.0
            velocityX = 33.0
            velocityY = 66.0
            needToSave = false
        }

        kalmanData.reset()
                .test()
                .assertComplete()

        assertThat(kalmanData.needToSave, equalTo(true))
        assertThat(kalmanData.x, equalTo(0.0))
        assertThat(kalmanData.velocityX, equalTo(0.0))
        assertThat(kalmanData.y, equalTo(0.0))
        assertThat(kalmanData.velocityY, equalTo(0.0))
    }

    @Test
    fun testSetXandVx() {
        kalmanData.setXandVx(valueToCompare)
        assertThat(kalmanData.x, equalTo(valueToCompare[0]))
        assertThat(kalmanData.velocityX, equalTo(valueToCompare[1]))
    }

    @Test
    fun testSetYandVy() {
        kalmanData.setYandVy(valueToCompare)
        assertThat(kalmanData.y, equalTo(valueToCompare[0]))
        assertThat(kalmanData.velocityY, equalTo(valueToCompare[1]))
    }
}
