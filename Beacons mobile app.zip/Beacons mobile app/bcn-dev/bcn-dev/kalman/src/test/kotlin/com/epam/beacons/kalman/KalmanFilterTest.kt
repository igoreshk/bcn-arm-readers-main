package com.epam.beacons.kalman

import com.epam.beacons.Coordinate
import com.epam.beacons.kalman.KotlinMockito.whn
import com.epam.beacons.tools.utils.ErrorProvider
import io.reactivex.Observable
import org.hamcrest.CoreMatchers.equalTo
import org.hamcrest.MatcherAssert.assertThat
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito.verify
import org.mockito.Spy
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class KalmanFilterTest {

    @Mock
    private lateinit var sensorCenter: SensorCenter
    @Mock
    private lateinit var errorProvider: ErrorProvider
    @Mock
    private lateinit var kalmanProcessor: KalmanProcessor
    @Spy
    private lateinit var kalmanData: KalmanData

    @InjectMocks
    private lateinit var kalmanFilter: KalmanFilter

    @Test
    fun testFilter() {
        val coordinate = Observable.fromCallable { Coordinate(1.0, 2.0) }
        val expectedCoordinate = Coordinate(5.0, 6.0)
        whn(sensorCenter.getSensorData()).thenReturn(Observable.fromCallable { floatArrayOf(3f, 4f, 5f) })
        whn(kalmanProcessor.getPrediction(doubleArrayOf(1.0, 0.0), 3f)).thenReturn(doubleArrayOf(5.0, 10.0))
        whn(kalmanProcessor.getPrediction(doubleArrayOf(2.0, 0.0), 4f)).thenReturn(doubleArrayOf(6.0, 3.0))
        kalmanFilter.filter(coordinate)
                .test()
                .assertValue(expectedCoordinate)

        assertThat(kalmanData.x, equalTo(5.0))
        assertThat(kalmanData.y, equalTo(6.0))
        assertThat(kalmanData.needToSave, equalTo(false))
        verify(errorProvider).getAccelerometerError()
        verify(errorProvider).getPositionError()
    }
}
