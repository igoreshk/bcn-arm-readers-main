package com.epam.beacons.kalman

import com.epam.beacons.kalman.KotlinMockito.whn
import com.epam.beacons.tools.utils.TimeProvider
import org.hamcrest.CoreMatchers.equalTo
import org.junit.Assert.assertThat
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class KalmanProcessorTest {

    @Mock
    private lateinit var timeProvider: TimeProvider

    @InjectMocks
    private lateinit var kalmanProcessor: KalmanProcessor

    @Test
    fun getPrediction() {
        whn(timeProvider.getCurrentSystemTime()).thenReturn(1000)
        assertThat(kalmanProcessor.getPrediction(doubleArrayOf(1.0, 1.5), 2f), equalTo(doubleArrayOf(4.551310861423221, 4.0295880149812735)))
        assertThat(kalmanProcessor.getPrediction(doubleArrayOf(2.0, 2.5), 3f), equalTo(doubleArrayOf(7.045183282149732, 6.026526749891684)))
        assertThat(kalmanProcessor.getPrediction(doubleArrayOf(3.0, 5.5), 4f), equalTo(doubleArrayOf(11.541193907258561, 10.025530811190343)))
    }
}
