package com.epam.beacons.kalman

import io.reactivex.Completable
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class KalmanData @Inject constructor() {
    internal var x = 0.0
    internal var velocityX = 0.0
    internal var y = 0.0
    internal var velocityY = 0.0
    internal var needToSave = true

    fun reset(): Completable = Completable.fromAction {
        x = 0.0
        velocityX = 0.0
        y = 0.0
        velocityY = 0.0
        needToSave = true
    }

    internal fun setXandVx(prediction: DoubleArray) {
        x = prediction[0]
        velocityX = prediction[1]
    }

    internal fun setYandVy(prediction: DoubleArray) {
        y = prediction[0]
        velocityY = prediction[1]
    }
}
