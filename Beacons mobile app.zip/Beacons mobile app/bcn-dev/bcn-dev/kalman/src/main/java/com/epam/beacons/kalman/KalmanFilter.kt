package com.epam.beacons.kalman

import com.epam.beacons.Coordinate
import com.epam.beacons.tools.utils.ErrorProvider
import io.reactivex.Observable
import io.reactivex.functions.BiFunction
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Main Kalman Filter class which combines inside precise acceleration from sensors with imprecise coordinates from beacons and process these data.
 */
@Singleton
class KalmanFilter @Inject constructor(
        private val sensorCenter: SensorCenter,
        private val kalmanProcessor: KalmanProcessor,
        private val errorProvider: ErrorProvider,
        private val data: KalmanData
) {

    /**
     * Applies filtering by [kalmanProcessor] with [sensorCenter] data separately to latitude and longitude of input [coordinate].
     * @param coordinate input coordinate which need to be updated according to values from sensors
     * @return new [Coordinate] wrapped by Observable with updated values
     */
    fun filter(coordinate: Observable<Coordinate>): Observable<Coordinate> =
            Observable.zip(coordinate, sensorCenter.getSensorData(), BiFunction<Coordinate, FloatArray, Coordinate> { c, sensorData ->
                with(data) {
                    if (needToSave) {
                        x = c.latitude
                        y = c.longitude
                        needToSave = false
                    }
                    kalmanProcessor.accelNoise = errorProvider.getAccelerometerError()
                    kalmanProcessor.measurementNoise = errorProvider.getPositionError()
                    setXandVx(kalmanProcessor.getPrediction(doubleArrayOf(x, velocityX), sensorData[0]))
                    setYandVy(kalmanProcessor.getPrediction(doubleArrayOf(y, velocityY), sensorData[1]))
                    Coordinate(x, y)
                }
            })
}
