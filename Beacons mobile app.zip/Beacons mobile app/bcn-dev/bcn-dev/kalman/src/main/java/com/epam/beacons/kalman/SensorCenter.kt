package com.epam.beacons.kalman

import io.reactivex.Observable

/**
 * Provides acceleration of the device in Earth coordinate system as array of North acceleration, East acceleration and down acceleration.
 * @return [Observable] with [FloatArray] of 3 accelerations
 */
interface SensorCenter {
    fun getSensorData(): Observable<FloatArray>
}
