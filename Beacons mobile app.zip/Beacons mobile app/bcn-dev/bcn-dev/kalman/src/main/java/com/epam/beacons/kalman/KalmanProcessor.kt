package com.epam.beacons.kalman

import com.epam.beacons.tools.utils.TimeProvider
import org.apache.commons.math3.filter.DefaultMeasurementModel
import org.apache.commons.math3.filter.DefaultProcessModel
import org.apache.commons.math3.filter.KalmanFilter
import org.apache.commons.math3.linear.Array2DRowRealMatrix
import org.apache.commons.math3.linear.ArrayRealVector
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Contains all vectors and matrixes for calculating predicted position and velocity.
 */
@Singleton
class KalmanProcessor @Inject constructor(private val timeProvider: TimeProvider) {

    /**
     * position measurement noise (meter).
     */
    var measurementNoise = 2.0
    /**
     * acceleration noise (meter/sec^2).
     */
    @Suppress("MagicNumber")
    var accelNoise = 0.2

    /**
     * discrete time interval.
     */
    private var dt = timeProvider.getCurrentSystemTime().toDouble() / MILLISEC_DIVIDER

    /**
     * state transition matrix.
     * mA = [ 1 dt ]
     *      [ 0  1 ]
     */
    private var mA = Array2DRowRealMatrix(arrayOf(doubleArrayOf(1.0, dt), doubleArrayOf(0.0, 1.0)))

    /**
     * control input matrix.
     * mB = [ dt^2/2 ]
     *      [ dt     ]
     */
    private var mB = Array2DRowRealMatrix(arrayOf(doubleArrayOf(Math.pow(dt, 2.0) / 2.0), doubleArrayOf(dt)))

    /**
     * measurement matrix.
     * mH = [ 1 0 ]
     */
    private val mH = Array2DRowRealMatrix(arrayOf(doubleArrayOf(1.0, 0.0)))

    private var tmp = Array2DRowRealMatrix(arrayOf(
            doubleArrayOf(Math.pow(dt, QUARTIC) / QUARTIC, Math.pow(dt, CUBIC) / 2.0),
            doubleArrayOf(Math.pow(dt, CUBIC) / 2.0, Math.pow(dt, 2.0))
    ))
    /**
     * process noise covariance matrix.
     * mQ = [ dt^4/4 dt^3/2 ]
     *      [ dt^3/2 dt^2   ]
     */
    private var mQ = tmp.scalarMultiply(Math.pow(accelNoise, 2.0))

    /**
     * error covariance matrix.
     * vP = [ 1 1 ]
     *      [ 1 1 ]
     */
    private val vP = Array2DRowRealMatrix(arrayOf(doubleArrayOf(1.0, 1.0), doubleArrayOf(1.0, 1.0)))

    /**
     * measurement noise covariance matrix.
     * vR = [ measurementNoise^2 ]
     */
    private var vR = Array2DRowRealMatrix(doubleArrayOf(Math.pow(measurementNoise, 2.0)))

    private var mm = DefaultMeasurementModel(mH, vR)

    /**
     * noise vectors.
     */
    private var tmpPNoise = ArrayRealVector(doubleArrayOf(Math.pow(dt, 2.0) / 2.0, dt))
    private val mNoise = ArrayRealVector(1)

    /**
     * @param data - input position and velocity.
     * @param acceleration - acceleration of the device in one axis, used to predict new position and velocity.
     * @return - updated [DoubleArray] of pair of both position and velocity.
     */
    fun getPrediction(data: DoubleArray, acceleration: Float): DoubleArray {
        dt = (timeProvider.getCurrentSystemTime() - dt) / MILLISEC_DIVIDER
        updateMatrixes()
        val dataVector = ArrayRealVector(data)
        val accelerationVector = ArrayRealVector(doubleArrayOf(acceleration.toDouble()))
        val pm = DefaultProcessModel(mA, mB, mQ, dataVector, vP)
        val filter = KalmanFilter(pm, mm)

        filter.predict(accelerationVector)

        // count acceleration noise
        val pNoise = tmpPNoise.mapMultiply(accelNoise)

        // x = mA * x + mB * u + pNoise
        val x = mA.operate(dataVector).add(mB.operate(accelerationVector)).add(pNoise)

        // measurement noise
        mNoise.setEntry(0, measurementNoise)

        // z = mH * x + m_noise
        val z = mH.operate(x).add(mNoise)

        filter.correct(z)

        val position = filter.stateEstimation[0]
        val velocity = filter.stateEstimation[1]

        return doubleArrayOf(position, velocity)
    }

    private fun updateMatrixes() {
        mA = Array2DRowRealMatrix(arrayOf(doubleArrayOf(1.0, dt), doubleArrayOf(0.0, 1.0)))
        mB = Array2DRowRealMatrix(arrayOf(doubleArrayOf(Math.pow(dt, 2.0) / 2.0), doubleArrayOf(dt)))
        tmp = Array2DRowRealMatrix(arrayOf(
                doubleArrayOf(Math.pow(dt, QUARTIC) / QUARTIC, Math.pow(dt, CUBIC) / 2.0),
                doubleArrayOf(Math.pow(dt, CUBIC) / 2.0, Math.pow(dt, 2.0))
        ))
        mQ = tmp.scalarMultiply(Math.pow(accelNoise, 2.0))
        vR = Array2DRowRealMatrix(doubleArrayOf(Math.pow(measurementNoise, 2.0)))
        mm = DefaultMeasurementModel(mH, vR)
        tmpPNoise = ArrayRealVector(doubleArrayOf(Math.pow(dt, 2.0) / 2.0, dt))
    }

    companion object {
        const val CUBIC = 3.0
        const val QUARTIC = 4.0
        const val MILLISEC_DIVIDER = 1000.0
    }
}
