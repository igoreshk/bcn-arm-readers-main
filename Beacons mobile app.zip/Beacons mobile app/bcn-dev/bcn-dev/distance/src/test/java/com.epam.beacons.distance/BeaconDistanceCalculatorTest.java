package com.epam.beacons.distance;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import java.util.Arrays;
import java.util.Collection;

import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class BeaconDistanceCalculatorTest {

    private static final double DELTA = 0.1;

    private final int    txPower;
    private final int    rssi;
    private final double expectedDistance;

    public BeaconDistanceCalculatorTest(int txPower, int rssi, double expectedDistance) {
        this.txPower = txPower;
        this.rssi = rssi;
        this.expectedDistance = expectedDistance;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {-55, -55, 1},
                {-55, -58, 1.414}
        });
    }

    @Test
    public void testBeaconDistanceCalculator() {
        final DistanceCalculator distanceCalculator = new BeaconDistanceCalculator();
        assertEquals(
                expectedDistance,
                distanceCalculator.calculateDistance(txPower, rssi),
                DELTA
        );
    }
}
