package com.epam.beacons.distance;

import com.epam.beacons.Beacon;
import com.epam.beacons.Measurement;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class BeaconDistanceCalibratorTest {
    private static final double DELTA = 0.001;

    private final List<Measurement> measurements;
    private final List<Measurement> nextMeasurements;
    private final List<Measurement> prevMeasurements;
    private final double            expectedDistance;

    private final Beacon beacon;

    @Mock
    private DistanceCalculator       distanceCalculator;
    @InjectMocks
    private BeaconDistanceCalibrator beaconDistanceCalibrator;

    public BeaconDistanceCalibratorTest(Beacon beacon,
                                        List<Measurement> measurements,
                                        List<Measurement> nextMeasurements,
                                        List<Measurement> prevMeasurements,
                                        double expectedDistance) {
        this.beacon = beacon;
        this.measurements = measurements;
        this.nextMeasurements = nextMeasurements;
        this.prevMeasurements = prevMeasurements;
        this.expectedDistance = expectedDistance;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        new Beacon("uuid", 1, 1, -50.0, -80),
                        Arrays.asList(
                                new Measurement(-80, 10, 1),
                                new Measurement(-80, 11, 2),
                                new Measurement(-80, 12, 3),
                                new Measurement(-80, 10, 4),
                                new Measurement(-80, 11, 5),
                                new Measurement(-80, 12, 6),
                                new Measurement(-80, 10, 7),
                                new Measurement(-80, 11, 8),
                                new Measurement(-80, 12, 9),
                                new Measurement(-80, 10, 10),
                                new Measurement(-80, 11, 10),
                                new Measurement(-80, 12, 10)
                        ),
                        Arrays.asList(
                                new Measurement(-81, 10, 1),
                                new Measurement(-81, 11, 2),
                                new Measurement(-81, 12, 3)
                        ),
                        Arrays.asList(
                                new Measurement(-79, 10, 1),
                                new Measurement(-79, 11, 2),
                                new Measurement(-79, 12, 3)
                        ),
                        10.969
                },
                {
                        new Beacon("uuid", 1, 1, -50.0, -80),
                        Arrays.asList(
                                new Measurement(-80, 10, 1),
                                new Measurement(-80, 11, 2),
                                new Measurement(-80, 12, 3)
                        ),
                        Arrays.asList(
                                new Measurement(-81, 10, 1),
                                new Measurement(-81, 11, 2),
                                new Measurement(-81, 11, 3)
                        ),
                        Arrays.asList(
                                new Measurement(-79, 10, 1),
                                new Measurement(-79, 11, 2),
                                new Measurement(-79, 12, 3)
                        ),
                        0d
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(distanceCalculator.calculateDistance(anyDouble(), anyDouble())).thenReturn(0d);
    }

    @Test
    public void testCalibrateDistance() {
        assertEquals(
                expectedDistance,
                beaconDistanceCalibrator.calibrateDistance(beacon, measurements, nextMeasurements, prevMeasurements),
                DELTA
        );
    }
}
