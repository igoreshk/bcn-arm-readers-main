package com.epam.beacons.distance;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class BeaconDistanceCalculator implements DistanceCalculator {

    private static final double COEFF1 = 10;
    private static final double COEFF2 = 0.89976;
    private static final double COEFF3 = 7.7095;
    private static final double COEFF4 = 0.111;

    @Inject
    public BeaconDistanceCalculator() { // default constructor for dagger
    }

    @Override
    /* This algorithm was determined experimentally, we use it as is */
    public double calculateDistance(double txPower, double rssi) {
        if (Double.compare(txPower, 0) == 0) {
            throw new IllegalStateException("TxPower can not be zero");
        }
        final double ratio = rssi * 1.0 / txPower;
        if (Double.compare(ratio, 1) < 0) {
            return Math.pow(ratio, COEFF1);
        } else {
            return COEFF2 * Math.pow(ratio, COEFF3) + COEFF4;
        }
    }
}
