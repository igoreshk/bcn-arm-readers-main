package com.epam.beacons.distance;

public interface DistanceCalculator {
    double calculateDistance(double referenceSignal, double currentSignal);
}
