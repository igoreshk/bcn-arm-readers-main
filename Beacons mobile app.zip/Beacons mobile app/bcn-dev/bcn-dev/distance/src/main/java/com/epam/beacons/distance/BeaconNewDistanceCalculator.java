package com.epam.beacons.distance;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class BeaconNewDistanceCalculator implements DistanceCalculator {

    private static final double COEFF1 = 10;
    private static final double COEFF2 = 20;

    @Inject
    BeaconNewDistanceCalculator() { // default constructor for dagger
    }

    @Override
    public double calculateDistance(double txPower, double rssi) {
        if (Double.compare(txPower, 0) == 0) {
            throw new IllegalStateException("TxPower can not be zero");
        }
        final double ratio = rssi * 1.0 / txPower;
        if (Double.compare(ratio, 1) < 0) {
            return Math.pow(ratio, COEFF1);
        } else {
            return Math.pow(COEFF1, (txPower - rssi) / COEFF2);
        }
    }
}
