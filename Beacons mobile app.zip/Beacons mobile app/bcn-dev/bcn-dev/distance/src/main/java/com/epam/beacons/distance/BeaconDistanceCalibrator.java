package com.epam.beacons.distance;

import androidx.annotation.NonNull;

import com.epam.beacons.Beacon;
import com.epam.beacons.Measurement;

import java.util.List;

import javax.inject.Inject;

public class BeaconDistanceCalibrator {
    private static final int COEFF1 = 10;
    private static final int COEFF2 = 20;
    @NonNull
    private final DistanceCalculator distanceCalculator;

    @Inject
    BeaconDistanceCalibrator(@NonNull DistanceCalculator distanceCalculator) {
        this.distanceCalculator = distanceCalculator;
    }

    public double calibrateDistance(@NonNull Beacon beacon,
                                    @NonNull List<Measurement> measurements,
                                    @NonNull List<Measurement> nextMeasurements,
                                    @NonNull List<Measurement> prevMeasurements) {
        double distanceFromMeasurements = calcDistanceFromMeasurements(beacon, measurements, nextMeasurements, prevMeasurements);

        if (distanceFromMeasurements > 0) {
            return distanceFromMeasurements;
        } else {
            return distanceCalculator.calculateDistance(beacon.getTxPower(), beacon.getRssi());
        }
    }

    private double calcDistanceFromMeasurements(@NonNull Beacon beacon,
                                                @NonNull List<Measurement> measurements,
                                                @NonNull List<Measurement> nextMeasurements,
                                                @NonNull List<Measurement> prevMeasurements) {
        double multDist = 1;
        double sumSignal = 0;
        int commonSize = measurements.size() + nextMeasurements.size() + prevMeasurements.size();

        if (measurements.size() < 10) {
            return -1;
        }

        for (Measurement measurement : measurements) {
            multDist *= Math.pow(measurement.getDistance(), 1.0 / commonSize);
            sumSignal += measurement.getRssi();
        }

        for (Measurement measurement : nextMeasurements) {
            multDist *= Math.pow(measurement.getDistance(), 1.0 / commonSize);
            sumSignal += measurement.getRssi();
        }

        for (Measurement measurement : prevMeasurements) {
            multDist *= Math.pow(measurement.getDistance(), 1.0 / commonSize);
            sumSignal += measurement.getRssi();
        }

        return multDist * Math.pow(COEFF1, (beacon.getRssi() - sumSignal / commonSize) / COEFF2);
    }
}