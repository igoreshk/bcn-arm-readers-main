package com.epam.beacons.notification;

import android.app.NotificationManager;
import android.content.Context;

import com.epam.beacons.IntentData;
import com.epam.beacons.Notification;
import com.epam.beacons.notification.utils.IntentMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(RobolectricTestRunner.class)
@Config(manifest = Config.NONE)
public class NotificationCenterTest {
    @Mock
    private NotificationManager manager;
    @Mock
    private Context             context;
    @Mock
    private IconProvider        iconProvider;
    @Mock
    private IntentMapper        intentMapper;

    private Notification             notification;
    private NotificationCompatCenter notificationCompatCenter;
    private IntentData               intentData;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        intentData = new IntentData("", IntentData.ActionType.SHARE_SAVED_FILE, IntentData.IntentType.ACTIVITY);

        notification = new Notification.Builder(Notification.ImageType.FILE_DOWNLOAD)
                .setId(2)
                .setTitle("title")
                .setText("text")
                .setChannelId("channelId")
                .setLargeIcon(Notification.ImageType.LAUNCHER_ROUND)
                .setIntentData(intentData)
                .build();
        when(context.getSystemService(Context.NOTIFICATION_SERVICE)).thenReturn(manager);
        notificationCompatCenter = new NotificationCompatCenter(context, intentMapper, iconProvider);
    }

    @Test
    public void testNotify() {
        notificationCompatCenter.showNotification(notification);
        verify(manager).notify(eq(2), any());
        verify(intentMapper).map(intentData);
    }

    @Test
    public void testDismiss() {
        notificationCompatCenter.dismiss(notification.getId());
        verify(manager).cancel(2);
    }
}