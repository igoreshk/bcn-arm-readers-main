package com.epam.beacons.notification;

import com.epam.beacons.Notification;

import javax.inject.Inject;

public class IconProvider {

    @Inject
    IconProvider() {
    }

    public int map(Notification.ImageType imageType) {
        switch (imageType) {
            case FILE_DOWNLOAD:
                return R.drawable.ic_file_download;
            case LAUNCHER_ROUND:
                return R.mipmap.ic_launcher_round;
            default:
                throw new IllegalArgumentException("Wrong type of image");
        }
    }
}
