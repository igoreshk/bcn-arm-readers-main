package com.epam.beacons.notification;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.BitmapFactory;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.epam.beacons.Notification;
import com.epam.beacons.notification.utils.IntentMapper;
import com.epam.beacons.utils.AppUtils;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class NotificationCompatCenter implements NotificationCenter {

    private static final String CHANNEL_NAME = "Beacons";
    @NonNull
    private final Context             context;
    @NonNull
    private final NotificationManager manager;
    @NonNull
    private final IntentMapper        intentMapper;
    @NonNull
    private final IconProvider        iconProvider;

    @Inject
    NotificationCompatCenter(@NonNull Context context, @NonNull IntentMapper mapper, @NonNull IconProvider iconProvider) {
        this.context = context;
        this.intentMapper = mapper;
        this.iconProvider = iconProvider;
        //noinspection ConstantConditions
        this.manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
    }

    @Override
    public void showNotification(@NonNull Notification notification) {
        final NotificationCompat.Builder builder =
                new NotificationCompat.Builder(context, notification.getChannelId())
                        .setSmallIcon(iconProvider.map(notification.getSmallIcon()))
                        .setContentTitle(notification.getTitle())
                        .setContentText(notification.getText())
                        .setLargeIcon(BitmapFactory.decodeResource(context.getResources(), iconProvider.map(notification.getLargeIcon())))
                        .setAutoCancel(true);
        if (notification.getIntentData() != null) {
            builder.setContentIntent(intentMapper.map(notification.getIntentData()));
        }

        if (AppUtils.isO()) {
            manager.createNotificationChannel(new NotificationChannel(notification.getChannelId(), CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH));
        }

        manager.notify(notification.getId(), builder.build());
    }

    @Override
    public void dismiss(int notificationId) {
        manager.cancel(notificationId);
    }
}
