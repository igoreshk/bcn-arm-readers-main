package com.epam.beacons.notification.utils

import android.app.PendingIntent
import android.content.Context
import com.epam.beacons.IntentData
import com.epam.beacons.IntentData.ActionType
import com.epam.beacons.IntentData.IntentType
import com.epam.beacons.tools.Mapper
import com.epam.beacons.utils.IntentFactory
import com.epam.beacons.utils.UriHelper
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class IntentMapper @Inject constructor(private val context: Context, private val uriHelper: UriHelper) : Mapper<IntentData, PendingIntent>() {

    @Suppress("UnsafeCallOnNullableType")
    override fun map(from: IntentData): PendingIntent {
        val intent = when (from.actionType) {
            ActionType.SHARE_SAVED_FILE -> IntentFactory.getShareFileIntent(uriHelper.getPathFromFile(from.extraString!!))
        }
        return when (from.intentType) {
            IntentType.ACTIVITY -> PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT)
            IntentType.BROADCAST_RECEIVER -> PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT)
            IntentType.SERVICE -> PendingIntent.getService(context, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT)
        }
    }
}
