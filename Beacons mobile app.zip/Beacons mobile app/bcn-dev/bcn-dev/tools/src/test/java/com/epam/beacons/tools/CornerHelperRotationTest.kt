package com.epam.beacons.tools

import com.epam.beacons.Coordinate
import com.epam.beacons.tools.KotlinMockito.anyNonNull
import com.epam.beacons.tools.KotlinMockito.whn
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.ScaleFactorCalculator
import junit.framework.TestCase.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.Parameterized
import org.mockito.Mock
import org.mockito.MockitoAnnotations

@RunWith(Parameterized::class)
class CornerHelperRotationTest(private val a: Coordinate, private val b: Coordinate, private val expectedRotation: Float) {
    @Mock
    private lateinit var scaleFactorCalculator: ScaleFactorCalculator
    @Mock
    private lateinit var distanceCalculator: CoordinateDistanceCalculator

    private lateinit var cornerHelper: CornerHelper

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)

        cornerHelper = CornerHelper(scaleFactorCalculator, distanceCalculator, 1)

        whn(scaleFactorCalculator.cornerScaleCoef).thenReturn(1.0)
        whn(distanceCalculator.calcDistance(anyNonNull(), anyNonNull())).thenReturn(1.0)
    }

    companion object {
        @JvmStatic
        @Parameterized.Parameters
        fun initializeParameters(): List<Array<Any>> {
            return listOf(
                    arrayOf(
                            Coordinate(10.0, 15.0), Coordinate(10.0, 20.0), 90f
                    ),
                    arrayOf(
                            Coordinate(10.0, 20.0), Coordinate(10.0, 15.0), -90f
                    ),
                    arrayOf(
                            Coordinate(10.0, 20.0), Coordinate(5.0, 20.0), 180f
                    ),
                    arrayOf(
                            Coordinate(5.0, 20.0), Coordinate(10.0, 20.0), 0f
                    ),
                    arrayOf(
                            Coordinate(-2.0, 10.0), Coordinate(6.0, 2.0), -45f
                    ),
                    arrayOf(
                            Coordinate(6.0, 2.0), Coordinate(-2.0, 10.0), 135f
                    ),
                    arrayOf(
                            Coordinate(-2.0, 2.0), Coordinate(6.0, 10.0), 45f
                    ),
                    arrayOf(
                            Coordinate(6.0, 10.0), Coordinate(-2.0, 2.0), -135f
                    ),
                    arrayOf(
                            Coordinate(0.0, 0.0), Coordinate(0.0, 0.0), 0f
                    ),
                    arrayOf(
                            Coordinate(MAX_VALUE, MIN_VALUE), Coordinate(MIN_VALUE, MAX_VALUE), 135f
                    ),
                    arrayOf(
                            Coordinate(MIN_VALUE, MAX_VALUE), Coordinate(MAX_VALUE, MIN_VALUE), -45f
                    ),
                    arrayOf(
                            Coordinate(POS_INF, POS_INF), Coordinate(NEG_INF, NEG_INF), -135f
                    ),
                    arrayOf(
                            Coordinate(NEG_INF, NEG_INF), Coordinate(POS_INF, POS_INF), 45f
                    )
            )
        }

        private val MAX_VALUE = Double.MAX_VALUE
        private val MIN_VALUE = Double.MIN_VALUE
        private val POS_INF = Double.POSITIVE_INFINITY
        private val NEG_INF = Double.NEGATIVE_INFINITY
    }

    @Test
    fun rotationTest() {
        cornerHelper.prepareData(listOf(a, b), Coordinate(1.0, 1.0))

        assertEquals(expectedRotation, cornerHelper.rotation)
    }
}
