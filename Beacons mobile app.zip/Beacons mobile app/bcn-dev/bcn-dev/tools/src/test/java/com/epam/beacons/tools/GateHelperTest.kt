package com.epam.beacons.tools

import com.epam.beacons.Coordinate
import com.epam.beacons.Gate
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import io.reactivex.functions.BiFunction
import org.hamcrest.CoreMatchers.`is`
import org.hamcrest.MatcherAssert.assertThat
import org.junit.Test

class GateHelperTest {

    private val gateHelper = GateHelper(CoordinateDistanceCalculator())

    private val userCoordinate = Coordinate(5.0, 5.0)
    private val destinationPlaceCoordinate = Coordinate(100.0, 100.0)

    private val boundOneAndTwo = mapOf(
            1 to Coordinate(1.0, 1.0),
            2 to Coordinate(2.0, 2.0)
    )

    private val boundTwoAndThree = mapOf(
            2 to Coordinate(3.0, 3.0),
            3 to Coordinate(4.0, 4.0)
    )

    private val gates = listOf(
            Gate(1, BUILDING_ID, EMPTY_IMG, GATE_TYPE, boundOneAndTwo),
            Gate(2, BUILDING_ID, EMPTY_IMG, GATE_TYPE, boundTwoAndThree)
    )

    @Test
    fun `Start and destination on the same floor`() {
        gateHelper.prepare(gates, destinationPlaceCoordinate, FLOOR_ONE, FLOOR_ONE)
        gateHelper.gatesPath(FLOOR_ONE, userCoordinate, destinationPlaceCoordinate)
                .test()
                .assertValue { it.first == userCoordinate && it.second == destinationPlaceCoordinate }
                .assertComplete()

        assertThat(gateHelper.prepared, `is`(true))
    }

    @Test
    fun `Path for floor but result for other floor`() {
        gateHelper.prepare(gates, destinationPlaceCoordinate, FLOOR_ONE, FLOOR_ONE)

        gateHelper.gatesPath(FLOOR_TWO, userCoordinate, destinationPlaceCoordinate)
                .test()
                .assertNoValues()
                .assertComplete()

        gateHelper.gatesPath(FLOOR_THREE, userCoordinate, destinationPlaceCoordinate)
                .test()
                .assertNoValues()
                .assertComplete()

        assertThat(gateHelper.prepared, `is`(true))
    }

    @Test
    fun `If user location not found returns no values`() {
        gateHelper.prepare(gates, destinationPlaceCoordinate, FLOOR_TWO, FLOOR_ONE)

        gateHelper.gatesPath(FLOOR_ONE, null, destinationPlaceCoordinate)
                .test()
                .assertNoValues()
                .assertComplete()
    }

    @Test
    fun `Direct gates between floor 1 and 2`() {
        gateHelper.prepare(gates, destinationPlaceCoordinate, FLOOR_TWO, FLOOR_ONE)

        gateHelper.gatesPath(FLOOR_ONE, userCoordinate, destinationPlaceCoordinate)
                .test()
                .assertValue { it.first == userCoordinate && it.second == boundOneAndTwo[1] }
                .assertComplete()

        gateHelper.gatesPath(FLOOR_TWO, null, destinationPlaceCoordinate)
                .test()
                .assertValue { it.first == boundOneAndTwo[2] && it.second == destinationPlaceCoordinate }
                .assertComplete()
    }

    @Test
    fun `Indirect path between floors 1,2,3`() {
        gateHelper.prepare(gates, destinationPlaceCoordinate, FLOOR_THREE, FLOOR_ONE)

        gateHelper.gatesPath(FLOOR_ONE, userCoordinate, destinationPlaceCoordinate)
                .test()
                .assertValue { it.first == userCoordinate && it.second == boundOneAndTwo[1] }
                .assertComplete()

        gateHelper.gatesPath(FLOOR_TWO, null, destinationPlaceCoordinate)
                .test()
                .assertValue { it.first == boundOneAndTwo[2] && it.second == boundTwoAndThree[2] }
                .assertComplete()

        gateHelper.gatesPath(FLOOR_THREE, null, destinationPlaceCoordinate)
                .test()
                .assertValue { it.first == boundTwoAndThree[3] && it.second == destinationPlaceCoordinate }
                .assertComplete()
    }

    @Test
    fun `Indirect path between floors 3,2,1`() {
        gateHelper.prepare(gates, destinationPlaceCoordinate, FLOOR_ONE, FLOOR_THREE)

        gateHelper.gatesPath(FLOOR_THREE, userCoordinate, destinationPlaceCoordinate)
                .test()
                .assertValue { it.first == userCoordinate && it.second == boundTwoAndThree[3] }
                .assertComplete()

        gateHelper.gatesPath(FLOOR_TWO, null, destinationPlaceCoordinate)
                .test()
                .assertValue { it.first == boundTwoAndThree[2] && it.second == boundOneAndTwo[2] }
                .assertComplete()

        gateHelper.gatesPath(FLOOR_ONE, null, destinationPlaceCoordinate)
                .test()
                .assertValue { it.first == boundOneAndTwo[1] && it.second == destinationPlaceCoordinate }
                .assertComplete()
    }

    @Test
    fun `When user comes to next floor his coord is prioritized`() {
        gateHelper.prepare(gates, destinationPlaceCoordinate, FLOOR_TWO, FLOOR_ONE)

        gateHelper.prepare(gates, destinationPlaceCoordinate, FLOOR_THREE, FLOOR_ONE)

        gateHelper.gatesPath(FLOOR_TWO, null, destinationPlaceCoordinate)
                .test()
                .assertValue { it.first == boundOneAndTwo[2] && it.second == boundTwoAndThree[2] }
                .assertComplete()

        gateHelper.gatesPath(FLOOR_TWO, userCoordinate, destinationPlaceCoordinate)
                .test()
                .assertValue { it.first == userCoordinate && it.second == boundTwoAndThree[2] }
                .assertComplete()
    }

    @Test(expected = UnsupportedOperationException::class)
    fun `Throws exception if path can't be build`() {
        gateHelper.prepare(gates, destinationPlaceCoordinate, FLOOR_TEN, FLOOR_ONE)
    }

    @Test
    fun `Just created GateHelper is not prepared`() {
        assertThat(gateHelper.prepared, `is`(false))
    }

    @Test
    fun `Test clear gate helper changes state`() {
        gateHelper.prepare(gates, destinationPlaceCoordinate, FLOOR_ONE, FLOOR_ONE)

        gateHelper.clear()
                .test()
                .assertComplete()

        assertThat(gateHelper.prepared, `is`(false))
    }

    @Test
    fun `Test clear gate helper clears gate map`() {
        gateHelper.prepare(gates, destinationPlaceCoordinate, FLOOR_ONE, FLOOR_ONE)

        gateHelper.gatesPath(FLOOR_ONE, userCoordinate, destinationPlaceCoordinate)
                .test()
                .assertValueCount(1)
                .assertComplete()

        gateHelper.gatesPath(FLOOR_ONE, userCoordinate, destinationPlaceCoordinate)
                .zipWith(gateHelper.clear().toMaybe(),
                        BiFunction { _: Any, t2: Coordinate -> t2 })
                .test()
                .assertNoValues()
                .assertComplete()
    }

    companion object {
        private const val BUILDING_ID = 1L
        private const val EMPTY_IMG = ""
        private const val GATE_TYPE = "Elevator"

        private const val FLOOR_ONE = 1
        private const val FLOOR_TWO = 2
        private const val FLOOR_THREE = 3
        private const val FLOOR_TEN = 10
    }
}
