package com.epam.beacons.tools

import org.mockito.Mockito
import org.mockito.stubbing.OngoingStubbing

object KotlinMockito {

    /**
     * Wrapper method just to simplify calling from kotlin
     */
    fun <T> whn(methodCall: T): OngoingStubbing<T> = Mockito.`when`(methodCall)

    /**
     * Wrapper to make `any()` null-safe
     */
    fun <T> anyNonNull(): T = Mockito.any<T>()
}
