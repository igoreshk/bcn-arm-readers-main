package com.epam.beacons.tools

import com.epam.beacons.Coordinate
import com.epam.beacons.tools.CornerHelper.Corner
import com.epam.beacons.tools.CornerHelper.DestOrientation
import com.epam.beacons.tools.KotlinMockito.anyNonNull
import com.epam.beacons.tools.KotlinMockito.whn
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.ScaleFactorCalculator
import junit.framework.TestCase.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.MockitoAnnotations
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class CornerHelperTest {
    @Mock
    private lateinit var scaleFactorCalculator: ScaleFactorCalculator
    @Mock
    private lateinit var distanceCalculator: CoordinateDistanceCalculator

    private lateinit var cornerHelper: CornerHelper

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)

        cornerHelper = CornerHelper(scaleFactorCalculator, distanceCalculator, 1)

        whn(scaleFactorCalculator.cornerScaleCoef).thenReturn(1.0)
        whn(distanceCalculator.calcDistance(anyNonNull(), anyNonNull())).thenCallRealMethod()
    }

    @Test
    fun testRouteFourDots() {
        val route = listOf(Coordinate(-2.0, -2.0), Coordinate(0.0, 2.0),
                Coordinate(1.0, 2.0), Coordinate(2.0, 0.0))
        val destination = Coordinate(3.0, 1.0)
        val expectedCorners = mutableListOf(4 to Corner.LEFT, 1 to Corner.LEFT, 2 to Corner.PLACE)

        cornerHelper.prepareData(route, destination)

        assertEquals(expectedCorners, cornerHelper.corners)
        assertEquals(DestOrientation.RIGHT, cornerHelper.destOrientation)
        assertEquals(8, cornerHelper.routeDistance)
    }

    @Test
    fun testRouteFourDotsStraight() {
        val route = listOf(Coordinate(1.0, 1.0), Coordinate(3.0, 1.0),
                Coordinate(4.0, 0.5), Coordinate(6.0, 1.0))
        val destination = Coordinate(8.0, 1.0)
        val expectedCorners = mutableListOf(5 to Corner.PLACE)

        cornerHelper.prepareData(route, destination)

        assertEquals(expectedCorners, cornerHelper.corners)
        assertEquals(DestOrientation.FORWARD, cornerHelper.destOrientation)
        assertEquals(5, cornerHelper.routeDistance)
    }

    @Test
    fun testRouteFiveDots() {
        val route = listOf(Coordinate(4.0, 4.0), Coordinate(3.0, 3.0),
                Coordinate(2.0, 2.0), Coordinate(3.0, 1.0), Coordinate(1.0, -2.0))
        val destination = Coordinate(-2.0, 0.0)
        val expectedCorners = listOf(3 to Corner.RIGHT, 1 to Corner.LEFT, 4 to Corner.PLACE)

        cornerHelper.prepareData(route, destination)

        assertEquals(expectedCorners, cornerHelper.corners)
        assertEquals(DestOrientation.LEFT, cornerHelper.destOrientation)
        assertEquals(8, cornerHelper.routeDistance)
    }

    @Test
    fun testRouteThreeDots() {
        val route = listOf(Coordinate(1.0, 1.0), Coordinate(3.0, 1.0), Coordinate(4.0, -2.0))
        val destination = Coordinate(5.0, 1.0)
        val expectedCorners = listOf(2 to Corner.LEFT, 3 to Corner.PLACE)

        cornerHelper.prepareData(route, destination)

        assertEquals(expectedCorners, cornerHelper.corners)
        assertEquals(DestOrientation.RIGHT, cornerHelper.destOrientation)
        assertEquals(5, cornerHelper.routeDistance)
    }

    @Test
    fun testRouteThreeDotsStraight() {
        val route = listOf(Coordinate(1.0, 6.0), Coordinate(2.0, 4.0), Coordinate(4.0, 1.0))
        val destination = Coordinate(6.0, -1.0)
        val expectedCorners = listOf(6 to Corner.PLACE)

        cornerHelper.prepareData(route, destination)

        assertEquals(expectedCorners, cornerHelper.corners)
        assertEquals(DestOrientation.FORWARD, cornerHelper.destOrientation)
        assertEquals(6, cornerHelper.routeDistance)
    }

    @Test
    fun testRouteTwoDots() {
        val route = listOf(Coordinate(0.0, 0.0), Coordinate(3.0, 3.0))
        val destination = Coordinate(4.0, 2.0)
        val expectedCorners = listOf(4 to Corner.PLACE)

        cornerHelper.prepareData(route, destination)

        assertEquals(expectedCorners, cornerHelper.corners)
        assertEquals(DestOrientation.LEFT, cornerHelper.destOrientation)
        assertEquals(4, cornerHelper.routeDistance)
    }

    @Test
    fun scalingDownTest() {
        whn(scaleFactorCalculator.cornerScaleCoef).thenReturn(0.5)

        cornerHelper = CornerHelper(scaleFactorCalculator, distanceCalculator, METER_AT_EQUATOR)

        val route = listOf(Coordinate(1.0e-5, 1.0e-5), Coordinate(3.0e-5, 3.0e-5))
        val destination = Coordinate(4.0e-5, 2.0e-5)

        cornerHelper.prepareData(route, destination)

        assertEquals(2, cornerHelper.routeDistance)
    }

    @Test
    fun scalingUpTest() {
        whn(scaleFactorCalculator.cornerScaleCoef).thenReturn(5.0)

        cornerHelper = CornerHelper(scaleFactorCalculator, distanceCalculator, METER_AT_EQUATOR)

        val route = listOf(Coordinate(1.0e-5, 1.0e-5), Coordinate(3.0e-5, 3.0e-5))
        val destination = Coordinate(4.0e-5, 2.0e-5)

        cornerHelper.prepareData(route, destination)

        assertEquals(16, cornerHelper.routeDistance)
    }

    @Test
    fun testBrokenRoute() {
        val route = listOf(Coordinate(3.0, 0.0))
        val destination = Coordinate(4.0, 2.0)

        cornerHelper.prepareData(route, destination)

        assertEquals(emptyList<Pair<Int, Corner>>(), cornerHelper.corners)
        assertEquals(DestOrientation.NONE, cornerHelper.destOrientation)
        assertEquals(0, cornerHelper.routeDistance)
        assertEquals(0f, cornerHelper.rotation)
    }

    @Test
    fun testClearDataInternal() {
        val route = listOf(Coordinate(0.0, 0.0), Coordinate(3.0, 3.0))
        val destination = Coordinate(4.0, 2.0)
        cornerHelper.prepareData(route, destination)

        cornerHelper.prepareData(listOf(Coordinate(3.0, 0.0)), destination)

        assertEquals(emptyList<Pair<Int, Corner>>(), cornerHelper.corners)
        assertEquals(DestOrientation.NONE, cornerHelper.destOrientation)
        assertEquals(0, cornerHelper.routeDistance)
        assertEquals(0f, cornerHelper.rotation)
    }

    @Test
    fun testClearData() {
        val route = listOf(Coordinate(1.0, 6.0), Coordinate(2.0, 4.0), Coordinate(4.0, 1.0))
        val destination = Coordinate(6.0, -1.0)
        cornerHelper.prepareData(route, destination)

        cornerHelper.clear()
                .test()
                .assertOf {
                    assertEquals(emptyList<Pair<Int, Corner>>(), cornerHelper.corners)
                    assertEquals(DestOrientation.NONE, cornerHelper.destOrientation)
                    assertEquals(0, cornerHelper.routeDistance)
                    assertEquals(0f, cornerHelper.rotation)
                }
    }

    companion object {
        private const val METER_AT_EQUATOR = 113200
    }
}
