package com.epam.beacons.tools.utils;

import androidx.annotation.NonNull;

import com.epam.beacons.Coordinate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;

import static junit.framework.TestCase.assertEquals;
import static org.junit.runners.Parameterized.Parameters;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class ScaleFactorCalculatorTest {
    private static final double DELTA                = 1e-6;
    private static final int    ONE_METER_AT_EQUATOR = 111320;
    @Mock
    private CoordinateDistanceCalculator coordinateDistanceCalculator;

    private ScaleFactorCalculator scaleFactorCalculator;

    private double realWidth;
    private double realHeight;
    private double expectedScaleCoef;
    private double expectedCornerScaleCoef;
    @NonNull
    private Coordinate overlaySouthWestBound = new Coordinate(-0.0001, -0.0001);
    @NonNull
    private Coordinate overlayNorthEastBound = new Coordinate(0.0001, 0.0001);

    public ScaleFactorCalculatorTest(double realWidth, double realHeight, double expectedScaleCoef, double expectedCornerScaleCoef) {
        this.realWidth = realWidth;
        this.realHeight = realHeight;
        this.expectedScaleCoef = expectedScaleCoef;
        this.expectedCornerScaleCoef = expectedCornerScaleCoef;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        11.132, 11.132, 2, 0.499999
                },
                {
                        111.32, 111.32, 0.2, 5.0
                },
                {
                        22.264, 22.264, 1, 0.999999
                },
                {
                        0.11132, 0.11132, 200, 0.005
                },
                {
                        Double.MAX_VALUE, Double.MAX_VALUE, 0, Double.POSITIVE_INFINITY
                },
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        scaleFactorCalculator = new ScaleFactorCalculator(coordinateDistanceCalculator, ONE_METER_AT_EQUATOR);

        when(coordinateDistanceCalculator.calcDistance(overlaySouthWestBound, overlayNorthEastBound))
                .thenReturn(2.82842712474619E-4);
    }

    @Test
    public void testScaleCoefficient() {
        scaleFactorCalculator.setScaleCoef(realWidth, realHeight, overlaySouthWestBound, overlayNorthEastBound);

        assertEquals(expectedScaleCoef, scaleFactorCalculator.getScaleCoef(), DELTA);

        assertEquals(expectedCornerScaleCoef, scaleFactorCalculator.getCornerScaleCoef(), DELTA);
    }
}
