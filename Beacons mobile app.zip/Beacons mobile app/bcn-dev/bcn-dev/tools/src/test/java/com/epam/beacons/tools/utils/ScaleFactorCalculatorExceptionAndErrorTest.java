package com.epam.beacons.tools.utils;

import androidx.annotation.NonNull;

import com.epam.beacons.Coordinate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import static junit.framework.TestCase.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class ScaleFactorCalculatorExceptionAndErrorTest {
    private static final int ONE_METER_AT_EQUATOR = 111320;
    @Mock
    private CoordinateDistanceCalculator coordinateDistanceCalculator;

    private ScaleFactorCalculator scaleFactorCalculator;
    @NonNull
    private Coordinate overlaySouthWestBound = new Coordinate(-0.0001, -0.0001);
    @NonNull
    private Coordinate overlayNorthEastBound = new Coordinate(0.0001, 0.0001);

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        scaleFactorCalculator = new ScaleFactorCalculator(coordinateDistanceCalculator, ONE_METER_AT_EQUATOR);
    }

    @Test(expected = IllegalStateException.class)
    public void testWidthAndHeightNegativeValues() {

        scaleFactorCalculator.setScaleCoef(-100, -50, overlaySouthWestBound, overlayNorthEastBound);
    }

    @Test(expected = IllegalStateException.class)
    public void testWidthAndHeightAreZero() {

        scaleFactorCalculator.setScaleCoef(0, 0, overlaySouthWestBound, overlayNorthEastBound);
    }

    @Test
    public void testCoordinatesAreNull() {
        scaleFactorCalculator.setScaleCoef(2, 2, null, null);

        assertEquals(0d, scaleFactorCalculator.getScaleCoef());
    }

    @Test
    public void testOneCoordinateIsNull() {
        scaleFactorCalculator.setScaleCoef(2, 2, overlaySouthWestBound, null);

        assertEquals(0d, scaleFactorCalculator.getScaleCoef());
    }
}
