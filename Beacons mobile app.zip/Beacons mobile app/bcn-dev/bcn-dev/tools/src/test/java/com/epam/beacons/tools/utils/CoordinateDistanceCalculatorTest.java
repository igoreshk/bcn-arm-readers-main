package com.epam.beacons.tools.utils;

import androidx.annotation.NonNull;

import com.epam.beacons.Coordinate;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;

import static junit.framework.TestCase.assertEquals;

@RunWith(Parameterized.class)
public class CoordinateDistanceCalculatorTest {
    private static final double DELTA = 1e-4;
    @NonNull
    private Coordinate overlaySouthWestBound;
    @NonNull
    private Coordinate overlayNorthEastBound;

    private double expectedValue;
    @NonNull
    private CoordinateDistanceCalculator coordinateDistanceCalculator = new CoordinateDistanceCalculator();

    public CoordinateDistanceCalculatorTest(@NonNull Coordinate overlaySouthWestBound,
                                            @NonNull Coordinate overlayNorthEastBound,
                                            double expectedValue) {
        this.overlaySouthWestBound = overlaySouthWestBound;
        this.overlayNorthEastBound = overlayNorthEastBound;
        this.expectedValue = expectedValue;
    }

    @Parameterized.Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        new Coordinate(-0.0001, -0.0001),
                        new Coordinate(0.0001, 0.0001),
                        0.00028
                },
                {
                        new Coordinate(-0.0001, -0.0001),
                        new Coordinate(-0.0001, -0.0001),
                        0
                },
                {
                        new Coordinate(-0.0001, -0.0001),
                        new Coordinate(-0.0002, -0.0002),
                        0.00014
                },
                {
                        new Coordinate(Double.MIN_VALUE, Double.MIN_VALUE),
                        new Coordinate(Double.MAX_VALUE, Double.MIN_VALUE),
                        Double.POSITIVE_INFINITY
                },
                {
                        new Coordinate(0, 0),
                        new Coordinate(1000, 1000),
                        1414.2135
                },
                {
                        new Coordinate(Double.MIN_VALUE, 0),
                        new Coordinate(0, Double.MIN_VALUE),
                        0
                }
        });
    }

    @Test
    public void coordinateDistanceCalculatorTest() {
        assertEquals(expectedValue, coordinateDistanceCalculator
                .calcDistance(overlaySouthWestBound, overlayNorthEastBound), DELTA);
    }
}
