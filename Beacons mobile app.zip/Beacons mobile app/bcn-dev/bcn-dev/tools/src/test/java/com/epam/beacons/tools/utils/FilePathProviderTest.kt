package com.epam.beacons.tools.utils

import junit.framework.TestCase.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.junit.MockitoJUnitRunner
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@RunWith(MockitoJUnitRunner::class)
class FilePathProviderTest {

    @Test
    fun filePathTest() {
        val locale = Locale.getDefault()
        val filePathProvider = FilePathProvider(locale)

        assertEquals(filePathProvider.filePath(),
                SimpleDateFormat(FilePathProvider.DATE_PATTERN, locale).format(Date()) + FilePathProvider.COMMON_FILE_NAME)
    }
}
