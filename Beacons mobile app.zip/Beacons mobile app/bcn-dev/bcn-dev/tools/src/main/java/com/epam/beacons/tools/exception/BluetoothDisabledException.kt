package com.epam.beacons.tools.exception

class BluetoothDisabledException : Exception()
