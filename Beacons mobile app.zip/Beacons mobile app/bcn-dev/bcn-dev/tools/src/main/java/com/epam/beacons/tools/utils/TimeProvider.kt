package com.epam.beacons.tools.utils

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TimeProvider @Inject constructor() {

    fun getCurrentSystemTime() = System.currentTimeMillis()
}
