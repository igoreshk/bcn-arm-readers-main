package com.epam.beacons.tools.utils

import javax.inject.Inject
import javax.inject.Singleton

/**
 * Provides error of measured data by outer sources.
 */
@Singleton
@Suppress("unused") // TODO: 4/4/2018 to be removed in EPMLSTRBCA-140
class ErrorProvider @Inject constructor() {
    /**
     * @return specific error value of calculated position by beacons signals
     */
    fun getPositionError() = 3.0 // TODO: 4/4/2018 to be implemented in EPMLSTRBCA-140

    /**
     * @return error of data measured by sensors
     */
    fun getAccelerometerError() = 0.1 // TODO: 4/4/2018 to be implemented in EPMLSTRBCA-140
}
