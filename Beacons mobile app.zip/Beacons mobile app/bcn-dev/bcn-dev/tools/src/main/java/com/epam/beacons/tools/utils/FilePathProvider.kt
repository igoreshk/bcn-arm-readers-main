package com.epam.beacons.tools.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FilePathProvider @Inject constructor(private val locale: Locale) {

    fun filePath() = SimpleDateFormat(DATE_PATTERN, locale).format(Date()) + COMMON_FILE_NAME

    companion object {
        const val COMMON_FILE_NAME = "_beacon_record.csv"
        const val DATE_PATTERN = "dd.MM_hh:mm"
    }
}
