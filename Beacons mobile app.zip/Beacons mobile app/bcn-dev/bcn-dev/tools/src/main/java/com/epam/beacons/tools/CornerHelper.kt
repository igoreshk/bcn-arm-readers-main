package com.epam.beacons.tools

import com.epam.beacons.Coordinate
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.ScaleFactorCalculator
import io.reactivex.Completable
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CornerHelper @Inject constructor(
        private val scaleFactorCalculator: ScaleFactorCalculator,
        private val distanceCalculator: CoordinateDistanceCalculator,
        private val oneMeterAtEquator: Int
) {

    var routeDistance: Int = 0
        private set
    var corners: MutableList<Pair<Int, Corner>> = mutableListOf()
        private set
    var destOrientation: DestOrientation = DestOrientation.NONE
        private set
    var rotation: Float = 0f
        private set
    private var distanceToTurningPoint = 0.0
    private var commonDistance = 0.0

    fun prepareData(route: List<Coordinate>, destination: Coordinate) {
        clearData()

        calcData(route, route.size, destination)

        if (route.size > 1) determineRotation(route[0], route[1])
    }

    fun clear(): Completable = Completable.fromAction { clearData() }

    private fun calcData(route: List<Coordinate>, size: Int, destination: Coordinate) {
        if (size <= 1) return

        if (size == 2) {
            routeDistance = scaledDistance(distanceCalculator.calcDistance(route[0], route[1]))
            corners.add(routeDistance to Corner.PLACE)

            determineDegrees(route[0], route[1], destination, false, true)
            return
        }

        if (size == 3) {
            determineDegrees(route[0], route[1], route[2], true, false)

            val lastSegment = distanceCalculator.calcDistance(route[1], route[2])
            handleLastSegment(lastSegment)

            determineDegrees(route[1], route[2], destination, false, true)
            return
        }

        for (i in 0 until size - 2) {
            determineDegrees(route[i], route[i + 1], route[i + 2], true, false)
        }

        val lastSegment = distanceCalculator.calcDistance(route[size - 2], route[size - 1])
        handleLastSegment(lastSegment)

        determineDegrees(route[size - 2], route[size - 1], destination, false, true)
    }

    private fun determineDegrees(a: Coordinate, b: Coordinate, c: Coordinate, needCorners: Boolean, needOrientation: Boolean) {
        val abx = b.latitude - a.latitude
        val aby = b.longitude - a.longitude
        val cbx = b.latitude - c.latitude
        val cby = b.longitude - c.longitude

        val dot = abx * cbx + aby * cby
        val cross = abx * cby - aby * cbx

        val alpha = Math.atan2(cross, dot)

        val result = Math.floor(Math.toDegrees(alpha) + ROUND_COEF).toInt()

        if (needOrientation) {
            destOrientation = when {
                Math.abs(result) > MAX_CORNER_DEGREE -> DestOrientation.FORWARD
                result <= 0 -> DestOrientation.RIGHT
                else -> DestOrientation.LEFT
            }
        }

        if (needCorners) {
            val abDistance = distanceCalculator.calcDistance(a, b)

            distanceToTurningPoint += abDistance
            commonDistance += abDistance

            if (Math.abs(result) < MAX_CORNER_DEGREE) {
                if (result <= 0) {
                    corners.add(scaledDistance(distanceToTurningPoint) to Corner.RIGHT)
                } else {
                    corners.add(scaledDistance(distanceToTurningPoint) to Corner.LEFT)
                }

                distanceToTurningPoint = 0.0
            }
        }
    }

    private fun determineRotation(a: Coordinate, b: Coordinate) {
        val alpha = Math.atan2(b.longitude - a.longitude, b.latitude - a.latitude)

        rotation = Math.toDegrees(alpha).toFloat()
    }

    private fun handleLastSegment(lastSegment: Double) {
        commonDistance += lastSegment
        routeDistance = scaledDistance(commonDistance)

        corners.add(scaledDistance(lastSegment + distanceToTurningPoint) to Corner.PLACE)
    }

    private fun scaledDistance(distance: Double) =
            Math.floor(distance * scaleFactorCalculator.cornerScaleCoef * oneMeterAtEquator + ROUND_COEF).toInt()

    private fun clearData() {
        routeDistance = 0
        corners = mutableListOf()
        destOrientation = DestOrientation.NONE
        distanceToTurningPoint = 0.0
        commonDistance = 0.0
        rotation = 0f
    }

    enum class Corner {
        LEFT,
        RIGHT,
        PLACE
    }

    enum class DestOrientation {
        LEFT,
        RIGHT,
        FORWARD,
        NONE
    }

    companion object {
        private const val ROUND_COEF = 0.5
        private const val MAX_CORNER_DEGREE = 120
    }
}
