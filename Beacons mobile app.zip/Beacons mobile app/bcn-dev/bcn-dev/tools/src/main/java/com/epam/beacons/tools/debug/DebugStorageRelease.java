package com.epam.beacons.tools.debug;

import androidx.annotation.NonNull;

import com.epam.beacons.Pivot;

import java.util.List;

import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Observable;

@Singleton
public class DebugStorageRelease implements DebugStorage {

    @NonNull
    @Override
    public Completable debugPivots(@NonNull List<Pivot> pivots) {
        return Completable.complete();
    }

    @NonNull
    @Override
    public Observable<List<Pivot>> getPivots() {
        return Observable.empty();
    }
}
