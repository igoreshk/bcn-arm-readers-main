package com.epam.beacons.tools

abstract class MapperWithBuildingId<in From, out To> {
    abstract fun map(buildingId: String, from: From): To

    fun map(buildingId: String, from: List<From>) = from.map { map(buildingId, it) }
}
