package com.epam.beacons.tools.utils;

import androidx.annotation.NonNull;

import com.epam.beacons.Coordinate;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class ScaleFactorCalculator {
    private double scaleCoef = 1;
    private double cornerScaleCoef = 1;
    @NonNull
    private final CoordinateDistanceCalculator coordinateDistanceCalculator;
    private final int                          oneMeterAtEquator;

    @Inject
    public ScaleFactorCalculator(@NonNull CoordinateDistanceCalculator coordinateDistanceCalculator,
                                 int oneMeterAtEquator) {
        this.coordinateDistanceCalculator = coordinateDistanceCalculator;
        this.oneMeterAtEquator = oneMeterAtEquator;
    }

    public double getScaleCoef() {
        return scaleCoef;
    }

    public double getCornerScaleCoef() {
        return cornerScaleCoef;
    }

    public void setScaleCoef(double distance, @NonNull Coordinate overlaySouthWestBound, @NonNull Coordinate overlayNorthEastBound) {
        if (distance > 0) {
            double inputHypot = coordinateDistanceCalculator.calcDistance(overlaySouthWestBound, overlayNorthEastBound)
                    * oneMeterAtEquator;
            scaleCoef = inputHypot / distance;
            cornerScaleCoef = distance / inputHypot;
        } else {
            throw new IllegalStateException("Width and height of floor can't equal zero or be negative");
        }
    }
}
