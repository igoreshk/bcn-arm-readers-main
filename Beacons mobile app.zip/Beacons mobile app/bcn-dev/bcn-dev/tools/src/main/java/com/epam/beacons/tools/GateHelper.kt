package com.epam.beacons.tools

import com.epam.beacons.Coordinate
import com.epam.beacons.Gate
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import io.reactivex.Completable
import io.reactivex.Maybe
import java.util.ArrayList
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GateHelper @Inject constructor(private val coordinateDistanceCalculator: CoordinateDistanceCalculator) {

    /**
     * <p>Map of gates to go on each floor.
     * First parameter of mutable map - floor number.
     * Second - pair of coordinates that represents from where to where user should go.
     *
     * If first coordinate is <code>null</code> it means that this pair represents current user floor and <code>null</code>
     * will be replaced with user coord in. Also if second coordinate is null it will be replaced with destination coord.
     * @see gatesPath - where nulls being replaced.
     * </p>
     */
    private var gateMap: MutableMap<Int, Pair<Coordinate?, Coordinate?>> = mutableMapOf()

    /**
     * Indicator for state of gateMap.
     * <code>true</code> if gateMap initialized and ready to use
     * <code>false</code> if gateMap is clear.
     */
    var prepared = false
        private set

    /**
     * Starts processing and switch state at the end.
     *
     * @param gates gates to process
     * @param end destination coordinate (place or marker on map)
     * @param toFloor destination floor number
     * @param fromFloor user floor number
     */
    fun prepare(gates: List<Gate>, end: Coordinate, toFloor: Int, fromFloor: Int) {
        process(gates, end, toFloor, fromFloor)
        prepared = true
    }

    /**
     * Calculates start and end coordinates for a specific floor.
     * Gets pair of coordinates for floor from gateMap and if one of coordinates is null
     * replaces it with user or destination coordinate to fill pairs.
     *
     * @param currentFloor as it is
     * @param start user coordinate
     * @param end destination coordinate
     *
     * @return Pair of coordinates for floor as a start and end coord for path.
     * If both coordinates in pair are null or pair is null itself returns null.
     */
    fun gatesPath(currentFloor: Int, start: Coordinate?, end: Coordinate): Maybe<Pair<Coordinate, Coordinate>> {
        val pair = gateMap[currentFloor]
        val realStartCoord = start ?: pair?.first
        val realEndCoord = pair?.second ?: end

        return if (pair == null || realStartCoord == null) {
            Maybe.empty()
        } else {
            Maybe.fromCallable { realStartCoord to realEndCoord }
        }
    }

    /**
     * Cleans data in GateHelper. Changes state.
     */
    fun clear(): Completable = Completable.fromAction {
        gateMap = mutableMapOf()
        prepared = false
    }

    /**
     * Method to calculate Map by which you can describe what gate we should use on exact floor when building route.
     * Main goal of process is to begin from a level where destination place located and search for nearest straightforward path to
     * user location floor via Gate. Same logic applied if destination floor level is lower then user, it's just inverted.
     *
     * If it's not possible algorithm search for nearest gate to go 1 floor down/up. If such gate exists it's added to the map as value
     * with key - floor where you can find this gate.
     * e.g. We looking for Gate from floor 5 to 4, gate found, to map added floor number '4' and Gate object
     *
     * If it's not possible to go 1 floor down - we increasing value and looking for gates 2 floor down until found or log that
     * path can't be build.
     *
     * @param gates gates in building
     * @param destinationFloor destination floor of the route
     * @param destinationCoordinate destinationCoordinate to calculate distance
     * @param currentFloorNumber current user floor
     */
    private fun process(gates: List<Gate>,
                        destinationCoordinate: Coordinate,
                        destinationFloor: Int,
                        currentFloorNumber: Int) {
        val direction = pathDirection(destinationFloor, currentFloorNumber)
        val algorithmDestination = destinationCoordinate.copy()
        var algorithmDestinationFloor = destinationFloor

        var pathFound: Boolean

        if (direction == SAME_FLOOR) {
            gateMap[currentFloorNumber] = null to destinationCoordinate
            return
        }

        while (algorithmDestinationFloor != currentFloorNumber) {
            pathFound = findBestGateAndSave(
                    gates,
                    algorithmDestination,
                    algorithmDestinationFloor,
                    currentFloorNumber
            )
            if (pathFound) {
                return
            } else {
                var floorChangeCount = direction
                var intermediateLevelFound = false
                while (!intermediateLevelFound) {
                    intermediateLevelFound = findBestGateAndSave(
                            gates,
                            algorithmDestination,
                            algorithmDestinationFloor,
                            algorithmDestinationFloor - floorChangeCount
                    )
                    if (!intermediateLevelFound) {
                        floorChangeCount += direction
                        if (algorithmDestinationFloor == currentFloorNumber + floorChangeCount) {
                            break
                        }
                    }
                }
                algorithmDestinationFloor -= floorChangeCount
            }
        }
        throw UnsupportedOperationException("Unable to build path through given gates " +
                "from floor to floor [ $currentFloorNumber ] to [ $destinationFloor ]")
    }

    /**
     * Gets direction of path.
     * <pre>
     *     For example:
     *     If user going from floor 0 to 9 return of this function will be UP_DIRECTION
     *     This return value is needed for algorithm
     * </pre>
     *
     * @param destinationFloor as it is
     * @param currentUserFloor as it is
     *
     * @return SAME_FLOOR if (destinationFloor == currentUserFloor). UP_DIRECTION if (destinationFloor > currentUserFloor).
     * DOWN_DIRECTION - otherwise
     */
    private fun pathDirection(destinationFloor: Int, currentUserFloor: Int) = when {
        destinationFloor == currentUserFloor -> SAME_FLOOR
        destinationFloor > currentUserFloor -> UP_DIRECTION
        else -> DOWN_DIRECTION
    }

    /**
     * Method for finding closest gate from given and saving them in gateMap.
     *
     * usefulGates - gates that lead directly from start to destination floor.
     *
     * @return <code>true</code> if useful gate found from given. <code>false</code> - otherwise
     */
    private fun findBestGateAndSave(gates: List<Gate>, position: Coordinate, toFloor: Int, fromFloor: Int): Boolean {
        val usefulGates = ArrayList<Gate>()

        gates.forEach {
            if (it.bounds.containsKey(toFloor) && it.bounds.containsKey(fromFloor)) {
                usefulGates.add(it)
            }
        }

        if (usefulGates.size > 0) {
            val closestGate = getClosestGate(usefulGates, position, toFloor)
            saveToGateMap(fromFloor, closestGate, false)
            saveToGateMap(toFloor, closestGate, true)

            val closestGateCoordinate = closestGate?.bounds?.get(fromFloor)
            if (closestGateCoordinate != null) {
                position.latitude = closestGateCoordinate.latitude
                position.longitude = closestGateCoordinate.longitude
            }
            return true
        }
        return false
    }

    /**
     * Defines in which position in pair should be coordinate stored.
     * If Pair doesn't exists creates new one. Otherwise takes value from already defined Pair.
     */
    private fun saveToGateMap(floorKey: Int, gate: Gate?, firstPositionInPair: Boolean) =
            if (!gateMap.containsKey(floorKey)) {
                if (firstPositionInPair) {
                    gateMap[floorKey] = gate?.bounds?.get(floorKey) to null
                } else {
                    gateMap[floorKey] = null to gate?.bounds?.get(floorKey)
                }
            } else {
                if (firstPositionInPair) {
                    gateMap[floorKey] = gate?.bounds?.get(floorKey) to gateMap[floorKey]?.second
                } else {
                    gateMap[floorKey] = gateMap[floorKey]?.first to gate?.bounds?.get(floorKey)
                }
            }

    /**
     * Finds closest gate from given gates.
     */
    private fun getClosestGate(gates: List<Gate>, position: Coordinate, floor: Int): Gate? {
        var bestGate: Gate? = null
        var minimalDistance = Double.MAX_VALUE
        gates.forEach {
            val distanceOnFloor = it.bounds[floor]?.let {
                coordinateDistanceCalculator.calcDistance(position, it)
            }
            if (distanceOnFloor != null && distanceOnFloor < minimalDistance) {
                minimalDistance = distanceOnFloor
                bestGate = it
            }
        }
        return bestGate
    }

    companion object {
        private const val UP_DIRECTION = 1
        private const val DOWN_DIRECTION = -1
        private const val SAME_FLOOR = 0
    }
}
