package com.epam.beacons.tools.debug;

import androidx.annotation.NonNull;

import com.epam.beacons.Pivot;

import java.util.List;

import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Observable;
import io.reactivex.subjects.PublishSubject;
import io.reactivex.subjects.Subject;

@Singleton
public class DebugStorageImpl implements DebugStorage {
    @NonNull
    private final Subject<List<Pivot>> pivots = PublishSubject.create();

    @NonNull
    @Override
    public Completable debugPivots(@NonNull List<Pivot> pivots) {
        return Completable.fromAction(() -> this.pivots.onNext(pivots));
    }

    @NonNull
    @Override
    public Observable<List<Pivot>> getPivots() {
        return pivots;
    }
}
