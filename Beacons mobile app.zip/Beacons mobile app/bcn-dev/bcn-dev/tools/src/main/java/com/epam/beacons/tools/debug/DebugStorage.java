package com.epam.beacons.tools.debug;

import androidx.annotation.NonNull;

import com.epam.beacons.Pivot;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Observable;

public interface DebugStorage {

    @NonNull
    Completable debugPivots(@NonNull List<Pivot> pivots);

    @NonNull
    Observable<List<Pivot>> getPivots();
}
