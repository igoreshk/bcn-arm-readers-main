package com.epam.beacons.tools.utils;

import androidx.annotation.NonNull;

import com.epam.beacons.Coordinate;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class CoordinateDistanceCalculator {

    @Inject
    public CoordinateDistanceCalculator() { // default constructor for Dagger
    }

    public double calcDistance(@NonNull Coordinate first, @NonNull Coordinate second) {
        return Math.sqrt(
                Math.pow((first.getLatitude() - second.getLatitude()), 2) +
                        Math.pow((first.getLongitude() - second.getLongitude()), 2));
    }
}