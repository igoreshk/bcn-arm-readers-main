package com.epam.beacons.locator;

import androidx.annotation.NonNull;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Pivot;
import com.epam.beacons.tools.Logger;

import org.apache.commons.math3.fitting.leastsquares.LeastSquaresOptimizer;
import org.apache.commons.math3.fitting.leastsquares.LeastSquaresOptimizer.Optimum;
import org.apache.commons.math3.fitting.leastsquares.LeastSquaresProblem;
import org.apache.commons.math3.linear.SingularMatrixException;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Solves a Trilateration problem with an instance of a
 * {@link LeastSquaresOptimizer}
 */
@Singleton
public class TrilaterationSolver {

    private static final int    DIMENSION                      = 2;
    private static final int    ITERATIONS_COUNT               = 25000;
    private static final int    CAN_NOT_CALCULATE_ERROR_RADIUS = 0;
    @NonNull
    private static final String LOG_TAG                        = TrilaterationSolver.class.getSimpleName();

    @NonNull
    private final TrilaterationFunction function;
    @NonNull
    private final LeastSquaresOptimizer leastSquaresOptimizer;
    @NonNull
    private final ProblemFactory        problemFactory;
    @NonNull
    private final Logger                logger;

    @Inject
    TrilaterationSolver(@NonNull TrilaterationFunction function,
                        @NonNull LeastSquaresOptimizer leastSquaresOptimizer,
                        @NonNull ProblemFactory problemFactory,
                        @NonNull Logger logger) {
        this.function = function;
        this.leastSquaresOptimizer = leastSquaresOptimizer;
        this.problemFactory = problemFactory;
        this.logger = logger;
    }

    @NonNull
    public Coordinate solve(@NonNull List<Pivot> pivots) {
        if (pivots.isEmpty()) {
            throw new IllegalArgumentException("List of pivots should not be empty");
        }
        function.setPivots(pivots);

        final double[] target = new double[pivots.size()];
        final double[] weights = new double[target.length];
        for (int i = 0; i < target.length; i++) {
            target[i] = 0.0;
            weights[i] = inverseSquareLaw(pivots.get(i).getDistance());
        }

        final Optimum optimum = solve(target, weights, calculateAverageInitialPoint(pivots));
        final double[] centroid = optimum.getPoint().toArray();

        return new Coordinate(centroid[0], centroid[1],
                              pivots.size() < 3 ? CAN_NOT_CALCULATE_ERROR_RADIUS : calculateErrorRadius(optimum)
        );
    }

    @NonNull
    private Optimum solve(@NonNull double[] target, @NonNull double[] weights,
                          @NonNull double[] initialPoint) {
        final LeastSquaresProblem leastSquaresProblem = problemFactory.create(
                function, target, initialPoint, weights, ITERATIONS_COUNT, ITERATIONS_COUNT);

        return leastSquaresOptimizer.optimize(leastSquaresProblem);
    }

    @NonNull
    private double[] calculateAverageInitialPoint(@NonNull List<Pivot> pivots) {
        final double[] initialPoint = new double[DIMENSION];

        for (Pivot pivot : pivots) {
            final Coordinate coordinate = pivot.getCoordinate();
            initialPoint[0] += coordinate.getLatitude();
            initialPoint[1] += coordinate.getLongitude();
        }
        for (int j = 0; j < initialPoint.length; j++) {
            initialPoint[j] /= pivots.size();
        }

        return initialPoint;
    }

    private double calculateErrorRadius(@NonNull Optimum optimum) {
        final double[] standardDeviation;
        try {
            standardDeviation = optimum.getSigma(0).toArray();
        } catch (SingularMatrixException e) {
            logger.e(LOG_TAG, e.getMessage());
            return CAN_NOT_CALCULATE_ERROR_RADIUS;
        }

        /* This is the square root of inverse of the chi-square cumulative distribution
          with 2 degrees of freedom, calculated for 0.95 probability value
          (can be calculated using function CHISQ.INV in LibreOffice Calc).
         */
        final double COEFF = 2.4477;

        final double halfMajorAxisSize = COEFF * standardDeviation[0];
        final double halfMinorAxisSize = COEFF * standardDeviation[1];

        /* Radius of circle is the max value of half-axes of ellipse */
        return Math.max(halfMajorAxisSize, halfMinorAxisSize);
    }

    private static double inverseSquareLaw(double distance) {
        return 1 / (distance * distance);
    }
}
