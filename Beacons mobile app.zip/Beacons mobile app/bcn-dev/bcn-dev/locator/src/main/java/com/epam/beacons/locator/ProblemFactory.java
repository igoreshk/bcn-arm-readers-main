package com.epam.beacons.locator;

import androidx.annotation.NonNull;

import org.apache.commons.math3.fitting.leastsquares.LeastSquaresFactory;
import org.apache.commons.math3.fitting.leastsquares.LeastSquaresProblem;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.DiagonalMatrix;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class ProblemFactory {

    @Inject
    ProblemFactory() { //default constructor for dagger
    }

    @NonNull
    public LeastSquaresProblem create(@NonNull TrilaterationFunction function,
                                      @NonNull double[] target,
                                      @NonNull double[] initialPoint,
                                      @NonNull double[] weights,
                                      int maxEvaluations, int maxIterations) {
        return LeastSquaresFactory.create(
                // function to be optimized
                function,
                // target values at optimal point in least square equation
                // (x0+xi)^2 + (y0+yi)^2 + ri^2 = target[i]
                new ArrayRealVector(target, false), new ArrayRealVector(initialPoint, false),
                new DiagonalMatrix(weights), null, maxEvaluations, maxIterations
        );
    }
}
