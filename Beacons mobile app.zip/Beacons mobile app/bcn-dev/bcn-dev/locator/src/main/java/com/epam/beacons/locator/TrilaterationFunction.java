package com.epam.beacons.locator;

import androidx.annotation.NonNull;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Pivot;

import org.apache.commons.math3.fitting.leastsquares.MultivariateJacobianFunction;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.util.Pair;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Models the Trilateration problem. This is a formulation for a nonlinear least
 * squares optimizer.
 */
@Singleton
public class TrilaterationFunction implements MultivariateJacobianFunction {

    private static final double EPSILON = 1E-7;

    private List<Pivot> pivots;

    @Inject
    TrilaterationFunction() { //default constructor for dagger
    }

    void setPivots(@NonNull List<Pivot> pivots) {
        // bound distances to strictly positive domain
        for (Pivot pivot : pivots) {
            pivot.setDistance(Math.max(pivot.getDistance(), EPSILON));
        }

        this.pivots = pivots;
    }

    /**
     * Calculate and return Jacobian function Actually return initialized function
     * <p>
     * Jacobian matrix, [i][j] at
     * J[i][0] = delta_[(x0-xi)^2 + (y0-yi)^2 - ri^2]/delta_[x0] at
     * J[i][1] = delta_[(x0-xi)^2 + (y0-yi)^2 - ri^2]/delta_[y0] partial derivative with respect
     * to the parameters passed to value() method
     *
     * @param point for which to calculate the slope
     * @return Jacobian matrix for point
     */
    @NonNull
    private RealMatrix jacobian(@NonNull RealVector point) {
        final double[] pointArray = point.toArray();

        final double[][] jacobian = new double[pivots.size()][pointArray.length];
        for (int i = 0; i < jacobian.length; i++) {
            final Coordinate coordinate = pivots.get(i).getCoordinate();
            jacobian[i][0] = 2 * pointArray[0] - 2 * coordinate.getLatitude();
            jacobian[i][1] = 2 * pointArray[1] - 2 * coordinate.getLongitude();
        }

        return new Array2DRowRealMatrix(jacobian);
    }

    @NonNull
    @Override
    public Pair<RealVector, RealMatrix> value(@NonNull RealVector point) {
        if (pivots == null) {
            throw new IllegalStateException("TrilaterationFunction needs Pivots field to be not null");
        }

        final double[] resultPoint = calculateResultPointUsingLeastSquares(point.toArray());
        return new Pair<>(new ArrayRealVector(resultPoint), jacobian(point));
    }

    @NonNull
    private double[] calculateResultPointUsingLeastSquares(@NonNull double[] point) {
        final double[] resultPoint = new double[pivots.size()];

        for (int i = 0; i < resultPoint.length; i++) {
            resultPoint[i] = 0.0;
            final Coordinate coordinate = pivots.get(i).getCoordinate();

            resultPoint[i] += Math.pow(point[0] - coordinate.getLatitude(), 2);
            resultPoint[i] += Math.pow(point[1] - coordinate.getLongitude(), 2);
            resultPoint[i] -= Math.pow(pivots.get(i).getDistance(), 2);
        }

        return resultPoint;
    }
}
