package com.epam.beacons.locator;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Pivot;

import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.util.Pair;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class TrilaterationFunctionTest {

    private List<Pivot>                  pivots;
    private RealVector                   point;
    private Pair<RealVector, RealMatrix> expectedValue;

    @Before
    public void setUp() {
        pivots = Arrays.asList(
                new Pivot(new Coordinate(1, 1), Math.sqrt(2)),
                new Pivot(new Coordinate(1, 2), 1),
                new Pivot(new Coordinate(2, 1), 1)
        );

        point = new ArrayRealVector(new double[]{1.3333333333333333, 1.3333333333333333});

        expectedValue = new Pair<>(
                new ArrayRealVector(new double[]{
                        -1.7777777777777783, -0.4444444444444444, -0.4444444444444444}),
                new Array2DRowRealMatrix(new double[][]{
                        {0.6666666666666665, 0.6666666666666665},
                        {0.6666666666666665, -1.3333333333333335},
                        {-1.3333333333333335, 0.6666666666666665}})
        );
    }

    @Test
    public void testTrilaterationFunction() {
        final TrilaterationFunction function = new TrilaterationFunction();
        function.setPivots(pivots);
        final Pair<RealVector, RealMatrix> value = function.value(point);
        assertEquals(expectedValue, value);
    }
}
