package com.epam.beacons.locator;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Pivot;
import com.epam.beacons.tools.Logger;

import org.apache.commons.math3.fitting.leastsquares.LeastSquaresOptimizer;
import org.apache.commons.math3.fitting.leastsquares.LeastSquaresProblem;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.linear.SingularMatrixException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class TrilaterationSolverTest {

    private static final int ITERATIONS_COUNT = 25000;

    @Mock
    private LeastSquaresOptimizer.Optimum mockedOptimum;
    @Mock
    private LeastSquaresProblem           mockedProblem;
    @Mock
    private TrilaterationFunction         trilaterationFunction;
    @Mock
    private LeastSquaresOptimizer         optimizer;
    @Mock
    private ProblemFactory                problemFactory;
    @Mock
    @SuppressWarnings("unused")
    private Logger                        logger;

    @InjectMocks
    private TrilaterationSolver trilaterationSolver;

    private final List<Pivot> pivots;
    private final double      expectedX;
    private final double      expectedY;
    private final double[]    targetArray;
    private final double[]    initialPointArray;
    private final double[]    weightsArray;
    private final RealVector  sigma;
    private final double      expectedErrorRadius;
    private final double      delta;


    public TrilaterationSolverTest(List<Pivot> pivots, double expectedX, double expectedY,
                                   double[] targetArray, double[] initialPointArray, double[] weightsArray,
                                   double[] sigmaArray, double expectedErrorRadius, double delta) {
        this.pivots = pivots;
        this.expectedX = expectedX;
        this.expectedY = expectedY;
        this.targetArray = targetArray;
        this.initialPointArray = initialPointArray;
        this.weightsArray = weightsArray;
        this.sigma = new ArrayRealVector(sigmaArray);
        this.expectedErrorRadius = expectedErrorRadius;
        this.delta = delta;
    }

    @Parameters
    public static Collection<Object[]> data() {

        final List<Pivot> pivots1 = new ArrayList<>();
        pivots1.add(new Pivot(new Coordinate(1, 1), Math.sqrt(2)));
        pivots1.add(new Pivot(new Coordinate(1, 2), 1));
        pivots1.add(new Pivot(new Coordinate(2, 1), 1));

        final List<Pivot> pivots2 = new ArrayList<>();
        pivots2.add(new Pivot(new Coordinate(1, 2), 1));
        pivots2.add(new Pivot(new Coordinate(1, 4), 1));

        final List<Pivot> pivots3 = new ArrayList<>();
        pivots3.add(new Pivot(new Coordinate(1, 1), 1));

        final List<Pivot> pivots4 = new ArrayList<>();
        pivots4.add(new Pivot(new Coordinate(1, 1), Math.sqrt(2)));
        pivots4.add(new Pivot(new Coordinate(1, 2), 1));
        pivots4.add(new Pivot(new Coordinate(2, 1), 1));
        pivots4.add(new Pivot(new Coordinate(1, 3), Math.sqrt(2)));
        pivots4.add(new Pivot(new Coordinate(3, 2), 1));

        final List<Pivot> pivots5 = new ArrayList<>();
        pivots5.add(new Pivot(new Coordinate(1, 1), 2));
        pivots5.add(new Pivot(new Coordinate(1, 2), 1));
        pivots5.add(new Pivot(new Coordinate(2, 2), Math.sqrt(2)));

        final List<Pivot> pivots6 = new ArrayList<>();
        pivots6.add(new Pivot(new Coordinate(1, 1), Math.sqrt(2)));
        pivots6.add(new Pivot(new Coordinate(1, 2), 1));
        pivots6.add(new Pivot(new Coordinate(2, 2), 0));

        return Arrays.asList(new Object[][]{
                {pivots1, 2, 2, new double[]{0, 0, 0},
                        new double[]{1.3333333333333333, 1.3333333333333333},
                        new double[]{0.4999999999999999, 1, 1},
                        new double[]{0, 0},
                        0, 1e-6},
                {pivots2, 1, 3, new double[]{0, 0},
                        new double[]{1, 3},
                        new double[]{1, 1},
                        new double[]{0, 0},
                        0, 1e-6},
                {pivots3, 1, 1, new double[]{0},
                        new double[]{1, 1},
                        new double[]{1},
                        new double[]{0, 0},
                        0, 1e-6},
                {pivots4, 2, 2, new double[]{0, 0, 0, 0, 0},
                        new double[]{1.6, 1.8},
                        new double[]{0.4999999999999999, 1, 1, 0.4999999999999999, 1},
                        new double[]{0, 0},
                        0, 1e-6},
                {pivots5, 1, 3, new double[]{0, 0, 0},
                        new double[]{1.3333333333333333, 1.6666666666666667},
                        new double[]{0.25, 1, 0.4999999999999999},
                        new double[]{0, 0},
                        0, 1e-6},
                {pivots6, 2, 2, new double[]{0, 0, 0},
                        new double[]{1.3333333333333333, 1.6666666666666667},
                        new double[]{0.4999999999999999, 1, Double.POSITIVE_INFINITY},
                        new double[]{0, 0},
                        0, 1e-6}
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        when(mockedOptimum.getPoint()).thenReturn(
                new ArrayRealVector(new double[]{
                        expectedX, expectedY}));
        if (Double.compare(expectedErrorRadius, 0) == 0) {
            when(mockedOptimum.getSigma(0)).thenThrow(new SingularMatrixException());
        } else {
            when(mockedOptimum.getSigma(0)).thenReturn(sigma);
        }

        when(problemFactory.create(trilaterationFunction, targetArray, initialPointArray,
                                   weightsArray, ITERATIONS_COUNT, ITERATIONS_COUNT
        )).thenReturn(mockedProblem);
        when(optimizer.optimize(mockedProblem)).thenReturn(mockedOptimum);
    }

    @Test
    public void testSolver() {
        final Coordinate coordinate = trilaterationSolver.solve(pivots);
        assertEquals(expectedX, coordinate.getLatitude(), delta);
        assertEquals(expectedY, coordinate.getLongitude(), delta);
        assertEquals(expectedErrorRadius, coordinate.getErrorRadius(), delta);
    }
}
