package com.epam.beacons.locator;

import com.epam.beacons.Pivot;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

@RunWith(Parameterized.class)
public class TrilaterationSolverExceptionTest {

    @InjectMocks
    private TrilaterationSolver trilaterationSolver;

    private final List<Pivot> pivots;

    public TrilaterationSolverExceptionTest(List<Pivot> pivots) {
        this.pivots = pivots;
    }

    @Parameters
    public static Collection<Object[]> data() {
        final List<Pivot> emptyPivots = new ArrayList<>();

        return Arrays.asList(new Object[][]{
                {emptyPivots}
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSolverWithNoPivots() {
        trilaterationSolver.solve(pivots);
    }
}
