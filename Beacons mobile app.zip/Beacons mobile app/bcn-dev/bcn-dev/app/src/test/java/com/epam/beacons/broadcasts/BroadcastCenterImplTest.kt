package com.epam.beacons.broadcasts

import android.content.Intent
import android.content.IntentFilter
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.epam.beacons.utils.Constants
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.any
import org.mockito.ArgumentMatchers.eq
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito.verify
import org.mockito.MockitoAnnotations
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE)
class BroadcastCenterImplTest {

    @Mock
    private lateinit var cleaningReceiver: CleaningReceiver
    @Mock
    private lateinit var manager: LocalBroadcastManager
    @InjectMocks
    private lateinit var center: BroadcastCenterImpl

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
    }

    @Test
    fun testSendLocalBroadcast() {
        center.sendLocalBroadcast(Constants.CLEANING_REQUESTED_ACTION)
        verify(manager).sendBroadcast(any(Intent::class.java))
    }

    @Test
    fun testReceiverRegistered() {
        verify(manager).registerReceiver(eq(cleaningReceiver), any(IntentFilter::class.java))
    }
}
