package com.epam.beacons.utils;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Place;
import com.epam.beacons.ui.widget.CustomMarker;
import com.epam.beacons.utils.mappers.CoordinatesToLatLngsMapper;
import com.epam.beacons.utils.mappers.PlaceToCustomMarkerMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@RunWith(RobolectricTestRunner.class)
@Config(manifest = Config.NONE)
public class MarkerHelperTest {
    private List<Place>                placesOnSameFloor;
    private List<Place>                placesOnDifferentFloors;
    private MarkerHelper               helper;
    private List<CustomMarker>         customMarkers;
    private CoordinatesToLatLngsMapper mapper;

    @Before
    public void setUp() {
        placesOnSameFloor = Arrays.asList(
                new Place(1L, "CoffeePoint", "CoffeePoint", new Coordinate(1, 1), 0),
                new Place(2L, "Shop", "Shop", new Coordinate(2, 2), 0),
                new Place(3L, "WC", "WC", new Coordinate(-2, -3), 0)
        );

        placesOnDifferentFloors = Arrays.asList(
                new Place(1L, "CoffeePoint", "on 7th floor", new Coordinate(1, 1), 7),
                new Place(2L, "Shop", "on 6th floor", new Coordinate(2, 2), 6),
                new Place(3L, "WC", "on 5th floor", new Coordinate(-2, -3), 5)
        );

        customMarkers = Collections.singletonList(new CustomMarker(2L));

        mapper = new CoordinatesToLatLngsMapper();

        helper = new MarkerHelper(new PlaceToCustomMarkerMapper(new CoordinatesToLatLngsMapper()));
    }

    @Test(expected = NullPointerException.class)
    @SuppressWarnings("ConstantConditions")
    public void testCustomMarkersAreNull() {
        helper.process(placesOnSameFloor, null, 0, false).blockingGet();
    }

    @Test(expected = IllegalArgumentException.class)
    @SuppressWarnings("ConstantConditions")
    public void testPlacesAreNull() {
        helper.process(null, customMarkers, 100, false).blockingGet();
    }

    @Test
    @SuppressWarnings("ConstantConditions")
    public void testUpdateMarker() {
        helper.process(placesOnSameFloor, customMarkers, 0, false)
              .zipWith(
                      helper.process(placesOnSameFloor, customMarkers, 0, false),
                      (customMarkers1, customMarkers2) -> customMarkers2
              )
              .test()
              .assertValue(newMarkers -> newMarkers.get(1).getMarkerStatus() == CustomMarker.Status.UPDATE)
              .assertValue(newMarkers -> newMarkers.get(1).getLatLng()
                                                   .equals(mapper.map(placesOnSameFloor.get(1).getCoordinate())));
    }

    @Test
    @SuppressWarnings("ConstantConditions")
    public void testAddMarker() {
        helper.process(placesOnSameFloor, customMarkers, 0, false)
              .zipWith(
                      helper.process(placesOnSameFloor, customMarkers, 0, false),
                      (customMarkers1, customMarkers2) -> customMarkers2
              )
              .test()
              .assertValue(newMarkers -> newMarkers.get(0).getMarkerStatus() == CustomMarker.Status.ADD)
              .assertValue(newMarkers -> "CoffeePoint CoffeePoint".equals(newMarkers.get(0).getMarkerOptions().getTitle()));
    }

    @Test
    public void testRemoveMarker() {
        helper.process(placesOnSameFloor, customMarkers, 0, false)
              .zipWith(
                      helper.process(placesOnSameFloor, Collections.singletonList(new CustomMarker(4L)), 0, false),
                      (customMarkers1, customMarkers2) -> customMarkers2
              )
              .test()
              .assertValue(newMarkers -> newMarkers.get(3).getMarkerStatus() == CustomMarker.Status.REMOVE);

    }

    @Test
    public void testChangeFloorRemovePreviousMarker() {
        helper.process(placesOnDifferentFloors, customMarkers, 100, false)
              .test()
              .assertValue(newMarkers -> newMarkers.get(3).getMarkerStatus() == CustomMarker.Status.REMOVE);
    }

    @Test
    public void testChangeFloorAddNewMarker() {
        helper.process(placesOnDifferentFloors, customMarkers, 100, false)
              .test()
              .assertValue(newMarkers -> newMarkers.get(1).getMarkerStatus() == CustomMarker.Status.ADD);
    }
}
