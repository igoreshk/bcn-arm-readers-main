package com.epam.beacons.ui.widget.bookmarks

import android.content.Context
import android.content.res.Configuration
import androidx.recyclerview.widget.RecyclerView
import android.util.AttributeSet
import com.epam.beacons.R
import com.epam.beacons.utils.extensions.dimenPx

class BookmarksRecyclerView @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleAttr: Int = 0
) : RecyclerView(context, attrs, defStyleAttr) {

    var maxHeight = if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
        context.dimenPx(R.dimen.bookmarks_recycler_max_height_v)
    } else {
        context.dimenPx(R.dimen.bookmarks_recycler_max_height_h)
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) = super.onMeasure(widthSpec, MeasureSpec.makeMeasureSpec(maxHeight, MeasureSpec.AT_MOST))
}
