package com.epam.beacons.parser

import android.content.Context
import com.epam.beacons.BuildIcon
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.rest.api.model.NetworkBeacon
import com.rest.api.model.NetworkBuilding
import com.rest.api.model.NetworkFloor
import com.rest.api.model.NetworkGate
import com.rest.api.service.DataParser
import java.io.FileNotFoundException
import java.lang.reflect.Type
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MockDataParser @Inject constructor(
        private val context: Context,
        private val gson: Gson
) : DataParser {

    override fun provideBuildings(): MutableList<NetworkBuilding> = context.toJson(buildingsPath, buildingsType)

    override fun provideIcon(id: String): MutableList<NetworkBeacon> = context.toJson("mocked/$id/beacon.json", beaconType)

    override fun provideEdge(id: String): MutableList<NetworkGate> = context.toJson("mocked/$id/edge.json", edgeType)

    override fun provideFloors(id: String): MutableList<NetworkFloor> = context.toJson("mocked/$id/floor.json", floorsType)

    override fun provideGates(id: String): MutableList<NetworkGate> = context.toJson("mocked/$id/gates.json", gatesType)

    private fun <E> Context.toJson(path: String, type: Type): E {
        try {
            return gson.fromJson<E>(this.assets.open(path).reader(), type)
        } catch (e: FileNotFoundException) {
            throw IllegalStateException("File $path doesn't exists. Please, rerun task :app:downloadRestData and cache new data.")
        }
    }

    companion object {
        private val buildingsType = object : TypeToken<MutableList<NetworkBuilding>>() {}.type
        private val beaconType = object : TypeToken<MutableList<NetworkBeacon>>() {}.type
        private val edgeType = object : TypeToken<MutableList<NetworkGate>>() {}.type
        private val floorsType = object : TypeToken<MutableList<NetworkFloor>>() {}.type
        private val gatesType = object : TypeToken<MutableList<NetworkGate>>() {}.type
        private const val buildingsPath = "mocked/buildings.json"
    }
}
