package com.epam.beacons.dagger

import com.epam.beacons.repository.LocationRepo
import com.epam.beacons.repository.StorageLayer
import com.epam.beacons.repository.cache.BeaconsCache
import com.epam.beacons.repository.cache.MeasurementCache
import com.epam.beacons.repository.cache.UserFloorBeaconsCache
import com.epam.beacons.utils.Constants
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object RepositoryModule {

    @JvmStatic
    @Provides
    @Singleton
    fun provideLocationRepo(storageLayer: StorageLayer,
                            userFloorBeaconsCache: UserFloorBeaconsCache,
                            beaconsCache: BeaconsCache,
                            measurementCache: MeasurementCache) =
            LocationRepo(storageLayer, userFloorBeaconsCache, beaconsCache, measurementCache, Constants.MEASUREMENTS_LIMIT)
}
