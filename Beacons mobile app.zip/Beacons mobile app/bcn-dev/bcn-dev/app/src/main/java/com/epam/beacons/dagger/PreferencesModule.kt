package com.epam.beacons.dagger

import com.epam.beacons.preferences.BeaconsPreferencesImpl
import com.epam.beacons.repository.preferences.BeaconsPreferences
import dagger.Binds
import dagger.Module
import javax.inject.Singleton

@Module
abstract class PreferencesModule {

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun provideDebugDrawPreferences(beaconsPreferences: BeaconsPreferencesImpl): BeaconsPreferences
}
