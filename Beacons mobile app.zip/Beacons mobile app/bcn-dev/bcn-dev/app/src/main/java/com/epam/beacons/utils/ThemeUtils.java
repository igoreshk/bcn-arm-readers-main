package com.epam.beacons.utils;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import androidx.core.content.ContextCompat;
import android.util.TypedValue;

public final class ThemeUtils {

    private ThemeUtils() {
        throw new UnsupportedOperationException();
    }

    public static int getColorFromTheme(final Context context, final int attr) {
        final TypedValue value = new TypedValue();
        final Resources.Theme theme = context.getTheme();
        theme.resolveAttribute(attr, value, true);

        return extractColor(context, value, attr);
    }

    public static int getColorFromTheme(final Context context, final int attr, final int defStyleAttr) {
        final Resources.Theme theme = context.getTheme();
        final TypedValue value = new TypedValue();
        final TypedArray typedArray = theme
                .obtainStyledAttributes(null, new int[]{attr}, defStyleAttr, 0);
        try {
            typedArray.getValue(0, value);
        } finally {
            typedArray.recycle();
        }

        return extractColor(context, value, attr);
    }

    private static int extractColor(final Context context, final TypedValue value, final int attr) {
        if (value.type >= TypedValue.TYPE_FIRST_COLOR_INT && value.type <= TypedValue.TYPE_LAST_COLOR_INT) {
            return ContextCompat.getColor(context, value.resourceId);
        }

        throw new Resources.NotFoundException("Couldn't read color attribute: " + attr);
    }

}
