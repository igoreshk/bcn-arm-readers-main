package com.epam.beacons.dagger

import androidx.lifecycle.ViewModelProvider
import android.content.Context
import android.os.Environment
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.epam.beacons.BuildConfig
import com.epam.beacons.MainApp
import com.epam.beacons.base.ViewModelFactory
import com.epam.beacons.broadcasts.BroadcastCenter
import com.epam.beacons.broadcasts.BroadcastCenterImpl
import com.epam.beacons.broadcasts.CleaningReceiver
import com.epam.beacons.logger.AppLogger
import com.epam.beacons.logger.ReleaseLogger
import com.epam.beacons.notification.NotificationCenter
import com.epam.beacons.notification.NotificationCompatCenter
import com.epam.beacons.tools.debug.DebugStorageImpl
import com.epam.beacons.tools.debug.DebugStorageRelease
import com.epam.beacons.tools.utils.FilePathProvider
import com.epam.beacons.utils.fps.DebugFpsHelper
import com.epam.beacons.utils.fps.ReleaseFpsHelper
import com.google.gson.Gson
import dagger.Binds
import dagger.Module
import dagger.Provides
import java.io.File
import java.util.Locale
import javax.inject.Singleton

@Module(subcomponents = [(ViewModelSubComponent::class)])
abstract class AppModule {

    @Module
    companion object {
        @JvmStatic
        @Provides
        @Singleton
        fun provideContext(application: MainApp): Context = application.applicationContext

        @JvmStatic
        @Provides
        @Singleton
        fun provideLogger() = if (BuildConfig.DEBUG) AppLogger() else ReleaseLogger()

        @JvmStatic
        @Provides
        @Singleton
        fun provideGson() = Gson()

        @JvmStatic
        @Provides
        @Singleton
        fun provideFile(filePathProvider: FilePathProvider) =
                File(Environment.getExternalStorageDirectory().absolutePath, filePathProvider.filePath())

        @JvmStatic
        @Provides
        @Singleton
        fun provideLocale(): Locale = Locale.getDefault()

        @JvmStatic
        @Provides
        @Singleton
        fun provideDebugStorage() = if (BuildConfig.DEBUG) DebugStorageImpl() else DebugStorageRelease()

        @JvmStatic
        @Provides
        @Singleton
        fun provideFpsHelper() = if (BuildConfig.DEBUG) DebugFpsHelper() else ReleaseFpsHelper()

        @JvmStatic
        @Provides
        @Singleton
        fun provideViewModelFactory(viewModelSubComponent: ViewModelSubComponent.Builder): ViewModelProvider.Factory =
                ViewModelFactory(viewModelSubComponent.build())

        @JvmStatic
        @Provides
        @Singleton
        fun provideBroadcastCenter(context: Context, cleaningReceiver: CleaningReceiver): BroadcastCenter =
                BroadcastCenterImpl(LocalBroadcastManager.getInstance(context), cleaningReceiver)
    }

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun provideNotificationCenter(notificationCenter: NotificationCompatCenter): NotificationCenter
}
