package com.epam.beacons.utils;

import androidx.annotation.NonNull;
import android.util.LongSparseArray;

import com.epam.beacons.Place;
import com.epam.beacons.ui.widget.CustomMarker;
import com.epam.beacons.utils.mappers.PlaceToCustomMarkerMapper;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Maybe;

@Singleton
public class MarkerHelper {
    @NonNull
    private final PlaceToCustomMarkerMapper placeToCustomMarkerMapper;
    @NonNull
    private final LongSparseArray<Place>        places        = new LongSparseArray<>();
    @NonNull
    private final LongSparseArray<CustomMarker> customMarkers = new LongSparseArray<>();

    private int floorNumber;

    @Inject
    MarkerHelper(@NonNull PlaceToCustomMarkerMapper placeToCustomMarkerMapper) {
        this.placeToCustomMarkerMapper = placeToCustomMarkerMapper;
    }

    @NonNull
    public Maybe<List<CustomMarker>> process(@NonNull List<Place> placesToProcess,
                                             @NonNull List<CustomMarker> markersToProcess,
                                             int currentFloorNumber,
                                             boolean activityWasDestroyed) {
        return Maybe.fromCallable(() -> {
            if (markersToProcess.isEmpty() || floorNumber != currentFloorNumber) {
                floorNumber = currentFloorNumber;

                return init(placeToCustomMarkerMapper.map(placesToProcess), markersToProcess);
            } else if (activityWasDestroyed) {
                return refresh(markersToProcess);
            } else {
                for (Place p : placesToProcess) {
                    places.put(Long.parseLong(p.getId()), p);
                }
                for (CustomMarker c : markersToProcess) {
                    customMarkers.put(Long.parseLong(c.getId()), c);
                }

                return refresh(customMarkers, places);
            }
        });
    }

    @NonNull
    private List<CustomMarker> init(@NonNull List<CustomMarker> markersToAdd,
                                    @NonNull List<CustomMarker> markersToRemove) {

        final List<CustomMarker> newMarkers = new ArrayList<>(markersToAdd);

        for (CustomMarker cm : markersToRemove) {
            cm.setMarkerStatus(CustomMarker.Status.REMOVE);
            newMarkers.add(cm);
        }

        return newMarkers;
    }

    @NonNull
    private List<CustomMarker> refresh(@NonNull List<CustomMarker> markersToAdd) {
        for (CustomMarker cm : markersToAdd) {
            cm.setMarkerStatus(CustomMarker.Status.ADD);
        }
        return markersToAdd;
    }

    @NonNull
    private List<CustomMarker> refresh(@NonNull LongSparseArray<CustomMarker> markersToRefresh,
                                       @NonNull LongSparseArray<Place> placesToRefresh) {

        final List<CustomMarker> newMarkers = new ArrayList<>();

        CustomMarker cm;

        for (int i = 0; i < placesToRefresh.size(); i++) {
            final long key = placesToRefresh.keyAt(i);
            cm = markersToRefresh.get(key);
            if (cm != null) {
                placeToCustomMarkerMapper.update(cm, placesToRefresh.get(key));
                newMarkers.add(cm);
                cm.setMarkerStatus(CustomMarker.Status.UPDATE);
            } else {
                cm = placeToCustomMarkerMapper.map(placesToRefresh.get(key));
                newMarkers.add(cm);
            }
        }

        for (int i = 0; i < markersToRefresh.size(); i++) {
            final long key = markersToRefresh.keyAt(i);
            if (placesToRefresh.get(key) == null) {
                cm = markersToRefresh.get(key);
                if (cm != null) {
                    newMarkers.add(cm);
                    cm.setMarkerStatus(CustomMarker.Status.REMOVE);
                }
            }
        }

        places.clear();
        customMarkers.clear();

        return newMarkers;
    }
}
