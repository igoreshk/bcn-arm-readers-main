package com.epam.beacons.utils

import android.content.Context
import android.graphics.drawable.Drawable
import android.widget.ImageView
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.bumptech.glide.request.transition.DrawableCrossFadeTransition
import com.epam.beacons.R
import com.epam.beacons.ui.widget.SearchAndBookmarksImageView
import com.epam.beacons.utils.extensions.drawableOrDefault

class GlideHelper(context: Context) {
    private val glide: GlideRequests = GlideApp.with(context)

    fun load(icon: String, targetImage: ImageView) {
        val sourceImage = targetImage as? SearchAndBookmarksImageView

        if (!icon.isBlank()) {
            glide.load(icon)
                    .listener(object : RequestListener<Drawable> {
                        override fun onLoadFailed(e: GlideException?, model: Any?, target: Target<Drawable>?, isFirstResource: Boolean): Boolean {
                            sourceImage?.setImage(sourceImage.context.drawableOrDefault(R.drawable.ic_search_error_icon))
                            return true
                        }

                        override fun onResourceReady(resource: Drawable, model: Any?, target: Target<Drawable>?,
                                                     dataSource: DataSource?, isFirstResource: Boolean): Boolean {
                            target?.onResourceReady(resource, DrawableCrossFadeTransition(CROSS_FADE_DURATION, !isFirstResource))
                            return true
                        }
                    })
                    .into(targetImage)
        } else {
            glide.load(R.drawable.ic_search_error_icon)
                    .into(targetImage)
        }
    }

    companion object {
        private const val CROSS_FADE_DURATION = 200
    }
}
