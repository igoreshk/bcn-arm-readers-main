package com.epam.beacons.buildings

import android.util.Log
import android.widget.ImageView
import androidx.annotation.NonNull
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.OnLifecycleEvent
import com.epam.beacons.*
import com.epam.beacons.base.modern.BaseViewModelNew
import com.epam.beacons.buildings.BuildingsState.Companion.DEFAULT_ERROR
import com.epam.beacons.interactors.DataInteractor
import com.epam.beacons.repository.cache.FloorNumbersCache
import com.epam.beacons.repository.exceptions.NoDataOnServerException
import com.epam.beacons.tools.Logger
import com.epam.beacons.tools.adapters.DisposableCompletableObserverAdapter
import com.epam.beacons.utils.ImageHelper
import com.epam.beacons.utils.mappers.BuildingToBuildingItemMapper
import io.reactivex.Maybe
import java.net.ConnectException
import java.net.SocketTimeoutException
import javax.inject.Inject

class BuildingsViewModel
@Inject constructor(logger: Logger,
                    private val imageHelper: ImageHelper,
                    private val dataInteractor: DataInteractor,
                    private val buildingsMapper: BuildingToBuildingItemMapper
) : BaseViewModelNew<BuildingsState>(BuildingsState(), logger) {


    override fun onOwnerCreated(restoring: Boolean) {
        super.onOwnerCreated(restoring)
        if (restoring && !data.value.updateState.noNetworkData) {
            return
        }

        dataInteractor.downloadBuildingsAnyway().execute(
                onFinished = this::hideProgress,
                onError = this::resolveError,
                onSuccess = this::updateBuildings
        )
    }

    fun downloadImage(imageView: ImageView, url: String) {
        imageHelper.loadImage(url, imageView)
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
    fun onStop() {
        if (data.value.hideProgressOnClose.needToShow && data.value.hideProgressOnClose.value) {
            hideProgress()
        }
    }

    fun onRefresh() {
        data.value.updateState.refreshing = true

        dataInteractor.downloadRecentBuildings()
            .execute(
                onFinished = this::hideProgress,
                onError = this::resolveErrorWhileRefresh,
                onSuccess = this::updateBuildings
        )
    }

    fun onViewModeChanged(mode: BuildingsState.ViewMode) {
        data.value.viewMode = mode
        data.notifyObservers()
    }

    fun onBuildingItemClicked(buildingId: String) {
        data.value.updateState.progressBarVisible = true
        data.notifyObservers()

       val gates: Maybe<List<Floor>> = dataInteractor.downloadFloorsAndGates(buildingId)
        gates.execute(
                onError = {
                    resolveError(it)
                    hideProgress()
                },
                onSuccess = {
                    handleDownloading()
                    hideProgressOnClose()
                },
                onComplete = {
                    handleDownloading()
                    hideProgressOnClose()
                })
    }

    fun onSwipeBuildingIndexChanged(index: Int) {
        data.value.swipeBuildingIndex = index
    }

    fun onExpandedListItemIndexChanged(index: Int) {
        data.value.expandedListItemIndex = index
    }

    private fun getRecentError(e: Throwable) = when (e) {
        is ConnectException -> R.string.noConnection
        is SocketTimeoutException -> R.string.timeoutReached
        is NoDataOnServerException -> R.string.noData
        else -> DEFAULT_ERROR
    }

    private fun resolveError(e: Throwable) {
        data.value.updateState.error.value = getRecentError(e)
        data.value.updateState.launchFirstTime = false
    }

    private fun resolveErrorWhileRefresh(e: Throwable) {
        if (data.value.buildings.isEmpty()) data.value.updateState.error.value = getRecentError(e)
        showNoNetwork()
    }

    private fun showNoNetwork() {
        data.value.updateState.noNetwork.value = true
    }

    private fun handleDownloading() {
        data.value.downloadFinished.value = true
        data.notifyObservers()
    }

    private fun setBeacons(beacons: List<Beacon>, floor:Floor) {
        Log.d("Beacons Result = ", beacons.size.toString())
        floor.beacons = beacons
    }

    private fun updateBuildings(buildings: List<Building>) {

        
        data.value.updateState.error.value = DEFAULT_ERROR
        data.value.buildings = buildingsMapper.map(buildings)!!
        data.value.updateState.noNetworkData = false
        data.notifyObservers()
    }

    private fun hideProgress() {
        data.value.apply {
            updateState.progressBarVisible = false
            updateState.refreshing = false
        }

        data.notifyObservers()
    }

    private fun hideProgressOnClose() {
        data.value.hideProgressOnClose.value = true
    }
}
