package com.epam.beacons.utils.mappers

import com.epam.beacons.Place
import com.epam.beacons.tools.Mapper
import com.epam.beacons.uimodel.SearchItem
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PlaceToSearchItemMapper @Inject constructor() : Mapper<Place, SearchItem>() {
    override fun map(from: Place) = SearchItem(from.id.toLong(),
            "", // TODO: Task EPMLSTRBCA-197
            from.description, "${from.type} - $LEVEL ${from.floorNumber}", from.isFavorite)

    companion object {
        private const val LEVEL = "Level"
    }
}
