package com.epam.beacons.utils.mappers

import com.epam.beacons.Coordinate
import com.epam.beacons.tools.Mapper
import com.google.android.gms.maps.model.LatLng
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LatLngToCoordinateMapper @Inject constructor() : Mapper<LatLng, Coordinate>() {

    override fun map(from: LatLng) = Coordinate(from.latitude, from.longitude)
}
