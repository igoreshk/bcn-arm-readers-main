package com.epam.beacons.utils.mappers

import com.epam.beacons.Place
import com.epam.beacons.uimodel.BookmarkItem
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PlaceToBookmarksItemMapper @Inject constructor() {

    fun map(from: Place) = BookmarkItem(
            from.id,
            "", //TODO: Task EPMLSTRBCA-197
            from.description,
            "${from.type} - $LEVEL ${from.floorNumber}")

    fun map(from: List<Place>) = from.map { map(it) }.toMutableList()

    companion object {
        private const val LEVEL = "Level"
    }
}
