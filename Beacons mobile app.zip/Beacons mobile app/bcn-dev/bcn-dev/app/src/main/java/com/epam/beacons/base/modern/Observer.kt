package com.epam.beacons.base.modern

interface Observer<in T> {

    fun onChanged(t: T)
}
