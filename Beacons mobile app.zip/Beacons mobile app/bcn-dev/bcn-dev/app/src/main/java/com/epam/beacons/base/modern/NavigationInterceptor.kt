package com.epam.beacons.base.modern

interface NavigationInterceptor {
    fun onBackPressed(): Boolean
    fun onUpPressed(): Boolean
}
