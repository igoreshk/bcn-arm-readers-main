package com.epam.beacons.ui.widget.floorselector

import android.content.Context
import androidx.recyclerview.widget.GridLayoutManager

class RtlGridLayoutManager(context: Context?, spanCount: Int, orientation: Int, reverseCount: Boolean) :
        GridLayoutManager(context, spanCount, orientation, reverseCount) {

    override fun isLayoutRTL(): Boolean = true

    override fun canScrollVertically(): Boolean = false

    override fun canScrollHorizontally(): Boolean = false
}
