package com.epam.beacons.utils;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import javax.inject.Inject;

public class PermissionHelper {

    @Inject
    public PermissionHelper() { // default constructor for Dagger
    }

    public boolean isPermissionsDenied(@NonNull Context context, @NonNull String[] permissions) {
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                return true;
            }
        }
        return false;
    }

    public void requestPermissions(@NonNull Activity activity, @NonNull String[] permissions, int requestCode) {
        ActivityCompat.requestPermissions(activity, permissions, requestCode);
    }

    @SuppressWarnings("SameReturnValue")
    @NonNull
    public String getLocationPermission() {
        return Manifest.permission.ACCESS_COARSE_LOCATION;
    }

    @SuppressWarnings("SameReturnValue")
    @NonNull
    public String getWriteExternalStoragePermission() {
        return Manifest.permission.WRITE_EXTERNAL_STORAGE;
    }

    @SuppressWarnings("SameReturnValue")
    @NonNull
    public String getAccessFineLocationPermission() {
        return Manifest.permission.ACCESS_FINE_LOCATION;
    }

    @SuppressWarnings("SameReturnValue")
    @NonNull
    public String getBluetoothPermission() {
        return Manifest.permission.BLUETOOTH;
    }

    @SuppressWarnings("SameReturnValue")
    @NonNull
    public String getBluetoothAdminPermission() {
        return Manifest.permission.BLUETOOTH_ADMIN;
    }
}
