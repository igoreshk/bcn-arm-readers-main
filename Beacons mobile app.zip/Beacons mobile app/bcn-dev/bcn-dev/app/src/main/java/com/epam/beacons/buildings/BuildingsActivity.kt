package com.epam.beacons.buildings

import android.content.Intent
import android.os.Bundle
import androidx.preference.PreferenceManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.recyclerview.widget.LinearLayoutManager
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import com.epam.beacons.R
import com.epam.beacons.base.modern.BaseActivityNew
import com.epam.beacons.base.modern.SingleEvent
import com.epam.beacons.buildings.BuildingsState.Companion.DEFAULT_ERROR
import com.epam.beacons.maps.MapsActivity
import com.epam.beacons.preferences.SettingsActivity
import com.epam.beacons.uimodel.BuildingItem
import com.epam.beacons.utils.ThemeUtils
import com.epam.beacons.utils.cancelAlarm
import com.epam.beacons.utils.extensions.changeStatusBarColor
import com.epam.beacons.utils.extensions.show
import com.epam.beacons.utils.extensions.toast
import com.epam.beacons.utils.setAlarm
import com.github.rubensousa.gravitysnaphelper.GravitySnapHelper
import com.lsjwzh.widget.recyclerviewpager.RecyclerViewPager
import kotlinx.android.synthetic.main.activity_buildings.*
import kotlinx.android.synthetic.main.launch_error.*
import javax.inject.Inject

class BuildingsActivity :
        BaseActivityNew<BuildingsState, BuildingsViewModel>(),
        SwipeRefreshLayout.OnRefreshListener,
        View.OnClickListener,
        RecyclerViewPager.OnPageChangedListener,
        DotsAdapter.OnDotItemClickListener,
        BuildingsAdapter.ImageDownloadCallback,
        BuildingsAdapter.ItemClickListener,
        BuildingsAdapter.GalleryClickListener,
        BuildingsAdapter.ShareClickListener,
        BuildingsAdapter.OutdoorMapClickListener,
        BuildingsAdapter.ToggleClickListener {

    @Inject
    lateinit var buildingsAdapter: BuildingsAdapter
    @Inject
    lateinit var dotsAdapter: DotsAdapter

    override val layoutRes = R.layout.activity_buildings

    override val vmClass = BuildingsViewModel::class.java

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestPermission(RC_PERMISSION_ALL,
                permissionHelper.accessFineLocationPermission,
                permissionHelper.bluetoothPermission,
                permissionHelper.bluetoothAdminPermission,
                permissionHelper.writeExternalStoragePermission
        )

        buildingsAdapter.apply {
            itemClickListener = this@BuildingsActivity
            galleryClickListener = this@BuildingsActivity
            shareClickListener = this@BuildingsActivity
            onMapClickListener = this@BuildingsActivity
            toggleClickListener = this@BuildingsActivity
            imageDownloadCallback = this@BuildingsActivity
        }

        buildings_list.apply {
            adapter = buildingsAdapter
            layoutManager = LinearLayoutManager(this@BuildingsActivity)
            itemAnimator = null
        }

        swipe_layout.apply {
            adapter = buildingsAdapter
            layoutManager = LinearLayoutManager(this@BuildingsActivity, LinearLayoutManager.HORIZONTAL, false)
            addOnPageChangedListener(this@BuildingsActivity)
        }

        dotsAdapter.apply {
            setOnDotItemClickListener(this@BuildingsActivity)
        }

        dots.apply {
            adapter = dotsAdapter
            layoutManager = LinearLayoutManager(this@BuildingsActivity, LinearLayoutManager.HORIZONTAL, false)
            hasFixedSize()
        }

        val snapHelper = GravitySnapHelper(Gravity.START)
        snapHelper.attachToRecyclerView(dots)

        swipe_refresh_layout.setOnRefreshListener(this)

        switch_to_pagination_mode.setOnClickListener(this)
        switch_to_list_mode.setOnClickListener(this)
        switch_to_settings.setOnClickListener(this)

        swipe_refresh_layout.setColorSchemeColors(
                ThemeUtils.getColorFromTheme(this, R.attr.colorAccent),
                ThemeUtils.getColorFromTheme(this, R.attr.colorPrimary),
                ThemeUtils.getColorFromTheme(this, R.attr.colorPrimaryDark)
        )

        launchPositionSharing()
    }

    override fun onDestroy() {
        buildingsAdapter.apply {
            itemClickListener = null
            galleryClickListener = null
            shareClickListener = null
            onMapClickListener = null
            toggleClickListener = null
            imageDownloadCallback = null
        }
        swipe_refresh_layout.setOnRefreshListener(null)
        view_animator.handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun applyChanges(state: BuildingsState) {
        showProgress(state.updateState, state.viewMode)
        if (state.buildings != buildingsAdapter.buildings) {
            updateBuildings(state.buildings, state.swipeBuildingIndex, state.expandedListItemIndex)
        }
        handleDownloadFinished(state.downloadFinished)

        showNoNetworkToast(state.updateState.noNetwork)
    }

    override fun onPermissionDenied(requestCode: Int, permissions: List<String>) {
        if (permissions.contains(permissionHelper.writeExternalStoragePermission)) {
            toast(R.string.error_write_ext_storage_required)
        }
        if (permissions.contains(permissionHelper.accessFineLocationPermission)) {
            toast(R.string.error_access_fine_location_permission_required)
        }
        if (permissions.contains(permissionHelper.bluetoothPermission)) {
            toast(R.string.error_bluetooth_permission_required)
        }
        if (permissions.contains(permissionHelper.bluetoothAdminPermission)) {
            toast(R.string.error_bluetooth_admin_permission_required)
        }
    }

    override fun onClick(v: View?) {
        when (v) {
            switch_to_list_mode -> viewModel.onViewModeChanged(BuildingsState.ViewMode.LIST)
            switch_to_pagination_mode -> viewModel.onViewModeChanged(BuildingsState.ViewMode.SWIPE)
            switch_to_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            else -> return
        }
    }

    override fun onImageLoading(imageView: ImageView, url: String) = viewModel.downloadImage(imageView, url)

    override fun onItemClick(itemId: String) = viewModel.onBuildingItemClicked(itemId)

    override fun onGalleryClick(itemId: String) = toast(R.string.not_implemented_stub)

    override fun onShareClick(itemId: String) = toast(R.string.not_implemented_stub)

    override fun onOutdoorMapClick(itemId: String) = toast(R.string.not_implemented_stub)

    override fun onToggleClick(expandedItemIndex: Int) = viewModel.onExpandedListItemIndexChanged(expandedItemIndex)

    override fun onRefresh() = viewModel.onRefresh()

    // First letter of method is uppercase (external library code)
    @Suppress("FunctionNaming")
    override fun OnPageChanged(from: Int, to: Int) {
        viewModel.onSwipeBuildingIndexChanged(to)
        dotsAdapter.changeSelectedDotIndex(from, to)
    }

    override fun onDotSelected(index: Int) {
        val layoutManager = dots.layoutManager
        if (layoutManager is LinearLayoutManager) {
            layoutManager.scrollToPositionWithOffset(index, 0)
        }
        swipe_layout.smoothScrollToPosition(index)
        viewModel.onSwipeBuildingIndexChanged(index)
    }

    private fun updateBuildings(buildings: List<BuildingItem>, swipeBuildingIndex: Int, expandedListItemIndex: Int) {
        buildingsAdapter.buildings = buildings
        buildingsAdapter.expandedItemPosition = expandedListItemIndex
        buildingsAdapter.notifyDataSetChanged()
        dotsAdapter.setDotsAmount(buildings.size, swipeBuildingIndex)
        dotsAdapter.notifyDataSetChanged()
    }

    private fun showProgress(state: BuildingsState.UpdateState, viewMode: BuildingsState.ViewMode) {
        swipe_refresh_layout.isRefreshing = state.refreshing

        when {
            state.progressBarVisible -> showProgress()
            !state.refreshing && state.launchFirstTime -> view_animator.postDelayed(showBuildings(state, viewMode), DELAY_MILLIS)
            state.error.value != DEFAULT_ERROR || state.refreshing && state.noNetworkData -> showError(state)
            !state.launchFirstTime && !state.noNetworkData -> view_animator.post(showBuildings(state, viewMode))
        }
    }

    private fun handleDownloadFinished(event: SingleEvent<Boolean>) {
        if (event.needToShow && event.value) {
            startActivity(Intent(this, MapsActivity::class.java))
        }
    }

    private fun showNoNetworkToast(event: SingleEvent<Boolean>) {
        if (event.needToShow && event.value) {
            toast(R.string.no_network_toast)
        }
    }

    private fun showProgress() {
        window.changeStatusBarColor(R.color.transparent)
        swipe_refresh_layout.isEnabled = false
        view_animator.show(launch_progress)
    }

    private fun showError(update: BuildingsState.UpdateState) {
        window.changeStatusBarColor(R.color.transparent)
        swipe_refresh_layout.isEnabled = true
        view_animator.show(launch_error)
        launch_error_text.setText(update.error.value)
    }

    private fun showBuildings(state: BuildingsState.UpdateState, mode: BuildingsState.ViewMode) = when (mode) {
        BuildingsState.ViewMode.LIST -> Runnable {
            buildingsAdapter.viewType = BuildingsAdapter.ViewType.LIST
            view_animator.show(buildings_list_container)
            swipe_refresh_layout.isEnabled = true
            state.launchFirstTime = false
        }

        BuildingsState.ViewMode.SWIPE -> Runnable {
            window.changeStatusBarColor(R.color.colorPrimaryDark)
            buildingsAdapter.viewType = BuildingsAdapter.ViewType.PAGINATION
            view_animator.show(slide_building_list)
            swipe_refresh_layout.isEnabled = true
            state.launchFirstTime = false
        }
    }

    private fun launchPositionSharing() {
        val isSwitcherOn = PreferenceManager
                .getDefaultSharedPreferences(this)
                .getBoolean(getString(R.string.syncing_switcher_key), false)
        if (isSwitcherOn) {
            setAlarm(this)
        } else {
            cancelAlarm(this)
        }
    }

    companion object {
        private const val RC_PERMISSION_ALL = 1
        private const val DELAY_MILLIS = 2000L
    }
}
