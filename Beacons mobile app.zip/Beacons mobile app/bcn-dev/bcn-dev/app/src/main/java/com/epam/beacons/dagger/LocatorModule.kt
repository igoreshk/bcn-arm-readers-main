package com.epam.beacons.dagger

import dagger.Module
import dagger.Provides
import org.apache.commons.math3.fitting.leastsquares.LeastSquaresOptimizer
import org.apache.commons.math3.fitting.leastsquares.LevenbergMarquardtOptimizer
import javax.inject.Singleton

@Module
object LocatorModule {

    @JvmStatic
    @Provides
    @Singleton
    fun provideLeastSquaresOptimizer(): LeastSquaresOptimizer = LevenbergMarquardtOptimizer()
}
