package com.epam.beacons.ui.widget.floorselector

import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.os.Parcelable
import androidx.recyclerview.widget.GridLayoutManager
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import com.epam.beacons.R
import com.epam.beacons.uimodel.FloorSelectorItem
import com.epam.beacons.utils.extensions.dimenPx
import com.epam.beacons.utils.extensions.doOnFinish
import com.epam.beacons.utils.extensions.doOnStart
import com.epam.beacons.utils.extensions.toAnimator
import kotlinx.android.synthetic.main.floor_selector_main.view.floor_selector_recycler as fsRecycler
import kotlinx.android.synthetic.main.floor_selector_main.view.floor_selector_shadow_container as fsShadow

class FloorSelector @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr),
        FloorSelectorAdapter.OnItemClickListener {

    var floorListener: FloorListener? = null

    var animationListener: AnimationListener? = null

    private var adapter: FloorSelectorAdapter

    private var layoutManager: RtlGridLayoutManager

    private val itemSizePx = context.dimenPx(R.dimen.fs_element_height)

    private val translationLeft = context.dimenPx(R.dimen.fs_side_margin).toFloat()

    private val marginLayoutParams: MarginLayoutParams?

    private var portrait = true

    private var restored = false

    private var closed = true

    private var routeActive = false

    private val animationHelper: FloorSelectorAnimationHelper

    init {
        inflate(context, R.layout.floor_selector_main, this)

        layoutManager = RtlGridLayoutManager(context, 1, GridLayoutManager.HORIZONTAL, false)
        adapter = FloorSelectorAdapter(context)
        fsRecycler.apply {
            layoutManager = this@FloorSelector.layoutManager
            adapter = this@FloorSelector.adapter
        }
        adapter.onItemClickListener = this@FloorSelector

        animationHelper = FloorSelectorAnimationHelper()
        animationHelper.initAnimatorsOnStart()

        marginLayoutParams = fsRecycler.layoutParams as? ViewGroup.MarginLayoutParams
        portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
    }

    fun setData(floorNumbers: List<FloorSelectorItem>) {
        layoutManager.spanCount = calculateSpanCount(floorNumbers.size)

        adapter.floorNumbers = floorNumbers

        initAnimators(floorNumbers)
    }

    private fun initAnimators(floorNumbers: List<FloorSelectorItem>) {
        val rowAnimValue = layoutManager.spanCount * itemSizePx - itemSizePx
        val numberOfRows = if (floorNumbers.size <= MAX_ROW_COUNT) {
            DEFAULT_NUMBER_OF_ROWS
        } else {
            Math.ceil(floorNumbers.size.toDouble() / MAX_ROW_COUNT).toInt()
        }
        val columnAnimValue = itemSizePx * numberOfRows - itemSizePx
        animationHelper.initAnimators(rowAnimValue, columnAnimValue, numberOfRows == 1)
    }

    fun show() {
        if (visibility != View.VISIBLE && animationHelper.animationFinished) {
            if (restored && !closed) {
                fsShadow.setBackgroundResource(R.drawable.fs_shadow_background)
                visibility = View.VISIBLE
            } else {
                resetParams()
                visibility = View.VISIBLE
                animationHelper.animateDown()
            }

            closed = false
            restored = false
        }
    }

    private fun resetParams() {
        marginLayoutParams?.setMargins(0, 0, 0, 0)
        fsRecycler.apply {
            setPadding(DEFAULT_PADDING, DEFAULT_PADDING, DEFAULT_PADDING, DEFAULT_PADDING)
            layoutParams = marginLayoutParams
        }
    }

    fun hide(searchInFocus: Boolean) {
        if (visibility != View.GONE) {
            if (searchInFocus) {
                visibility = View.GONE
            } else if (animationHelper.animationFinished) {
                animationHelper.animateUp()
            }
            closed = true
        }
    }

    override fun onSaveInstanceState(): Parcelable = Bundle().apply {
        putParcelable(SUPER_KEY, super.onSaveInstanceState())
        putBoolean(RESTORE_KEY, true)
        putBoolean(CLOSE_KEY, closed)
        if (adapter.floorNumbers.isNotEmpty()) {
            putParcelableArrayList(DATA_KEY, ArrayList(adapter.floorNumbers))
        }
    }

    override fun onRestoreInstanceState(state: Parcelable?) {
        if (state !is Bundle) {
            super.onRestoreInstanceState(state)
            return
        }

        restored = state.getBoolean(RESTORE_KEY)
        closed = state.getBoolean(CLOSE_KEY)
        state.getParcelableArrayList<FloorSelectorItem>(DATA_KEY)?.let { setData(it) }
        super.onRestoreInstanceState(state.getParcelable(SUPER_KEY))
    }

    override fun onItemSelected(floorItem: FloorSelectorItem) {
        floorListener?.onFloorItemClicked(floorItem)
    }

    private fun calculateSpanCount(floorNumbers: Int): Int {
        if (!portrait) {
            layoutManager.orientation = GridLayoutManager.VERTICAL
        }
        return if (floorNumbers < MAX_ROW_COUNT) floorNumbers else MAX_ROW_COUNT
    }

    fun onRouteActive() {
        if (!routeActive) {
            routeActive = true
            translationX = -translationLeft
        }
    }

    fun onRouteNonActive() {
        if (routeActive) {
            routeActive = false
            animationHelper.moveViewRight.start()
        }
    }

    interface FloorListener {
        fun onFloorItemClicked(floorItem: FloorSelectorItem)
    }

    interface AnimationListener {
        fun onAnimationChanged(finished: Boolean)
    }

    inner class FloorSelectorAnimationHelper {
        lateinit var moveViewRight: ObjectAnimator

        private var firstItemAnimator: ValueAnimator? = null
        private var singleRowAnimator: ValueAnimator? = null
        private var multipleRowsAnimator: AnimatorSet? = null
        private var alphaAnimator: ValueAnimator? = null

        private val decelerateInterpolator = DecelerateInterpolator()
        private val accelerateInterpolator = AccelerateInterpolator()

        private var multiRowBottomPadding = 0
        private var multiRowLeftPadding = 0

        private var rowAnimValue = 0
        private var columnAnimValue = 0
        private var isSingleRow = true

        var animationFinished = true

        fun initAnimatorsOnStart() {
            moveViewRight = toAnimator(View.TRANSLATION_X, 0f, TRANSITION_DURATION, accelerateInterpolator)
        }

        fun initAnimators(rowAnimValue: Int, columnAnimValue: Int, isSingleRow: Boolean) {
            this.rowAnimValue = rowAnimValue
            this.columnAnimValue = columnAnimValue
            this.isSingleRow = isSingleRow
        }

        fun animateUp() {
            firstItemAnimator = firstItemAnimator(isSingleRow, 0, -itemSizePx / 2, Direction.UP)
            alphaAnimator = alphaAnimator(MED_ALPHA, MIN_ALPHA, Direction.UP)

            if (isSingleRow) {
                singleRowAnimator = singleRowAnimator(0, -rowAnimValue, Direction.UP)
                singleRowAnimator?.start()
            } else {
                multipleRowsAnimator = multipleRowsAnimator(0, -rowAnimValue, 0, -columnAnimValue, Direction.UP)
                multipleRowsAnimator?.start()
            }

            alphaAnimator?.start()
        }

        fun animateDown() {
            firstItemAnimator = firstItemAnimator(isSingleRow, -itemSizePx / 2, 0, Direction.DOWN)
            alphaAnimator = alphaAnimator(MIN_ALPHA, MAX_ALPHA, Direction.DOWN)

            if (isSingleRow) {
                singleRowAnimator = singleRowAnimator(-rowAnimValue, 0, Direction.DOWN)
            } else {
                multipleRowsAnimator = multipleRowsAnimator(-rowAnimValue, 0, -columnAnimValue, 0, Direction.DOWN)
            }

            alphaAnimator?.start()
            firstItemAnimator?.start()
        }

        private fun firstItemAnimator(isSingleRow: Boolean, startValue: Int, endValue: Int, direction: Direction) =
                ValueAnimator.ofInt(startValue, endValue).apply {
                    duration = FIRST_ITEM_ANIM_DURATION
                    interpolator = if (direction === Direction.UP) decelerateInterpolator else accelerateInterpolator

                    if (isSingleRow) updateFirstItemSingleRow() else updateFirstItemMultiRows()

                    onFirstItemEvent(direction)
                }

        //all casts are absolutely safe here
        @Suppress("UnsafeCast")
        private fun ValueAnimator.updateFirstItemSingleRow() {
            addUpdateListener {
                val value = it.animatedValue as Int
                if (portrait) {
                    fsRecycler.setPadding(value, 0, value, -rowAnimValue + value * 2)
                } else {
                    fsRecycler.setPadding(-rowAnimValue + value, 0, value, value * 2)
                }
                updateFirstItemCommonValues()
            }
        }

        //all casts are absolutely safe here
        @Suppress("UnsafeCast")
        private fun ValueAnimator.updateFirstItemMultiRows() {
            addUpdateListener {
                val value = it.animatedValue as Int
                if (portrait) {
                    fsRecycler.setPadding(-columnAnimValue + value, 0, value, -rowAnimValue + value * 2)
                } else {
                    fsRecycler.setPadding(-rowAnimValue + value, 0, value, -columnAnimValue + value * 2)
                }
                updateFirstItemCommonValues()
            }
        }

        //all casts are absolutely safe here
        @Suppress("UnsafeCast")
        private fun ValueAnimator.updateFirstItemCommonValues() {
            marginLayoutParams?.setMargins(0, 0, Math.abs(animatedValue as Int), 0)
            fsRecycler.layoutParams = marginLayoutParams
        }

        private fun Animator.onFirstItemEvent(direction: Direction) {
            doOnStart {
                if (direction === Direction.DOWN) {
                    animationFinished = false
                    animationListener?.onAnimationChanged(false)
                }
            }
            doOnFinish {
                if (direction === Direction.UP) {
                    visibility = View.GONE
                    animationFinished = true
                    animationListener?.onAnimationChanged(true)
                } else {
                    fsShadow.setBackgroundResource(R.drawable.fs_shadow_background)
                    singleRowAnimator?.start()
                    multipleRowsAnimator?.start()
                }
            }
        }

        //all casts are absolutely safe here
        @Suppress("UnsafeCast")
        private fun singleRowAnimator(startValue: Int, endValue: Int, direction: Direction) =
                ValueAnimator.ofInt(startValue, endValue).apply {
                    duration = ANIM_DURATION
                    interpolator = if (direction === Direction.UP) accelerateInterpolator else decelerateInterpolator

                    addUpdateListener {
                        if (portrait) {
                            fsRecycler.setPadding(0, 0, 0, it.animatedValue as Int)
                        } else {
                            fsRecycler.setPadding(it.animatedValue as Int, 0, 0, 0)
                        }
                    }
                    onRowItemsEvent(direction)
                }

        private fun multipleRowsAnimator(startHeight: Int, endHeight: Int, startWidth: Int, endWidth: Int, direction: Direction): AnimatorSet {
            val heightAnimator = setHeightAnimator(startHeight, endHeight)
            val widthAnimator = setWidthAnimator(startWidth, endWidth)

            return AnimatorSet().apply {
                playTogether(heightAnimator, widthAnimator)
                duration = ANIM_DURATION
                interpolator = if (direction === Direction.UP) accelerateInterpolator else decelerateInterpolator
                onRowItemsEvent(direction)
            }
        }

        //all casts are absolutely safe here
        @Suppress("UnsafeCast")
        private fun setHeightAnimator(startHeight: Int, endHeight: Int) =
                ValueAnimator.ofInt(startHeight, endHeight).apply {
                    addUpdateListener {
                        if (portrait) {
                            multiRowBottomPadding = it.animatedValue as Int
                            fsRecycler.setPadding(multiRowLeftPadding, 0, 0, multiRowBottomPadding)
                        } else {
                            multiRowLeftPadding = it.animatedValue as Int
                            fsRecycler.setPadding(multiRowLeftPadding, 0, 0, multiRowBottomPadding)
                        }
                    }
                }

        //all casts are absolutely safe here
        @Suppress("UnsafeCast")
        private fun setWidthAnimator(startWidth: Int, endWidth: Int) =
                ValueAnimator.ofInt(startWidth, endWidth).apply {
                    addUpdateListener {
                        if (portrait) {
                            multiRowLeftPadding = it.animatedValue as Int
                            fsRecycler.setPadding(multiRowLeftPadding, 0, 0, multiRowBottomPadding)
                        } else {
                            multiRowBottomPadding = it.animatedValue as Int
                            fsRecycler.setPadding(multiRowLeftPadding, 0, 0, multiRowBottomPadding)
                        }
                    }
                }

        private fun Animator.onRowItemsEvent(direction: Direction) {
            doOnStart {
                if (direction === Direction.UP) {
                    animationFinished = false
                    animationListener?.onAnimationChanged(false)
                }
            }
            doOnFinish {
                if (direction === Direction.UP) {
                    fsShadow.background = null
                    firstItemAnimator?.start()
                } else {
                    animationFinished = true
                    animationListener?.onAnimationChanged(true)
                }
            }
        }

        //all casts are absolutely safe here
        @Suppress("UnsafeCast")
        private fun alphaAnimator(startValue: Int, endValue: Int, direction: Direction) =
                ValueAnimator.ofInt(startValue, endValue).apply {
                    duration = if (direction === Direction.DOWN) ALPHA_DURATION_DOWN else ALPHA_DURATION_UP

                    addUpdateListener {
                        for (i in 0 until adapter.itemCount) {
                            adapter.getItem(i).alpha = it.animatedValue as Int
                        }
                        adapter.notifyDataSetChanged()
                    }
                }
    }

    companion object {
        private const val DEFAULT_NUMBER_OF_ROWS = 1
        private const val MAX_ROW_COUNT = 10
        private const val RESTORE_KEY = "restore"
        private const val CLOSE_KEY = "close"
        private const val SUPER_KEY = "super"
        private const val DATA_KEY = "data"
        private const val FIRST_ITEM_ANIM_DURATION = 200L
        private const val TRANSITION_DURATION = 200L
        private const val ANIM_DURATION = 400L
        private const val ALPHA_DURATION_DOWN = 800L
        private const val ALPHA_DURATION_UP = 500L
        private const val MAX_ALPHA = 255
        private const val MED_ALPHA = 200
        private const val MIN_ALPHA = 0
        private const val DEFAULT_PADDING = Integer.MIN_VALUE
    }

    enum class Direction {
        UP,
        DOWN
    }
}
