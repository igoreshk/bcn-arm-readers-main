package com.epam.beacons.utils.mappers

import com.epam.beacons.Building
import com.epam.beacons.tools.Mapper
import com.epam.beacons.uimodel.BuildingItem
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BuildingToBuildingItemMapper @Inject constructor() : Mapper<Building, BuildingItem>() {

    override fun map(from: Building) = BuildingItem(from.entityId, from.address, from.width, from.height,
            from.name, from.phoneNumber, from.workingHours)
}
