package com.epam.beacons.record

import com.epam.beacons.base.modern.BaseState
import com.epam.beacons.uimodel.RecordStateModel

class RecordDataState(
        var recordState: RecordStateModel,
        var fileName: String?
) : BaseState()
