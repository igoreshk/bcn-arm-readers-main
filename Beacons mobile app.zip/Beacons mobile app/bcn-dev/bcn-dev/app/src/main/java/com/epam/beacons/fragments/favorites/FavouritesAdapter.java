package com.epam.beacons.fragments.favorites;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.epam.beacons.R;
import com.epam.beacons.uimodel.SearchItem;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class FavouritesAdapter extends RecyclerView.Adapter<FavouritesAdapter.ItemViewHolder> {

    @Nullable
    private ItemClickListener itemClickListener;

    @NonNull
    private List<SearchItem> list = new ArrayList<>();

    @Inject
    FavouritesAdapter() { // default constructor for dagger
    }

    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        final View viewItem = LayoutInflater.from(parent.getContext()).inflate(R.layout.favorites_item, parent, false);
        final ItemViewHolder holder = new ItemViewHolder(viewItem);
        viewItem.setOnClickListener(v -> {
            if (itemClickListener != null) {
                itemClickListener.onClick(getSearchItem(holder.getAdapterPosition()));
            }
        });
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        final SearchItem searchItem = getSearchItem(position);
        holder.name.setText(String.format("%s", searchItem.getTitle()));
        holder.description.setText(String.format("%s", searchItem.getSecondaryTitle()));
    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    @NonNull
    private SearchItem getSearchItem(int position) {
        return list.get(position);
    }

    @SuppressWarnings("unused")
    public void setData(@NonNull List<SearchItem> newList) {
        list = newList;
        notifyDataSetChanged();
    }

    void setItemClickListener(@NonNull ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    public interface ItemClickListener {
        @SuppressWarnings({"EmptyMethod", "unused"})
        void onClick(@NonNull SearchItem item);
    }


    class ItemViewHolder extends RecyclerView.ViewHolder {
        final TextView  name;
        final TextView  description;
        final ImageView leftIcon;
        final ImageView rightIcon;

        ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.item_name);
            description = itemView.findViewById(R.id.item_description);
            leftIcon = itemView.findViewById(R.id.favorites_item_left_icon);
            rightIcon = itemView.findViewById(R.id.favorites_item_right_icon);
        }
    }
}