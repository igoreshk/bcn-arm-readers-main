package com.epam.beacons.ui.widget

import android.animation.ObjectAnimator
import android.content.Context
import android.os.Bundle
import android.os.Parcelable
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import com.epam.beacons.R
import com.epam.beacons.utils.extensions.dimenPxFloat
import com.epam.beacons.utils.extensions.doOnFinish
import com.epam.beacons.utils.extensions.doOnStart
import com.epam.beacons.utils.extensions.visible
import kotlinx.android.synthetic.main.view_add_bookmark.view.*

class AddBookmarkView @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    var closeListener: CloseListener? = null

    private var isAnimationFinished = true
    private var isRestored = false
    private var isClosed = true

    private val hiddenTranslation = -context.dimenPxFloat(R.dimen.add_bookmark_panel_height)

    private val showAnimator: ObjectAnimator
    private val hideAnimator: ObjectAnimator

    init {
        inflate(context, R.layout.view_add_bookmark, this)

        close_add_bookmark.setOnClickListener { closeListener?.onCloseClick() }

        showAnimator = ObjectAnimator.ofFloat(this, "translationY", hiddenTranslation, 0f).apply {
            doOnStart(false) { isAnimationFinished = false }
            doOnFinish(false) { isAnimationFinished = true }
        }
        hideAnimator = ObjectAnimator.ofFloat(this, "translationY", 0f, hiddenTranslation).apply {
            doOnStart(false) { isAnimationFinished = false }
            doOnFinish(false) {
                isAnimationFinished = true
                visible(false)
            }
        }
    }

    fun show() {
        if (isAnimationFinished && visibility == View.GONE) {
            visible(true)

            if (isRestored && !isClosed) translationY = 0f else showAnimator.start()

            isRestored = false
            isClosed = false
        }
    }

    fun hide() {
        if (isAnimationFinished && visibility == View.VISIBLE) {
            isClosed = true
            hideAnimator.start()
        }
    }

    override fun onSaveInstanceState(): Parcelable = Bundle().apply {
        putParcelable(SUPER_KEY, super.onSaveInstanceState())
        putBoolean(CLOSED_KEY, isClosed)
    }

    override fun onRestoreInstanceState(state: Parcelable?) {
        if (state !is Bundle) {
            super.onRestoreInstanceState(state)
            return
        }

        isRestored = true
        isClosed = state.getBoolean(CLOSED_KEY)

        super.onRestoreInstanceState(state.getParcelable(SUPER_KEY))
    }

    interface CloseListener {
        fun onCloseClick()
    }

    companion object {
        private const val SUPER_KEY = "superKey"
        private const val CLOSED_KEY = "closedKey"
    }
}
