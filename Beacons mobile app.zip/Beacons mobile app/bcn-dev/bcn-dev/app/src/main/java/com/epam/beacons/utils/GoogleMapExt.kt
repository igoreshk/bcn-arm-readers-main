package com.epam.beacons.utils

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.TimeInterpolator
import android.animation.TypeEvaluator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import android.util.Property
import android.view.animation.DecelerateInterpolator
import com.epam.beacons.utils.extensions.doOnFinish
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.Circle
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.Marker

val markerPositionProperty: Property<Marker, LatLng> = object : Property<Marker, LatLng>(LatLng::class.java, "markerPosition") {
    override fun get(target: Marker) = target.position
    override fun set(target: Marker, value: LatLng) {
        target.position = value
    }
}

val circlePositionProperty: Property<Circle, LatLng> = object : Property<Circle, LatLng>(LatLng::class.java, "circlePosition") {
    override fun get(target: Circle) = target.center
    override fun set(target: Circle, value: LatLng) {
        target.center = value
    }
}

val latLngEvaluator = TypeEvaluator<LatLng>(function = { fraction, startValue, endValue ->
    return@TypeEvaluator startValue + (endValue - startValue) * fraction
})

fun GoogleMap.doOnMapLoaded(func: () -> Unit) {
    setOnMapLoadedCallback {
        func()
    }
}

fun GoogleMap.moveTo(center: LatLngBounds) {
    moveCamera(CameraUpdateFactory.newLatLngBounds(center, 0))
}

fun GoogleMap.moveToWithZoom(center: LatLng, zoom: Float) {
    moveCamera(CameraUpdateFactory.newLatLngZoom(center, zoom))
}

fun GoogleMap.animateTo(center: LatLng) {
    animateCamera(CameraUpdateFactory.newLatLng(center))
}

fun GoogleMap.animateToWithZoom(center: LatLng, callback: GoogleMap.CancelableCallback?, zoom: Float) {
    animateCamera(CameraUpdateFactory.newLatLngZoom(center, zoom), callback)
}

fun Marker.animateTo(end: LatLng, duration: Long = DEFAULT_DURATION, interpolator: TimeInterpolator = DecelerateInterpolator()) {
    (tag as? Animator?)?.cancel()

    val animator = ObjectAnimator.ofObject(this, markerPositionProperty, latLngEvaluator, position, end)
            .setDuration(duration)

    animator.interpolator = interpolator
    animator.doOnFinish { tag = null }

    animator.start()

    tag = animator
}

fun Circle.animateTo(end: LatLng, duration: Long = DEFAULT_DURATION, interpolator: TimeInterpolator = DecelerateInterpolator()) {
    (tag as? Animator?)?.cancel()

    val animator = ObjectAnimator.ofObject(this, circlePositionProperty, latLngEvaluator, center, end)
            .setDuration(duration)

    animator.interpolator = interpolator
    animator.doOnFinish { tag = null }

    animator.start()

    tag = animator
}

private operator fun LatLng.times(times: Float) = LatLng(this.latitude * times, this.longitude * times)

private operator fun LatLng.minus(minus: LatLng) = LatLng(this.latitude - minus.latitude, this.longitude - minus.longitude)

private operator fun LatLng.plus(plus: LatLng) = LatLng(this.latitude + plus.latitude, this.longitude + plus.longitude)

fun createLatLngBounds(vararg latLngs: LatLng): LatLngBounds {
    val builder = LatLngBounds.Builder()
    latLngs.forEach { builder.include(it) }
    return builder.build()
}

fun vectorToMarker(context: Context, @DrawableRes id: Int): BitmapDescriptor? {
    val vectorDrawable = ContextCompat.getDrawable(context, id) ?: return null
    val bitmap = Bitmap.createBitmap(vectorDrawable.intrinsicWidth, vectorDrawable.intrinsicHeight, Bitmap.Config.ARGB_8888)

    val canvas = Canvas(bitmap)
    vectorDrawable.setBounds(0, 0, canvas.width, canvas.height)
    vectorDrawable.draw(canvas)

    return BitmapDescriptorFactory.fromBitmap(bitmap)
}

private const val DEFAULT_DURATION = 500L
