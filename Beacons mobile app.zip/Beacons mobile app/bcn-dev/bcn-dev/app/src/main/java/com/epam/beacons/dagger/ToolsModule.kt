package com.epam.beacons.dagger

import com.epam.beacons.tools.CornerHelper
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.ScaleFactorCalculator
import com.epam.beacons.utils.Constants
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object ToolsModule {

    @JvmStatic
    @Provides
    @Singleton
    fun provideScaleFactorCalculator(coordinateDistanceCalculator: CoordinateDistanceCalculator) =
            ScaleFactorCalculator(coordinateDistanceCalculator, Constants.ONE_METER_AT_EQUATOR)

    @JvmStatic
    @Provides
    @Singleton
    fun provideCornerHelper(scaleFactorCalculator: ScaleFactorCalculator, distanceCalculator: CoordinateDistanceCalculator) =
            CornerHelper(scaleFactorCalculator, distanceCalculator, Constants.ONE_METER_AT_EQUATOR)
}
