package com.epam.beacons.utils.mappers

import android.content.Context
import androidx.annotation.DrawableRes
import com.epam.beacons.Place
import com.epam.beacons.PlaceTypes
import com.epam.beacons.R
import com.epam.beacons.uimodel.MarkerModel
import com.epam.beacons.tools.Mapper
import com.epam.beacons.utils.vectorToMarker
import com.google.android.gms.maps.model.MarkerOptions
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PlaceToMarkerMapper @Inject constructor(
        private val context: Context,
        private val coordinateMapper: CoordinatesToLatLngsMapper
) : Mapper<Place, MarkerModel>() {

    override fun map(from: Place): MarkerModel {
        val id = iconIdByType(from.type.toString())
        return MarkerModel(
                MarkerOptions()
                        .position(coordinateMapper.map(from.coordinate))
                        .icon(vectorToMarker(context, id))
                        .title(formatTitle(from)),
                id)
    }

    private fun formatTitle(place: Place) = "${place.type} ${place.description}"

    @DrawableRes
    private fun iconIdByType(type: String): Int {
        return when (type) {
            PlaceTypes.ROOM -> R.drawable.ic_room
            PlaceTypes.RESTROOM -> R.drawable.ic_restroom
            PlaceTypes.REST_AREA -> R.drawable.ic_rest_area
            PlaceTypes.CAFE -> R.drawable.ic_coffee
            PlaceTypes.UNKNOWN -> R.drawable.ic_destination
            else -> R.drawable.ic_destination
        }
    }
}
