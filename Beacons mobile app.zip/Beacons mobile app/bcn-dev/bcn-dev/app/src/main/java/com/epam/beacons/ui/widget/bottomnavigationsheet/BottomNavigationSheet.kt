package com.epam.beacons.ui.widget.bottomnavigationsheet

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.os.Parcelable
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.android.material.bottomsheet.BottomSheetBehavior
import androidx.coordinatorlayout.widget.CoordinatorLayout
import android.transition.ChangeBounds
import android.transition.Fade
import android.transition.TransitionManager
import android.transition.TransitionSet
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import com.epam.beacons.R
import com.epam.beacons.uimodel.bottomnavigationsheet.DestinationItem
import com.epam.beacons.uimodel.bottomnavigationsheet.RouteItem
import com.epam.beacons.utils.extensions.dimenPx
import com.epam.beacons.utils.extensions.doOnFinish
import com.epam.beacons.utils.extensions.doOnStart
import com.epam.beacons.utils.extensions.drawable
import com.epam.beacons.utils.extensions.isClickableAndFocusable
import com.epam.beacons.utils.extensions.string
import com.epam.beacons.utils.extensions.toAnimator
import com.epam.beacons.utils.extensions.toast
import com.epam.beacons.utils.extensions.visible
import kotlinx.android.synthetic.main.bottom_nav_sheet.view.*
import kotlin.math.min

class BottomNavigationSheet
@JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0)
    : ConstraintLayout(context, attrs, defStyleAttr) {

    var listener: Listener? = null
    var route: List<RouteItem> = emptyList()
        set(value) {
            if (field != value) {
                field = value
                if (mode == Mode.START) maxHeight(value.size)
                TransitionManager.beginDelayedTransition(this, routeTransition)
                routeAdapter.items = value
            }
        }
    var destination = DestinationItem()
        set(value) {
            if (field != value) {
                field = value
                if (mode == Mode.PRE_ROUTE || mode == Mode.ROUTE) {
                    if (value.isFavorite) {
                        bn_left_image.setImageDrawable(context.drawable(R.drawable.ic_remove))
                        bn_left_text.text = context.string(R.string.bottom_sheet_remove_text)
                    } else {
                        bn_left_image.setImageDrawable(context.drawable(R.drawable.ic_save))
                        bn_left_text.text = context.string(R.string.bottom_sheet_save_text)
                    }
                }
                bn_destination_distance.text = context.getString(R.string.bottom_sheet_destination_distance, value.distance)
                bn_destination_description.text = value.description
            }
        }
    private val routeTransition = TransitionSet().addTransition(ChangeBounds()).addTransition(Fade())
            .setOrdering(TransitionSet.ORDERING_TOGETHER)
    private var routeAdapter: RouteDetailsAdapter
    private val animationHelper: AnimationHelper
    private var behavior: BottomSheetBehavior<BottomNavigationSheet>? = null
    private var behaviorInitialized = false
    private val peekHeight = context.dimenPx(R.dimen.bn_peek_height).toFloat()
    private val size = context.dimenPx(R.dimen.bn_route_item_height)
    private val mxHeightV = context.dimenPx(R.dimen.bn_max_height)
    private val mxHeightH = context.dimenPx(R.dimen.bn_max_height_h)
    private val marginTop = context.dimenPx(R.dimen.bn_recycler_view_margin_top) * 2
    private var mode = Mode.HIDDEN
    private var portrait = true
    private var restored = false

    init {
        inflate(context, R.layout.bottom_nav_sheet, this)
        routeAdapter = RouteDetailsAdapter(context)
        bn_route_details_recycler.apply {
            layoutManager = NonScrollableLinearLayoutManager(context)
            isNestedScrollingEnabled = false
            adapter = routeAdapter
        }
        bn_route_button.setOnClickListener { onStartRouteClick() }
        bn_right_button.setOnClickListener { onRightButtonClick() }
        bn_left_button.setOnClickListener { onLeftButtonClick() }
        animationHelper = AnimationHelper()
        animationHelper.initAnimators()

        portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
    }

    private fun maxHeight(amount: Int) {
        layoutParams = (layoutParams as? CoordinatorLayout.LayoutParams)?.apply {
            if (amount > 0) height = min(amount * size + marginTop, if (portrait) mxHeightV else mxHeightH)
        }
        bn_draggable_line.visible(amount > 1)
    }

    override fun onSaveInstanceState(): Parcelable = Bundle().apply {
        putParcelable(SUPER_STATE, super.onSaveInstanceState())
        putSerializable(MODE_STATE, mode)
    }

    override fun onRestoreInstanceState(state: Parcelable?) {
        if (state !is Bundle) {
            super.onRestoreInstanceState(state)
            return
        }
        restored = true
        (state.getSerializable(MODE_STATE) as? Mode)?.let { mode = it }
        super.onRestoreInstanceState(state.getParcelable(SUPER_STATE))
    }

    fun show() {
        if (visibility != View.VISIBLE && animationHelper.animationFinished) {
            if (!behaviorInitialized) {
                behavior = BottomSheetBehavior.from(this)
                behaviorInitialized = true
            }
            if (restored) {
                restoreState()
            } else {
                translationY = peekHeight
                animationHelper.moveUp.start()
            }
        }
    }

    fun hide(routingError: Boolean) {
        if (visibility != View.GONE && animationHelper.animationFinished || routingError) {
            behavior?.state = BottomSheetBehavior.STATE_COLLAPSED
            translationY = 0f
            mode = Mode.HIDDEN
            animationHelper.moveDown.start()
        }
    }

    @Suppress("NON_EXHAUSTIVE_WHEN")
    private fun restoreState() {
        mode.let {
            when (it) {
                Mode.PRE_ROUTE -> visible(true)
                Mode.ROUTE -> {
                    bn_route_button.text = context.string(R.string.bottom_sheet_start_text)
                    visible(true)
                }
                Mode.START -> {
                    maxHeight(route.size)
                    visible(true)
                    bn_right_button.visible(true)
                    bn_right_line.translationX = START_TRANSLATION
                    bn_right_text.translationX = START_TRANSLATION
                    bn_right_image.translationX = START_TRANSLATION
                    bn_route_details_recycler.alpha = MAX_ALPHA
                    bn_route_details_recycler.visible(true)
                    bn_right_gradient.alpha = MAX_ALPHA
                    bn_right_gradient.visible(true)
                    bn_route_button.visible(false)
                    bn_right_line.visible(true)
                    if (route.size > 1) bn_draggable_line.visible(true)
                    bn_right_image.visible(true)
                    bn_right_text.visible(true)
                    bn_destination_description.visible(false)
                    bn_destination_to.visible(false)
                    bn_destination_distance.visible(false)
                    bn_left_image.setImageDrawable(context.drawable(R.drawable.ic_add_stop))
                    bn_left_text.text = context.string(R.string.bottom_sheet_add_stop_text)
                }
            }
        }
        restored = false
    }

    private fun onStartRouteClick() {
        if (mode == Mode.PRE_ROUTE) {
            listener?.onRouteButtonClicked()
            bn_route_button.text = context.string(R.string.bottom_sheet_start_text)
            mode = Mode.ROUTE
        } else if (mode == Mode.ROUTE) {
            if (route.isEmpty()) {
                context.toast(R.string.noRouteFound)
                return
            }
            animationHelper.turnRouteModeOff.start()
            maxHeight(route.size)
            listener?.onStartButtonClicked()
            mode = Mode.START
        }
    }

    private fun onLeftButtonClick() {
        when (mode) {
            Mode.START -> context.toast(R.string.not_implemented_stub)
            else -> {
                listener?.onFavoriteButtonClick(destination.placeId)
                destination.isFavorite = !destination.isFavorite
                if (destination.placeId != DestinationItem.EMPTY_PLACE_ID) {
                    displayFavorite(destination.isFavorite)
                } else {
                    context.toast(R.string.bottom_sheet_cannot_be_saved)
                }
            }
        }
    }

    private fun onRightButtonClick() = context.toast(R.string.not_implemented_stub)

    private fun displayFavorite(isFavorite: Boolean) {
        if (isFavorite) {
            bn_left_text.text = context.string(R.string.bottom_sheet_remove_text)
            bn_left_image.setImageDrawable(context.drawable(R.drawable.ic_remove))
        } else {
            bn_left_text.text = context.string(R.string.bottom_sheet_save_text)
            bn_left_image.setImageDrawable(context.drawable(R.drawable.ic_save))
        }
    }

    private inner class AnimationHelper {
        lateinit var moveDown: ObjectAnimator
        lateinit var moveUp: ObjectAnimator
        lateinit var routeButtonFadeOut: ObjectAnimator
        lateinit var leftImageFadeOut: ObjectAnimator
        lateinit var leftTextFadeOut: ObjectAnimator
        lateinit var destinationDescriptionFadeOut: ObjectAnimator
        lateinit var destinationDistanceFadeOut: ObjectAnimator
        lateinit var destinationToFadeOut: ObjectAnimator
        lateinit var leftImageFadeIn: ObjectAnimator
        lateinit var rightGradientFadeIn: ObjectAnimator
        lateinit var leftTextFadeIn: ObjectAnimator
        lateinit var recyclerFadeIn: ObjectAnimator
        lateinit var moveRightLine: ObjectAnimator
        lateinit var moveRightImage: ObjectAnimator
        lateinit var moveRightText: ObjectAnimator
        lateinit var turnRouteModeOff: AnimatorSet
        lateinit var turnStartModeOn: AnimatorSet
        val decelerate = DecelerateInterpolator()
        val accelerate = AccelerateInterpolator()
        var animationFinished = true

        fun initAnimators() {
            bn_right_line.translationX = context.dimenPx(R.dimen.bn_peek_height).toFloat()
            bn_right_text.translationX = context.dimenPx(R.dimen.bn_peek_height).toFloat()
            bn_right_image.translationX = context.dimenPx(R.dimen.bn_peek_height).toFloat()

            initTurnStartModeOnAnimators()
            initTurnRouteModeOffAnimators()

            moveDown = toAnimator(View.TRANSLATION_Y, peekHeight, ANIM_DURATION, decelerate).apply {
                doOnStart(false) { animationFinished = false }
                doOnFinish(false) {
                    animationFinished = true
                    resetToInitialState()
                }
            }
            moveUp = toAnimator(View.TRANSLATION_Y, START_TRANSLATION, ANIM_DURATION, accelerate).apply {
                doOnStart(false) {
                    animationFinished = false
                    mode = Mode.PRE_ROUTE
                    visible(true)
                }
                doOnFinish(false) { animationFinished = true }
            }
        }

        private fun resetToInitialState() {
            visible(false)
            bn_right_gradient.visible(false)
            bn_route_details_recycler.visible(false)
            bn_draggable_line.visible(false)
            displayFavorite(destination.isFavorite)
            bn_right_line.visible(false)
            bn_right_button.visible(false)
            bn_right_image.visible(false)
            bn_right_text.visible(false)
            bn_destination_description.visible(true)
            bn_destination_distance.visible(true)
            bn_route_button.visible(true)
            bn_destination_to.visible(true)
            bn_route_button.text = context.string(R.string.bottom_sheet_route_text)
            bn_destination_to.alpha = MAX_ALPHA
            bn_destination_description.alpha = MAX_ALPHA
            bn_destination_distance.alpha = MAX_ALPHA
            bn_route_button.alpha = MAX_ALPHA
            maxHeight(1)
        }

        private fun initTurnRouteModeOffAnimators() {
            routeButtonFadeOut = bn_route_button.toAnimator(View.ALPHA, MIN_ALPHA, ANIM_DURATION, accelerate).apply {
                doOnFinish(false) {
                    bn_right_gradient.visible(true)
                    bn_right_button.isClickableAndFocusable(true)
                    bn_route_button.visible(false)
                }
            }
            leftImageFadeOut = bn_left_image.toAnimator(View.ALPHA, MIN_ALPHA, ANIM_DURATION, accelerate).apply {
                doOnFinish(false) { bn_left_image.setImageDrawable(context.drawable(R.drawable.ic_add_stop)) }
            }
            leftTextFadeOut = bn_left_text.toAnimator(View.ALPHA, MIN_ALPHA, ANIM_DURATION, accelerate).apply {
                doOnFinish(false) { bn_left_text.text = context.string(R.string.bottom_sheet_add_stop_text) }
            }
            destinationDescriptionFadeOut = bn_destination_description.toAnimator(View.ALPHA, MIN_ALPHA, ANIM_DURATION, accelerate)
            destinationDistanceFadeOut = bn_destination_distance.toAnimator(View.ALPHA, MIN_ALPHA, ANIM_DURATION, accelerate)
            destinationToFadeOut = bn_destination_to.toAnimator(View.ALPHA, MIN_ALPHA, ANIM_DURATION, accelerate)

            turnRouteModeOff = AnimatorSet().apply {
                play(leftImageFadeOut).with(leftTextFadeOut).with(routeButtonFadeOut)
                        .with(destinationDescriptionFadeOut).with(destinationDistanceFadeOut).with(destinationToFadeOut)
                doOnFinish(false) { turnStartModeOn.start() }
            }
        }

        private fun initTurnStartModeOnAnimators() {
            leftImageFadeIn = bn_left_image.toAnimator(View.ALPHA, MAX_ALPHA, ANIM_DURATION, accelerate)
            leftTextFadeIn = bn_left_text.toAnimator(View.ALPHA, MAX_ALPHA, ANIM_DURATION, accelerate)
            rightGradientFadeIn = bn_right_gradient.toAnimator(View.ALPHA, MAX_ALPHA, ANIM_DURATION, accelerate).apply {
                doOnStart(false) { bn_right_gradient.visible(true) }
            }
            recyclerFadeIn = bn_route_details_recycler.toAnimator(View.ALPHA, MAX_ALPHA, ANIM_DURATION, accelerate).apply {
                doOnStart(false) { bn_route_details_recycler.visible(true) }
            }

            moveRightLine = bn_right_line.toAnimator(View.TRANSLATION_X, START_TRANSLATION, ANIM_DURATION, accelerate)
            moveRightImage = bn_right_image.toAnimator(View.TRANSLATION_X, START_TRANSLATION, ANIM_DURATION, accelerate)
            moveRightText = bn_right_text.toAnimator(View.TRANSLATION_X, START_TRANSLATION, ANIM_DURATION, accelerate)

            turnStartModeOn = AnimatorSet().apply {
                play(leftImageFadeIn).with(leftTextFadeIn).with(recyclerFadeIn).with(rightGradientFadeIn)
                        .with(moveRightLine).with(moveRightText).with(moveRightImage)
                doOnStart(false) {
                    bn_right_line.visible(true)
                    bn_right_text.visible(true)
                    bn_right_image.visible(true)
                    bn_right_button.visible(true)
                }
            }
        }
    }

    interface Listener {
        fun onFavoriteButtonClick(placeId: String)

        fun onRouteButtonClicked()

        fun onStartButtonClicked()
    }

    private enum class Mode {
        PRE_ROUTE, ROUTE, START, HIDDEN
    }

    companion object {
        private const val ANIM_DURATION = 300L
        private const val MAX_ALPHA = 1f
        private const val MIN_ALPHA = 0f
        private const val START_TRANSLATION = 0f
        private const val SUPER_STATE = "superState"
        private const val MODE_STATE = "modeState"
    }
}
