package com.epam.beacons.fragments.favorites;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

import com.epam.beacons.R;
import com.epam.beacons.utils.ThemeUtils;

class FavoritesDrawableItemDecorator extends RecyclerView.ItemDecoration {

    @NonNull
    private final Paint paint;
    private final int   lineThickness;
    private final int   marginStart;

    FavoritesDrawableItemDecorator(@NonNull Context context) {
        paint = new Paint();
        lineThickness = context.getResources().getDimensionPixelSize(R.dimen.favorites_line_height);
        marginStart = context.getResources().getDimensionPixelSize(R.dimen.favorites_horizontal_line_margin_start);
        paint.setColor(ThemeUtils.getColorFromTheme(context, R.attr.iconTintSecondary));
        paint.setStrokeWidth(lineThickness);
    }

    @Override
    public void onDraw(@NonNull Canvas c, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
        final int left = parent.getPaddingLeft() + marginStart;
        final int right = parent.getWidth() - parent.getPaddingRight();

        final int childCount = parent.getChildCount();
        for (int i = 0; i < childCount; i++) {
            final View child = parent.getChildAt(i);
            final RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) child.getLayoutParams();
            final int bottomLineOrdinat = child.getBottom() + params.bottomMargin;
            if (i == childCount - 1) {
                c.drawLine(parent.getPaddingLeft(), child.getBottom(), right, child.getBottom(), paint);
            } else {
                c.drawLine(left, bottomLineOrdinat, right, bottomLineOrdinat, paint);
            }
        }
    }

    @Override
    public void getItemOffsets(@NonNull Rect outRect, @NonNull View view,
                               @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
        outRect.bottom = lineThickness;
    }
}
