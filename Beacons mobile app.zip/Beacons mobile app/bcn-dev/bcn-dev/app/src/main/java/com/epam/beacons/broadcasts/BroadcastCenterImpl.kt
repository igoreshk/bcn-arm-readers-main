package com.epam.beacons.broadcasts

import android.content.Intent
import android.content.IntentFilter
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.epam.beacons.utils.Constants
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BroadcastCenterImpl @Inject constructor(
        private val manager: LocalBroadcastManager,
        cleaningReceiver: CleaningReceiver
) : BroadcastCenter {
    init {
        manager.registerReceiver(cleaningReceiver, IntentFilter(Constants.CLEANING_REQUESTED_ACTION))
    }

    override fun sendLocalBroadcast(action: String) {
        manager.sendBroadcast(Intent(action))
    }
}
