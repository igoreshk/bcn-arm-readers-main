package com.epam.beacons.buildings

import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import com.epam.beacons.ui.widget.dottednavigation.Dot
import javax.inject.Inject

class DotsAdapter @Inject constructor() : RecyclerView.Adapter<DotsAdapter.DotHolder>() {

    private var dotsAmount = -1
    private var currentDotIndex = -1

    private var onDotItemClickListener: OnDotItemClickListener? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DotHolder {
        val viewItem = Dot(parent.context, null, 0)
        val holder = DotHolder(viewItem)

        viewItem.setOnClickListener(View.OnClickListener {
            if (currentDotIndex == holder.adapterPosition) {
                return@OnClickListener
            }

            val previousPosition = currentDotIndex
            currentDotIndex = holder.adapterPosition
            notifyItemChanged(currentDotIndex)
            onDotItemClickListener?.onDotSelected(currentDotIndex)

            if (previousPosition != -1) {
                notifyItemChanged(previousPosition)
            }
        })

        return holder
    }

    override fun getItemCount() = dotsAmount

    override fun onBindViewHolder(holder: DotHolder, position: Int) {
        holder.itemView.isSelected = currentDotIndex == holder.adapterPosition
    }

    override fun getItemId(position: Int) = position.toLong()

    fun changeSelectedDotIndex(previousPosition: Int, currentDotIndex: Int) {
        this.currentDotIndex = currentDotIndex
        notifyItemChanged(previousPosition)
        notifyItemChanged(currentDotIndex)
    }

    fun setDotsAmount(dotsAmount: Int, selectedDotPosition: Int) {
        if (dotsAmount > 1) {
            this.dotsAmount = dotsAmount
            currentDotIndex = 0
            if (selectedDotPosition != 0) {
                currentDotIndex = selectedDotPosition
            }
        }
    }

    fun setOnDotItemClickListener(onDotItemClickListener: OnDotItemClickListener) {
        this.onDotItemClickListener = onDotItemClickListener
    }

    class DotHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    interface OnDotItemClickListener {
        fun onDotSelected(index: Int)
    }
}
