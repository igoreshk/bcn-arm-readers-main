package com.epam.beacons.ui.widget

import android.os.Parcelable
import androidx.annotation.DrawableRes
import kotlinx.android.parcel.Parcelize

@Parcelize
data class BottomNavigationItemModel(
        val title: String?,
        @DrawableRes val iconRes: Int,
        val position: Int,
        var isSelected: Boolean = false,
        var isDotShown: Boolean = false
) : Parcelable
