package com.epam.beacons.ui.widget.dottednavigation

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import com.epam.beacons.R
import com.epam.beacons.utils.extensions.color
import com.epam.beacons.utils.extensions.dimenPx

class Dot : View {

    private val emptyDotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val filledDotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dotStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var dotRadius: Int = 0
    private var emptyDotRadius: Int = 0
    private var dotStrokeRadius: Int = 0

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init(context)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)

        val desiredWeight = context.dimenPx(R.dimen.dot_weight)
        val desiredHeight = context.dimenPx(R.dimen.dot_height)

        setMeasuredDimension(desiredWeight, desiredHeight)
    }

    private fun init(context: Context) {

        dotRadius = context.dimenPx(R.dimen.dot_radius)
        emptyDotRadius = context.dimenPx(R.dimen.dot_radius_empty)
        dotStrokeRadius = context.dimenPx(R.dimen.dot_stroke_radius)

        emptyDotPaint.style = Paint.Style.FILL
        emptyDotPaint.color = context.color(R.color.emptyDotColor)

        filledDotPaint.style = Paint.Style.FILL
        filledDotPaint.color = context.color(R.color.filledDotInnerColor)

        dotStrokePaint.style = Paint.Style.STROKE
        dotStrokePaint.color = context.color(R.color.filledDotOuterColor)
        dotStrokePaint.strokeWidth = dotStrokeRadius.toFloat()
    }

    override fun onDraw(canvas: Canvas) {
        val widthPivot = width / 2
        val heightPivot = height / 2

        if (isSelected) {
            canvas.drawCircle(widthPivot.toFloat(), heightPivot.toFloat(), dotRadius.toFloat(), dotStrokePaint)
            canvas.drawCircle(widthPivot.toFloat(), heightPivot.toFloat(), dotRadius.toFloat(), filledDotPaint)
        } else {
            canvas.drawCircle(widthPivot.toFloat(), heightPivot.toFloat(), emptyDotRadius.toFloat(), emptyDotPaint)
        }

        super.onDraw(canvas)
    }
}
