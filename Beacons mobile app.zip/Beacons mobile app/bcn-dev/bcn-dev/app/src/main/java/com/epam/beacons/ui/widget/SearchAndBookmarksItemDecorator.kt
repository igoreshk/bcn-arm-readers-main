package com.epam.beacons.ui.widget

import android.content.Context
import android.graphics.Canvas
import androidx.recyclerview.widget.RecyclerView
import com.epam.beacons.R
import com.epam.beacons.utils.extensions.dimenPx
import com.epam.beacons.utils.extensions.drawableOrDefault
import com.epam.beacons.utils.extensions.forEach

class SearchAndBookmarksItemDecorator(context: Context) : RecyclerView.ItemDecoration() {

    private val divider = context.drawableOrDefault(R.drawable.item_decorator)
    private val padding = context.dimenPx(R.dimen.decorator_padding_start)

    override fun onDraw(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        parent.forEach { child ->
            run {
                val top = child.bottom + ((child.layoutParams as? RecyclerView.LayoutParams)?.bottomMargin ?: 0)

                divider.setBounds(parent.paddingLeft + padding, top, parent.width - parent.paddingRight, top + divider.intrinsicHeight)
                divider.draw(c)
            }
        }
    }
}
