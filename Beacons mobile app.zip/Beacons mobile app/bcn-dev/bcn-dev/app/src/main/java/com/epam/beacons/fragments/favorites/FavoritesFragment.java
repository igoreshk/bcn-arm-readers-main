package com.epam.beacons.fragments.favorites;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.epam.beacons.R;
import com.epam.beacons.fragments.BaseFragment;
import com.epam.beacons.uimodel.SearchItem;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;

public class FavoritesFragment extends BaseFragment implements FavouritesAdapter.ItemClickListener {
    private static final int    FAVORITES_FRAGMENT = 1;
    private static final String FAVORITES_TAG      = FavoritesFragment.class.getSimpleName();

    @BindView(R.id.favorites_list)
    RecyclerView favoritesRecyclerView;

    @BindView(R.id.favorites_fragment_inner_container)
    LinearLayout favoritesContainer;

    @Inject
    FavouritesAdapter adapter;

    @Inject
    public FavoritesFragment() { // default constructor for dagger
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = super.onCreateView(inflater, container, savedInstanceState);

        if (view == null) {
            return null;
        }

        ButterKnife.bind(this, view);
        favoritesRecyclerView.setAdapter(adapter);
        favoritesRecyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        favoritesRecyclerView.addItemDecoration(new FavoritesDrawableItemDecorator(view.getContext()));
        adapter.setItemClickListener(this);

        return view;
    }

    @Override
    protected int getLayoutRes() {
        return R.layout.fragment_favorites;
    }

    @Nullable
    @Override
    protected Class getViewModelClass() {
        return FavoritesFragmentViewModel.class;
    }

    @Override
    public void onClick(@NonNull SearchItem item) {
        // empty stub
    }
}