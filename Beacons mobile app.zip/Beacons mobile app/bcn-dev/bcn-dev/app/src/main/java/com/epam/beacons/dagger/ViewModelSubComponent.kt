package com.epam.beacons.dagger

import com.epam.beacons.buildings.BuildingsViewModel
import com.epam.beacons.fragments.favorites.FavoritesFragmentViewModel
import com.epam.beacons.maps.MapsViewModel
import dagger.Subcomponent

@Subcomponent
interface ViewModelSubComponent {

    @Subcomponent.Builder
    interface Builder {
        fun build(): ViewModelSubComponent
    }

    fun buildingsViewModel(): BuildingsViewModel

    fun mapsViewModel(): MapsViewModel

    fun favoritesFragmentViewModel(): FavoritesFragmentViewModel
}
