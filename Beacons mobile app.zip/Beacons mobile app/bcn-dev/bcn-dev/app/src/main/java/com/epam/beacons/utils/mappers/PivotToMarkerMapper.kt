package com.epam.beacons.utils.mappers

import com.epam.beacons.Pivot
import com.epam.beacons.tools.Mapper
import com.google.android.gms.maps.model.MarkerOptions
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PivotToMarkerMapper @Inject constructor(
        private val mapper: ScaleAwareCoordinateToLatLngMapper
) : Mapper<Pivot, MarkerOptions>() {

    override fun map(from: Pivot): MarkerOptions = MarkerOptions().position(mapper.map(from.coordinate))
}
