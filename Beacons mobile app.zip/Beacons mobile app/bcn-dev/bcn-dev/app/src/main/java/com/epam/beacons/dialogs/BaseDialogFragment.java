package com.epam.beacons.dialogs;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import javax.inject.Inject;

import butterknife.ButterKnife;
import dagger.android.support.AndroidSupportInjection;

public abstract class BaseDialogFragment<T extends ViewModel> extends DialogFragment {

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    @SuppressWarnings("WeakerAccess")
    protected T viewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(getLayoutRes(), container);
        ButterKnife.bind(this, view);
        this.getDialog().setTitle(getDialogTitle());
        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidSupportInjection.inject(this);
        super.onCreate(savedInstanceState);
        if (getActivity() != null) {
            viewModel = ViewModelProviders.of(getActivity(), viewModelFactory).get(getViewModelClass());
        }
    }

    protected abstract int getDialogTitle();

    protected abstract int getLayoutRes();

    @NonNull
    protected abstract Class<T> getViewModelClass();
}
