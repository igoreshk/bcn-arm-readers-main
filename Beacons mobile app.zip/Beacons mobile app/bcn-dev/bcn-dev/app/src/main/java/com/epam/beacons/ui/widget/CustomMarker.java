package com.epam.beacons.ui.widget;

import androidx.annotation.IntDef;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class CustomMarker {
    private final String          id;
    @Nullable
    private       Marker        marker;
    @Nullable
    private       MarkerOptions markerOptions;
    @Nullable
    private       LatLng        latLng;
    @Nullable
    private       String        title;
    @Status
    private int markerStatus = Status.ADD;

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({Status.ADD, Status.UPDATE, Status.REMOVE})
    public @interface Status {
        int ADD    = 1;
        int UPDATE = 2;
        int REMOVE = 3;
    }

    public CustomMarker(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setMarker(@NonNull Marker marker) {
        this.marker = marker;
    }

    @Nullable
    public MarkerOptions getMarkerOptions() {
        return markerOptions;
    }

    public void setMarkerOptions(@NonNull MarkerOptions markerOptions) {
        this.markerOptions = markerOptions;
    }

    @Nullable
    public Marker getMarker() {
        return marker;
    }

    @Status
    public int getMarkerStatus() {
        return markerStatus;
    }

    public void setMarkerStatus(@Status int markerStatus) {
        this.markerStatus = markerStatus;
    }

    @Nullable
    public String getTitle() {
        return title;
    }

    public void setTitle(@NonNull String title) {
        this.title = title;
    }

    @Nullable
    public LatLng getLatLng() {
        return latLng;
    }

    public void setLatLng(@NonNull LatLng latLng) {
        this.latLng = latLng;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final CustomMarker that = (CustomMarker) o;

        return id == that.id;
    }

    @Override
    public int hashCode() {
        return (int) (id.hashCode() ^ (id.hashCode() >>> 32));
    }
}
