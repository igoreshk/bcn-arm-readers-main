package com.epam.beacons.ui.widget.floorselector

import android.content.Context
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.epam.beacons.R
import com.epam.beacons.uimodel.FloorSelectorItem
import com.epam.beacons.utils.extensions.alphaComponent
import com.epam.beacons.utils.extensions.inflate
import com.epam.beacons.utils.extensions.isClickableAndFocusable
import java.util.ArrayList

class FloorSelectorAdapter(val context: Context) : RecyclerView.Adapter<FloorSelectorAdapter.ItemViewHolder>() {

    var onItemClickListener: OnItemClickListener? = null

    var floorNumbers: List<FloorSelectorItem> = ArrayList()
        set(value) {
            field = value
            val size = value.size
            itemCount = if (size > MAX_ROW_COUNT) {
                Math.ceil(size.toDouble() / MAX_ROW_COUNT).toInt() * MAX_ROW_COUNT
            } else {
                size
            }
            notifyDataSetChanged()
        }

    private var itemCount = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FloorSelectorAdapter.ItemViewHolder =
            ItemViewHolder(parent.inflate(R.layout.floor_selector_item)).apply {
                floor.setOnClickListener { onItemClickListener?.onItemSelected(getItem(adapterPosition)) }
            }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = getItem(position)

        when {
            item === EMPTY_FLOOR -> holder.floor.background = null
            item.active -> bindActiveItem(holder, item)
            else -> bindInactiveItem(holder, item)
        }
    }

    private fun bindActiveItem(holder: ItemViewHolder, item: FloorSelectorItem) {
        holder.apply {
            bindCommonItem(holder, item)

            floor.setTextColor(context.alphaComponent(R.color.colorWhite, item.alpha))

            floor.setBackgroundResource(R.drawable.fs_selected_background)
        }
    }

    private fun bindInactiveItem(holder: ItemViewHolder, item: FloorSelectorItem) {
        holder.apply {
            bindCommonItem(holder, item)

            floor.setTextColor(context.alphaComponent(R.color.fsUnselectedColor, item.alpha))

            floor.background = null
        }
    }

    private fun bindCommonItem(holder: ItemViewHolder, item: FloorSelectorItem) {
        holder.apply {
            floor.text = item.title
            floor.isClickableAndFocusable(true)
        }
    }

    override fun getItemCount() = itemCount

    fun getItem(position: Int) = if (position < floorNumbers.size) floorNumbers[position] else EMPTY_FLOOR

    class ItemViewHolder(
            itemView: View,
            val floor: TextView = itemView.findViewById(R.id.floor_selector_item)
    ) : RecyclerView.ViewHolder(itemView)

    interface OnItemClickListener {
        fun onItemSelected(floorItem: FloorSelectorItem)
    }

    companion object {
        private const val MAX_ROW_COUNT = 10
        private val EMPTY_FLOOR = FloorSelectorItem(Int.MIN_VALUE, "", false)
    }
}
