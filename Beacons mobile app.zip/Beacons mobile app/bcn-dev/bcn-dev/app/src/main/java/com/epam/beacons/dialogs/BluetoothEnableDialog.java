package com.epam.beacons.dialogs;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import android.widget.Button;

import com.epam.beacons.R;
import com.epam.beacons.maps.MapsViewModel;

import butterknife.BindView;
import butterknife.OnClick;

public class BluetoothEnableDialog extends BaseDialogFragment<MapsViewModel> {

    @NonNull
    private static final String DIALOG_TAG = BluetoothEnableDialog.class.getSimpleName();

    @BindView(R.id.bluetooth_dialog_enable)
    Button enableBluetooth;
    @BindView(R.id.bluetooth_dialog_cancel)
    Button cancelEnableBluetooth;

    public static void show(@NonNull FragmentManager fragmentManager) {
        if (fragmentManager.findFragmentByTag(DIALOG_TAG) == null) {
            BluetoothEnableDialog enableDialog = new BluetoothEnableDialog();
            enableDialog.show(fragmentManager, DIALOG_TAG);
        }
    }

    @OnClick(R.id.bluetooth_dialog_enable)
    public void enableBluetooth() {
        viewModel.onBluetoothEnableClicked();
        getDialog().dismiss();
    }

    @OnClick(R.id.bluetooth_dialog_cancel)
    public void cancelEnableBluetooth() {
        getDialog().dismiss();
    }

    @Override
    protected int getDialogTitle() {
        return R.string.bluetooth_dialog_title;
    }

    @Override
    protected int getLayoutRes() {
        return R.layout.bluetooth_enable_dialog;
    }

    @NonNull
    @Override
    protected Class<MapsViewModel> getViewModelClass() {
        return MapsViewModel.class;
    }
}
