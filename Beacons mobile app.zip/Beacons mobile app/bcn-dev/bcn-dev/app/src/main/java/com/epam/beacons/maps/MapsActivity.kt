package com.epam.beacons.maps

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.RelativeLayout
import com.epam.beacons.R
import com.epam.beacons.base.modern.BaseActivityNew
import com.epam.beacons.base.modern.SingleEvent
import com.epam.beacons.dialogs.BluetoothEnableDialog
import com.epam.beacons.extensions.observe
import com.epam.beacons.maps.MapsState.Companion.DEFAULT_FLOOR
import com.epam.beacons.maps.MapsState.Companion.DEFAULT_ID
import com.epam.beacons.maps.MapsState.Companion.EMPTY_LAT_LNG
import com.epam.beacons.record.DataRecordDialog
import com.epam.beacons.ui.widget.AddBookmarkView
import com.epam.beacons.ui.widget.BottomNavigationItemModel
import com.epam.beacons.ui.widget.BottomNavigationView
import com.epam.beacons.ui.widget.bookmarks.BookmarksView
import com.epam.beacons.ui.widget.bottomnavigationsheet.BottomNavigationSheet
import com.epam.beacons.ui.widget.floorselector.FloorSelector
import com.epam.beacons.ui.widget.search.SearchWidget
import com.epam.beacons.uimodel.FloorImage
import com.epam.beacons.uimodel.FloorSelectorItem
import com.epam.beacons.uimodel.MarkerModel
import com.epam.beacons.uimodel.SearchItem
import com.epam.beacons.uimodel.bottomnavigationsheet.DestinationItem.Companion.DEFAULT_DESTINATION
import com.epam.beacons.utils.*
import com.epam.beacons.utils.extensions.*
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.GoogleMap.OnCameraMoveStartedListener.REASON_GESTURE
import com.google.android.gms.maps.GoogleMapOptions
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import kotlinx.android.synthetic.main.activity_maps.*
import kotlinx.android.synthetic.main.point_of_interests_view.view.*
import kotlinx.android.synthetic.main.activity_maps.add_bookmark_panel as addBookmarkPanel
import kotlinx.android.synthetic.main.activity_maps.bookmarks_view as bookmarksView
import kotlinx.android.synthetic.main.activity_maps.floor_selector_view as floorSelector
import kotlinx.android.synthetic.main.activity_maps.navigation_panel as navPanel
import kotlinx.android.synthetic.main.activity_maps.point_of_interests_view as pointOfInterestsView
import kotlinx.android.synthetic.main.activity_maps.route_cancel as routeCancel
import kotlinx.android.synthetic.main.activity_maps.search_container as searchContainer
import kotlinx.android.synthetic.main.activity_maps.simple_location as simpleLocationButton
import kotlinx.android.synthetic.main.activity_maps.translucent_background as translucentBackground
import kotlinx.android.synthetic.main.activity_maps.user_location as userLocation
import kotlinx.android.synthetic.main.activity_maps.where_am_i as whereAmI
import kotlinx.android.synthetic.main.point_of_interests_view.view.show_button as showButton
import kotlinx.android.synthetic.main.view_search.view.level_number as levelNumber

class MapsActivity : BaseActivityNew<MapsState, MapsViewModel>(), OnMapReadyCallback, GoogleMap.CancelableCallback {
    override val vmClass = MapsViewModel::class.java

    override val layoutRes = R.layout.activity_maps

    private val colorsHolder = ColorsHolder()

    private lateinit var map: GoogleMap

    private lateinit var mapImage: GroundOverlay

    private lateinit var mapFragment: SupportMapFragment

    private val user: Marker by lazy {
        map.addMarker(MarkerOptions()
            .visible(false)
            .position(EMPTY_LAT_LNG)
            .zIndex(USER_Z)
            .anchor(USER_ANCHOR, USER_ANCHOR)
            .icon(vectorToMarker(this, R.drawable.ic_user))
        )
    }

    private val error: Circle by lazy {
        map.addCircle(CircleOptions()
            .visible(false)
            .center(EMPTY_LAT_LNG)
            .strokeWidth(NO_LINE)
            .fillColor(colorsHolder.errorCircleColor)
            .zIndex(ERROR_Z)
        )
    }

    private val destination: Marker by lazy {
        map.addMarker(MarkerOptions()
            .visible(false)
            .position(EMPTY_LAT_LNG))
    }

    private val route: Polyline by lazy {
        map.addPolyline(PolylineOptions()
            .visible(false)
            .color(colorsHolder.colorPolyline)
            .width(dimenPxFloat(R.dimen.polyline_width))
            .pattern(listOf(Dot(), Gap(dimenPxFloat(R.dimen.polyline_gap)))))
    }

    private val routingListener = object : BottomNavigationSheet.Listener {
        override fun onFavoriteButtonClick(placeId: String) {
            viewModel.onFavoriteButtonClicked(placeId)
        }

        override fun onRouteButtonClicked() {
            viewModel.onRouteButtonClicked()
        }

        override fun onStartButtonClicked() {
            viewModel.onStartRoutingClicked()
        }
    }

    private val navigationViewListener = object : BottomNavigationView.OnSelectListener {
        override fun onItemSelected(position: Int) {
            when (position) {
                0 -> viewModel.onObjectsButtonClicked()
                1 -> viewModel.onBookmarksButtonSelected()
            }
        }

        override fun onItemUnselected(position: Int) {
            if (position == 1) {
                viewModel.onBookmarksButtonUnselected()
                translucentBackground.elevation = dimenPxFloat(R.dimen.translucent_background_elevation_high)
            }
        }
    }

    private val debugBeacons: MutableList<Marker> = mutableListOf()

    private val beaconDistances: MutableList<Circle> = mutableListOf()

    private val placeMarkers: MutableList<Marker> = mutableListOf()

    private val beacons: MutableList<Marker> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        colorsHolder.resolve(this)

        initMap()

        @Suppress("MagicNumber")
        navigation.setData(listOf(
            BottomNavigationItemModel(string(R.string.action_objects_title), R.drawable.ic_objects, 0),
            BottomNavigationItemModel(string(R.string.action_bookmarks_title), R.drawable.ic_bookmarks, 1),
            BottomNavigationItemModel(string(R.string.action_nearby_title), R.drawable.ic_nearby, 2),
            BottomNavigationItemModel(string(R.string.action_messages_title), R.drawable.ic_messages, 3)
        ))
        navigation.listener = navigationViewListener

        navPanel.listener = routingListener
        window.apply {
            decorView.setStatusBarInvisible()
            changeStatusBarColor(R.color.colorPrimary)
        }
        search.layoutParams = (search.layoutParams as? FrameLayout.LayoutParams)?.apply {
            setMargins(0, getStatusBarHeight() + dimenPx(R.dimen.search_margin), 0, 0)
        }

        routeCancel.layoutParams = (routeCancel.layoutParams as? FrameLayout.LayoutParams)?.apply {
            setMargins(0, getStatusBarHeight() + dimenPx(R.dimen.search_margin), 0, 0)
        }

        floorSelector.layoutParams = (floorSelector.layoutParams as? FrameLayout.LayoutParams)?.apply {
            setMargins(0, getStatusBarHeight() + dimenPx(R.dimen.search_margin) + dimenPx(R.dimen.search_selector_margin_top), 0, 0)
        }

        search.routeModeListener = object : SearchWidget.RouteModeListener {
            override fun onRouteModeChanged(active: Boolean) = routeCancel.isVisible(active)
        }

        addBookmarkPanel.closeListener = object : AddBookmarkView.CloseListener {
            override fun onCloseClick() {
                viewModel.onCloseBookmarkAddingClicked()
            }
        }

        viewModel.apply {
            observe(pointOfInterestsLiveData, ::updatePointOfInterestsPanel)
            observe(navigateToPoiLiveData, ::navigateToPointOfInterests)
            observe(userLocationLiveData, ::updateUserLocation)
        }
    }

    override fun onDestroy() {
        search.handler.removeCallbacksAndMessages(null)

        super.onDestroy()
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.setOnMapClickListener {
            destination.isVisible = true
            viewModel.onMapClicked(it)
        }
        map.setOnMarkerClickListener {
            viewModel.onMapClicked(it.position)
            // false return statement will pop up the info window as usual
            false
        }
        map.setOnCameraMoveStartedListener { reason -> viewModel.onCameraMoveStarted(reason == REASON_GESTURE) }
        map.setOnCameraMoveListener { viewModel.onCameraMoved(map.cameraPosition.target, map.cameraPosition.zoom) }
        userLocation.setOnClickListener { viewModel.onCenterLocationClicked() }
        routeCancel.setOnClickListener { viewModel.onRouteCancelClicked() }
        whereAmI.setOnClickListener { viewModel.onWhereAmIClicked() }
        translucentBackground.setOnClickListener { navigation.onItemUnselected(1) }
        initSearchWidget()
        initBookmarksView()
        initPointOfInterestsPanel()
        simpleLocationButton.setOnClickListener { viewModel.onSimpleLocationButtonClicked() }
        changeGoogleMapCompassPosition()
        viewModel.onMapReady()
    }

    override fun onFinish() {
        viewModel.onCameraZoomFinished()
    }

    override fun onCancel() {
        viewModel.onCameraZoomCanceled()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            RC_BLUETOOTH -> handleBluetoothResult(resultCode)
            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun applyChanges(state: MapsState) {
        if (!::map.isInitialized) {
            return
        }

        state.apply {
            updateFloorSelector(floorSelectorState)
            updateSearchFocus(searchWidgetState.searchInFocus, floorSelectorState.animationFinished)
            updateSearchWidget(searchWidgetState.searchItems)
            updateRouteMode(routeState)
            updateCurrentFloorButton(currentFloor)
            updateUserLocation(userLocationState)
            updateWhereAmIVisibility(whereAmIVisibility)
            updateDestination(destination)
            updateRoute(route)
            updateDebugBeacons(debugState.beacons)
            updateDebugDistances(debugState.beaconDistances)
            updateDebugDataShown(debugState.shown)
            updateImage(floorImage)
            updateMarkers(places, placeMarkers)
            updateNavigationSheet(bottomSheetState)
            updateUserLocationVisibility(userLocationButtonVisibility)
            updateMapCenter(mapCenterState)
            updateBookmarksView(bookmarksViewState)
            updateTranslucentBackground(translucentBackgroundVisibility, bookmarkAddingActive)
            updateBookmarkAddingVisibility(bookmarkAddingActive)
            updateSimpleLocationButton(simpleLocationActive, beacons)
            shareFile(shareFile)
            showFileDoesntExists(showFileDoesntExists)
            showNoRoute(showNoRoute)
            requestBluetooth(requestBluetooth)
            showBluetoothDialog(showBluetoothDialog)
            showRecordDialog(showRecordDialog)
            showRecordFinished(showRecordFinished)
            showLocationStopped(showLocationStopped)
            showDestinationReached(destinationReached)
            showPositionNotFound(showLocationNotFound)
            close(close)
        }
    }

    private fun updateSimpleLocationButton(simpleLocationActive: SingleEvent<Boolean>, beaconsOptions: List<MarkerOptions>) {
        if (simpleLocationActive.needToShow) {
            clearBeacons()
            if (simpleLocationActive.value) {
                simpleLocationButton.background = drawable(R.drawable.ic_simple_location_on)
                beaconsOptions.forEach { if (it.position != EMPTY_LAT_LNG) beacons.add(map.addMarker(it)) }
            } else {
                simpleLocationButton.background = drawable(R.drawable.ic_simple_location_off)
            }
        }
    }

    private fun updateTranslucentBackground(translucentBackgroundVisibility: SingleEvent<Boolean>, addingBookmarksVisibility: Boolean) {
        translucentBackground.apply {
            translucentBackgroundVisibility.apply {
                if (needToShow) {
                    value.also {
                        elevation = if (addingBookmarksVisibility) {
                            dimenPxFloat(R.dimen.translucent_background_elevation_low)
                        } else {
                            dimenPxFloat(R.dimen.translucent_background_elevation_high)
                        }
                        visible(it)
                        isClickableAndFocusable(it)
                        if (!it) navigation.unselectHighlight(1)
                    }
                }
            }
        }
    }

    private fun updateBookmarksView(bookmarksViewState: MapsState.BookmarksViewState) = with(bookmarksViewState) {
        if (bookmarks.needToShow) {
            bookmarksView.data = bookmarks.value
            bookmarksView.lastDeletedData = deletedData
        }
        if (bookmarksViewVisibility.needToShow) {
            if (bookmarksViewVisibility.value) bookmarksView.show() else bookmarksView.hide()
        }
        if (showUndo.needToShow && showUndo.value && deletedData.first != DEFAULT_ID) {
            bookmarksView.showUndo(deletedData)
        }
    }

    private fun updateRouteMode(routeState: MapsState.RouteState) = with(routeState) {
        if (routeActive.needToShow) {
            search.layoutParams = (search.layoutParams as? FrameLayout.LayoutParams)?.apply {
                if (routeActive.value) {
                    width = ViewGroup.LayoutParams.WRAP_CONTENT
                    gravity = Gravity.END
                    search.onRouteActive()
                    floorSelector.onRouteActive()
                } else {
                    search.postDelayed({
                        width = ViewGroup.LayoutParams.MATCH_PARENT
                        gravity = Gravity.NO_GRAVITY
                        floorSelector.onRouteNonActive()
                    }, DELAY_MILLIS)
                    search.onRouteNonActive()
                }
                active = routeActive.value
            }
        }
    }

    private fun updateSearchWidget(searchItems: SingleEvent<List<SearchItem>>) {
        if (searchItems.needToShow) search.setData(searchItems.value)
    }

    private fun updateSearchFocus(searchInFocus: SingleEvent<Boolean>, fsAnimationFinished: SingleEvent<Boolean>) {
        if (searchInFocus.needToShow || fsAnimationFinished.needToShow) {
            searchContainer.isClickableAndFocusable(searchInFocus.value)
            search.focusChanged(searchInFocus.value, fsAnimationFinished.value)
        }
    }

    private fun updateFloorSelector(floorSelectorState: MapsState.FloorSelectorState) {
        if (floorSelectorState.floorNumbers.needToShow && floorSelectorState.floorNumbers.value.isNotEmpty()) {
            floorSelector.setData(floorSelectorState.floorNumbers.value)
        }
        if (floorSelectorState.floorSelectorVisibility.first) {
            floorSelector.show()
        } else {
            floorSelector.hide(floorSelectorState.floorSelectorVisibility.second)
        }
    }

    private fun updateCurrentFloorButton(floorNumber: Int) {
        if (floorNumber != DEFAULT_FLOOR) {
            search.levelNumber.text = floorNumber.toString()
        }
    }

    private fun initMap() {
        val options = GoogleMapOptions()
            .minZoomPreference(MAP_MIN_ZOOM)
            .maxZoomPreference(MAP_MAX_ZOOM)
            .mapToolbarEnabled(false)
            .mapType(GoogleMap.MAP_TYPE_NONE)

        mapFragment = SupportMapFragment.newInstance(options)
        replaceFragment(R.id.map_container, mapFragment, MAP_FRAGMENT)
        mapFragment.getMapAsync(this)
    }

    private fun handleBluetoothResult(resultCode: Int) {
        if (resultCode != Activity.RESULT_OK) {
            toast(R.string.bluetooth_not_enabled)
            return
        }

        viewModel.onBluetoothActivated()
    }


    private fun showFileDoesntExists(show: SingleEvent<Boolean>) {
        if (show.needToShow && show.value) toast(R.string.fileDoesntExistToastText)
    }

    private fun showNoRoute(show: SingleEvent<Boolean>) {
        if (show.needToShow && show.value) toast(R.string.noRouteFound)
    }

    private fun shareFile(share: SingleEvent<String>) {
        if (share.needToShow && share.value.isNotBlank()) {
            startActivity(Intent.createChooser(
                IntentFactory.getShareFileIntent(share.value),
                string(R.string.intentChooserTitle)))
        }
    }

    private fun updateNavigationSheet(state: MapsState.BottomSheetState) = with(state) {
        navPanel.apply {
            bottomSheetItem.apply {
                if (needToShow && value.first.isNotEmpty() && value.second.latLng != DEFAULT_DESTINATION) {
                    route = value.first
                    destination = value.second
                }
            }
            if (navigationPanelVisibility && bottomSheetItem.value.first.isNotEmpty()) show() else hide(routingError)
            if (routingError) routingError = false
        }
    }

    private fun updateUserLocationVisibility(visibility: Boolean) {
        userLocation.visible(visibility)
    }

    private fun updateWhereAmIVisibility(visibility: Boolean) {
        whereAmI.visible(visibility)
    }

    private fun updateDebugDataShown(shown: Boolean) {
        search.debugDataActive = shown
    }

    private fun updateMarkers(places: List<MarkerModel>, markers: MutableList<Marker>) {
        var i = 0
        while (i < places.size && i < markers.size) {
            val marker = markers[i]
            val place = places[i]

            marker.position = place.markerOptions.position
            marker.title = place.markerOptions.title

            i++
        }

        if (i < markers.size) {
            //new places less, than existing markers
            markers.forEach { it.remove() }
            markers.removeAll(markers.slice(i until markers.size))
        } else if (i < places.size) {
            //new places exceed existing markers
            places.forEach {
                markers.add(map.addMarker(it.markerOptions))
            }
        }
    }

    private fun updateImage(image: FloorImage?) {
        if (image == null || !image.needToUpdate) {
            return
        }

        if (::mapImage.isInitialized) {
            mapImage.remove()
        }

        val bounds = createLatLngBounds(image.southWestBound, image.northEastBound)

        val groundOverlayOptions = GroundOverlayOptions()
            .clickable(false)
            .image(BitmapDescriptorFactory.fromBitmap(image.image))

        if (image.needToUpdateSize) {
            groundOverlayOptions.position(image.position, image.width, image.height)
        } else {
            groundOverlayOptions.positionFromBounds(bounds)
        }

        map.setLatLngBoundsForCameraTarget(bounds)
        image.needToUpdate = false

        mapImage = map.addGroundOverlay(groundOverlayOptions)
    }

    private fun updateDebugDistances(dist: List<CircleOptions>) {
        clearDistances()

        dist.forEach { beaconDistances.add(map.addCircle(it)) }
    }

    private fun updateDebugBeacons(beacons: List<MarkerOptions>) {
        clearDebugBeacons()

        beacons.forEach { this.debugBeacons.add(map.addMarker(it)) }
    }

    private fun updateRoute(points: List<LatLng>) {
        route.points = points
        route.isVisible = points.isNotEmpty()
    }

    private fun updateDestination(point: LatLng) {
        if (point === EMPTY_LAT_LNG) {
            destination.isVisible = false
            return
        }
        destination.position = point
    }

    private fun showDestinationReached(show: SingleEvent<Boolean>) {
        if (show.needToShow && show.value) {
            toast(R.string.endOfRouteMessage)
        }
    }

    private fun showPositionNotFound(show: SingleEvent<Boolean>) {
        if (show.needToShow && show.value) {
            toast(R.string.noPositionToastText)
        }
    }

    private fun showRecordFinished(show: SingleEvent<Boolean>) {
        if (show.needToShow && show.value) {
            toast(R.string.record_data_play_finished_text)
        }
    }

    private fun showLocationStopped(show: SingleEvent<Boolean>) {
        if (show.needToShow && show.value) {
            toast(R.string.error_location_stopped)
        }
    }

    private fun updatePointOfInterestsPanel(pointOfInterests: MarkerModel?) {
        pointOfInterests?.let {
            pointOfInterestsView.title.text = String.format(this@MapsActivity.string(R.string.you_are_on_point_of_interest), it.markerOptions.title)
            pointOfInterestsView.icon.setImageDrawable(this@MapsActivity.drawableOrDefault(it.id))
            showPointOfInterestsPanel()
        }
    }

    private fun showPointOfInterestsPanel() {
        pointOfInterestsView.apply {
            if (visibility == ViewGroup.GONE) {
                alpha = 0f
                visibility = View.VISIBLE
                animate()
                    .alpha(1f)
                    .translationY(context.dimenPxFloat(R.dimen.point_of_interests_top_margin))
                    .setDuration(ANIMATION_DURATION_IN_MILLISECONDS)
                    .setListener(null)

            }
        }
    }

    private fun hidePointOfInterestsPanel() {
        pointOfInterestsView.apply {
            if (visibility == ViewGroup.VISIBLE) {
                animate()
                    .alpha(0f)
                    .translationY(-context.dimenPxFloat(R.dimen.point_of_interests_top_margin))
                    .setDuration(ANIMATION_DURATION_IN_MILLISECONDS)
                    .setListener(object : AnimatorListenerAdapter() {
                        override fun onAnimationEnd(animation: Animator) {
                            pointOfInterestsView.visibility = View.GONE
                        }
                    })
            }
        }
    }

    private fun navigateToPointOfInterests(location: LatLng?) {
        location?.let {
            map.animateToWithZoom(it, this@MapsActivity, MapsState.DEFAULT_ZOOM)
            hidePointOfInterestsPanel()
        }
    }

    private fun showRecordDialog(show: SingleEvent<Boolean>) {
        if (show.needToShow && show.value) {
            DataRecordDialog.show(supportFragmentManager)
        }
    }

    private fun showBluetoothDialog(show: SingleEvent<Boolean>) {
        if (show.needToShow && show.value) {
            BluetoothEnableDialog.show(supportFragmentManager)
        }
    }

    private fun requestBluetooth(request: SingleEvent<Boolean>) {
        if (request.needToShow && request.value) {
            startActivityForResult(IntentFactory.getEnableBluetoothIntent(), RC_BLUETOOTH)
        }
    }

    private fun updateMapCenter(mapCenter: MapsState.MapCenterState) = with(mapCenter) {
        map.doOnMapLoaded {
            when {
                centerOnPlace(this) ->
                    if (!levelRestored) {
                        map.animateToWithZoom(center.value, this@MapsActivity, zoom)
                    } else {
                        map.moveToWithZoom(center.value, zoom)
                        levelRestored = false
                    }
                centerOnMapBounds(this) -> {
                    map.moveTo(bounds.value)
                    if (levelSwitched) {
                        levelSwitched = false
                    }
                }
            }
        }
    }

    private fun centerOnPlace(mapCenter: MapsState.MapCenterState): Boolean = with(mapCenter) {
        center.needToShow && center.value !== EMPTY_LAT_LNG && !levelSwitched
    }

    private fun centerOnMapBounds(mapCenter: MapsState.MapCenterState): Boolean = with(mapCenter) {
        bounds.needToShow && !zoomActivated && center.value === EMPTY_LAT_LNG
    }

    @Suppress("ComplexMethod")
    private fun updateUserLocation(userLocationState: MapsState.UserLocationState?) {
        userLocationState?.apply {
            if (currentLocation.latLng === EMPTY_LAT_LNG) {
                user.isVisible = false
                error.isVisible = false
                return
            }

            user.apply {
                isFlat = if (isArrow && !isSimpleLocation) {
                    setIcon(vectorToMarker(this@MapsActivity, R.drawable.ic_user_arrow))
                    rotation = currentRotation
                    true
                } else {
                    setIcon(vectorToMarker(this@MapsActivity, R.drawable.ic_user))
                    rotation = DEFAULT_ROTATION
                    false
                }

                animateTo(currentLocation.latLng)
                isVisible = true
            }

            error.apply {
                if (isSimpleLocation) {
                    isVisible = false
                } else {
                    animateTo(currentLocation.latLng)
                    isVisible = true
                    radius = currentLocation.additionalRadius
                }
            }
        }
    }

    private fun updateBookmarkAddingVisibility(visible: Boolean) {
        if (visible) {
            addBookmarkPanel.show()
            search.onAddBookmarkActive()
        } else {
            addBookmarkPanel.hide()
            search.onAddBookmarkNonActive()
        }
    }

    private fun clearDistances() {
        beaconDistances.run {
            forEach { it.remove() }
            clear()
        }
    }

    private fun clearDebugBeacons() {
        debugBeacons.run {
            forEach { it.remove() }
            clear()
        }
    }

    private fun clearBeacons() {
        beacons.run {
            forEach { it.remove() }
            clear()
        }
    }

    private fun close(close: SingleEvent<Boolean>) {
        if (close.needToShow && close.value) {
            finish()
        }
    }

    @Suppress("ComplexMethod")
    private fun initSearchWidget() {
        search.apply {
            debugListener = object : SearchWidget.DebugListener {
                override fun onDebugDataClicked() = viewModel.onShowDebugDataClicked()

                override fun onRecordClicked() = viewModel.onOpenRecordDialogClicked()
            }
            searchListener = object : SearchWidget.SearchListener {
                override fun onSearchClicked() = viewModel.onSearchClicked()
            }
            levelsListener = object : SearchWidget.LevelsListener {
                override fun onLevelClicked() = if (!levelsFocused) {
                    viewModel.onCurrentFloorButtonClicked()
                } else {
                    viewModel.onOutsideSearchWidgetClicked()
                }
            }
            queryListener = object : SearchWidget.QueryChangeListener {
                override fun onQueryChange(query: CharSequence) = viewModel.onQueryChanged(query)
            }
            searchItemClickListener = object : SearchWidget.SearchItemClickListener {
                override fun onSearchItemClicked(itemId: String, favorite: Boolean) = viewModel.onSearchItemClicked(itemId, favorite)
            }
            floorSelector.floorListener = object : FloorSelector.FloorListener {
                override fun onFloorItemClicked(floorItem: FloorSelectorItem) = viewModel.onFloorSelectorItemClicked(floorItem)
            }
            floorSelector.animationListener = object : FloorSelector.AnimationListener {
                override fun onAnimationChanged(finished: Boolean) = viewModel.onFloorSelectorAnimation(finished)
            }
            searchContainer.setOnClickListener { viewModel.onOutsideSearchWidgetClicked() }
        }
    }

    private fun initBookmarksView() {
        bookmarksView.apply {
            closeListener = object : BookmarksView.CloseListener {
                override fun onCloseClicked() = navigation.onItemUnselected(1)
            }
            animationListener = object : BookmarksView.AnimationListener {
                override fun onAnimationChanged(finished: Boolean) {
                    navigation.animationFinished = finished
                }
            }
            addBookmarkListener = object : BookmarksView.AddBookmarkListener {
                override fun onAddBookmarkClicked() {
                    translucentBackground.elevation = dimenPxFloat(R.dimen.translucent_background_elevation_low)
                    viewModel.onAddBookmarkClicked()
                }
            }
            deleteItemListener = object : BookmarksView.DeleteItemListener {
                override fun onDeleteItemClicked(itemId: String, position: Int) = viewModel.onDeleteBookmarkClicked(itemId, position)
            }
            undoListener = object : BookmarksView.UndoListener {
                override fun onUndoClicked(itemId: String) = viewModel.onUndoButtonClicked(itemId)
            }
            onItemClickListener = object : BookmarksView.ItemClickListener {
                override fun onItemClicked(itemId: String) = viewModel.onSearchItemClicked(itemId, true)
            }
        }
    }

    private fun initPointOfInterestsPanel() {
        pointOfInterestsView.apply {
            showButton.setOnClickListener {
                viewModel.onShowPointOfInterestsClicked()
            }
        }
    }

    private fun changeGoogleMapCompassPosition() {
        val compassButton = mapFragment.view?.run {
            this.findViewWithTag<View>(GOOGLE_MAP_COMPASS_TAG)
        }

        compassButton?.apply {
            val rlp = layoutParams as RelativeLayout.LayoutParams
            rlp.addRule(RelativeLayout.ALIGN_PARENT_END)
            rlp.addRule(RelativeLayout.ALIGN_PARENT_TOP)
            rlp.addRule(RelativeLayout.ALIGN_PARENT_START,0)
            rlp.topMargin = context.dimenPx(R.dimen.google_map_compass_top_margin)
            rlp.rightMargin = context.dimenPx(R.dimen.google_map_compass_right_margin)

            layoutParams = rlp
        }
    }

    companion object {
        private const val MAP_MIN_ZOOM = 15.0f
        private const val MAP_MAX_ZOOM = 100.0f

        private const val USER_Z = 2.0f
        private const val USER_ANCHOR = 0.5f

        private const val ERROR_Z = 1.0f
        private const val NO_LINE = 0f

        private const val DEFAULT_ROTATION = 0f

        private const val RC_BLUETOOTH = 4

        private const val DELAY_MILLIS = 300L
        private const val ANIMATION_DURATION_IN_MILLISECONDS = 1000L

        private const val MAP_FRAGMENT = "MAP_FRAGMENT"
        private const val GOOGLE_MAP_COMPASS_TAG = "GoogleMapCompass"
    }
}
