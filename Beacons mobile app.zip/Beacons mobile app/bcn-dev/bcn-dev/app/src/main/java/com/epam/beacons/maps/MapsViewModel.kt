package com.epam.beacons.maps


import androidx.lifecycle.Lifecycle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.OnLifecycleEvent
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import androidx.annotation.NonNull
import com.epam.beacons.Coordinate
import com.epam.beacons.Floor
import com.epam.beacons.Pivot
import com.epam.beacons.Place
import com.epam.beacons.base.modern.BaseViewModelNew
import com.epam.beacons.broadcasts.BroadcastCenter
import com.epam.beacons.interactors.BeaconsRecorderInteractor
import com.epam.beacons.interactors.DataInteractor
import com.epam.beacons.interactors.FavoritesInteractor
import com.epam.beacons.interactors.LocationInteractor
import com.epam.beacons.interactors.PathInteractor
import com.epam.beacons.interactors.SearchInteractor
import com.epam.beacons.maps.MapsState.Companion.DEFAULT_FLOOR
import com.epam.beacons.maps.MapsState.Companion.DEFAULT_ID
import com.epam.beacons.maps.MapsState.Companion.DEFAULT_NORTH_EAST_BOUND
import com.epam.beacons.maps.MapsState.Companion.DEFAULT_POSITION
import com.epam.beacons.maps.MapsState.Companion.DEFAULT_SOUTH_WEST_BOUND
import com.epam.beacons.maps.MapsState.Companion.DEFAULT_ZOOM
import com.epam.beacons.maps.MapsState.Companion.EMPTY_LAT_LNG
import com.epam.beacons.record.DataRecordDialog
import com.epam.beacons.record.DataRecordDialog.Command.OPEN
import com.epam.beacons.record.DataRecordDialog.Command.PLAY
import com.epam.beacons.record.DataRecordDialog.Command.SAVE
import com.epam.beacons.record.DataRecordDialog.Command.SHARE
import com.epam.beacons.record.DataRecordDialog.Command.START
import com.epam.beacons.record.DataRecordDialog.Command.STOP
import com.epam.beacons.record.RecordDataState
import com.epam.beacons.record.RecordLiveData
import com.epam.beacons.sensors.Sensors
import com.epam.beacons.tools.Logger
import com.epam.beacons.tools.exception.BluetoothDisabledException
import com.epam.beacons.uimodel.*
import com.epam.beacons.utils.*
import com.epam.beacons.utils.Constants.NEARBY_POI_DISTANCE
import com.epam.beacons.utils.mappers.BeaconToMarkerMapper
import com.epam.beacons.utils.mappers.CoordinateToLatLngWrapperMapper
import com.epam.beacons.utils.mappers.CoordinatesToLatLngsMapper
import com.epam.beacons.utils.mappers.LatLngToCoordinateMapper
import com.epam.beacons.utils.mappers.NumberToFloorSelectorItemMapper
import com.epam.beacons.utils.mappers.PivotToCircleMapper
import com.epam.beacons.utils.mappers.PivotToMarkerMapper
import com.epam.beacons.utils.mappers.PlaceToBookmarksItemMapper
import com.epam.beacons.utils.mappers.PlaceToMarkerMapper
import com.epam.beacons.utils.mappers.PlaceToSearchItemMapper
import com.epam.beacons.utils.mappers.RouteResultToDestinationItemMapper
import com.epam.beacons.utils.mappers.RouteResultToRouteItemsMapper
import com.google.android.gms.maps.model.LatLng
import io.reactivex.disposables.Disposable
import io.reactivex.internal.disposables.EmptyDisposable
import javax.inject.Inject

@Suppress("TooManyFunctions")
class MapsViewModel
@Inject constructor(
        logger: Logger,
        private val locationInteractor: LocationInteractor,
        private val dataInteractor: DataInteractor,
        private val pathInteractor: PathInteractor,
        private val searchInteractor: SearchInteractor,
        private val favoritesInteractor: FavoritesInteractor,
        private val recorderInteractor: BeaconsRecorderInteractor,
        private val imageHelper: ImageHelper,
        private val uriHelper: UriHelper,
        private val coordinateMapper: CoordinatesToLatLngsMapper,
        private val coordWrapperMapper: CoordinateToLatLngWrapperMapper,
        private val latLngMapper: LatLngToCoordinateMapper,
        private val pivotToCircleMapper: PivotToCircleMapper,
        private val pivotToMarkerMapper: PivotToMarkerMapper,
        private val placeToMarkerMapper: PlaceToMarkerMapper,
        private val numberToFloorSelectorItemMapper: NumberToFloorSelectorItemMapper,
        private val placeToSearchItemMapper: PlaceToSearchItemMapper,
        private val routeResultToDestinationItemMapper: RouteResultToDestinationItemMapper,
        private val routeResultToRouteItemsMapper: RouteResultToRouteItemsMapper,
        private val placeToBookmarksItemMapper: PlaceToBookmarksItemMapper,
        private val beaconToMarkerMapper: BeaconToMarkerMapper,
        private val broadcastCenter: BroadcastCenter,
        private val sensors: Sensors
) : BaseViewModelNew<MapsState>(MapsState(), logger) {

    val recordDataState: RecordLiveData<RecordDataState> = RecordLiveData(RecordDataState(RecordStateModel.DATA_EMPTY, ""))
    val pointOfInterestsLiveData: MutableLiveData<MarkerModel> = MutableLiveData()
    val navigateToPoiLiveData: MutableLiveData<LatLng> = MutableLiveData()
    val userLocationLiveData: MutableLiveData<MapsState.UserLocationState> = MutableLiveData()

    private var locationDisposable: Disposable = EmptyDisposable.INSTANCE
    private var debugDataDisposable: Disposable = EmptyDisposable.INSTANCE
    private var routeDisposable: Disposable = EmptyDisposable.INSTANCE
    private var searchDisposable: Disposable = EmptyDisposable.INSTANCE
    private var queryDisposable: Disposable = EmptyDisposable.INSTANCE
    private val destinationData = DestinationData()

    @OnLifecycleEvent(Lifecycle.Event.ON_CREATE)
    fun onCreate() {
        dataInteractor.currentFloor.execute(
                onNext = {
                    resetData()
                    updateFloor(it)
                    checkLocationMode()
                }
        )
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    fun onStart() {
        checkLocationMode()
        updateDebugIcon()
        updateSearchInFocus()
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
    fun onResume() {
        sensors.registerListeners()
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
    fun onPause() {
        sensors.unregisterListeners()
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
    fun onStop() {
        locationDisposable.dispose()
        debugDataDisposable.dispose()
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    fun onDestroy() {
        data.value.apply {
            bottomSheetState.bottomSheetItem.needToShow = true
            routeState.routeActive.needToShow = true
            mapCenterState.levelRestored = true
            mapCenterState.center.needToShow = true
            translucentBackgroundVisibility.needToShow = true
            bookmarksViewState.apply {
                bookmarks.needToShow = true
                bookmarksViewVisibility.needToShow = true
            }
            handleLocationButtons()
        }
    }

    fun onMapReady() {
        data.notifyObservers()
    }

    fun onMapClicked(point: LatLng) {
        if (data.value.route.isEmpty() && !data.value.bottomSheetState.navigationPanelVisibility) {
            destinationData.preRouteMode = true
            resetPreRoute(point, DestinationData.EMPTY_DESC, DestinationData.EMPTY_PLACE_ID, false)
        }
    }

    fun onCameraMoveStarted(isGesture: Boolean) {
        data.value.apply {
            if (!routeState.active && mapCenterState.zoomActivated && userLocationButtonVisibility) {
                userLocationButtonVisibility = false
            } else if (routeState.active && !whereAmIVisibility && isGesture) {
                whereAmIVisibility = true
            }
            data.notifyObservers()
        }
    }

    fun onCameraZoomFinished() {
        handleLocationButtons()
        data.notifyObservers()
    }

    fun onCameraZoomCanceled() {
        handleLocationButtons()
        data.notifyObservers()
    }

    fun onCameraMoved(toTarget: LatLng, withZoom: Float) {
        data.value.mapCenterState.apply {
            if (!levelSwitched) {
                center.value = toTarget
                zoom = withZoom
            }
        }
    }

    fun onSearchClicked() {
        data.value.floorSelectorState.floorSelectorVisibility = false to true
        data.value.searchWidgetState.searchInFocus.value = true

        startTrackingQuery()
        getRecentSearchItems()
    }

    fun onCurrentFloorButtonClicked() {
        if (data.value.currentFloor != DEFAULT_FLOOR) {
            dataInteractor.floorNumbers.execute(onSuccess = {
                createFloorSelector(it, data.value.currentFloor)
            })
        }
    }

    fun onFloorSelectorItemClicked(floor: FloorSelectorItem) {
        if (floor.number == data.value.currentFloor) {
            data.value.floorSelectorState.floorSelectorVisibility = false to false
            data.value.searchWidgetState.searchInFocus.value = false
            data.notifyObservers()
        } else {
            dataInteractor.switchFloor(floor.number).execute(
                    onComplete = {
                        data.value.route = emptyList()
                        data.value.destination = EMPTY_LAT_LNG
                        data.value.mapCenterState.levelSwitched = true
                        data.value.mapCenterState.center.value = EMPTY_LAT_LNG
                        startTrackingRoute()
                    }
            )
        }
    }

    fun onOutsideSearchWidgetClicked() {
        searchDisposable.dispose()
        queryDisposable.dispose()

        data.value.floorSelectorState.floorSelectorVisibility = false to false
        data.value.searchWidgetState.searchInFocus.value = false
        if (data.value.bookmarkAddingActive) onCloseBookmarkAddingClicked()
        data.notifyObservers()
    }

    fun onCenterLocationClicked() {
        data.value.apply {
            if (lastKnownUserLocation === EMPTY_LAT_LNG) {
                showLocationNotFound.value = true
            } else {
                dataInteractor.switchToUserFloor().execute(onComplete = {
                    mapCenterState.apply {
                        data.value.route = emptyList()
                        data.value.destination = EMPTY_LAT_LNG
                        center.value = lastKnownUserLocation
                        activateZoom()
                        startTrackingRoute()
                    }
                })
            }
        }
        data.notifyObservers()
    }

    fun onBluetoothEnableClicked() {
        data.value.requestBluetooth.value = true
        data.notifyObservers()
    }

    fun onBluetoothActivated() {
        checkLocationMode()
    }

    fun onShowDebugDataClicked() {
        dataInteractor.switchDebugDrawing().execute()
        startTrackingDebugData()
        data.value.debugState.shown = !data.value.debugState.shown
        data.notifyObservers()
    }

    fun onRouteButtonClicked() {
        destinationData.preRouteMode = false
        activateRoute()
    }

    fun onFavoriteButtonClicked(placeId: String) {
        if (placeId != DestinationData.EMPTY_PLACE_ID) favoritesInteractor.switchFavorite(placeId).execute()
    }

    fun onDeleteBookmarkClicked(placeId: String, position: Int) {
        favoritesInteractor.switchFavorite(placeId).execute(onComplete = {
            data.value.bookmarksViewState.deletedData = placeId to position
            data.value.bookmarksViewState.showUndo.value = true
            data.notifyObservers()
        })
    }

    fun onUndoButtonClicked(placeId: String) {
        favoritesInteractor.switchFavorite(placeId).execute(onComplete = {
            favoritesInteractor.getFavorites().execute(onSuccess = {
                data.value.bookmarksViewState.deletedData = DEFAULT_ID to 0
                data.value.bookmarksViewState.showUndo.value = false
                data.value.bookmarksViewState.bookmarks.value = placeToBookmarksItemMapper.map(it)
                data.notifyObservers()
            })
        })
    }

    fun onStartRoutingClicked() {
        data.value.userLocationState.isArrow = true
        data.notifyObservers()
    }

    fun onOpenRecordDialogClicked() {
        locationInteractor.isPlayFinished.execute(
                onComplete = this::showRecordPlayFinished,
                onFinished = this::startTrackingLocation
        )

        data.value.showRecordDialog.value = true
        data.notifyObservers()
    }

    fun onRecordPlayerOpenEvent(filePath: String, fileName: String) {
        recorderInteractor.updateData(filePath).execute(
                onComplete = { updateRecordState(RecordStateModel.FILE_OPENED, fileName) }
        )
    }

    fun onRecordPlayerEvent(@DataRecordDialog.Command event: Int) {
        when (event) {
            START -> startRecord()
            STOP -> stopRecord()
            PLAY -> playRecord()
            SAVE -> saveRecord()
            SHARE -> shareRecord()
            OPEN -> openRecord()
        }
    }

    fun onSearchItemClicked(itemId: String, favorite: Boolean) {
        if (data.value.bookmarkAddingActive) {
            favoritesInteractor.switchFavorite(itemId).execute(onComplete = { onQueryChanged(data.value.searchWidgetState.lastQuery) })
            return
        }

        searchDisposable.dispose()
        queryDisposable.dispose()

        searchInteractor.moveToPlaceAndAddToHistory(itemId).execute(
                onSubscribe = { searchDisposable = it },
                onSuccess = {
                    val placePoint = coordinateMapper.map(it.coordinate)

                    data.value.apply {
                        mapCenterState.center.value = placePoint
                        activateZoom()
                        searchWidgetState.searchInFocus.value = false
                        bookmarksViewState.bookmarksViewVisibility.value = false
                        translucentBackgroundVisibility.value = false

                        if (mapCenterState.levelRestored) {
                            mapCenterState.levelRestored = false
                        }
                    }
                    destinationData.preRouteMode = true
                    resetPreRoute(placePoint, it.description, it.id, favorite)
                }
        )
    }

    fun onQueryChanged(query: CharSequence) {
        data.value.searchWidgetState.lastQuery = query

        if (query.isNotEmpty()) searchInteractor.filters.onNext(query) else getRecentSearchItems()
    }

    fun onObjectsButtonClicked() {
        data.value.close.value = true
        data.notifyObservers()
    }

    fun onBookmarksButtonSelected() {
        favoritesInteractor.getFavorites().execute(onSuccess = {
            data.value.bookmarksViewState.bookmarks.value = placeToBookmarksItemMapper.map(it)
            data.value.bookmarksViewState.bookmarksViewVisibility.value = true
            data.value.translucentBackgroundVisibility.value = true
            data.notifyObservers()
        })
    }

    fun onBookmarksButtonUnselected() {
        data.value.bookmarksViewState.bookmarksViewVisibility.value = false
        data.value.translucentBackgroundVisibility.value = false
        data.value.searchWidgetState.searchInFocus.value = false
        data.value.bookmarkAddingActive = false
        data.notifyObservers()
    }

    fun onAddBookmarkClicked() {
        data.value.bookmarksViewState.bookmarksViewVisibility.value = false
        data.value.bookmarkAddingActive = true
        data.notifyObservers()
    }

    fun onCloseBookmarkAddingClicked() = data.apply {
        value.bookmarkAddingActive = false
        value.searchWidgetState.searchInFocus.value = false
        onBookmarksButtonSelected()
        notifyObservers()
    }

    fun onFloorSelectorAnimation(finished: Boolean) {
        data.value.floorSelectorState.animationFinished.value = finished
        data.notifyObservers()
    }

    override fun onBackPressed(): Boolean = with(data.value) {
        when {
            searchWidgetState.searchInFocus.value -> {
                searchWidgetState.searchInFocus.value = false
                floorSelectorState.floorSelectorVisibility = false to false
                if (bookmarkAddingActive) {
                    bookmarkAddingActive = false
                    onBookmarksButtonSelected()
                }
                data.notifyObservers()
                true
            }
            bookmarksViewState.bookmarksViewVisibility.value -> {
                onBookmarksButtonUnselected()
                true
            }
            destination != EMPTY_LAT_LNG || destination == EMPTY_LAT_LNG && bottomSheetState.navigationPanelVisibility -> {
                handleRouteMode(false)
                resetRoute()
                true
            }
            else -> false
        }
    }

    fun onRouteCancelClicked() {
        resetRoute()
        handleRouteMode(false)
    }

    fun onWhereAmIClicked() {
        onCenterLocationClicked()
    }

    fun onSimpleLocationButtonClicked() {
        dataInteractor.switchAndGetSimpleLocationMode().execute(
                onSuccess = { getLocationMode(it) }
        )
    }

    fun onShowPointOfInterestsClicked() {
        navigateToPoiLiveData.value = pointOfInterestsLiveData.value?.markerOptions?.position
    }

    override fun onCleared() {
        broadcastCenter.sendLocalBroadcast(Constants.CLEANING_REQUESTED_ACTION)
        super.onCleared()
    }

    private fun checkLocationMode() {
        dataInteractor.isSimpleLocationMode.execute(
                onSuccess = { getLocationMode(it) }
        )
    }

    private fun getLocationMode(isSimple: Boolean) {
        if (!isSimple) {
            data.value.simpleLocationActive.value = false
            data.notifyObservers()
            startTrackingLocation()
        } else {
            data.value.simpleLocationActive.value = true
            data.notifyObservers()
            startTrackingSimpleLocation()
        }
    }

    private fun showRecordPlayFinished() {
        data.value.showRecordFinished.value = true
        data.notifyObservers()
    }

    private fun startTrackingLocation() {
        locationDisposable.dispose()

        locationInteractor.userLocation.execute(
                onSubscribe = {
                    locationDisposable = it
                    data.value.userLocationState.isSimpleLocation = false
                    data.notifyObservers()
                },
                onNext = {
                    updateLocation(it)
                    tryToShowPointOfInterests()
                    startTrackingRoute()
                    checkReachingDestination()
                },
                onError = this::handleLocationError,
                onFinished = { resetLocation() })
    }

    private fun startTrackingSimpleLocation() {
        locationDisposable.dispose()

        locationInteractor.simpleUserLocation.execute(
                onSubscribe = {
                    locationDisposable = it
                    data.value.userLocationState.isSimpleLocation = true
                    data.notifyObservers()
                },
                onNext = {
                    updateLocation(it)
                    tryToShowPointOfInterests()
                    startTrackingRoute()
                },
                onError = this::handleLocationError)
    }

    private fun startTrackingQuery() {
        queryDisposable.dispose()

        searchInteractor.search().execute(
                onNext = { updateSearchQuery(it) },
                onSubscribe = { queryDisposable = it }
        )
    }

    private fun startTrackingDebugData() {
        debugDataDisposable.dispose()

        dataInteractor.debugData.execute(
                onNext = this::updateDebugState,
                onSubscribe = { debugDataDisposable = it },
                onFinished = { updateDebugState(emptyList()) })
    }

    private fun startTrackingRoute() {
        if (destinationData.destination == DestinationData.EMPTY_DESTINATION || destinationData.start == DestinationData.EMPTY_START) {
            return
        }

        routeDisposable.dispose()

        pathInteractor.startRoute(destinationData.start, destinationData.destination).execute(
                onSubscribe = { routeDisposable = it },
                onSuccess = {
                    if (!destinationData.preRouteMode) {
                        updateRoute(it)
                        handleRouteMode(true)
                    }
                    updateBottomNavigationSheet(it, destinationData)
                },
                onError = {
                    if (it is IllegalStateException) {
                        data.value.showNoRoute.value = true
                        data.value.bottomSheetState.routingError = true
                        resetRoute()
                    }
                }
        )
    }

    private fun activateRoute() {
        destinationData.start = latLngMapper.map(data.value.lastKnownUserLocation)
        destinationData.destination = latLngMapper.map(data.value.destination)
        startTrackingRoute()
    }

    private fun updateBottomNavigationSheet(routeResult: PathInteractor.RouteResult, destinationData: DestinationData) {
        data.value.apply {
            bottomSheetState.bottomSheetItem.value = routeResultToRouteItemsMapper.map(routeResult) to
                    routeResultToDestinationItemMapper.map(routeResult to destinationData)
            data.notifyObservers()
        }
    }

    private fun updateDebugIcon() {
        dataInteractor.isDebugAllowed.execute(onSuccess = {
            data.value.debugState.shown = it
            data.notifyObservers()
        })
    }

    private fun updateSearchInFocus() {
        data.value.searchWidgetState.searchInFocus.needToShow = true
        data.notifyObservers()
    }

    private fun checkReachingDestination() {
        locationInteractor.isDestinationReached(destinationData.start, destinationData.destination).execute(
                onSuccess = {
                    data.value.destinationReached.value = true
                    onRouteCancelClicked()
                }
        )
    }

    private fun updateDestination(dest: LatLng, description: String, id: String, isFavorite: Boolean) {
        data.value.apply {
            destination = dest
            bottomSheetState.navigationPanelVisibility = true
            destinationData.description = description
            destinationData.placeId = id
            destinationData.isFavorite = isFavorite
            data.notifyObservers()
        }
    }

    private fun resetRoute() {
        clearRouteData()
        pathInteractor.endRoute().execute()
        data.value.apply {
            userLocationState.isArrow = false
            bottomSheetState.navigationPanelVisibility = false
        }
        data.notifyObservers()
    }

    private fun resetPreRoute(placePoint: LatLng, description: String, id: String, favorite: Boolean) {
        clearRouteData()
        pathInteractor.endRoute().execute(onComplete = {
            updateDestination(placePoint, description, id, favorite)
            activateRoute()
        })
    }

    private fun clearRouteData() {
        routeDisposable.dispose()

        destinationData.apply {
            start = DestinationData.EMPTY_START
            destination = DestinationData.EMPTY_DESTINATION
            description = DestinationData.EMPTY_DESC
            placeId = DestinationData.EMPTY_PLACE_ID
            isFavorite = false
        }
        data.value.destination = EMPTY_LAT_LNG
        data.value.route = emptyList()
    }

    private fun resetData() {
        data.value.apply {
            if (!mapCenterState.levelRestored) {
                userLocationState.currentLocation = LatLngWrapper(EMPTY_LAT_LNG)
                debugState.beacons = emptyList()
                debugState.beaconDistances = emptyList()
                places = emptyList()
                beacons = emptyList()
                data.notifyObservers()
            }
        }
    }

    private fun updateRoute(result: PathInteractor.RouteResult) {
        data.value.userLocationState.currentRotation = result.rotation
        data.value.route = coordinateMapper.map(result.route)!!
        data.notifyObservers()
    }

    private fun updateDebugState(pivots: List<Pivot>) {
        data.value.debugState.apply {
            beaconDistances = pivotToCircleMapper.map(pivots)!!
            beacons = pivotToMarkerMapper.map(pivots)!!
        }
        data.notifyObservers()
    }

    private fun updateLocation(location: Coordinate) {
        destinationData.start = location
        data.value.userLocationState.currentLocation = coordWrapperMapper.map(location)
        data.value.lastKnownUserLocation = coordinateMapper.map(location)

        userLocationLiveData.value = data.value.userLocationState
    }

    private fun tryToShowPointOfInterests() {
        var targetDistance = Float.MAX_VALUE
        var targetPointOfInterests: MarkerModel? = null

        for (pointOfInterests in data.value.places) {
            val distance = data.value.lastKnownUserLocation.distanceTo(pointOfInterests.markerOptions.position)
            if (NEARBY_POI_DISTANCE - distance >= 0) {
                if (targetDistance > distance) {
                    targetDistance = distance
                    targetPointOfInterests = pointOfInterests
                }
            }
        }
        targetPointOfInterests?.let { updatePointOfInterestsVieState(it) }
    }

    private fun updatePointOfInterestsVieState(pointOfInterests: MarkerModel) {
        pointOfInterestsLiveData.value = pointOfInterests
    }

    private fun resetLocation() {
        data.value.userLocationState.currentLocation = LatLngWrapper(EMPTY_LAT_LNG)

        data.notifyObservers()
    }

    private fun updateFloor(floor: Floor) {
        imageHelper.loadImage(floor.image, getCallback(floor))
        data.value.places = placeToMarkerMapper.map(floor.places)!!
        data.value.beacons = beaconToMarkerMapper.map(floor.beacons)!!
        data.value.currentFloor = floor.number

        updateFloorSelector(floor.number)

        data.notifyObservers()
    }

    private fun getRecentSearchItems() {
        searchDisposable.dispose()

        searchInteractor.getRecentItems().execute(
                onSuccess = { updateRecentItems(it) },
                onSubscribe = { searchDisposable = it }
        )
    }

    private fun updateRecentItems(places: List<Place>) {
        if (data.value.searchWidgetState.lastQuery.isEmpty()) {
            data.value.searchWidgetState.searchItems.value = placeToSearchItemMapper.map(places)!!
            data.notifyObservers()
        }
    }

    private fun updateSearchQuery(places: List<Place>) {
        if (data.value.searchWidgetState.lastQuery.isNotEmpty()) {
            data.value.searchWidgetState.searchItems.value = placeToSearchItemMapper.map(places)!!
            data.notifyObservers()
        }
    }

    private fun createFloorSelector(floors: List<Int>, currentFloor: Int) {
        data.value.floorSelectorState.floorNumbers.value = numberToFloorSelectorItemMapper.map(floors, currentFloor)!!
        data.value.floorSelectorState.floorSelectorVisibility = true to true
        data.value.searchWidgetState.searchInFocus.value = true
        data.notifyObservers()
    }

    private fun updateFloorSelector(floor: Int) {
        val floorNumbers = data.value.floorSelectorState.floorNumbers

        if (floorNumbers.value.isNotEmpty()) {
            numberToFloorSelectorItemMapper.update(floorNumbers.value, floor)
            floorNumbers.needToShow = true
        }
    }

    private fun handleLocationError(throwable: Throwable) {
        if (throwable is BluetoothDisabledException) {
            data.value.showBluetoothDialog.value = true
        }
        data.value.showLocationStopped.value = true

        data.notifyObservers()
    }

    private fun startRecord() {
        updateRecordState(RecordStateModel.RECORDING)
        recorderInteractor.startRecording().execute(onComplete = { startTrackingLocation() })
    }

    private fun stopRecord() {
        recorderInteractor.stopRecording().execute(
                onComplete = { updateRecordState(RecordStateModel.STOPPED) },
                onError = { updateRecordState(RecordStateModel.DATA_EMPTY) },
                onFinished = this::startTrackingLocation
        )
    }

    private fun playRecord() {
        recorderInteractor.startPlaying().execute(onComplete = { startTrackingLocation() })
    }

    private fun saveRecord() {
        recorderInteractor.saveToFile().execute(onComplete = { updateRecordState(RecordStateModel.SAVED) })
    }

    private fun shareRecord() {
        recorderInteractor.file.execute(onSuccess = {
            if (it != null && it.exists()) {
                data.value.shareFile.value = uriHelper.getPathFromFile(it)
            } else {
                data.value.showFileDoesntExists.value = true
            }
            data.notifyObservers()
        })
    }

    private fun openRecord() {
        updateRecordState(RecordStateModel.FILE_OPENING)
    }

    private fun updateRecordState(recordState: RecordStateModel, fileName: String = "") {
        recordDataState.value = recordDataState.value.apply {
            this.fileName = fileName
            this.recordState = recordState
        }
    }

    private fun handleLocationButtons() {
        data.value.apply {
            if (mapCenterState.zoomActivated) {
                if (!routeState.active && !userLocationButtonVisibility) {
                    userLocationButtonVisibility = true
                } else if (routeState.active && whereAmIVisibility) {
                    whereAmIVisibility = false
                }
                mapCenterState.zoomActivated = false
            }
        }
    }

    private fun handleRouteMode(active: Boolean) {
        data.value.apply {
            userLocationButtonVisibility = !active
            routeState.routeActive.value = active
            if (!active) {
                whereAmIVisibility = false
            }
            data.notifyObservers()
        }
    }

    private fun activateZoom() {
        data.value.mapCenterState.apply {
            zoom = DEFAULT_ZOOM
            zoomActivated = true
        }
    }

    private fun getCallback(floor: Floor) = object : ImageHelper.Callback {

        override fun onLoaded(image: Bitmap) {
            val floorImage = FloorImage(image).apply {
                northEastBound = coordinateMapper.map(floor.overlayNorthEastBound)
                southWestBound = coordinateMapper.map(floor.overlaySouthWestBound)
                needToUpdateSize = false
            }
            with(data) {
                value.floorImage = floorImage
                value.mapCenterState.bounds.value = createLatLngBounds(floorImage.southWestBound, floorImage.northEastBound)
                notifyObservers()
            }
        }

        override fun onError(error: Drawable) {
            val errorImage = createDefaultFloorImage(error)
            with(data) {
                value.floorImage = errorImage
                value.mapCenterState.bounds.value = createLatLngBounds(errorImage.southWestBound, errorImage.northEastBound)
                notifyObservers()
            }
        }

        override fun onLoading(placeholder: Drawable) {
            val placeholderImage = createDefaultFloorImage(placeholder)
            with(data) {
                value.floorImage = placeholderImage
                value.mapCenterState.bounds.value = createLatLngBounds(placeholderImage.southWestBound, placeholderImage.northEastBound)
                notifyObservers()
            }
        }
    }

    private fun createDefaultFloorImage(drawable: Drawable) = FloorImage(
            imageHelper.drawableToBitmap(drawable),
            Constants.PLACEHOLDER_ERROR_SIZE,
            Constants.PLACEHOLDER_ERROR_SIZE,
            DEFAULT_SOUTH_WEST_BOUND,
            DEFAULT_NORTH_EAST_BOUND,
            DEFAULT_POSITION)
}
