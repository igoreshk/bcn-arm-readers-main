package com.epam.beacons.record

import androidx.lifecycle.LiveData
import com.epam.beacons.base.modern.BaseState

class RecordLiveData<State : BaseState>(state: State) : LiveData<State>() {

    init {
        value = state
    }

    public override fun setValue(state: State) = super.setValue(state)

    override fun getValue() = super.getValue()
            ?: throw IllegalStateException("Value cannot be null. Value should be initialized in init block")
}
