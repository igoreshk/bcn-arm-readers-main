package com.epam.beacons.base.modern

import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer

open class BaseLiveData<State : BaseState>(state: State) : LiveData<State>() {
    init {
        value = state
    }

    override fun getValue() =
            super.getValue() ?: throw IllegalStateException("Value cannot be null. Value should be initialized in init block")

    fun observe(owner: LifecycleOwner, observer: com.epam.beacons.base.modern.Observer<State>) {
        super.observe(owner, Observer {
            it?.let {
                observer.onChanged(it)
            }
        })
    }

    fun notifyObservers() {
        value = value
    }
}
