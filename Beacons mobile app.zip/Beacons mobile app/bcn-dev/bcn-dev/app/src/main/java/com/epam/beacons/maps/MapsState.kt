package com.epam.beacons.maps

import com.epam.beacons.base.modern.BaseState
import com.epam.beacons.base.modern.SingleEvent
import com.epam.beacons.uimodel.*
import com.epam.beacons.uimodel.bottomnavigationsheet.DestinationItem
import com.epam.beacons.uimodel.bottomnavigationsheet.RouteItem
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.MarkerOptions

class MapsState : BaseState() {

    var lastKnownUserLocation: LatLng = EMPTY_LAT_LNG

    val showBluetoothDialog: SingleEvent<Boolean> = SingleEvent(false)

    val requestBluetooth: SingleEvent<Boolean> = SingleEvent(false)

    val showRecordDialog: SingleEvent<Boolean> = SingleEvent(false)

    val showRecordFinished: SingleEvent<Boolean> = SingleEvent(false)

    val showLocationStopped: SingleEvent<Boolean> = SingleEvent(false)

    val showLocationNotFound: SingleEvent<Boolean> = SingleEvent(false)

    val destinationReached: SingleEvent<Boolean> = SingleEvent(false)

    val showFileDoesntExists: SingleEvent<Boolean> = SingleEvent(false)

    val showNoRoute: SingleEvent<Boolean> = SingleEvent(false)

    val shareFile: SingleEvent<String> = SingleEvent(String())

    val close: SingleEvent<Boolean> = SingleEvent(false)

    var destination: LatLng = EMPTY_LAT_LNG

    var route: List<LatLng> = emptyList()

    var userLocationButtonVisibility: Boolean = true

    var whereAmIVisibility: Boolean = false

    var simpleLocationActive: SingleEvent<Boolean> = SingleEvent(false)

    var debugState: DebugState = DebugState()

    var mapCenterState: MapCenterState = MapCenterState()

    var floorImage: FloorImage? = null

    var places: List<MarkerModel> = emptyList()

    var beacons: List<MarkerOptions> = emptyList()

    var currentFloor: Int = DEFAULT_FLOOR

    var translucentBackgroundVisibility: SingleEvent<Boolean> = SingleEvent(false)

    var bookmarkAddingActive: Boolean = false

    var floorSelectorState = FloorSelectorState()

    var searchWidgetState = SearchWidgetState()

    var bottomSheetState = BottomSheetState()

    var routeState = RouteState()

    var userLocationState = UserLocationState()

    var bookmarksViewState = BookmarksViewState()

    inner class UserLocationState : BaseState() {
        var currentLocation: LatLngWrapper = LatLngWrapper(EMPTY_LAT_LNG)
        var isArrow: Boolean = false
        var currentRotation: Float = 0f
        var isSimpleLocation: Boolean = false
    }

    inner class SearchWidgetState : BaseState() {
        var searchInFocus: SingleEvent<Boolean> = SingleEvent(false)
        var searchItems: SingleEvent<List<SearchItem>> = SingleEvent(emptyList())
        var lastQuery: CharSequence = DEFAULT_QUERY
    }

    inner class FloorSelectorState : BaseState() {
        var floorSelectorVisibility: Pair<Boolean, Boolean> = false to false
        var floorNumbers: SingleEvent<List<FloorSelectorItem>> = SingleEvent(emptyList())
        var animationFinished: SingleEvent<Boolean> = SingleEvent(false)
    }

    inner class DebugState : BaseState() {
        var beaconDistances: List<CircleOptions> = emptyList()
        var beacons: List<MarkerOptions> = emptyList()
        var shown: Boolean = false
    }

    inner class MapCenterState : BaseState() {
        var center: SingleEvent<LatLng> = SingleEvent(EMPTY_LAT_LNG)
        val bounds: SingleEvent<LatLngBounds> = SingleEvent(LatLngBounds(EMPTY_LAT_LNG, EMPTY_LAT_LNG))
        var zoom: Float = DEFAULT_ZOOM
        var zoomActivated: Boolean = false
        var levelRestored: Boolean = false
        var levelSwitched: Boolean = true
    }

    inner class BottomSheetState : BaseState() {
        var navigationPanelVisibility: Boolean = false
        var bottomSheetItem: SingleEvent<Pair<List<RouteItem>, DestinationItem>> = SingleEvent(mutableListOf<RouteItem>() to DestinationItem())
        var routingError: Boolean = false
    }

    inner class RouteState : BaseState() {
        var routeActive: SingleEvent<Boolean> = SingleEvent(false)
        var active: Boolean = false
    }

    inner class BookmarksViewState : BaseState() {
        var bookmarks: SingleEvent<MutableList<BookmarkItem>> = SingleEvent(mutableListOf())
        var bookmarksViewVisibility: SingleEvent<Boolean> = SingleEvent(false)
        var showUndo: SingleEvent<Boolean> = SingleEvent(false)
        var deletedData: Pair<String, Int> = DEFAULT_ID to 0
    }

    companion object {
        const val DEFAULT_QUERY = ""
        const val DEFAULT_ZOOM = 20f
        const val DEFAULT_FLOOR = Int.MIN_VALUE
        const val DEFAULT_ID = "DEFAULT"
        val EMPTY_LAT_LNG = LatLng(Double.MAX_VALUE, Double.MAX_VALUE)
        val DEFAULT_POSITION = LatLng(0.0, 0.0)
        val DEFAULT_SOUTH_WEST_BOUND = LatLng(-0.0004, -0.0004)
        val DEFAULT_NORTH_EAST_BOUND = LatLng(0.0004, 0.0004)
    }
}
