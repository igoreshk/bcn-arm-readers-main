package com.epam.beacons.record;

import androidx.lifecycle.Observer;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.IntDef;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentManager;
import android.widget.Button;
import android.widget.TextView;

import com.epam.beacons.R;
import com.epam.beacons.dialogs.BaseDialogFragment;
import com.epam.beacons.maps.MapsViewModel;
import com.epam.beacons.utils.IntentFactory;
import com.epam.beacons.utils.extensions.UriExtKt;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import butterknife.BindView;
import butterknife.OnClick;

import static android.app.Activity.RESULT_OK;

public class DataRecordDialog extends BaseDialogFragment<MapsViewModel> {

    @NonNull
    private static final String DIALOG_TAG           = DataRecordDialog.class.getSimpleName();
    private static final int    PICKFILE_RESULT_CODE = 1;

    @BindView(R.id.btn_start_record)
    Button   startRecord;
    @BindView(R.id.btn_stop_record)
    Button   stopRecord;
    @BindView(R.id.btn_play_record)
    Button   playRecord;
    @BindView(R.id.btn_save_record)
    Button   saveRecord;
    @BindView(R.id.btn_share_record)
    Button   shareRecord;
    @BindView(R.id.btn_open_record)
    Button   openRecord;
    @BindView(R.id.file_name)
    TextView fileName;

    @NonNull
    private final Observer<RecordDataState> recordStateObserver = state -> {
        if (state == null) {
            return;
        }
        switch (state.getRecordState()) {
            case DATA_EMPTY:
                setNoDataState();
                break;
            case RECORDING:
                setRecordingState();
                break;
            case STOPPED:
                setStoppedState();
                break;
            case SAVED:
                setSavedState();
                break;
            case FILE_OPENED:
                setFileOpenedState();
                break;
            case FILE_OPENING:
                openFileManager();
                break;
            default:
                break;
        }
        fileName.setText(state.getFileName());
    };

    private void setNoDataState() {
        startRecord.setEnabled(true);
        stopRecord.setEnabled(false);
        playRecord.setEnabled(false);
        saveRecord.setEnabled(false);
        shareRecord.setEnabled(false);
        openRecord.setEnabled(true);
    }

    private void setRecordingState() {
        startRecord.setEnabled(false);
        stopRecord.setEnabled(true);
        playRecord.setEnabled(false);
        saveRecord.setEnabled(false);
        shareRecord.setEnabled(false);
        openRecord.setEnabled(false);
    }

    private void setStoppedState() {
        startRecord.setEnabled(true);
        stopRecord.setEnabled(false);
        playRecord.setEnabled(true);
        saveRecord.setEnabled(true);
        shareRecord.setEnabled(false);
        openRecord.setEnabled(true);
    }

    private void setSavedState() {
        shareRecord.setEnabled(true);
    }

    private void setFileOpenedState() {
        playRecord.setEnabled(true);
        shareRecord.setEnabled(true);
        saveRecord.setEnabled(false);
    }

    public static void show(@NonNull FragmentManager fragmentManager) {
        DataRecordDialog dataRecordDialog = new DataRecordDialog();
        dataRecordDialog.show(fragmentManager, DIALOG_TAG);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel.getRecordDataState().observe(this, recordStateObserver);
    }

    @OnClick(R.id.btn_start_record)
    public void startRecord() {
        viewModel.onRecordPlayerEvent(Command.START);
    }

    @OnClick(R.id.btn_stop_record)
    public void stopRecord() {
        setCancelable(true);
        viewModel.onRecordPlayerEvent(Command.STOP);
    }

    @OnClick(R.id.btn_play_record)
    public void playRecord() {
        viewModel.onRecordPlayerEvent(Command.PLAY);
        dismiss();
    }

    @OnClick(R.id.btn_save_record)
    public void saveRecord() {
        viewModel.onRecordPlayerEvent(Command.SAVE);
    }

    @OnClick(R.id.btn_share_record)
    public void shareRecord() {
        viewModel.onRecordPlayerEvent(Command.SHARE);
    }

    @OnClick(R.id.btn_open_record)
    public void openRecord() {
        viewModel.onRecordPlayerEvent(Command.OPEN);
    }

    private void openFileManager() {
        startActivityForResult(IntentFactory.getFileManagerIntent(), PICKFILE_RESULT_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == PICKFILE_RESULT_CODE && resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                viewModel.onRecordPlayerOpenEvent(UriExtKt.getExternalPath(data.getData()), data.getData().getLastPathSegment());
            }
        }
    }

    @Override
    protected int getDialogTitle() {
        return R.string.record_dialog_title;
    }

    @Override
    protected int getLayoutRes() {
        return R.layout.record_dialog;
    }

    @NonNull
    @Override
    protected Class<MapsViewModel> getViewModelClass() {
        return MapsViewModel.class;
    }

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({
            DataRecordDialog.Command.START,
            DataRecordDialog.Command.STOP,
            DataRecordDialog.Command.PLAY,
            DataRecordDialog.Command.SAVE,
            DataRecordDialog.Command.SHARE,
            DataRecordDialog.Command.OPEN})
    public @interface Command {
        int START = 1;
        int STOP  = 2;
        int PLAY  = 3;
        int SAVE  = 4;
        int SHARE = 5;
        int OPEN  = 6;
    }
}
