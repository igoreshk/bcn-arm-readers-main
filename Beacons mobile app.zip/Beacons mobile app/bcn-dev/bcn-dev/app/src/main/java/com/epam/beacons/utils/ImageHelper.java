package com.epam.beacons.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.widget.ImageView;

import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.epam.beacons.R;
import com.epam.beacons.tools.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class ImageHelper {
    private static final float  MAX_SIZE_IN_PIXELS = 2000;
    @NonNull
    private static final String LOG_TAG            = ImageHelper.class.getSimpleName();
    @NonNull
    private final Context  context;
    @NonNull
    private final Logger   logger;
    @Nullable
    private       Callback callback;
    @NonNull
    private final SimpleTarget<Bitmap> target = new SimpleTarget<Bitmap>() {
        @Override
        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
            if (callback != null) {
                callback.onLoaded(checkImage(resource));
                callback = null;
            }
            logger.d(LOG_TAG, "Image loaded successfully");
        }

        @Override
        public void onLoadStarted(@Nullable Drawable placeholder) {
            if (callback != null && placeholder != null) {
                callback.onLoading(placeholder);
            }
            logger.d(LOG_TAG, "Image is loading");
        }

        @Override
        public void onLoadFailed(@Nullable Drawable errorDrawable) {
            if (callback != null && errorDrawable != null) {
                callback.onError(errorDrawable);
                callback = null;
            }
            logger.e(LOG_TAG, "Error, image not loaded");
        }
    };

    @Inject
    ImageHelper(@NonNull Context context, @NonNull Logger logger) {
        this.context = context;
        this.logger = logger;
    }

    public void loadImage(@NonNull String url, @NonNull Callback callback) {
        this.callback = callback;

        clearMemory();

        GlideApp.with(context)
                .asBitmap()
                .load(url)
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.error)
                .into(target);
    }

    public void loadImage(@NonNull String url, @NonNull ImageView imageView) {
        GlideApp.with(context)
                .load(url)
                .placeholder(R.drawable.placeholder_animated)
                .error(R.drawable.error)
                .centerCrop()
                .into(imageView);
    }

    private void clearMemory() {
        GlideApp.with(context)
                .clear(target);

        GlideApp.get(context)
                .clearMemory();
    }

    @NonNull
    public Bitmap drawableToBitmap(@NonNull Drawable source) {
        final Bitmap bitmap = Bitmap.createBitmap(source.getIntrinsicWidth(), source.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);

        final Canvas canvas = new Canvas(bitmap);
        source.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        source.draw(canvas);

        return bitmap;
    }

    @NonNull
    private Bitmap checkImage(@NonNull Bitmap resource) {
        final float originalWidth = resource.getWidth();
        final float originalHeight = resource.getHeight();

        final float currentMaxSideSize = Math.max(originalWidth, originalHeight);

        final float scale = Math.min(MAX_SIZE_IN_PIXELS / currentMaxSideSize, 1);

        return Bitmap.createScaledBitmap(resource, (int) (originalWidth * scale), (int) (originalHeight * scale), true);
    }

    public interface Callback {

        void onLoaded(@NonNull Bitmap image);

        void onError(@NonNull Drawable error);

        void onLoading(@NonNull Drawable placeholder);
    }
}
