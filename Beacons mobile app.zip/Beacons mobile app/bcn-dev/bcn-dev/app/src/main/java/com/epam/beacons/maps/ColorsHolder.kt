package com.epam.beacons.maps

import android.app.Activity
import androidx.annotation.ColorInt
import androidx.core.graphics.ColorUtils
import com.epam.beacons.R
import com.epam.beacons.utils.ThemeUtils

class ColorsHolder {

    @ColorInt
    var colorPolyline: Int = 0
    @ColorInt
    var errorCircleColor: Int = 0

    fun resolve(activity: Activity) {
        colorPolyline = ThemeUtils.getColorFromTheme(activity, R.attr.mapPolylineColor, R.attr.mapTheme)
        errorCircleColor = ColorUtils.setAlphaComponent(
                ThemeUtils.getColorFromTheme(activity, R.attr.mapCircleColor, R.attr.mapTheme), CIRCLE_ALPHA_COLOR)
    }

    companion object {
        private const val CIRCLE_ALPHA_COLOR = 61
    }
}
