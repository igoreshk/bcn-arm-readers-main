package com.epam.beacons.utils.mappers

import com.epam.beacons.interactors.PathInteractor
import com.epam.beacons.maps.DestinationData
import com.epam.beacons.tools.Mapper
import com.epam.beacons.uimodel.bottomnavigationsheet.DestinationItem
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RouteResultToDestinationItemMapper @Inject constructor(
        private val mapper: CoordinatesToLatLngsMapper
) : Mapper<Pair<PathInteractor.RouteResult, DestinationData>, DestinationItem>() {

    override fun map(from: Pair<PathInteractor.RouteResult, DestinationData>) =
            DestinationItem(
                    from.second.description,
                    mapper.map(from.first.destination),
                    from.first.routeDistance,
                    from.second.placeId,
                    from.second.isFavorite
            )
}
