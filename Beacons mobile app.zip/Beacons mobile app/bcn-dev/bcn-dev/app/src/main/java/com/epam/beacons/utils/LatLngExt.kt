package com.epam.beacons.utils

import android.location.Location
import android.location.LocationManager
import com.google.android.gms.maps.model.LatLng

fun LatLng.toLocation() = Location(LocationManager.GPS_PROVIDER).apply {
    latitude = this@toLocation.latitude
    longitude = this@toLocation.longitude
}

fun LatLng.distanceTo(latLng: LatLng) = toLocation().distanceTo(latLng.toLocation())
