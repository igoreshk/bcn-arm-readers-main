package com.epam.beacons.dagger

import android.content.Context
import com.epam.beacons.BuildConfig
import com.epam.beacons.parser.MockDataParser
import com.epam.beacons.utils.SslUtils.CERTIFICATE_FILE_NAME
import com.epam.beacons.utils.SslUtils.createTrustManagers
import com.epam.beacons.utils.SslUtils.getSslContextForCertificateFile
import com.epam.beacons.utils.SslUtils.getTrustManager
import com.rest.api.RestLayer
import com.rest.api.RestLayerImpl
import com.rest.api.service.DataParser
import com.rest.api.service.MockedService
import com.rest.api.service.RestService
import dagger.Binds
import dagger.Module
import dagger.Provides
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.mock.BehaviorDelegate
import retrofit2.mock.MockRetrofit
import retrofit2.mock.NetworkBehavior
import java.net.URI
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
abstract class RestModule {

    @Module
    companion object {
        private const val REST_TIMEOUT = 15L

        @JvmStatic
        @Provides
        @Singleton
        fun provideRestService(retrofit: Retrofit, service: MockedService): RestService =
                if ("mocked" == BuildConfig.FLAVOR) service else retrofit.create(RestService::class.java)

        @JvmStatic
        @Provides
        @Singleton
        fun provideHttpClient(context: Context): OkHttpClient {
            val interceptor = HttpLoggingInterceptor()
            interceptor.level = HttpLoggingInterceptor.Level.BODY

            val trustManagers = createTrustManagers(context, CERTIFICATE_FILE_NAME)
            val trustManager = getTrustManager(trustManagers)
            val sslContext = getSslContextForCertificateFile(trustManagers)

            return OkHttpClient.Builder()
                    .connectTimeout(REST_TIMEOUT, TimeUnit.SECONDS)
                    .addInterceptor(interceptor)
                    .sslSocketFactory(sslContext.socketFactory, trustManager)
                    .hostnameVerifier { hostname, _ -> URI(BuildConfig.REST).host == hostname }
                    .build()
        }

        @JvmStatic
        @Provides
        @Singleton
        fun provideRetrofit(client: OkHttpClient): Retrofit =
                Retrofit.Builder()
                        .baseUrl(BuildConfig.REST)
                        .addConverterFactory(GsonConverterFactory.create())
                        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                        .client(client)
                        .build()

        @JvmStatic
        @Provides
        @Singleton
        fun provideBehaviorDelegate(retrofit: Retrofit): BehaviorDelegate<RestService> =
                MockRetrofit.Builder(retrofit)
                        .networkBehavior(NetworkBehavior.create())
                        .build()
                        .create(RestService::class.java)
    }

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun provideRestLayer(rest: RestLayerImpl): RestLayer

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun provideDataParser(dataParser: MockDataParser): DataParser
}
