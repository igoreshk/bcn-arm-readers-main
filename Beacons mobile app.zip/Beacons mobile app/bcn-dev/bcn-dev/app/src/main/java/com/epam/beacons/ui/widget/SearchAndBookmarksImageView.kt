package com.epam.beacons.ui.widget

import android.content.Context
import android.graphics.drawable.Drawable
import androidx.appcompat.widget.AppCompatImageView
import android.util.AttributeSet
import com.epam.beacons.R
import com.epam.beacons.utils.extensions.drawableOrDefault

class SearchAndBookmarksImageView @JvmOverloads constructor(context: Context, attributeSet: AttributeSet? = null, defStyleAttr: Int = 0)
    : AppCompatImageView(context, attributeSet, defStyleAttr) {

    private var drawableToShow = context.drawableOrDefault(R.drawable.ic_search_error_icon)
    private val postImage = { setImageDrawable(drawableToShow) }

    fun setImage(resource: Drawable) {
        handler?.removeCallbacks(postImage)
        drawableToShow = resource
        handler?.postDelayed(postImage, DELAY_DURATION) ?: post(postImage)
    }

    companion object {
        private const val DELAY_DURATION = 600L
    }
}
