package com.epam.beacons.utils.mappers

import com.epam.beacons.Coordinate
import com.epam.beacons.tools.Mapper
import com.epam.beacons.uimodel.LatLngWrapper
import com.google.android.gms.maps.model.LatLng
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CoordinateToLatLngWrapperMapper @Inject constructor() : Mapper<Coordinate, LatLngWrapper>() {

    override fun map(from: Coordinate): LatLngWrapper {
        val result = LatLngWrapper(LatLng(from.latitude, from.longitude))
        result.additionalRadius = from.errorRadius
        return result
    }
}
