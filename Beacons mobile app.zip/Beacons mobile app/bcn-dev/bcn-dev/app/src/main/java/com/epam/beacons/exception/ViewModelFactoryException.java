package com.epam.beacons.exception;

public class ViewModelFactoryException extends RuntimeException {

    public ViewModelFactoryException(Throwable cause) {
        super(cause);
    }
}