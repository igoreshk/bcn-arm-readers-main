package com.epam.beacons.dagger

import com.epam.beacons.MainApp
import dagger.Component
import dagger.android.AndroidInjectionModule
import dagger.android.AndroidInjector
import dagger.android.support.AndroidSupportInjectionModule
import javax.inject.Singleton

@Singleton
@Component(modules = [
    AndroidInjectionModule::class,
    AndroidSupportInjectionModule::class,
    AndroidBindingModule::class,
    AppModule::class,
    InteractorsModule::class,
    LocatorModule::class,
    DistanceModule::class,
    ScannerModule::class,
    RepositoryModule::class,
    ToolsModule::class,
    KalmanModule::class,
    SensorsModule::class,
    RestModule::class,
    StorageModule::class,
    PreferencesModule::class,
    CacheModule::class,
    GraphBinderModule::class
])
interface AppComponent : AndroidInjector<MainApp> {

    @Component.Builder
    abstract class Builder : AndroidInjector.Builder<MainApp>()
}
