package com.epam.beacons.broadcasts

interface BroadcastCenter {
    fun sendLocalBroadcast(action: String)
}
