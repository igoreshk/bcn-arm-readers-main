package com.epam.beacons.base.modern

import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import butterknife.ButterKnife
import com.epam.beacons.utils.PermissionHelper
import com.epam.beacons.utils.fps.FpsHelper
import dagger.android.AndroidInjection
import java.util.ArrayList
import java.util.LinkedList
import javax.inject.Inject

abstract class BaseActivityNew<State : BaseState, ViewModel : BaseViewModelNew<State>> : AppCompatActivity() {

    protected abstract val vmClass: Class<ViewModel>

    protected abstract val layoutRes: Int

    @Inject
    lateinit var factory: ViewModelProvider.Factory

    @Inject
    lateinit var permissionHelper: PermissionHelper

    @Inject
    lateinit var fpsHelper: FpsHelper

    protected val viewModel: ViewModel by lazy {
        ViewModelProviders.of(this, factory).get(this.vmClass)
    }

    private val navigationInterceptors: MutableList<NavigationInterceptor> by lazy {
        LinkedList<NavigationInterceptor>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)

        setContentView(layoutRes)

        // TODO: 20.02.2018 should be replaced with kotlin android extensions EPMLSTRBCA-50
        ButterKnife.bind(this)

        viewModel.data.observe(this, object : Observer<State> {
            override fun onChanged(t: State) {
                applyChanges(t)
            }
        })

        //noinspection RestrictedApi
        lifecycle.addObserver(viewModel)

        viewModel.onOwnerCreated(savedInstanceState != null)

        register(viewModel)
    }

    override fun onResume() {
        super.onResume()
        fpsHelper.show(this)
    }

    override fun onPause() {
        fpsHelper.hide(this)
        super.onPause()
    }

    override fun onDestroy() {
        //noinspection RestrictedApi
        lifecycle.removeObserver(viewModel)
        unregister(viewModel)
        super.onDestroy()
    }

    final override fun onBackPressed() {
        if (!handleBackByInterceptors()) {
            super.onBackPressed()
        }
    }

    final override fun onNavigateUp(): Boolean {
        if (!handleUpByInterceptors()) {
            return super.onNavigateUp()
        }
        return true
    }

    final override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        val deniedPermissions = ArrayList<String>()
        val grantedPermissions = ArrayList<String>()

        grantResults.indices.forEach {
            if (grantResults[it] == PackageManager.PERMISSION_GRANTED) {
                grantedPermissions += permissions[it]
            } else {
                deniedPermissions += permissions[it]
            }
        }

        if (grantedPermissions.isNotEmpty()) {
            onPermissionGranted(requestCode, grantedPermissions)
        }

        if (deniedPermissions.isNotEmpty()) {
            onPermissionDenied(requestCode, deniedPermissions)
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    private fun register(interceptor: NavigationInterceptor) {
        navigationInterceptors.add(interceptor)
    }

    private fun unregister(interceptor: NavigationInterceptor) {
        navigationInterceptors.remove(interceptor)
    }

    protected fun requestPermission(requestCode: Int, vararg permissions: String) {
        if (permissionHelper.isPermissionsDenied(this, permissions)) {
            permissionHelper.requestPermissions(this, permissions, requestCode)
        } else {
            onPermissionGranted(requestCode, permissions.toList())
        }
    }

    protected open fun onPermissionGranted(requestCode: Int, permissions: List<String>) {
    }

    protected open fun onPermissionDenied(requestCode: Int, permissions: List<String>) {
    }

    abstract fun applyChanges(state: State)

    private fun handleBackByInterceptors() = navigationInterceptors.any { it.onBackPressed() }

    private fun handleUpByInterceptors() = navigationInterceptors.any { it.onUpPressed() }
}
