package com.epam.beacons.utils.mappers

import com.epam.beacons.Coordinate
import com.epam.beacons.tools.Mapper
import com.epam.beacons.utils.Constants
import com.google.android.gms.maps.model.LatLng
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ScaleAwareCoordinateToLatLngMapper @Inject constructor(
        private val mapper: CoordinatesToLatLngsMapper
) : Mapper<Coordinate, LatLng>() {

    override fun map(from: Coordinate): LatLng {
        val scaled = Coordinate(
                from.latitude / Constants.ONE_METER_AT_EQUATOR,
                from.longitude / Constants.ONE_METER_AT_EQUATOR
        )
        return mapper.map(scaled)
    }
}
