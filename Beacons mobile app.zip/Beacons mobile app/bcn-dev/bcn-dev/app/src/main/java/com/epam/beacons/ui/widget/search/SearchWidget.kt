package com.epam.beacons.ui.widget.search

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Outline
import android.os.Bundle
import android.os.Parcelable
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import android.transition.ChangeBounds
import android.transition.Fade
import android.transition.TransitionManager
import android.transition.TransitionSet
import android.util.AttributeSet
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import com.epam.beacons.R
import com.epam.beacons.ui.widget.SearchAndBookmarksItemDecorator
import com.epam.beacons.uimodel.SearchItem
import com.epam.beacons.utils.GlideHelper
import com.epam.beacons.utils.extensions.*
import kotlinx.android.synthetic.main.view_search.view.*
import kotlinx.android.synthetic.main.view_search.view.action_debug_data as debugData
import kotlinx.android.synthetic.main.view_search.view.action_record_dialog as recordDialog
import kotlinx.android.synthetic.main.view_search.view.bottom_background_container as bottomColorContainer
import kotlinx.android.synthetic.main.view_search.view.clear_cross as clearSearch
import kotlinx.android.synthetic.main.view_search.view.level_number as levelNumber
import kotlinx.android.synthetic.main.view_search.view.level_text as levelText
import kotlinx.android.synthetic.main.view_search.view.line_separator as separator
import kotlinx.android.synthetic.main.view_search.view.middle_background_container as initialColorContainer
import kotlinx.android.synthetic.main.view_search.view.search_edit as searchEdit
import kotlinx.android.synthetic.main.view_search.view.search_icon as searchIcon
import kotlinx.android.synthetic.main.view_search.view.search_results as searchResults
import kotlinx.android.synthetic.main.view_search.view.top_background_container as activeColorContainer

class SearchWidget @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleAttr: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr) {

    var searchListener: SearchListener? = null
    var levelsListener: LevelsListener? = null
    var debugListener: DebugListener? = null
    var queryListener: QueryChangeListener? = null
    var searchItemClickListener: SearchItemClickListener? = null
    var routeModeListener: RouteModeListener? = null
    var levelsFocused = false
    var debugDataActive: Boolean = false
        set(value) {
            debugData.setImageResource(if (value) R.drawable.ic_visibility else R.drawable.ic_visibility_off)
        }
    private var searchActive = false
    private val searchResultAdapter = SearchResultsAdapter(GlideHelper(context))
    private val animationHelper: SearchAnimationHelper
    private val translationMiddle = (context.dimenPx(R.dimen.search_levels_width) / 2).toFloat()
    private val translationLeft = context.dimenPx(R.dimen.search_panel_side_margin).toFloat()
    private val searchResultsTransition = TransitionSet().addTransition(ChangeBounds()).addTransition(Fade())
            .setOrdering(TransitionSet.ORDERING_TOGETHER)
    private val widgetHeight = context.dimenPx(R.dimen.search_widget_height)
    private val searchResultsMargin = context.dimenPx(R.dimen.search_margin) + context.dimenPx(R.dimen.search_results_keyboard_margin)
    private val bottomPanelHeight = context.dimenPx(R.dimen.bottom_navigation_height)
    private val topPanelHeight = context.dimenPx(R.dimen.add_bookmark_panel_height) - context.getStatusBarHeight()
    private val levelsSize = context.dimenPx(R.dimen.search_levels_width)
    private val widgetElevation = context.dimenPx(R.dimen.search_widget_elevation)
    private val widgetElevationRouteRight = context.dimenPx(R.dimen.search_widget_elevation_route_mode_right)
    private val widgetElevationRouteLeft = context.dimenPx(R.dimen.search_widget_elevation_route_mode_left)
    private val cornerRadius = context.dimenPx(R.dimen.search_corner_radius).toFloat()
    private val cornerRadiusRoute = context.dimenPx(R.dimen.search_corner_radius_route_mode).toFloat()
    private val addBookmarkModeTranslation = context.dimenPx(R.dimen.add_bookmark_panel_height).toFloat() - context.getStatusBarHeight()
    private var routeActive = false
    private var addBookmarkActive = false
    private var restored = false

    init {
        inflate(context, R.layout.view_search, this)

        setupSearchEdit()
        setupSearchIcon()
        setupSearchResults()
        levels.setOnClickListener { levelsListener?.onLevelClicked() }
        clearSearch.setOnClickListener {
            searchEdit.clear()
            queryListener?.onQueryChange(EMPTY_QUERY)
        }

        debugData.setOnClickListener { debugListener?.onDebugDataClicked() }
        recordDialog.setOnClickListener { debugListener?.onRecordClicked() }
        levelNumber.text = INITIAL_FLOOR

        animationHelper = SearchAnimationHelper()

        doOnLayoutChange { animationHelper.initAnimators() }
    }

    fun setData(data: List<SearchItem>) {
        TransitionManager.beginDelayedTransition(this, searchResultsTransition)
        searchResultAdapter.data = data
    }

    fun focusChanged(inFocus: Boolean, fsAnimationFinished: Boolean) {
        when {
            !inFocus && searchActive -> disableSearch()
            inFocus && !levelsFocused && !searchActive && !fsAnimationFinished -> activateLevels()
            !inFocus && levelsFocused && fsAnimationFinished -> disableLevels()
        }
    }

    fun onRouteActive() {
        if (!routeActive) {
            routeActive = true
            animationHelper.routeModeActive.start()
        }
    }

    fun onRouteNonActive() {
        if (routeActive) {
            routeActive = false
            animationHelper.routeModeNonActive.start()
        }
    }

    fun onAddBookmarkActive() {
        if (!addBookmarkActive) {
            addBookmarkActive = true
            animationHelper.moveDown.start()
            searchEdit.performClick()
        } else if (addBookmarkActive && restored) {
            translationY = addBookmarkModeTranslation
            restored = false
            searchEdit.performClick()
        }
    }

    fun onAddBookmarkNonActive() {
        if (addBookmarkActive) {
            addBookmarkActive = false
            animationHelper.moveUp.start()
            disableSearch()
        }
    }

    override fun onSaveInstanceState(): Parcelable = Bundle().apply {
        putParcelable(SUPER_STATE_KEY, super.onSaveInstanceState())
        putParcelableArrayList(SEARCH_ITEMS, ArrayList<Parcelable>(searchResultAdapter.data))
        putBoolean(SEARCH_ACTIVE_KEY, searchActive)
        putBoolean(SEARCH_LEVEL_FOCUSED, levelsFocused)
        putBoolean(ROUTE_ACTIVE, routeActive)
        putBoolean(BOOKMARK_ACTIVE, addBookmarkActive)
    }

    override fun onRestoreInstanceState(state: Parcelable?) {
        if (state !is Bundle) {
            super.onRestoreInstanceState(state)
            return
        }
        routeActive = state.getBoolean(ROUTE_ACTIVE)
        levelsFocused = state.getBoolean(SEARCH_LEVEL_FOCUSED)
        addBookmarkActive = state.getBoolean(BOOKMARK_ACTIVE)
        restored = true

        if (routeActive) {
            restoreRouteActive()
        } else {
            state.getBoolean(SEARCH_ACTIVE_KEY).let {
                searchActive = it
                setTextEdited(it)
                if (it) searchEdit.showKeyboard(true)
            }

            searchResultAdapter.data = state.getParcelableArrayList<SearchItem>(SEARCH_ITEMS) as List<SearchItem>
        }
        animationHelper.initAnimators()

        super.onRestoreInstanceState(state.getParcelable(SUPER_STATE_KEY))
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        outlineProvider = when {
            routeActive -> SearchOutlineProviderRoute()
            //
            searchResults.adapter?.itemCount!! > 0 && searchResults.visibility == View.VISIBLE -> SearchOutlineProvider(w, h)
            else -> SearchOutlineProvider(w)
        }
    }

    private fun setupSearchResults() {
        searchResults.apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
            searchResultAdapter.onSearchItemClickListener = object : SearchResultsAdapter.OnSearchItemClickListener {
                override fun onSearchItemSelected(searchItem: String, isFavorite: Boolean) {
                    showKeyboard(false)
                    searchItemClickListener?.onSearchItemClicked(searchItem, isFavorite)
                }
            }
            addItemDecoration(SearchAndBookmarksItemDecorator(context))
            adapter = searchResultAdapter
            itemAnimator = null
            viewTreeObserver.addOnGlobalLayoutListener { resizeSearchResults() }
        }
    }

    private fun resizeSearchResults() = searchResults.run {
        if (!searchActive) return

        val usableHeight = computeUsableHeight()
        if (usableHeight != previousUsableHeight) {
            maxHeight = usableHeight - widgetHeight - searchResultsMargin
            if (usableHeight > previousUsableHeight && !isKeyboardVisible()) {
                maxHeight -= bottomPanelHeight
            }
            if (addBookmarkActive) {
                maxHeight -= topPanelHeight
            }
            requestLayout()
            previousUsableHeight = usableHeight
        }
    }

    private fun setupSearchEdit() {
        searchEdit.apply {
            setOnClickListener {
                if (!searchActive) {
                    onClick()
                    showKeyboard(true)
                }
            }
            onTextChange { newString -> onTextChanges(newString) }
            onEditorAction { query ->
                run {
                    if (searchResultAdapter.data.isEmpty()) {
                        return@onEditorAction
                    }
                    val item = searchResultAdapter.data[0]
                    if (query.toString() == item.title) {
                        showKeyboard(false)
                        searchItemClickListener?.onSearchItemClicked(item.id.toString(), item.marked)
                    } else {
                        onTextChanges(query)
                    }
                }
            }
        }
    }

    private fun setupSearchIcon() {
        searchIcon.setOnClickListener { this@SearchWidget.searchEdit.performClick() }
    }

    private fun onClick() {
        activateSearch()
        searchListener?.onSearchClicked()
    }

    private fun onTextChanges(newString: CharSequence?) {
        newString?.let { queryListener?.onQueryChange(it) }

        if (!newString.isNullOrEmpty() && searchActive) {
            if (clearSearch.visibility == View.VISIBLE) return
            animationHelper.showCross.start()
        } else {
            hideCloseCross()
        }
    }

    private fun hideCloseCross() {
        animationHelper.hideCross.start()
    }

    private fun activateSearch() {
        searchEdit.isFocusableInTouchMode = true
        if (!searchEdit.text.isNullOrEmpty()) {
            animationHelper.activateAndShowCrossAnimation.start()
        } else {
            animationHelper.activateAnimation.start()
        }

        if (levelsFocused) {
            animationHelper.showActiveBackground.start()
        } else {
            animationHelper.initialToActiveBackground.start()
        }
        searchResults.visible(true)
        levelsFocused = false
        searchActive = true
    }

    private fun disableSearch() {
        searchEdit.showKeyboard(false)
        if (!searchEdit.text.isNullOrEmpty()) hideCloseCross()

        animationHelper.deactivateAnimation.start()
        animationHelper.hideActiveAndInitialBackground.start()
        searchResults.visible(false)
        levelsFocused = false
        searchActive = false
    }

    private fun activateLevels() {
        if (!routeActive) {
            toAnimator(View.TRANSLATION_Z, ACTIVE_TRANSLATION_Z).start()
            animationHelper.showInitialBackground.start()
        }
        levelsFocused = true
    }

    private fun disableLevels() {
        if (!routeActive) {
            toAnimator(View.TRANSLATION_Z, REST_TRANSLATION_Z).start()
            animationHelper.hideInitialBackground.start()
        }
        levelsFocused = false
    }

    private fun setTextEdited(value: Boolean) {
        if (value) {
            activeColorContainer.alpha = MAX_ALPHA
            initialColorContainer.alpha = MIN_ALPHA
            separator.translationX = translationMiddle
            levelText.translationX = translationMiddle
            levelNumber.translationX = translationMiddle
        } else {
            activeColorContainer.alpha = MIN_ALPHA
            initialColorContainer.alpha = if (levelsFocused) MAX_ALPHA else MIN_ALPHA
            separator.translationX = TRANSLATION_BEGINNING
            levelText.translationX = TRANSLATION_BEGINNING
            levelNumber.translationX = TRANSLATION_BEGINNING
        }
        levels.visible(!value)
        separator.visible(!value)
        searchResults.visible(value)
    }

    private fun restoreRouteActive() {
        routeModeIcons(false)
        levels.setBackgroundResource(R.drawable.buttons_in_route_mode_background)
        translationX = -translationLeft
        searchIcon.alpha = MIN_ALPHA
        searchEdit.alpha = MIN_ALPHA
        recordDialog.alpha = MIN_ALPHA
        debugData.alpha = MIN_ALPHA
        separator.alpha = MIN_ALPHA
        bottomColorContainer.alpha = MIN_ALPHA
        routeModeListener?.onRouteModeChanged(true)
    }

    private fun routeModeIcons(visible: Boolean) {
        searchIcon.visible(visible)
        searchEdit.visible(visible)
        recordDialog.visible(visible)
        debugData.visible(visible)
        separator.visible(visible)

        bottomColorContainer.visible(visible)
        initialColorContainer.visible(visible)
        activeColorContainer.visible(visible)
    }

    interface SearchListener {
        fun onSearchClicked()
    }

    interface LevelsListener {
        fun onLevelClicked()
    }

    interface DebugListener {
        fun onDebugDataClicked()
        fun onRecordClicked()
    }

    interface QueryChangeListener {
        fun onQueryChange(query: CharSequence)
    }

    interface SearchItemClickListener {
        fun onSearchItemClicked(itemId: String, favorite: Boolean)
    }

    interface RouteModeListener {
        fun onRouteModeChanged(active: Boolean)
    }

    inner class SearchAnimationHelper {
        lateinit var activateAnimation: AnimatorSet
        lateinit var deactivateAnimation: AnimatorSet
        lateinit var initialToActiveBackground: AnimatorSet
        lateinit var activateAndShowCrossAnimation: AnimatorSet
        lateinit var hideActiveAndInitialBackground: AnimatorSet
        lateinit var routeModeActive: AnimatorSet
        lateinit var routeModeNonActive: AnimatorSet
        lateinit var showCross: ObjectAnimator
        lateinit var hideCross: ObjectAnimator
        lateinit var showInitialBackground: ObjectAnimator
        lateinit var hideInitialBackground: ObjectAnimator
        lateinit var showActiveBackground: ObjectAnimator
        lateinit var moveDown: ObjectAnimator
        lateinit var moveUp: ObjectAnimator
        private lateinit var hideSearchIcon: ObjectAnimator
        private lateinit var showSearchIcon: ObjectAnimator
        private lateinit var hideSearchEdit: ObjectAnimator
        private lateinit var showSearchEdit: ObjectAnimator
        private lateinit var hideRecordIcon: ObjectAnimator
        private lateinit var showRecordIcon: ObjectAnimator
        private lateinit var hideDebugData: ObjectAnimator
        private lateinit var showDebugData: ObjectAnimator
        private lateinit var hideSeparator: ObjectAnimator
        private lateinit var showSeparator: ObjectAnimator
        private lateinit var hideBottomContainer: ObjectAnimator
        private lateinit var showBottomContainer: ObjectAnimator
        private lateinit var moveViewLeft: ObjectAnimator
        private lateinit var moveViewRight: ObjectAnimator
        private lateinit var hideActiveBackground: ObjectAnimator
        private lateinit var fadeInLevelText: ObjectAnimator
        private lateinit var fadeInLevelNumber: ObjectAnimator
        private lateinit var moveLineAnimationLeft: ObjectAnimator
        private lateinit var moveLevelTextLeft: ObjectAnimator
        private lateinit var moveLevelNumberLeft: ObjectAnimator
        private lateinit var decreaseShadow: ObjectAnimator
        private lateinit var fadeOutLevelText: ObjectAnimator
        private lateinit var fadeOutLevelNumber: ObjectAnimator
        private lateinit var moveLineAnimationRight: ObjectAnimator
        private lateinit var moveLevelTextRight: ObjectAnimator
        private lateinit var moveLevelNumberRight: ObjectAnimator
        private lateinit var increaseShadow: ObjectAnimator
        private val accelerateInterpolator = AccelerateInterpolator(INTERPOLATOR_FACTOR)
        private val decelerateInterpolator = DecelerateInterpolator(INTERPOLATOR_FACTOR)

        init {
            translationZ = REST_TRANSLATION_Z
        }

        @Suppress("LongMethod", "ComplexMethod")
        fun initAnimators() {
            initLevelTextAnimators()
            initLevelNumberAnimators()
            initSeparatorAnimators()
            initCloseSearchAnimators()
            initShadowAnimators()
            initBackgroundAnimators()
            initRouteAnimators()

            decreaseShadow.doOnFinish(false) {
                levels.visible(true)
                separator.visible(true)
            }
            moveLineAnimationRight.doOnFinish(false) {
                levels.visible(false)
                separator.visible(false)
            }

            hideCross.doOnFinish(false) {
                clearSearch.visible(false)
            }

            showCross.doOnStart(false) {
                clearSearch.visible(true)
            }

            activateAnimation = AnimatorSet().apply {
                play(moveLineAnimationRight).with(moveLevelTextRight).with(moveLevelNumberRight).with(fadeOutLevelNumber).with(fadeOutLevelText)
                play(increaseShadow).with(moveLineAnimationRight)
                play(moveLineAnimationRight)
                duration = TRANSITION_DURATION.toLong()
            }

            deactivateAnimation = AnimatorSet().apply {
                play(decreaseShadow)
                play(fadeInLevelNumber).with(fadeInLevelText).with(moveLineAnimationLeft)
                        .with(moveLevelTextLeft).with(moveLevelNumberLeft).after(decreaseShadow)
                duration = TRANSITION_DURATION.toLong()
            }

            activateAndShowCrossAnimation = AnimatorSet().apply {
                play(showCross).after(activateAnimation)
            }

            initialToActiveBackground = AnimatorSet().apply {
                play(showActiveBackground).with(hideInitialBackground)
            }

            hideActiveAndInitialBackground = AnimatorSet().apply {
                play(hideActiveBackground).with(hideInitialBackground)
            }

            routeModeActive = AnimatorSet().apply {
                play(hideSearchIcon).with(hideSearchEdit).with(hideRecordIcon).with(hideDebugData)
                        .with(hideSeparator).with(hideBottomContainer).with(moveViewLeft)
                duration = TRANSITION_DURATION.toLong()
            }

            routeModeNonActive = AnimatorSet().apply {
                play(showSearchIcon).with(showSearchEdit).with(showRecordIcon).with(showDebugData)
                        .with(showSeparator).with(showBottomContainer).with(moveViewRight)
                duration = TRANSITION_DURATION.toLong()
                startDelay = DELAY_MILLIS
            }
            routeModeActive.doOnStart(false) {
                outlineProvider = null
                levels.setBackgroundResource(R.drawable.buttons_in_route_mode_background)
                levelText.setTextColor(context.color(R.color.colorWhite))
                levelNumber.setTextColor(context.color(R.color.colorWhite))
            }
            routeModeActive.doOnFinish(false) {
                routeModeIcons(false)
                routeModeListener?.onRouteModeChanged(true)
            }
            routeModeNonActive.doOnStart(false) {
                levelText.setTextColor(context.color(R.color.colorPrimary))
                levelNumber.setTextColor(context.color(R.color.colorPrimary))
                handler?.apply {
                    removeCallbacks(null)
                    postDelayed({
                        if (levelsFocused) activateLevels()
                        routeModeIcons(true)
                    }, DELAY_MILLIS)
                }
                routeModeListener?.onRouteModeChanged(false)
            }
            routeModeNonActive.doOnFinish(false) { levels.background = null }

            moveDown = toAnimator(View.TRANSLATION_Y, addBookmarkModeTranslation)
            moveUp = toAnimator(View.TRANSLATION_Y, 0f)
        }

        private fun initRouteAnimators() {
            hideSearchIcon = searchIcon.toAnimator(View.ALPHA, MIN_ALPHA)
            showSearchIcon = searchIcon.toAnimator(View.ALPHA, MAX_ALPHA)
            hideSearchEdit = searchEdit.toAnimator(View.ALPHA, MIN_ALPHA)
            showSearchEdit = searchEdit.toAnimator(View.ALPHA, MAX_ALPHA)
            hideRecordIcon = recordDialog.toAnimator(View.ALPHA, MIN_ALPHA)
            showRecordIcon = recordDialog.toAnimator(View.ALPHA, MAX_ALPHA)
            hideDebugData = debugData.toAnimator(View.ALPHA, MIN_ALPHA)
            showDebugData = debugData.toAnimator(View.ALPHA, MAX_ALPHA)
            hideSeparator = separator.toAnimator(View.ALPHA, MIN_ALPHA)
            showSeparator = separator.toAnimator(View.ALPHA, MAX_ALPHA)
            hideBottomContainer = bottomColorContainer.toAnimator(View.ALPHA, MIN_ALPHA)
            showBottomContainer = bottomColorContainer.toAnimator(View.ALPHA, MAX_ALPHA)
            moveViewLeft = toAnimator(View.TRANSLATION_X, -translationLeft, -1, decelerateInterpolator)
            moveViewRight = toAnimator(View.TRANSLATION_X, TRANSLATION_BEGINNING, -1, accelerateInterpolator)
        }

        private fun initBackgroundAnimators() {
            showActiveBackground = activeColorContainer.toAnimator(View.ALPHA, MAX_ALPHA, TRANSITION_DURATION.toLong())
            hideActiveBackground = activeColorContainer.toAnimator(View.ALPHA, MIN_ALPHA, TRANSITION_DURATION.toLong())
            showInitialBackground = initialColorContainer.toAnimator(View.ALPHA, MAX_ALPHA, TRANSITION_DURATION.toLong())
            hideInitialBackground = initialColorContainer.toAnimator(View.ALPHA, MIN_ALPHA, TRANSITION_DURATION.toLong())
        }

        private fun initShadowAnimators() {
            increaseShadow = toAnimator(View.TRANSLATION_Z, ACTIVE_TRANSLATION_Z)
            decreaseShadow = toAnimator(View.TRANSLATION_Z, REST_TRANSLATION_Z)
        }

        private fun initCloseSearchAnimators() {
            showCross = clearSearch.toAnimator(View.ALPHA, MAX_ALPHA, TRANSITION_DURATION.toLong())
            hideCross = clearSearch.toAnimator(View.ALPHA, MIN_ALPHA, TRANSITION_DURATION.toLong())
        }

        private fun initSeparatorAnimators() {
            moveLineAnimationLeft = separator.toAnimator(View.TRANSLATION_X, TRANSLATION_BEGINNING,
                    TRANSITION_DURATION.toLong(), decelerateInterpolator)
            moveLineAnimationRight = separator.toAnimator(View.TRANSLATION_X, translationMiddle,
                    TRANSITION_DURATION.toLong(), accelerateInterpolator)
        }

        private fun initLevelNumberAnimators() {
            moveLevelNumberLeft = levelNumber.toAnimator(View.TRANSLATION_X, TRANSLATION_BEGINNING,
                    TRANSITION_DURATION.toLong(), decelerateInterpolator)
            moveLevelNumberRight = levelNumber.toAnimator(View.TRANSLATION_X, translationMiddle,
                    TRANSITION_DURATION.toLong(), accelerateInterpolator)
            fadeInLevelNumber = levelNumber.toAnimator(View.ALPHA, MAX_ALPHA, TRANSITION_DURATION.toLong())
            fadeOutLevelNumber = levelNumber.toAnimator(View.ALPHA, MIN_ALPHA, TRANSITION_DURATION.toLong())
        }

        private fun initLevelTextAnimators() {
            moveLevelTextLeft = levelText.toAnimator(View.TRANSLATION_X, TRANSLATION_BEGINNING,
                    TRANSITION_DURATION.toLong(), decelerateInterpolator)
            moveLevelTextRight = levelText.toAnimator(View.TRANSLATION_X, translationMiddle,
                    TRANSITION_DURATION.toLong(), accelerateInterpolator)
            fadeInLevelText = levelText.toAnimator(View.ALPHA, MAX_ALPHA, TRANSITION_DURATION.toLong())
            fadeOutLevelText = levelText.toAnimator(View.ALPHA, MIN_ALPHA, TRANSITION_DURATION.toLong())
        }
    }

    private inner class SearchOutlineProvider(val w: Int, val h: Int = widgetHeight) : ViewOutlineProvider() {
        override fun getOutline(view: View?, outline: Outline?) {
            outline?.setRoundRect(
                    -widgetElevation,
                    0,
                    w + widgetElevation,
                    h,
                    cornerRadius)
        }
    }

    private inner class SearchOutlineProviderRoute : ViewOutlineProvider() {
        override fun getOutline(view: View?, outline: Outline?) {
            outline?.setRoundRect(
                    -widgetElevationRouteLeft,
                    0,
                    levelsSize + widgetElevationRouteRight,
                    levelsSize + widgetElevation,
                    cornerRadiusRoute)
        }
    }

    companion object {
        private const val EMPTY_QUERY = ""
        private const val INITIAL_FLOOR = ""
        private const val TRANSITION_DURATION = 200
        private const val DELAY_MILLIS = 300L
        private const val MIN_ALPHA = 0f
        private const val MAX_ALPHA = 1f
        private const val TRANSLATION_BEGINNING = 0f
        private const val REST_TRANSLATION_Z = 2f
        private const val ACTIVE_TRANSLATION_Z = 6f
        private const val INTERPOLATOR_FACTOR = 1.5f
        private const val SUPER_STATE_KEY = "superState"
        private const val SEARCH_ACTIVE_KEY = "active"
        private const val SEARCH_LEVEL_FOCUSED = "levelFocused"
        private const val SEARCH_ITEMS = "searchItems"
        private const val ROUTE_ACTIVE = "routeActive"
        private const val BOOKMARK_ACTIVE = "bookmarkActive"
    }
}
