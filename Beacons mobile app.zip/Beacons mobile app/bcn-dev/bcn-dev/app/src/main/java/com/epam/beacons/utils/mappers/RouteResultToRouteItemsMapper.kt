package com.epam.beacons.utils.mappers

import com.epam.beacons.interactors.PathInteractor
import com.epam.beacons.tools.CornerHelper
import com.epam.beacons.tools.Mapper
import com.epam.beacons.uimodel.bottomnavigationsheet.RouteItem
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RouteResultToRouteItemsMapper @Inject constructor() : Mapper<PathInteractor.RouteResult, List<RouteItem>>() {
    override fun map(from: PathInteractor.RouteResult) =
            from.corners.map {
                RouteItem(
                        it.first,
                        cornerToRouteItemTypeMapper(it.second),
                        cornerToDestOrientationMapper(it.second, from.destOrientation)
                )
            }

    private fun cornerToRouteItemTypeMapper(corner: CornerHelper.Corner) =
            when (corner) {
                CornerHelper.Corner.LEFT -> RouteItem.Type.LEFT
                CornerHelper.Corner.RIGHT -> RouteItem.Type.RIGHT
                CornerHelper.Corner.PLACE -> RouteItem.Type.PLACE
            }

    private fun cornerToDestOrientationMapper(corner: CornerHelper.Corner, destOrientation: CornerHelper.DestOrientation) =
            if (corner == CornerHelper.Corner.PLACE) {
                when (destOrientation) {
                    CornerHelper.DestOrientation.LEFT -> RouteItem.DestOrientation.LEFT
                    CornerHelper.DestOrientation.RIGHT -> RouteItem.DestOrientation.RIGHT
                    CornerHelper.DestOrientation.FORWARD -> RouteItem.DestOrientation.FORWARD
                    else -> RouteItem.DestOrientation.NONE
                }
            } else {
                RouteItem.DestOrientation.NONE
            }
}
