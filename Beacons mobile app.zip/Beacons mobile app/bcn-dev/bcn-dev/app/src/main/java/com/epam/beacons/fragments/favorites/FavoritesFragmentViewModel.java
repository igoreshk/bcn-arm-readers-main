package com.epam.beacons.fragments.favorites;

import androidx.annotation.NonNull;

import com.epam.beacons.MainApp;
import com.epam.beacons.base.BaseViewModel;
import com.epam.beacons.tools.Logger;

import javax.inject.Inject;

public class FavoritesFragmentViewModel extends BaseViewModel {

    @Inject
    FavoritesFragmentViewModel(@NonNull MainApp application,
                               @NonNull Logger logger) {
        super(application, logger);
    }
}
