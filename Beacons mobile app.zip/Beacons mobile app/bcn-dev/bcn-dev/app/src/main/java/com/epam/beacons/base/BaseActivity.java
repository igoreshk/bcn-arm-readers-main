package com.epam.beacons.base;

import androidx.lifecycle.LifecycleRegistry;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import android.content.pm.PackageManager;
import android.os.Bundle;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.epam.beacons.base.modern.BaseActivityNew;
import com.epam.beacons.utils.PermissionHelper;
import com.epam.beacons.utils.fps.FpsHelper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

import butterknife.ButterKnife;
import dagger.android.AndroidInjection;

/**
 * @deprecated Use {@link BaseActivityNew}
 */
@Deprecated
@SuppressWarnings({"WeakerAccess", "EmptyMethod", "unused", "DeprecatedIsStillUsed"})
public abstract class BaseActivity<T extends BaseViewModel> extends AppCompatActivity {

    private final LifecycleRegistry registry = new LifecycleRegistry(this);

    protected T viewModel;

    @Inject
    protected PermissionHelper permissionHelper;
    @Inject
    ViewModelProvider.Factory viewModelFactory;
    @Inject
    FpsHelper                 fpsHelper;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AndroidInjection.inject(this);

        super.onCreate(savedInstanceState);

        setContentView(getLayoutRes());

        ButterKnife.bind(this);
        onViewInflated(savedInstanceState != null);

        viewModel = ViewModelProviders.of(this, viewModelFactory).get(getViewModelClass());
        viewModel.addObserver(getLifecycle());
    }

    protected void onViewInflated(boolean restoring) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        fpsHelper.show(this);
    }

    @Override
    protected void onPause() {
        fpsHelper.hide(this);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        viewModel.removeObserver(getLifecycle());
        super.onDestroy();
    }

    @Override
    @NonNull
    public LifecycleRegistry getLifecycle() {
        return registry;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        final List<String> deniedPermissions = new ArrayList<>();
        final List<String> grantedPermissions = new ArrayList<>();

        for (int i = 0; i < grantResults.length; i++) {
            if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                grantedPermissions.add(permissions[i]);
            } else {
                deniedPermissions.add(permissions[i]);
            }
        }
        if (!grantedPermissions.isEmpty()) {
            onPermissionGranted(requestCode, grantedPermissions);
        }
        if (!deniedPermissions.isEmpty()) {
            onPermissionDenied(requestCode, deniedPermissions);
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    protected void requestPermission(int requestCode, @NonNull String... permissions) {
        if (permissionHelper.isPermissionsDenied(this, permissions)) {
            permissionHelper.requestPermissions(this, permissions, requestCode);
        } else {
            onPermissionGranted(requestCode, Arrays.asList(permissions));
        }
    }

    protected void onPermissionGranted(int requestCode, List<String> permissions) {

    }

    protected void onPermissionDenied(int requestCode, List<String> permissions) {

    }

    @LayoutRes
    protected abstract int getLayoutRes();

    @NonNull
    protected abstract Class<T> getViewModelClass();
}
