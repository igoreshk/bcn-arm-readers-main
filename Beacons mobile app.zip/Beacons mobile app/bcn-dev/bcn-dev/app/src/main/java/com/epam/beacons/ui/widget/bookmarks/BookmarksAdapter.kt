package com.epam.beacons.ui.widget.bookmarks

import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import com.daimajia.swipe.SimpleSwipeListener
import com.daimajia.swipe.SwipeLayout
import com.daimajia.swipe.adapters.RecyclerSwipeAdapter
import com.epam.beacons.R
import com.epam.beacons.uimodel.BookmarkItem
import com.epam.beacons.utils.GlideHelper
import com.epam.beacons.utils.extensions.inflate

class BookmarksAdapter(private val glideHelper: GlideHelper) : RecyclerSwipeAdapter<BookmarksAdapter.ItemViewHolder>() {

    var onItemClickListener: OnItemClickListener? = null
    var items: MutableList<BookmarkItem> = mutableListOf()

    init {
        setHasStableIds(true)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            ItemViewHolder(parent.inflate(R.layout.bookmarks_item)).apply {
                container.setOnClickListener { onItemClickListener?.onItemClicked(getItemId(adapterPosition).toString()) }

                delete.setOnClickListener {
                    mItemManger.closeAllItems()
                    onItemClickListener?.onDeleteItemClicked(getItem(adapterPosition), adapterPosition)
                    notifyItemRemoved(adapterPosition)
                }

                swipeLayout.addSwipeListener(object : SimpleSwipeListener() {
                    override fun onOpen(layout: SwipeLayout) {
                        onItemClickListener?.onSwipeOpened(adapterPosition)
                    }

                    override fun onClose(layout: SwipeLayout) {
                        onItemClickListener?.onSwipeClosed(adapterPosition)
                    }
                })
            }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) = with(holder) {
        val bookmarkItem = items[position]

        glideHelper.load(bookmarkItem.icon, image)

        title.text = bookmarkItem.title
        secondaryTitle.text = bookmarkItem.secondaryTitle

        mItemManger.bindView(itemView, position)
    }

    override fun getSwipeLayoutResourceId(position: Int) = R.id.bookmarks_swipe_layout

    override fun getItemCount() = items.size

    override fun getItemId(position: Int) = items[position].id.toLong()

    private fun getItem(position: Int) = items[position]

    class ItemViewHolder(
            itemView: View,
            val image: ImageView = itemView.findViewById(R.id.bookmarks_item_icon),
            val title: TextView = itemView.findViewById(R.id.bookmarks_item_title),
            val secondaryTitle: TextView = itemView.findViewById(R.id.bookmarks_item_secondary),
            val swipeLayout: SwipeLayout = itemView.findViewById(R.id.bookmarks_swipe_layout),
            val container: FrameLayout = itemView.findViewById(R.id.bookmark_foreground_container),
            val delete: ImageButton = itemView.findViewById(R.id.bookmarks_delete_button)
    ) : RecyclerView.ViewHolder(itemView)

    interface OnItemClickListener {
        fun onItemClicked(itemId: String)
        fun onDeleteItemClicked(item: BookmarkItem, position: Int)
        fun onSwipeOpened(position: Int)
        fun onSwipeClosed(position: Int)
    }
}
