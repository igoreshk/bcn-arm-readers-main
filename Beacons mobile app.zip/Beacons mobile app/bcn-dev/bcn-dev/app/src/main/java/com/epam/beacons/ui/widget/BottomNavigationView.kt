package com.epam.beacons.ui.widget

import android.content.Context
import android.os.Bundle
import android.os.Parcelable
import android.util.AttributeSet
import android.widget.LinearLayout

import java.util.ArrayList

class BottomNavigationView @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr),
        BottomNavigationItemCanvas.OnSelectListener {

    var listener: OnSelectListener? = null
    var animationFinished = true
    private var models: List<BottomNavigationItemModel> = mutableListOf()

    init {
        orientation = LinearLayout.HORIZONTAL
    }

    fun setData(models: List<BottomNavigationItemModel>) {
        this.models = models
        removeAllViews()
        models.indices.forEach {
            addView(BottomNavigationItemCanvas(context).apply {
                setDescriptor(models[it])
                setListener(this@BottomNavigationView)
                showHighlight(models[it].isSelected)
            })
        }
    }

    override fun onItemSelected(position: Int) {
        if (animationFinished) {
            (0 until childCount).forEach { selectItem(it, it == position) }
            listener?.onItemSelected(position)
        }
    }

    override fun onItemUnselected(position: Int) {
        if (animationFinished) {
            selectItem(position, false)
            listener?.onItemUnselected(position)
        }
    }

    fun unselectHighlight(position: Int) = selectItem(position, false)

    override fun getChildAt(index: Int) = super.getChildAt(index) as? BottomNavigationItemCanvas

    override fun onSaveInstanceState() = Bundle().apply {
        putParcelable(KEY_SUPER, super.onSaveInstanceState())
        putParcelableArrayList(KEY_MODELS, ArrayList(models))
    }

    override fun onRestoreInstanceState(state: Parcelable) {
        if (state !is Bundle) {
            super.onRestoreInstanceState(state)
            return
        }

        state.getParcelableArrayList<BottomNavigationItemModel>(KEY_MODELS)?.let { setData(it) }
        super.onRestoreInstanceState(state.getParcelable(KEY_SUPER))
    }

    private fun selectItem(position: Int, show: Boolean) {
        val item = getChildAt(position)
        if (models[position].isSelected && !show) listener?.onItemUnselected(position)
        models[position].isSelected = show
        item?.showHighlight(show)
    }

    interface OnSelectListener {
        fun onItemSelected(position: Int)

        fun onItemUnselected(position: Int)
    }

    companion object {
        private const val KEY_SUPER = "super"
        private const val KEY_MODELS = "models"
    }
}
