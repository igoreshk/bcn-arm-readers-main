package com.epam.beacons.utils

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.preference.PreferenceManager
import com.epam.beacons.R
import com.epam.beacons.broadcasts.WakeUpReceiver

fun setAlarm(context: Context) {
    var alarmMgr: AlarmManager? = null
    var alarmIntent: PendingIntent
    alarmMgr = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarmIntent = Intent(context, WakeUpReceiver::class.java).let { intent ->
        PendingIntent.getBroadcast(context, 0, intent, 0)
    }

    val minutes = PreferenceManager
            .getDefaultSharedPreferences(context)
            .getString(context.getString(R.string.frequency_key), "30")

    if (minutes != null) {
        alarmMgr?.setRepeating(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis(),
                1000 * 60 * minutes.toLong(),
                alarmIntent
        )
    }
}

fun cancelAlarm(context: Context) {
    var alarmMgr: AlarmManager? = null
    var alarmIntent: PendingIntent
    alarmMgr = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarmIntent = Intent(context, WakeUpReceiver::class.java).let { intent ->
        PendingIntent.getBroadcast(context, 0, intent, 0)
    }
    alarmMgr?.cancel(alarmIntent)
}
