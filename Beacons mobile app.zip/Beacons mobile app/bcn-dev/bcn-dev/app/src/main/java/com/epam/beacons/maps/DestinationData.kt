package com.epam.beacons.maps

import com.epam.beacons.Coordinate

class DestinationData {
    var destination: Coordinate = EMPTY_DESTINATION
    var start: Coordinate = EMPTY_START
    var description: String = EMPTY_DESC
    var placeId = EMPTY_PLACE_ID
    var isFavorite = false
    var preRouteMode = false

    companion object {
        val EMPTY_DESTINATION = Coordinate(Double.MAX_VALUE, Double.MAX_VALUE)
        val EMPTY_START = EMPTY_DESTINATION
        const val EMPTY_PLACE_ID = "DEFAULT"
        const val EMPTY_DESC = "unknown"
    }
}
