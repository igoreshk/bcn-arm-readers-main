package com.epam.beacons.dagger

import android.bluetooth.le.ScanSettings
import android.content.Context
import com.epam.beacons.scanner.AndroidBeaconScanner
import com.epam.beacons.scanner.BeaconScanner
import com.epam.beacons.scanner.BluetoothHelper
import com.epam.beacons.scanner.BluetoothHelperImpl
import dagger.Binds
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
abstract class ScannerModule {

    @Module
    companion object {
        @JvmStatic
        @Provides
        @Singleton
        fun provideBluetoothHelper(context: Context): BluetoothHelper =
                BluetoothHelperImpl(context, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build())
    }

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun provideBeaconScanner(beaconScanner: AndroidBeaconScanner): BeaconScanner
}
