package com.epam.beacons.ui.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.epam.beacons.R
import com.epam.beacons.utils.extensions.color
import com.epam.beacons.utils.extensions.dimenPx
import com.epam.beacons.utils.extensions.drawable
import com.epam.beacons.utils.extensions.drawableOrDefault
import com.epam.beacons.utils.extensions.tint

class BottomNavigationItemCanvas @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr),
        View.OnClickListener {

    private lateinit var icon: Drawable
    private var name = TextView(context)
    private var position = NO_POSITION

    private val paint = Paint().apply { textSize = context.dimenPx(R.dimen.bottom_navigation_text_size).toFloat() }
    private lateinit var text: String

    private var textSize = 0f
    private var textColor = context.color(R.color.bnTextColor)
    private var selectedTextColor = context.color(R.color.bnSelectedTextColor)

    private var dotColor = context.color(R.color.bnDotColor)
    private val dotRadius = context.dimenPx(R.dimen.bottom_navigation_dot_size) / 2.0f
    private var isDotVisible = false
    private var dotX = 0f
    private var dotY = 0f

    private var listener: BottomNavigationItemCanvas.OnSelectListener? = null

    init {
        setOnClickListener(this)
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        background = context.drawable(R.drawable.bn_background)
    }

    fun setDescriptor(bottomNavigationItemModel: BottomNavigationItemModel) {
        icon = context.drawableOrDefault(bottomNavigationItemModel.iconRes)
        name.text = bottomNavigationItemModel.title
        text = name.text.toString()
        textSize = paint.measureText(text)
        position = bottomNavigationItemModel.position
        icon.tint(textColor)
    }

    fun setListener(listener: BottomNavigationItemCanvas.OnSelectListener) {
        this.listener = listener
    }

    @Suppress("MagicNumber")
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)

        val iconSize = context.dimenPx(R.dimen.bottom_navigation_icon_size)
        val iconWidthPivot = measuredWidth / 2
        val iconHeightPivot = (measuredHeight / 2 * ICON_HEIGHT_COEFFICIENT).toInt()

        val iconLeftBound = iconWidthPivot - iconSize / 2
        val iconRightBound = iconWidthPivot + iconSize / 2
        val iconTopBound = iconHeightPivot - iconSize / 2
        val iconBottomBound = iconHeightPivot + iconSize / 2

        icon.setBounds(iconLeftBound, iconTopBound, iconRightBound, iconBottomBound)
        dotX = icon.bounds.right.toFloat() - dotRadius * 2 / 3
        dotY = icon.bounds.top.toFloat() + dotRadius / 2
    }

    override fun onDraw(canvas: Canvas) {
        val textX = width / 2 - textSize / 2
        val textY = icon.bounds?.bottom?.times(TEXT_Y_COEFFICIENT) ?: height / 2f
        if (isSelected) {
            paint.color = selectedTextColor
            icon.tint(selectedTextColor)
        } else {
            paint.color = textColor
        }

        canvas.drawText(text, textX, textY, paint)
        icon.draw(canvas)

        if (isDotVisible) {
            drawDot(canvas)
        }

        super.onDraw(canvas)
    }

    override fun onClick(v: View) {
        if (isSelected) listener?.onItemUnselected(position) else listener?.onItemSelected(position)
    }

    fun showHighlight(isShown: Boolean) {
        if (!isShown) {
            icon.tint(textColor)
        }
        isSelected = isShown
    }

    private fun drawDot(canvas: Canvas) {
        paint.color = dotColor
        canvas.drawCircle(dotX, dotY, dotRadius, paint)
    }

    interface OnSelectListener {
        fun onItemSelected(position: Int)

        fun onItemUnselected(position: Int)
    }

    companion object {
        private const val NO_POSITION = -1
        private const val TEXT_Y_COEFFICIENT = 1.55f
        private const val ICON_HEIGHT_COEFFICIENT = 0.7f
    }
}
