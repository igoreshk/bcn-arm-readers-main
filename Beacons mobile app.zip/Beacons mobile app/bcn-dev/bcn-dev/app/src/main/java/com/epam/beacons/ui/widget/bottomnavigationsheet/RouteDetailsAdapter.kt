package com.epam.beacons.ui.widget.bottomnavigationsheet

import android.content.Context
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.epam.beacons.R
import com.epam.beacons.uimodel.bottomnavigationsheet.RouteItem
import com.epam.beacons.utils.extensions.drawable
import com.epam.beacons.utils.extensions.string
import java.util.ArrayList
import javax.inject.Inject

class RouteDetailsAdapter @Inject constructor(private val context: Context)
    : RecyclerView.Adapter<RouteDetailsAdapter.RouteItemViewHolder>() {

    var items: List<RouteItem> = ArrayList()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    init {
        setHasStableIds(true)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = RouteItemViewHolder(LayoutInflater.from(parent.context)
            .inflate(R.layout.bottom_sheet_route_item, parent, false))

    override fun onBindViewHolder(holder: RouteItemViewHolder, position: Int) {
        val item = getRouteItem(position)
        when (item.type) {
            RouteItem.Type.PLACE -> bindPlaceItem(holder, item)
            RouteItem.Type.LEFT -> bindLeftDirectionItem(holder, item)
            RouteItem.Type.RIGHT -> bindRightDirectionItem(holder, item)
        }
        if (position == 0) holder.opaque()
    }

    private fun bindLeftDirectionItem(holder: RouteItemViewHolder, item: RouteItem) = holder.apply {
        description.text = context.string(R.string.bottom_sheet_turn_left)
        distance.text = context.getString(R.string.route_item_distance_text, item.distance)
        icon.setImageDrawable(context.drawable(R.drawable.ic_left))
    }

    private fun bindRightDirectionItem(holder: RouteItemViewHolder, item: RouteItem) = holder.apply {
        description.text = context.string(R.string.bottom_sheet_turn_right)
        distance.text = context.getString(R.string.route_item_distance_text, item.distance)
        icon.setImageDrawable(context.drawable(R.drawable.ic_right))
    }

    private fun bindPlaceItem(holder: RouteItemViewHolder, item: RouteItem) = holder.apply {
        distance.text = context.getString(R.string.route_item_distance_text, item.distance)
        description.text = when (item.destOrientation) {
            RouteItem.DestOrientation.LEFT -> context.string(R.string.bottom_sheet_on_left)
            RouteItem.DestOrientation.RIGHT -> context.string(R.string.bottom_sheet_on_right)
            RouteItem.DestOrientation.FORWARD -> context.string(R.string.bottom_sheet_forward)
            else -> context.string(R.string.bottom_sheet_unknown)
        }
        icon.setImageDrawable(context.drawable(R.drawable.ic_destination))
    }

    private fun getRouteItem(position: Int) = items[position]

    override fun getItemCount() = items.size

    inner class RouteItemViewHolder(
            view: View,
            val description: TextView = view.findViewById(R.id.route_item_description),
            val distance: TextView = view.findViewById(R.id.route_item_distance),
            val icon: ImageView = view.findViewById(R.id.route_item_image_view),
            val to: TextView = view.findViewById(R.id.to))
        : RecyclerView.ViewHolder(view) {

        fun opaque() {
            distance.alpha = OPAQUE
            description.alpha = OPAQUE
            icon.alpha = OPAQUE
            to.alpha = OPAQUE
        }
    }

    companion object {
        private const val OPAQUE = 1f
    }
}
