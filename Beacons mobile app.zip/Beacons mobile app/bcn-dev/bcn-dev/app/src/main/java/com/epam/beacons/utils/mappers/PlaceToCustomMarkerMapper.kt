package com.epam.beacons.utils.mappers

import com.epam.beacons.Place
import com.epam.beacons.tools.Mapper
import com.epam.beacons.ui.widget.CustomMarker
import com.google.android.gms.maps.model.MarkerOptions

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PlaceToCustomMarkerMapper @Inject constructor(
        private val coordinatesToLatLngsMapper: CoordinatesToLatLngsMapper
) : Mapper<Place, CustomMarker>() {

    override fun map(from: Place): CustomMarker {
        val marker = CustomMarker(from.id)
        marker.setMarkerOptions(MarkerOptions()
                .position(coordinatesToLatLngsMapper.map(from.coordinate))
                .title(formatTitle(from)))
        return marker
    }

    fun update(marker: CustomMarker, place: Place) {
        marker.setLatLng(coordinatesToLatLngsMapper.map(place.coordinate))
        marker.setTitle(formatTitle(place))
    }

    private fun formatTitle(place: Place) = "${place.type} ${place.description}"
}
