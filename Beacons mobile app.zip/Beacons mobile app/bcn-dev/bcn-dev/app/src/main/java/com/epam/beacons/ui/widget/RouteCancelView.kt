package com.epam.beacons.ui.widget

import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Outline
import android.os.Bundle
import android.os.Parcelable
import androidx.appcompat.widget.AppCompatImageButton
import android.util.AttributeSet
import android.view.View
import android.view.ViewOutlineProvider
import com.epam.beacons.R
import com.epam.beacons.utils.extensions.dimenPx
import com.epam.beacons.utils.extensions.doOnFinish
import com.epam.beacons.utils.extensions.doOnStart
import com.epam.beacons.utils.extensions.toAnimator

class RouteCancelView @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleAttr: Int = 0
) : AppCompatImageButton(context, attrs, defStyleAttr) {
    private val cornerRadiusRoute = context.dimenPx(R.dimen.search_corner_radius_route_mode).toFloat()
    private val routeCancelSize = context.dimenPx(R.dimen.route_cancel_width)
    private val elevationLeft = context.dimenPx(R.dimen.route_cancel_elevation_left)
    private val elevationRight = context.dimenPx(R.dimen.route_cancel_elevation_right)
    private val elevationBottom = context.dimenPx(R.dimen.route_cancel_elevation_bottom)

    private var show: ObjectAnimator
    private var hide: ObjectAnimator

    private var visible = false

    init {
        outlineProvider = RouteCancelOutlineProvider()
        show = toAnimator(View.ALPHA, MAX_ALPHA, DURATION_APPEAR)
        hide = toAnimator(View.ALPHA, MIN_ALPHA, DURATION_DISAPPEAR)

        show.doOnStart(false) { visibility = View.VISIBLE }
        hide.doOnFinish(false) { visibility = View.GONE }
    }

    fun isVisible(visible: Boolean) {
        this.visible = visible
        if (visible && alpha != MAX_ALPHA) {
            show.start()
        } else if (!visible && alpha != MIN_ALPHA) {
            hide.start()
        }
    }

    override fun onSaveInstanceState(): Parcelable = Bundle().apply {
        putParcelable(SUPER_STATE_KEY, super.onSaveInstanceState())
        if (visible) putFloat(ALPHA_STATE_KEY, MAX_ALPHA) else putFloat(ALPHA_STATE_KEY, MIN_ALPHA)
        putBoolean(VISIBILITY_STATE_KEY, visible)
    }

    override fun onRestoreInstanceState(state: Parcelable?) {
        if (state !is Bundle) {
            super.onRestoreInstanceState(state)
            return
        }

        alpha = state.getFloat(ALPHA_STATE_KEY)
        state.getBoolean(VISIBILITY_STATE_KEY).let {
            if (it) visibility = View.VISIBLE
        }

        super.onRestoreInstanceState(state.getParcelable(SUPER_STATE_KEY))
    }

    private inner class RouteCancelOutlineProvider : ViewOutlineProvider() {
        override fun getOutline(view: View?, outline: Outline?) {
            outline?.setRoundRect(
                    -elevationLeft,
                    0,
                    routeCancelSize + elevationRight,
                    routeCancelSize + elevationBottom,
                    cornerRadiusRoute)
        }
    }

    companion object {
        private const val VISIBILITY_STATE_KEY = "visibilityState"
        private const val ALPHA_STATE_KEY = "alphaState"
        private const val SUPER_STATE_KEY = "superState"
        private const val MAX_ALPHA = 1f
        private const val MIN_ALPHA = 0f
        private const val DURATION_APPEAR = 300L
        private const val DURATION_DISAPPEAR = 200L
    }
}
