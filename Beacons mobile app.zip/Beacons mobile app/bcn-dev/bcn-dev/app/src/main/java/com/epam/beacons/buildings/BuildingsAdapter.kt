package com.epam.beacons.buildings

import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.NO_POSITION
import android.transition.AutoTransition
import android.transition.ChangeTransform
import android.transition.TransitionManager
import android.transition.TransitionSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.epam.beacons.R
import com.epam.beacons.uimodel.BuildingItem
import com.epam.beacons.utils.extensions.visible
import java.util.ArrayList
import javax.inject.Inject

class BuildingsAdapter @Inject constructor() : RecyclerView.Adapter<BuildingsAdapter.BuildingViewHolder>() {
    init {
        super.setHasStableIds(true)
    }

    var imageDownloadCallback: ImageDownloadCallback? = null
    var itemClickListener: ItemClickListener? = null
    var galleryClickListener: GalleryClickListener? = null
    var shareClickListener: ShareClickListener? = null
    var onMapClickListener: OutdoorMapClickListener? = null
    var toggleClickListener: ToggleClickListener? = null

    var viewType: ViewType = ViewType.PAGINATION
    var expandedItemPosition: Int = NO_POSITION
    var buildings: List<BuildingItem> = ArrayList()

    private val transition = TransitionSet().addTransition(AutoTransition()).addTransition(ChangeTransform())

    override fun getItemViewType(position: Int) = viewType.ordinal

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BuildingViewHolder {
        val viewItem = LayoutInflater.from(parent.context)
                .inflate(if (viewType == ViewType.LIST.ordinal) R.layout.building_item else R.layout.building_item_paginated, parent, false)
        val holder = if (viewType == ViewType.LIST.ordinal) ListedViewHolder(viewItem) else PaginatedViewHolder(viewItem)

        viewItem.setOnClickListener { itemClickListener?.onItemClick(buildings[holder.adapterPosition].id) }
        holder.galleryButton.setOnClickListener { galleryClickListener?.onGalleryClick(buildings[holder.adapterPosition].id) }
        holder.shareButton.setOnClickListener { shareClickListener?.onShareClick(buildings[holder.adapterPosition].id) }
        holder.onMapButton.setOnClickListener { onMapClickListener?.onOutdoorMapClick(buildings[holder.adapterPosition].id) }
        holder.indoorButton.setOnClickListener { itemClickListener?.onItemClick(buildings[holder.adapterPosition].id) }

        if (holder is ListedViewHolder) {
            holder.toggleButton.setOnClickListener {
                expandedItemPosition = if (expandedItemPosition == holder.adapterPosition) NO_POSITION else holder.adapterPosition
                toggleClickListener?.onToggleClick(expandedItemPosition)
                (holder.itemView.parent as? ViewGroup)?.let { TransitionManager.beginDelayedTransition(it, transition) }
                notifyDataSetChanged()
            }
        }
        return holder
    }

    override fun onBindViewHolder(holder: BuildingViewHolder, position: Int) {
        val building = buildings[position]

       // imageDownloadCallback?.onImageLoading(holder.image, building.)
        holder.name.text = building.name
        holder.address.text = building.address
        holder.youAreHereText.visible(false) // TODO: 03.05.18 EPMLSTRBCA-155

        if (holder is PaginatedViewHolder) {
            holder.description.text = building.address
            holder.phoneNumber.text = building.phoneNumber
            holder.workingHours.text = building.workingHours
            holder.itemView.isClickable = false
        }

        if (holder is ListedViewHolder) {
            val isExpanded = expandedItemPosition == position
            holder.toggleButton.rotation = if (isExpanded) EXPANDED_ROTATION else COLLAPSED_ROTATION
            holder.buttonsPanel.visible(isExpanded)
            holder.itemView.isClickable = !isExpanded
        }
    }

    override fun getItemCount() = buildings.size

    override fun getItemId(position: Int): Long = position.toLong()

    // empty override to prevent IllegalStateException caused by calls from RecyclerViewPager when adapter is already in use
    override fun setHasStableIds(hasStableIds: Boolean) {}

    abstract class BuildingViewHolder(
            itemView: View,
            val image: ImageView = itemView.findViewById(R.id.building_image),
            val name: TextView = itemView.findViewById(R.id.building_name),
            val address: TextView = itemView.findViewById(R.id.building_address),
            val indoorButton: Button = itemView.findViewById(R.id.building_indoor_button),
            val galleryButton: Button = itemView.findViewById(R.id.building_gallery_button),
            val shareButton: Button = itemView.findViewById(R.id.building_share_button),
            val onMapButton: Button = itemView.findViewById(R.id.building_on_map_button),
            val youAreHereText: TextView = itemView.findViewById(R.id.you_are_here_text)
    ) : RecyclerView.ViewHolder(itemView)

    inner class PaginatedViewHolder(
            itemView: View,
            val description: TextView = itemView.findViewById(R.id.building_description),
            val phoneNumber: TextView = itemView.findViewById(R.id.building_contacts_text),
            val workingHours: TextView = itemView.findViewById(R.id.building_working_hours_text)
    ) : BuildingViewHolder(itemView)

    inner class ListedViewHolder(
            itemView: View,
            val toggleButton: ImageButton = itemView.findViewById(R.id.building_item_toggle_button),
            val buttonsPanel: LinearLayout = itemView.findViewById(R.id.building_buttons_panel)
    ) : BuildingViewHolder(itemView)

    interface ImageDownloadCallback {
        fun onImageLoading(imageView: ImageView, url: String)
    }

    interface ItemClickListener {
        fun onItemClick(itemId: String)
    }

    interface GalleryClickListener {
        fun onGalleryClick(itemId: String)
    }

    interface ShareClickListener {
        fun onShareClick(itemId: String)
    }

    interface OutdoorMapClickListener {
        fun onOutdoorMapClick(itemId: String)
    }

    interface ToggleClickListener {
        fun onToggleClick(expandedItemIndex: Int)
    }

    enum class ViewType {
        PAGINATION,
        LIST
    }

    companion object {
        const val COLLAPSED_ROTATION = 0f
        const val EXPANDED_ROTATION = 180f
    }
}
