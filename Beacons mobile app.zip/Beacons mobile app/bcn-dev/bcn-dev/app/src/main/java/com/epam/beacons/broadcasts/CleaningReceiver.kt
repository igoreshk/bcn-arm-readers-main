package com.epam.beacons.broadcasts

import android.content.Context
import android.content.Intent
import com.epam.beacons.base.modern.BaseBroadcastReceiver
import com.epam.beacons.interactors.CleaningInteractor
import javax.inject.Inject
import javax.inject.Singleton

/**
 * BroadcastReceiver responsible for calling a particular cleaning chain of [CleaningInteractor].
 */
@Singleton
class CleaningReceiver @Inject constructor() : BaseBroadcastReceiver() {

    @Inject
    lateinit var cleaningInteractor: CleaningInteractor

    override fun onReceive(context: Context?, intent: Intent?) {
        super.onReceive(context, intent)
        cleaningInteractor.clearBuildingData().execute()
    }
}
