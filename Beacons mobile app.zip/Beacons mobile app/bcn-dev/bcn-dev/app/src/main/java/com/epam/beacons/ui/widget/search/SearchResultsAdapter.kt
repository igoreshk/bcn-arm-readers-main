package com.epam.beacons.ui.widget.search

import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.epam.beacons.R
import com.epam.beacons.uimodel.SearchItem
import com.epam.beacons.utils.GlideHelper
import com.epam.beacons.utils.extensions.inflate

class SearchResultsAdapter(private val glideHelper: GlideHelper) : RecyclerView.Adapter<SearchResultsAdapter.ItemViewHolder>() {

    var onSearchItemClickListener: OnSearchItemClickListener? = null
    var data: List<SearchItem> = listOf()
        set(value) {
            if (field != value) {
                field = value
                notifyDataSetChanged()
            }
        }

    init {
        setHasStableIds(true)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val viewItem = parent.inflate(R.layout.search_item)
        val holder = ItemViewHolder(viewItem)

        viewItem.setOnClickListener {
            onSearchItemClickListener?.onSearchItemSelected(
                    getItemId(holder.adapterPosition).toString(),
                    getItemMarked(holder.adapterPosition))
        }
        return holder
    }

    override fun getItemCount() = data.size

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) = with(holder) {
        val searchItem = data[position]

        glideHelper.load(searchItem.icon, image)

        title.text = searchItem.title
        secondaryTitle.text = searchItem.secondaryTitle
        bookmark.let {
            if (searchItem.marked) it.setImageResource(R.drawable.ic_bookmark) else it.setImageResource(0)
        }
    }

    override fun getItemId(position: Int) = data[position].id

    private fun getItemMarked(position: Int) = data[position].marked

    class ItemViewHolder(
            itemView: View,
            val image: ImageView = itemView.findViewById(R.id.search_result_icon),
            val title: TextView = itemView.findViewById(R.id.search_result_title),
            val secondaryTitle: TextView = itemView.findViewById(R.id.search_result_secondary),
            val bookmark: ImageView = itemView.findViewById(R.id.search_bookmark)
    ) : RecyclerView.ViewHolder(itemView)

    interface OnSearchItemClickListener {
        fun onSearchItemSelected(searchItem: String, isFavorite: Boolean)
    }
}
