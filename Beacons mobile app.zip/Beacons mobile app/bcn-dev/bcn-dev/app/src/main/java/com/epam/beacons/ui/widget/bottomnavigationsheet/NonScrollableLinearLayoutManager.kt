package com.epam.beacons.ui.widget.bottomnavigationsheet

import android.content.Context
import androidx.recyclerview.widget.LinearLayoutManager

class NonScrollableLinearLayoutManager(context: Context) :
        LinearLayoutManager(context) {

    override fun canScrollVertically(): Boolean = false

    override fun canScrollHorizontally(): Boolean = false
}
