package com.epam.beacons.utils;

import androidx.annotation.NonNull;

public class Constants {
    public static final long    SCANNING_PERIOD_MILLISECONDS        = 3000;
    public static final int     ONE_METER_AT_EQUATOR                = 111320;
    public static final int     MEASUREMENTS_LIMIT                  = 30;
    public static final long    DISTANCE_BOUNDER_MILLISECONDS_LIMIT = SCANNING_PERIOD_MILLISECONDS + 1000;
    public static final float   PLACEHOLDER_ERROR_SIZE              = 15f;
    public static final int     HISTORY_LIMIT                       = 5;

    /**
     * The distance in meters between the current user location and a point of interests
     * to show a popup "You are on <POI name>"
     */
    public static final int     NEARBY_POI_DISTANCE                 = 10;
    @NonNull
    public static final String CLEANING_REQUESTED_ACTION           = "CLEANING_REQUESTED_ACTION";

    private Constants() { // private constructor to hide the implicit public one
    }
}
