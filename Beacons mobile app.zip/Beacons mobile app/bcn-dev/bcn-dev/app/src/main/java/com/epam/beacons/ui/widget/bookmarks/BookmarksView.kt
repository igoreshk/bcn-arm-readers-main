package com.epam.beacons.ui.widget.bookmarks

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.os.Parcelable
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.util.AttributeSet
import android.util.Property
import android.view.View
import android.view.animation.DecelerateInterpolator
import com.daimajia.swipe.util.Attributes
import com.epam.beacons.R
import com.epam.beacons.ui.widget.SearchAndBookmarksItemDecorator
import com.epam.beacons.uimodel.BookmarkItem
import com.epam.beacons.utils.GlideHelper
import com.epam.beacons.utils.extensions.dimenPx
import com.epam.beacons.utils.extensions.doOnFinish
import com.epam.beacons.utils.extensions.doOnStart
import com.epam.beacons.utils.extensions.toAnimator
import com.epam.beacons.utils.extensions.visible
import kotlinx.android.synthetic.main.bookmarks_view.view.*

class BookmarksView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0)
    : ConstraintLayout(context, attrs, defStyleAttr), BookmarksAdapter.OnItemClickListener {

    var data: MutableList<BookmarkItem> = mutableListOf()
        set(value) {
            if (field != value) {
                field = value
                calcCurrentHeight(value.size)
                if (undoClicked) {
                    restorePosition(value)
                    layoutParams.height = currentHeight.also { layoutParams = layoutParams }
                    undoClicked = false
                }
                bookmarksAdapter.items = value
                restoreOpenedItem()
                bookmarksAdapter.notifyDataSetChanged()
            }
        }
    var closeListener: CloseListener? = null
    var addBookmarkListener: AddBookmarkListener? = null
    var undoListener: UndoListener? = null
    var animationListener: AnimationListener? = null
    var deleteItemListener: DeleteItemListener? = null
    var onItemClickListener: ItemClickListener? = null
    private val animationHelper: AnimationHelper
    private val bookmarksAdapter = BookmarksAdapter(GlideHelper(context))
    private val maxHeightV = context.dimenPx(R.dimen.bookmarks_max_height_v)
    private val maxHeightH = context.dimenPx(R.dimen.bookmarks_max_height_h)
    private val upperContainerHeight = context.dimenPx(R.dimen.bookmarks_upper_container_height)
    private val recyclerItemHeight = context.dimenPx(R.dimen.bookmarks_recycler_item_height)
    private val separatorHeight = context.dimenPx(R.dimen.bookmarks_separator_height)
    private var currentHeight = upperContainerHeight
    private var restored = false
    private var portrait = false
    private var closed = true
    private var snackbarOpened = false
    private var undoClicked = false
    var lastDeletedData = DEFAULT_ID to 0
    private var lastOpenedPosition = NO_POSITION
    private var lastClosedPosition = NO_POSITION

    init {
        inflate(context, R.layout.bookmarks_view, this)

        outlineProvider = null

        bookmarks_recycler.apply {
            layoutManager = LinearLayoutManager(context)
            addItemDecoration(SearchAndBookmarksItemDecorator(context))
            bookmarksAdapter.mode = Attributes.Mode.Single
            bookmarksAdapter.onItemClickListener = this@BookmarksView
            adapter = bookmarksAdapter

            addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    restoreOpenedItem()
                }
            })
        }

        portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT

        animationHelper = AnimationHelper()
        animationHelper.initAnimators()

        bookmarks_close_view_button.setOnClickListener { closeListener?.onCloseClicked() }
        bookmarks_add_bookmark.setOnClickListener { addBookmarkListener?.onAddBookmarkClicked() }
        bookmarks_snackbar_undo.setOnClickListener {
            undoClicked = true
            if (lastDeletedData.first != DEFAULT_ID) undoListener?.onUndoClicked(lastDeletedData.first)
            animationHelper.apply {
                if (!snackbarUpDownAnimationFinished) moveSnackbarUp.cancel()
                if (snackbarDownAnimationFinished) {
                    moveSnackbarDown.apply {
                        startDelay = 0
                        start()
                    }
                }
            }
        }
    }

    fun show() {
        if (visibility != View.VISIBLE && animationHelper.animationFinished) {
            animationHelper.moveUp.setIntValues(0, currentHeight)

            if (restored && !closed) {
                alpha = MAX_ALPHA
                visible(true)
                if (snackbarOpened) {
                    bookmarks_snackbar_container.visible(true)
                    animationHelper.moveSnackbarDown.apply {
                        startDelay = DELAY_MILLIS
                        start()
                    }
                }
                restored = false
            } else {
                animationHelper.showView.start()
            }
            closed = false
        }
    }

    fun hide() {
        if (visibility != View.GONE && animationHelper.animationFinished) {
            animationHelper.moveDown.setIntValues(currentHeight, 0)
            animationHelper.hideView.start()
            closed = true
        }
    }

    override fun onItemClicked(itemId: String) {
        onItemClickListener?.onItemClicked(itemId)
    }

    override fun onDeleteItemClicked(item: BookmarkItem, position: Int) {
        data.remove(item)
        calcCurrentHeight(data.size)
        layoutParams.height = currentHeight.also { layoutParams = layoutParams }
        lastClosedPosition = NO_POSITION
        lastOpenedPosition = NO_POSITION
        deleteItemListener?.onDeleteItemClicked(item.id, position)
    }

    fun showUndo(deletedData: Pair<String, Int>) {
        lastDeletedData = deletedData.first to deletedData.second
        animationHelper.apply {
            if (!snackbarDownAnimationFinished) moveSnackbarDown.cancel()
            if (snackbarUpDownAnimationFinished) {
                moveSnackbarDown.startDelay = DELAY_MILLIS
                moveSnackbarUp.start()
            }
        }
    }

    override fun onSwipeOpened(position: Int) {
        lastOpenedPosition = position
        if (lastOpenedPosition == lastClosedPosition) lastClosedPosition = NO_POSITION
    }

    override fun onSwipeClosed(position: Int) {
        lastClosedPosition = position
        if (lastClosedPosition == lastOpenedPosition) lastOpenedPosition = NO_POSITION
    }

    override fun onSaveInstanceState(): Parcelable = Bundle().apply {
        putParcelable(SUPER_KEY, super.onSaveInstanceState())
        putInt(OPENED_POSITION_KEY, lastOpenedPosition)
        putInt(CLOSED_POSITION_KEY, lastClosedPosition)
        putBoolean(SNACKBAR_KEY, snackbarOpened)
        putBoolean(CLOSED_VIEW_KEY, closed)
    }

    override fun onRestoreInstanceState(state: Parcelable?) {
        if (state !is Bundle) {
            super.onRestoreInstanceState(state)
            return
        }

        restored = true
        lastOpenedPosition = state.getInt(OPENED_POSITION_KEY)
        lastClosedPosition = state.getInt(CLOSED_POSITION_KEY)
        snackbarOpened = state.getBoolean(SNACKBAR_KEY)
        closed = state.getBoolean(CLOSED_VIEW_KEY)
        super.onRestoreInstanceState(state.getParcelable(SUPER_KEY))
    }

    private fun restoreOpenedItem() {
        if (lastOpenedPosition != lastClosedPosition && !bookmarksAdapter.isOpen(lastOpenedPosition)) {
            bookmarksAdapter.openItem(lastOpenedPosition)
        }
    }

    private fun calcCurrentHeight(size: Int) {
        currentHeight = when {
            !portrait && size > MAX_ITEMS_H -> maxHeightH
            portrait && size > MAX_ITEMS_V -> maxHeightV
            else -> recyclerItemHeight * size + upperContainerHeight + separatorHeight
        }
    }

    private fun restorePosition(bookmarks: MutableList<BookmarkItem>) = with(bookmarks) {
        find { it.id == lastDeletedData.first }.also { it ->
            it?.let {
                remove(it)
                add(lastDeletedData.second, it)
            }
        }
    }

    interface CloseListener {
        fun onCloseClicked()
    }

    interface AddBookmarkListener {
        fun onAddBookmarkClicked()
    }

    interface UndoListener {
        fun onUndoClicked(itemId: String)
    }

    interface AnimationListener {
        fun onAnimationChanged(finished: Boolean)
    }

    interface ItemClickListener {
        fun onItemClicked(itemId: String)
    }

    interface DeleteItemListener {
        fun onDeleteItemClicked(itemId: String, position: Int)
    }

    private inner class AnimationHelper {
        lateinit var moveUp: ObjectAnimator
        lateinit var moveDown: ObjectAnimator
        lateinit var showView: AnimatorSet
        lateinit var hideView: AnimatorSet
        lateinit var moveSnackbarUp: ObjectAnimator
        lateinit var moveSnackbarDown: ObjectAnimator
        private lateinit var showAlpha: ObjectAnimator
        private lateinit var hideAlpha: ObjectAnimator
        private val decelerate = DecelerateInterpolator()
        private val heightProperty: Property<View, Int> = object : Property<View, Int>(Int::class.java, "height") {
            override fun get(view: View) = view.height
            override fun set(view: View, value: Int) = with(view) {
                layoutParams.height = value.also { layoutParams = layoutParams }
            }
        }
        var animationFinished = true
        var snackbarUpDownAnimationFinished = true
        var snackbarDownAnimationFinished = true

        fun initAnimators() {
            moveUp = ObjectAnimator.ofInt(this@BookmarksView, heightProperty, 0, currentHeight)
            moveDown = ObjectAnimator.ofInt(this@BookmarksView, heightProperty, currentHeight, 0)

            showAlpha = toAnimator(View.ALPHA, MAX_ALPHA)
            hideAlpha = toAnimator(View.ALPHA, MIN_ALPHA)

            showView = AnimatorSet().apply {
                duration = ANIMATION_DURATION
                interpolator = decelerate

                playTogether(moveUp, showAlpha)

                doOnStart(false) {
                    animationFinished = false
                    animationListener?.onAnimationChanged(false)
                    layoutParams.height = 0.also { layoutParams = layoutParams }
                    visible(true)
                }
                doOnFinish(false) {
                    animationFinished = true
                    animationListener?.onAnimationChanged(true)
                }
            }

            hideView = AnimatorSet().apply {
                duration = ANIMATION_DURATION
                interpolator = decelerate

                playTogether(moveDown, hideAlpha)

                doOnStart(false) {
                    animationListener?.onAnimationChanged(false)
                    animationFinished = false
                }

                doOnFinish(false) {
                    visible(false)
                    animationFinished = true
                    animationListener?.onAnimationChanged(true)
                }
            }

            moveSnackbarUp = ObjectAnimator.ofInt(bookmarks_snackbar_container, heightProperty, 0, upperContainerHeight).apply {
                duration = ANIMATION_DURATION
                interpolator = decelerate

                doOnStart(false) {
                    snackbarOpened = true
                    snackbarUpDownAnimationFinished = false
                    bookmarks_snackbar_container.apply {
                        layoutParams.height = 0.also { layoutParams = layoutParams }
                        visible(true)
                    }
                }
                doOnFinish(false) { moveSnackbarDown.start() }
            }

            moveSnackbarDown = ObjectAnimator.ofInt(bookmarks_snackbar_container, heightProperty, upperContainerHeight, 0).apply {
                duration = ANIMATION_DURATION
                interpolator = decelerate

                doOnStart(false) {
                    snackbarDownAnimationFinished = false
                }
                doOnFinish(false) {
                    snackbarOpened = false
                    bookmarks_snackbar_container.visible(false)
                    snackbarUpDownAnimationFinished = true
                    snackbarDownAnimationFinished = true
                }
            }
        }
    }

    companion object {
        private const val DEFAULT_ID = "DEFAULT"
        private const val MAX_ITEMS_V = 4
        private const val MAX_ITEMS_H = 2
        private const val ANIMATION_DURATION = 300L
        private const val DELAY_MILLIS = 2500L
        private const val MAX_ALPHA = 1f
        private const val MIN_ALPHA = 0.5f
        private const val NO_POSITION = -1
        private const val SUPER_KEY = "superKey"
        private const val OPENED_POSITION_KEY = "openedPositionKey"
        private const val CLOSED_POSITION_KEY = "closesPositionKey"
        private const val SNACKBAR_KEY = "snackbarKey"
        private const val CLOSED_VIEW_KEY = "closedViewKey"
    }
}
