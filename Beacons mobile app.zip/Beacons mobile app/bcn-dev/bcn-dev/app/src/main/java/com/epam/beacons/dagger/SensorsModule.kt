package com.epam.beacons.dagger

import android.content.Context
import android.hardware.SensorManager
import com.epam.beacons.sensors.SensorSmoother
import com.epam.beacons.sensors.Sensors
import com.epam.beacons.sensors.SensorsListener
import com.epam.beacons.utils.Constants
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object SensorsModule {

    @JvmStatic
    @Provides
    @Singleton
    fun provideSensors(context: Context, listener: SensorsListener) =
            Sensors(context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager, listener)

    @JvmStatic
    @Provides
    @Singleton
    fun provideSensorSmoother(): SensorSmoother = SensorSmoother(Constants.SCANNING_PERIOD_MILLISECONDS)
}
