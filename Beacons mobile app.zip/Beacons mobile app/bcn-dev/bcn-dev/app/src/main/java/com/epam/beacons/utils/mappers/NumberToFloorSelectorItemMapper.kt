package com.epam.beacons.utils.mappers

import com.epam.beacons.uimodel.FloorSelectorItem
import com.rest.api.mapper.MapperWithFloorNumber
import java.util.Locale
import javax.inject.Inject

class NumberToFloorSelectorItemMapper @Inject constructor(private val locale: Locale) : MapperWithFloorNumber<Int, FloorSelectorItem>() {

    override fun map(from: Int, floorNumber: Int) =
            FloorSelectorItem(from, String.format(from.toString(), locale), from == floorNumber)

    fun update(items: List<FloorSelectorItem>, floorNumber: Int) = items.forEach { it.active = floorNumber == it.number }
}
