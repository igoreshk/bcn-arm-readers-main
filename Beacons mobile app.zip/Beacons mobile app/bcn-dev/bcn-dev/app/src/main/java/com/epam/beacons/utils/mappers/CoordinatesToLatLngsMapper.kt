package com.epam.beacons.utils.mappers

import com.epam.beacons.Coordinate
import com.epam.beacons.tools.Mapper
import com.google.android.gms.maps.model.LatLng

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CoordinatesToLatLngsMapper @Inject constructor() : Mapper<Coordinate, LatLng>() {

    override fun map(from: Coordinate) = LatLng(from.latitude, from.longitude)

    fun map(coordinate: Coordinate, scaleFactor: Int) = LatLng(coordinate.latitude * scaleFactor, coordinate.longitude * scaleFactor)
}
