package com.epam.beacons.dagger

import com.epam.beacons.broadcasts.CleaningReceiver
import com.epam.beacons.broadcasts.WakeUpReceiver
import com.epam.beacons.buildings.BuildingsActivity
import com.epam.beacons.dialogs.BluetoothEnableDialog
import com.epam.beacons.fragments.favorites.FavoritesFragment
import com.epam.beacons.maps.MapsActivity
import com.epam.beacons.record.DataRecordDialog
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
@Suppress("unused")
abstract class AndroidBindingModule {

    @ContributesAndroidInjector
    abstract fun mapsActivityInjector(): MapsActivity

    @ContributesAndroidInjector
    abstract fun buildingsActivityInjector(): BuildingsActivity

    @ContributesAndroidInjector
    abstract fun dataRecordDialogInjector(): DataRecordDialog

    @ContributesAndroidInjector
    abstract fun bluetoothEnableDialogInjector(): BluetoothEnableDialog

    @ContributesAndroidInjector
    abstract fun favoritesFragmentInjector(): FavoritesFragment

    @ContributesAndroidInjector
    abstract fun cleaningReceiverInjector(): CleaningReceiver

    @ContributesAndroidInjector
    abstract fun WakeUpReceiverInjector(): WakeUpReceiver

}
