package com.epam.beacons.dagger

import com.epam.beacons.graphbinder.GraphBinderData
import com.epam.beacons.graphbinder.GraphBinderProcessor
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.ScaleFactorCalculator
import com.epam.beacons.utils.Constants
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object GraphBinderModule {

    @JvmStatic
    @Provides
    @Singleton
    fun provideGraphBinderProcessor(distanceCalculator: CoordinateDistanceCalculator,
                                    scaleFactorCalculator: ScaleFactorCalculator,
                                    graphBinderData: GraphBinderData) =
            GraphBinderProcessor(distanceCalculator, scaleFactorCalculator, graphBinderData, Constants.ONE_METER_AT_EQUATOR)
}
