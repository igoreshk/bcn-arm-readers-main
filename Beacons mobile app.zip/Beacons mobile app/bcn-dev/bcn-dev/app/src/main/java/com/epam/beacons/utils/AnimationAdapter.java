package com.epam.beacons.utils;

import androidx.annotation.NonNull;
import android.view.animation.Animation;

public class AnimationAdapter implements Animation.AnimationListener {
    @Override
    public void onAnimationStart(@NonNull Animation animation) {
        // empty stub
    }

    @Override
    public void onAnimationEnd(@NonNull Animation animation) {
        // empty stub
    }

    @Override
    public void onAnimationRepeat(@NonNull Animation animation) {
        // empty stub
    }
}