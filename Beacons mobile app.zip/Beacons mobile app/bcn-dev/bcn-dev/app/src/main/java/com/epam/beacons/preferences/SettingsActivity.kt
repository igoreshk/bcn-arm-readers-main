package com.epam.beacons.preferences

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.*
import com.epam.beacons.R
import com.epam.beacons.utils.cancelAlarm
import com.epam.beacons.utils.setAlarm

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (supportFragmentManager.findFragmentById(android.R.id.content) == null) {
            supportFragmentManager.beginTransaction()
                    .add(android.R.id.content, SettingsFragment())
                    .commit()
        }
    }

    class SettingsFragment : PreferenceFragmentCompat() {

        private val bindPreferenceSummaryToValueListener = Preference.OnPreferenceChangeListener { preference, value ->
            when (preference) {
                is EditTextPreference -> {
                    val stringValue = value.toString()
                    preference.setSummary(if (stringValue.isEmpty()) this.getString(R.string.user_name_preference) else stringValue)
                }
                is SwitchPreference -> {
                    if (value is Boolean && value) {
                        setAlarm(preference.context)
                    } else {
                        cancelAlarm(preference.context)
                    }
                }
            }
            true
        }

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            addPreferencesFromResource(R.xml.preferences)
            bindPreferenceSummaryToValue(findPreference(getString(R.string.user_name_key)))
            bindPreferenceSummaryToValue(findPreference(getString(R.string.syncing_switcher_key)))
        }

        private fun bindPreferenceSummaryToValue(preference: Preference?) {
            // Set the listener to watch for value changes.
            preference?.apply {
                onPreferenceChangeListener = bindPreferenceSummaryToValueListener

                // Trigger the listener immediately with the preference's
                // current value.
                if (this is SwitchPreference) {
                    onPreferenceChangeListener.onPreferenceChange(this,
                            PreferenceManager
                                    .getDefaultSharedPreferences(preference.context)
                                    .getBoolean(preference.key, false))
                } else {
                    onPreferenceChangeListener.onPreferenceChange(this,
                            PreferenceManager
                                    .getDefaultSharedPreferences(preference.context)
                                    .getString(preference.key, ""))
                }
            }
        }
    }
}
