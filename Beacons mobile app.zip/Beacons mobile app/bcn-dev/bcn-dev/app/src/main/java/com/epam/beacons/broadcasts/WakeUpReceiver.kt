package com.epam.beacons.broadcasts

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.util.Log
import com.epam.beacons.Track
import com.epam.beacons.interactors.LocationInteractor
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.tools.Logger
import dagger.android.AndroidInjection
import io.reactivex.Completable
import io.reactivex.CompletableObserver
import io.reactivex.Single
import io.reactivex.SingleObserver
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject


class WakeUpReceiver : BroadcastReceiver() {

    companion object {
        private val LOG_TAG = WakeUpReceiver::class.java.simpleName
    }

    @Inject
    lateinit var locationInteractor: LocationInteractor

    @Inject
    lateinit var stateHelper: StateHelper

    @Inject
    lateinit var logger: Logger

    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)

        logger.w(LOG_TAG, "WakeUP!")

        locationInteractor.userLocationOnce.execute(
                onSuccess = {
                    logger.w(LOG_TAG, "location: $it")

                    // TODO: Use userId when authentication / authorization will be implemented
                    val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
                    val df = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US)
                    val timeStamp = df.format(Calendar.getInstance().time)
                    val jsonList = listOf(Track(androidId, it.latitude, it.longitude, timeStamp,
                            stateHelper.buildingId.toInt(), stateHelper.userFloor))
                    locationInteractor.postTracks(jsonList).execute()
                },
                onError = {
                    logger.w(LOG_TAG, "location: $it state helper id: ${stateHelper.buildingId}")
                })
    }

    private fun <Coordinate> Single<Coordinate>.execute(onSuccess: (Coordinate) -> Unit = emptySuccess(),
                                                        onError: (Throwable) -> Unit = emptyError(),
                                                        onSubscribe: (Disposable) -> Unit = emptySubscribe(),
                                                        onFinished: () -> Unit = emptyFinished()) {
        observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(object : SingleObserver<Coordinate> {

                    override fun onSubscribe(d: Disposable) {
                        onSubscribe(d)
                    }

                    override fun onSuccess(t: Coordinate) {
                        onSuccess(t)
                    }

                    override fun onError(e: Throwable) {
                        onError(e)
                        onFinished()
                    }
                })
    }

    private fun Completable.execute(onComplete: () -> Unit = emptyComplete(),
                                    onError: (Throwable) -> Unit = emptyError(),
                                    onSubscribe: (Disposable) -> Unit = emptySubscribe(),
                                    onFinished: () -> Unit = emptyFinished()) {
        observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(object : CompletableObserver {
                    override fun onComplete() {
                        onComplete()
                        onFinished()
                    }

                    override fun onSubscribe(d: Disposable) {
                        onSubscribe(d)
                    }

                    override fun onError(e: Throwable) {
                        onError(e)
                        onFinished()
                    }
                })
    }

    private fun <E> emptySuccess(): (E) -> Unit = {}

    private fun emptyComplete(): () -> Unit = {}

    private fun emptyError(): (Throwable) -> Unit = {
        Log.e(WakeUpReceiver::class.java.simpleName, it.message ?: "", it)
    }

    private fun emptySubscribe(): (Disposable) -> Unit = {}

    private fun emptyFinished(): () -> Unit = {}
}
