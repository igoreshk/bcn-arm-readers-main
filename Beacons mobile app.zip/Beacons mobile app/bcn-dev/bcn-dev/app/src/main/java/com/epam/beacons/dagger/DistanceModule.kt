package com.epam.beacons.dagger

import com.epam.beacons.distance.BeaconDistanceCalculator
import com.epam.beacons.distance.DistanceCalculator
import dagger.Binds
import dagger.Module
import javax.inject.Singleton

@Module
abstract class DistanceModule {

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun provideDistanceCalculator(calculator: BeaconDistanceCalculator): DistanceCalculator
}
