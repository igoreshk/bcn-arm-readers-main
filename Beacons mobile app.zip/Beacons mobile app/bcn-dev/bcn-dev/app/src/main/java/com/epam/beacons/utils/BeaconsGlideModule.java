package com.epam.beacons.utils;

import android.content.Context;
import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Registry;
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.integration.okhttp3.OkHttpUrlLoader;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.module.AppGlideModule;
import com.epam.beacons.BuildConfig;

import java.io.InputStream;
import java.net.URI;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;

import static com.epam.beacons.utils.SslUtils.CERTIFICATE_FILE_NAME;

@GlideModule
public class BeaconsGlideModule extends AppGlideModule {
    @Override
    public void registerComponents(@NonNull Context context, @NonNull Glide glide, @NonNull Registry registry) {
        try {
            TrustManager[] trustManagers = SslUtils.INSTANCE.createTrustManagers(context, CERTIFICATE_FILE_NAME);
            SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustManagers, null);

            if (trustManagers != null) {
                SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
                OkHttpClient okHttpClient = new OkHttpClient.Builder()
                        .sslSocketFactory(sslSocketFactory, (X509TrustManager) trustManagers[0])
                        .hostnameVerifier((hostname, session) ->
                                URI.create(BuildConfig.REST).getHost().equals(hostname))
                        .build();
                registry.replace(GlideUrl.class, InputStream.class, new OkHttpUrlLoader.Factory(okHttpClient));
            }
        } catch (NoSuchAlgorithmException | KeyManagementException e) {
            super.registerComponents(context, glide, registry);
        }
    }
}
