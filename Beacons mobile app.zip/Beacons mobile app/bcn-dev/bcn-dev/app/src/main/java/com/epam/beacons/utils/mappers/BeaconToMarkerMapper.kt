package com.epam.beacons.utils.mappers

import android.content.Context
import com.epam.beacons.Beacon
import com.epam.beacons.Coordinate
import com.epam.beacons.R
import com.epam.beacons.tools.Mapper
import com.epam.beacons.utils.vectorToMarker
import com.google.android.gms.maps.model.MarkerOptions
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BeaconToMarkerMapper @Inject constructor(
        private val context: Context,
        private val coordinateMapper: CoordinatesToLatLngsMapper
) : Mapper<Beacon, MarkerOptions>() {

    override fun map(from: Beacon): MarkerOptions = MarkerOptions()
            .position(coordinateMapper.map(from.coordinate ?: EMPTY_COORD))
            .icon(vectorToMarker(context, R.drawable.ic_beacon))
            .anchor(USER_ANCHOR, USER_ANCHOR)

    companion object {
        private val EMPTY_COORD = Coordinate(Double.MAX_VALUE, Double.MAX_VALUE)
        private const val USER_ANCHOR = 0.5f
    }
}
