package com.epam.beacons

import androidx.appcompat.app.AppCompatDelegate
import com.epam.beacons.dagger.DaggerAppComponent
import com.google.android.gms.maps.MapsInitializer
import dagger.android.AndroidInjector
import dagger.android.DaggerApplication

class MainApp : DaggerApplication() {

    override fun onCreate() {
        super.onCreate()
        MapsInitializer.initialize(this)
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)
    }

    override fun applicationInjector(): AndroidInjector<out DaggerApplication> = DaggerAppComponent.builder().create(this)
}
