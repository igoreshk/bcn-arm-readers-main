package com.epam.beacons.utils.mappers

import android.content.Context
import com.epam.beacons.Pivot
import com.epam.beacons.R
import com.epam.beacons.tools.Mapper
import com.epam.beacons.utils.extensions.color
import com.google.android.gms.maps.model.CircleOptions
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PivotToCircleMapper @Inject constructor(
        private val mapper: ScaleAwareCoordinateToLatLngMapper,
        private val context: Context
) : Mapper<Pivot, CircleOptions>() {

    override fun map(from: Pivot): CircleOptions = CircleOptions()
            .zIndex(LOWEST_Z_INDEX)
            .fillColor(context.color(R.color.mapDebugCircleColor))
            .strokeWidth(NO_LINE)
            .center(mapper.map(from.coordinate))
            .radius(from.distance)

    companion object {
        private const val LOWEST_Z_INDEX = 0.5f
        private const val NO_LINE = 0f
    }
}
