package com.epam.beacons.utils

import android.content.Context
import java.security.KeyStore
import java.security.SecureRandom
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

object SslUtils {
    const val CERTIFICATE_FILE_NAME = "4-Root_2023.cer"

    fun getSslContextForCertificateFile(trustManagers: Array<out TrustManager>?): SSLContext {
        return SSLContext.getInstance("SSL").apply {
            init(null, trustManagers, SecureRandom())
        }
    }

    fun getTrustManager(trustManagers: Array<out TrustManager>?): X509TrustManager {
        return trustManagers?.get(0) as X509TrustManager
    }

    fun createTrustManagers(context: Context, fileName: String): Array<out TrustManager>? {
        // Create a KeyStore containing our trusted CAs
        val keyStoreType = KeyStore.getDefaultType()
        val keyStore = KeyStore.getInstance(keyStoreType).apply {
            load(null, null)
            setCertificateEntry("ca", createCertificate(context, fileName))
        }

        // Create a TrustManager that trusts the CAs inputStream our KeyStore
        val tmfAlgorithm: String = TrustManagerFactory.getDefaultAlgorithm()
        val tmf: TrustManagerFactory = TrustManagerFactory.getInstance(tmfAlgorithm).apply {
            init(keyStore)
        }
        return tmf.trustManagers
    }

    private fun createCertificate(context: Context, fileName: String): Certificate? {
        val assetManager = context.assets
        val certificateFactory = CertificateFactory.getInstance("X.509")
        val caInput = assetManager.open(fileName)
        return caInput.use {
            certificateFactory.generateCertificate(it) as X509Certificate
        }
    }
}
