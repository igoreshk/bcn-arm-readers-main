package com.epam.beacons.buildings

import com.epam.beacons.base.modern.BaseState
import com.epam.beacons.base.modern.SingleEvent
import com.epam.beacons.uimodel.BuildingItem

class BuildingsState : BaseState() {

    var hideProgressOnClose: SingleEvent<Boolean> = SingleEvent(false)

    var buildings: List<BuildingItem> = emptyList()
        set(value) {
            expandedListItemIndex = NO_POSITION
            field = value
        }

    var downloadFinished: SingleEvent<Boolean> = SingleEvent(false)

    var swipeBuildingIndex: Int = 0
    var expandedListItemIndex: Int = NO_POSITION

    var viewMode: ViewMode = ViewMode.SWIPE

    val updateState = UpdateState()

    inner class UpdateState : BaseState() {
        var progressBarVisible: Boolean = true
        var error: SingleEvent<Int> = SingleEvent(DEFAULT_ERROR)
        var refreshing: Boolean = false
        var noNetworkData: Boolean = true
        var launchFirstTime: Boolean = true
        var noNetwork: SingleEvent<Boolean> = SingleEvent(false)
    }

    enum class ViewMode {
        SWIPE,
        LIST
    }

    companion object {
        const val DEFAULT_ERROR = 0
        const val NO_POSITION = -1
    }
}
