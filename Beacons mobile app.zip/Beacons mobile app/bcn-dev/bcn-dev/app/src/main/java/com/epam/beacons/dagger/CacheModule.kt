package com.epam.beacons.dagger

import com.epam.beacons.repository.cache.BeaconsCache
import com.epam.beacons.repository.cache.FavoritePlacesCache
import com.epam.beacons.repository.cache.FloorNumbersCache
import com.epam.beacons.repository.cache.GatesCache
import com.epam.beacons.repository.cache.GraphsCache
import com.epam.beacons.repository.cache.HistoryPlacesCache
import com.epam.beacons.repository.cache.MeasurementCache
import com.epam.beacons.repository.cache.PlacesCache
import com.epam.beacons.repository.cache.UserFloorBeaconsCache
import com.epam.beacons.storage.cache.BeaconsCacheImpl
import com.epam.beacons.storage.cache.FavoritePlacesCacheImpl
import com.epam.beacons.storage.cache.FloorNumbersCacheImpl
import com.epam.beacons.storage.cache.GatesCacheImpl
import com.epam.beacons.storage.cache.GraphsCacheImpl
import com.epam.beacons.storage.cache.HistoryPlacesCacheImpl
import com.epam.beacons.storage.cache.MeasurementCacheImpl
import com.epam.beacons.storage.cache.PlacesCacheImpl
import com.epam.beacons.storage.cache.UserFloorBeaconsCacheImpl
import com.epam.beacons.utils.Constants
import dagger.Binds
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
abstract class CacheModule {

    @Module
    companion object {
        @JvmStatic
        @Provides
        @Singleton
        fun provideHistoryPlacesCache(): HistoryPlacesCache = HistoryPlacesCacheImpl(Constants.HISTORY_LIMIT)
    }

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun provideGatesCache(gatesCacheImpl: GatesCacheImpl): GatesCache

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun provideGraphsCache(graphsCacheImpl: GraphsCacheImpl): GraphsCache

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun provideFloorNumbersCache(floorNumbersCacheImpl: FloorNumbersCacheImpl): FloorNumbersCache

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun providePlacesCache(placesCache: PlacesCacheImpl): PlacesCache

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun provideMeasurementsCache(measurementCache: MeasurementCacheImpl): MeasurementCache

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun provideUserFloorBeaconsCache(userFloorBeaconsCache: UserFloorBeaconsCacheImpl): UserFloorBeaconsCache

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun provideBeaconsCache(beaconsCache: BeaconsCacheImpl): BeaconsCache

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun provideFavoritePlacesCache(favoritePlacesCache: FavoritePlacesCacheImpl): FavoritePlacesCache
}
