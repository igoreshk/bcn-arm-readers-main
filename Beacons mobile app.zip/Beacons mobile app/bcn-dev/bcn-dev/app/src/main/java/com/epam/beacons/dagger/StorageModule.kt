package com.epam.beacons.dagger

import androidx.room.Room
import android.content.Context
import com.epam.beacons.repository.StorageLayer
import com.epam.beacons.storage.AppDatabase
import com.epam.beacons.storage.StorageLayerImpl
import com.epam.beacons.storage.mappers.from.StorageBeaconToBeaconMapper
import com.epam.beacons.storage.mappers.from.StorageBuildingToBuildingMapper
import com.epam.beacons.storage.mappers.from.StorageFloorToFloorMapper
import com.epam.beacons.storage.mappers.from.StorageGateToGateMapper
import com.epam.beacons.storage.mappers.from.StorageMeasurementToMeasurementMapper
import com.epam.beacons.storage.mappers.from.StoragePlaceToPlaceMapper
import com.epam.beacons.storage.mappers.from.StorageVerticesAndEdgesToGraphMapper
import com.epam.beacons.storage.mappers.to.BeaconToStorageBeaconMapper
import com.epam.beacons.storage.mappers.to.BuildingToStorageBuildingMapper
import com.epam.beacons.storage.mappers.to.EdgeToStorageEdgeMapper
import com.epam.beacons.storage.mappers.to.FloorToStorageFloorMapper
import com.epam.beacons.storage.mappers.to.GateToStorageBoundMapper
import com.epam.beacons.storage.mappers.to.GateToStorageGateMapper
import com.epam.beacons.storage.mappers.to.MeasurementToStorageMeasurementMapper
import com.epam.beacons.storage.mappers.to.PlaceIdToStoragePlaceInFavoritesMapper
import com.epam.beacons.storage.mappers.to.PlaceIdToStoragePlaceInHistoryMapper
import com.epam.beacons.storage.mappers.to.PlaceToStoragePlaceMapper
import com.epam.beacons.storage.mappers.to.VertexToStorageVertexMapper
import com.epam.beacons.tools.Logger
import com.epam.beacons.utils.Constants
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object StorageModule {

    @JvmStatic
    @Provides
    @Singleton
    fun provideAppDatabase(context: Context) =
            Room.databaseBuilder(context, AppDatabase::class.java, "beacons-database").build()

    @JvmStatic
    @Provides
    @Singleton
    @Suppress("LongParameterList")
    fun provideStorageLayer(appDatabase: AppDatabase,
                            buildingToStorageBuildingMapper: BuildingToStorageBuildingMapper,
                            floorToStorageFloorMapper: FloorToStorageFloorMapper,
                            vertexToStorageVertexMapper: VertexToStorageVertexMapper,
                            edgeToStorageEdgeMapper: EdgeToStorageEdgeMapper,
                            beaconToStorageBeaconMapper: BeaconToStorageBeaconMapper,
                            placeToStoragePlaceMapper: PlaceToStoragePlaceMapper,
                            placeIdToStoragePlaceInHistoryMapper: PlaceIdToStoragePlaceInHistoryMapper,
                            placeIdToStoragePlaceInFavoritesMapper: PlaceIdToStoragePlaceInFavoritesMapper,
                            gateToStorageBoundMapper: GateToStorageBoundMapper,
                            storageBuildingToBuildingMapper: StorageBuildingToBuildingMapper,
                            storageBeaconToBeaconMapper: StorageBeaconToBeaconMapper,
                            storageFloorToFloorMapper: StorageFloorToFloorMapper,
                            storagePlaceToPlaceMapper: StoragePlaceToPlaceMapper,
                            measurementToStorageMeasurementMapper: MeasurementToStorageMeasurementMapper,
                            storageMeasurementToMeasurementMapper: StorageMeasurementToMeasurementMapper,
                            gateToStorageGateMapper: GateToStorageGateMapper,
                            storageGateToGateMapper: StorageGateToGateMapper,
                            storageVerticesAndEdgesToGraphMapper: StorageVerticesAndEdgesToGraphMapper,
                            logger: Logger): StorageLayer =
            StorageLayerImpl(appDatabase, buildingToStorageBuildingMapper, floorToStorageFloorMapper,
                    vertexToStorageVertexMapper, edgeToStorageEdgeMapper, beaconToStorageBeaconMapper,
                    placeToStoragePlaceMapper, placeIdToStoragePlaceInHistoryMapper,
                    placeIdToStoragePlaceInFavoritesMapper, gateToStorageBoundMapper,
                    storageBuildingToBuildingMapper, storageBeaconToBeaconMapper,
                    storageFloorToFloorMapper, storagePlaceToPlaceMapper, measurementToStorageMeasurementMapper,
                    storageMeasurementToMeasurementMapper, gateToStorageGateMapper, storageGateToGateMapper,
                    storageVerticesAndEdgesToGraphMapper, logger, Constants.HISTORY_LIMIT
            )
}
