package com.epam.beacons.base.modern

abstract class BaseState
