package com.epam.beacons.dagger

import com.epam.beacons.sensors.AccelerationResolver
import com.epam.beacons.sensors.SensorCenterImpl
import com.epam.beacons.sensors.SensorSmoother
import com.epam.beacons.sensors.SensorsListener
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
object KalmanModule {

    @JvmStatic
    @Provides
    @Singleton
    fun provideSensorCenter(listener: SensorsListener, accelResolver: AccelerationResolver, sensorSmoother: SensorSmoother) =
            SensorCenterImpl(listener, accelResolver, sensorSmoother)
}
