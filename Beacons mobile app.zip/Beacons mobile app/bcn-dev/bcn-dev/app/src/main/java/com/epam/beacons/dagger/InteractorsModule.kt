package com.epam.beacons.dagger

import com.epam.beacons.bounders.DistanceBounder
import com.epam.beacons.calibrator.BeaconCalibrator
import com.epam.beacons.distance.BeaconDistanceCalculator
import com.epam.beacons.distance.BeaconDistanceCalibrator
import com.epam.beacons.filter.BeaconFilter
import com.epam.beacons.graphbinder.GraphBinder
import com.epam.beacons.graphbinder.GraphBinderData
import com.epam.beacons.interactors.LocationInteractor
import com.epam.beacons.interactors.PathInteractor
import com.epam.beacons.interactors.shared.BeaconsGetter
import com.epam.beacons.interactors.shared.FloorDeterminator
import com.epam.beacons.interactors.util.FileHandler
import com.epam.beacons.interactors.util.MeasurementHelper
import com.epam.beacons.interactors.util.RecordHelper
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.locator.TrilaterationSolver
import com.epam.beacons.navigation.DijkstraAlgorithm
import com.epam.beacons.navigation.ProximateVertexFinder
import com.epam.beacons.repository.DataRepo
import com.epam.beacons.repository.LocationRepo
import com.epam.beacons.repository.RoutingRepo
import com.epam.beacons.scanner.BeaconScanner
import com.epam.beacons.smoothers.AverageSmoother
import com.epam.beacons.tools.CornerHelper
import com.epam.beacons.tools.GateHelper
import com.epam.beacons.tools.Logger
import com.epam.beacons.tools.debug.DebugStorage
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.ScaleFactorCalculator
import com.epam.beacons.tools.utils.TimeProvider
import com.epam.beacons.utils.Constants
import com.epam.beacons.utils.FileHandlerImpl
import dagger.Binds
import dagger.Module
import dagger.Provides
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
abstract class InteractorsModule {

    @Module
    companion object {
        @JvmStatic
        @Provides
        @Singleton
        @Suppress("LongParameterList")
        fun provideLocationInteractor(beaconsGetter: BeaconsGetter,
                                      floorDeterminator: FloorDeterminator,
                                      averageSmoother: AverageSmoother,
                                      beaconFilter: BeaconFilter,
                                      beaconCalibrator: BeaconCalibrator,
                                      distanceCalibrator: BeaconDistanceCalibrator,
                                      distanceCalculator: BeaconDistanceCalculator,
                                      trilaterationSolver: TrilaterationSolver,
                                      distanceBounder: DistanceBounder,
                                      locationRepository: LocationRepo,
                                      dataRepo: DataRepo,
                                      stateHelper: StateHelper,
                                      debugStorage: DebugStorage,
                                      recordHelper: RecordHelper,
                                      measurementHelper: MeasurementHelper,
                                      graphBinder: GraphBinder,
                                      scaleFactorCalculator: ScaleFactorCalculator,
                                      coordinateDistanceCalculator: CoordinateDistanceCalculator, logger: Logger) =
                LocationInteractor(beaconsGetter, floorDeterminator, averageSmoother, beaconFilter, beaconCalibrator, distanceCalibrator,
                        distanceCalculator, trilaterationSolver, distanceBounder, locationRepository, dataRepo, stateHelper, debugStorage, recordHelper,
                        measurementHelper, graphBinder, scaleFactorCalculator, coordinateDistanceCalculator, logger, Constants.ONE_METER_AT_EQUATOR
                )

        @JvmStatic
        @Provides
        @Singleton
        @Suppress("LongParameterList")
        fun providePathInteractor(dijkstraAlgorithm: DijkstraAlgorithm,
                                  proximateVertexFinder: ProximateVertexFinder,
                                  dataRepo: DataRepo,
                                  locationRepo: LocationRepo,
                                  routingRepo: RoutingRepo,
                                  floorDeterminator: FloorDeterminator,
                                  beaconsGetter: BeaconsGetter,
                                  stateHelper: StateHelper,
                                  gateHelper: GateHelper,
                                  graphBinderData: GraphBinderData,
                                  coordinateDistanceCalculator: CoordinateDistanceCalculator,
                                  cornerHelper: CornerHelper,
                                  scaleFactorCalculator: ScaleFactorCalculator) =
                PathInteractor(dijkstraAlgorithm, proximateVertexFinder, dataRepo, locationRepo, routingRepo, floorDeterminator,
                        beaconsGetter, stateHelper, gateHelper, graphBinderData, coordinateDistanceCalculator,
                        scaleFactorCalculator, cornerHelper, Constants.ONE_METER_AT_EQUATOR
                )

        @JvmStatic
        @Provides
        @Singleton
        fun provideAverageSmoother() = AverageSmoother(Constants.SCANNING_PERIOD_MILLISECONDS, TimeUnit.MILLISECONDS)

        @JvmStatic
        @Provides
        @Singleton
        fun provideRecordHelper(fileHandler: FileHandler) = RecordHelper(fileHandler, Constants.SCANNING_PERIOD_MILLISECONDS)

        @JvmStatic
        @Provides
        @Singleton
        fun provideBeaconsGetter(recordHelper: RecordHelper, beaconScanner: BeaconScanner) =
                BeaconsGetter(recordHelper, beaconScanner, Constants.SCANNING_PERIOD_MILLISECONDS)

        @JvmStatic
        @Provides
        @Singleton
        fun provideDistanceBounder(debugStorage: DebugStorage,
                                   coordinateDistanceCalculator: CoordinateDistanceCalculator,
                                   timeProvider: TimeProvider) =
                DistanceBounder(debugStorage, coordinateDistanceCalculator, timeProvider, Constants.DISTANCE_BOUNDER_MILLISECONDS_LIMIT)
    }

    @Binds
    @Singleton
    @Suppress("unused")
    abstract fun provideFileHandler(fileHandlerImpl: FileHandlerImpl): FileHandler
}
