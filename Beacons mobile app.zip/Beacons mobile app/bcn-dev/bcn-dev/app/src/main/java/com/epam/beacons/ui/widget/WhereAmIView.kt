package com.epam.beacons.ui.widget

import android.content.Context
import android.graphics.Outline
import androidx.appcompat.widget.AppCompatButton
import android.util.AttributeSet
import android.view.View
import android.view.ViewOutlineProvider
import com.epam.beacons.R
import com.epam.beacons.utils.extensions.dimenPx

class WhereAmIView @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleAttr: Int = 0
) : AppCompatButton(context, attrs, defStyleAttr) {
    private val cornerRadius = context.dimenPx(R.dimen.where_am_i_shadow_radius).toFloat()
    private val widgetWidth = context.dimenPx(R.dimen.where_am_i_width)
    private val widgetHeight = context.dimenPx(R.dimen.where_am_i_height)
    private val elevation = context.dimenPx(R.dimen.where_am_i_elevation)
    private val elevationBottom = context.dimenPx(R.dimen.where_am_i_elevation_bottom)

    init {
        outlineProvider = RouteCancelOutlineProvider()
    }

    private inner class RouteCancelOutlineProvider : ViewOutlineProvider() {
        override fun getOutline(view: View?, outline: Outline?) {
            outline?.setRoundRect(
                    -elevation,
                    -elevation,
                    widgetWidth + elevation,
                    widgetHeight + elevationBottom,
                    cornerRadius)
        }
    }
}
