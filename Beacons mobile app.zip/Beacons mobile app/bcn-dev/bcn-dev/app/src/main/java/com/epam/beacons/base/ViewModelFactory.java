package com.epam.beacons.base;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.annotation.NonNull;
import androidx.collection.ArrayMap;

import com.epam.beacons.buildings.BuildingsViewModel;
import com.epam.beacons.dagger.ViewModelSubComponent;
import com.epam.beacons.exception.ViewModelFactoryException;
import com.epam.beacons.fragments.favorites.FavoritesFragmentViewModel;
import com.epam.beacons.maps.MapsViewModel;

import java.util.Map;
import java.util.concurrent.Callable;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class ViewModelFactory implements ViewModelProvider.Factory {
    @NonNull
    private final ArrayMap<Class, Callable<? extends ViewModel>> creators;

    @Inject
    public ViewModelFactory(@NonNull ViewModelSubComponent viewModelSubComponent) {
        creators = new ArrayMap<>();
        creators.put(BuildingsViewModel.class, viewModelSubComponent::buildingsViewModel);
        creators.put(MapsViewModel.class, viewModelSubComponent::mapsViewModel);
        creators.put(FavoritesFragmentViewModel.class, viewModelSubComponent::favoritesFragmentViewModel);
    }

    @Override
    @NonNull
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        Callable<? extends ViewModel> creator = creators.get(modelClass);
        if (creator == null) {
            for (Map.Entry<Class, Callable<? extends ViewModel>> entry : creators.entrySet()) {
                if (modelClass.isAssignableFrom(entry.getKey())) {
                    creator = entry.getValue();
                    break;
                }
            }
        }
        if (creator == null) {
            throw new IllegalArgumentException("Unknown model class " + modelClass);
        }
        try {
            //noinspection unchecked
            return (T) creator.call();
        } catch (Exception e) {
            throw new ViewModelFactoryException(e);
        }
    }
}