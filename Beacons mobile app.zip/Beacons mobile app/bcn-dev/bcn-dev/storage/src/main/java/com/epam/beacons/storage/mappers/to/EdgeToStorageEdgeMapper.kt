package com.epam.beacons.storage.mappers.to

import com.epam.beacons.Edge
import com.epam.beacons.storage.entities.StorageEdge

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class EdgeToStorageEdgeMapper @Inject constructor() : StorageMapper<Edge, StorageEdge>() {

    override fun map(buildingId: String, floorNumber: Int, from: Edge) =
            StorageEdge(buildingId, floorNumber, from.weight!!, from.source!!.id, from.destination!!.id)
}
