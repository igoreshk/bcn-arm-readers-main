package com.epam.beacons.storage;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.epam.beacons.storage.dao.BeaconDao;
import com.epam.beacons.storage.dao.BoundDao;
import com.epam.beacons.storage.dao.BuildingDao;
import com.epam.beacons.storage.dao.EdgeDao;
import com.epam.beacons.storage.dao.FloorDao;
import com.epam.beacons.storage.dao.GateDao;
import com.epam.beacons.storage.dao.MeasurementDao;
import com.epam.beacons.storage.dao.PlaceDao;
import com.epam.beacons.storage.dao.PlaceInFavoritesDao;
import com.epam.beacons.storage.dao.PlaceInHistoryDao;
import com.epam.beacons.storage.dao.VertexDao;
import com.epam.beacons.storage.entities.StorageBeacon;
import com.epam.beacons.storage.entities.StorageBound;
import com.epam.beacons.storage.entities.StorageBuilding;
import com.epam.beacons.storage.entities.StorageEdge;
import com.epam.beacons.storage.entities.StorageFloor;
import com.epam.beacons.storage.entities.StorageGate;
import com.epam.beacons.storage.entities.StorageMeasurement;
import com.epam.beacons.storage.entities.StoragePlace;
import com.epam.beacons.storage.entities.StoragePlaceInFavorites;
import com.epam.beacons.storage.entities.StoragePlaceInHistory;
import com.epam.beacons.storage.entities.StorageVertex;

@Database(
        entities = {
                StorageBuilding.class,
                StorageFloor.class,
                StorageBeacon.class,
                StorageEdge.class,
                StorageVertex.class,
                StoragePlace.class,
                StoragePlaceInHistory.class,
                StoragePlaceInFavorites.class,
                StorageGate.class,
                StorageBound.class,
                StorageMeasurement.class
        }, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    public abstract BuildingDao buildingDao();

    public abstract FloorDao floorDao();

    public abstract BeaconDao beaconDao();

    public abstract EdgeDao edgeDao();

    public abstract VertexDao vertexDao();

    public abstract PlaceDao placeDao();

    public abstract PlaceInHistoryDao placeInHistoryDao();

    public abstract PlaceInFavoritesDao placeInFavoritesDao();

    public abstract GateDao gateDao();

    public abstract BoundDao boundDao();

    public abstract MeasurementDao measurementDao();
}
