package com.epam.beacons.storage.entities;

import androidx.room.Embedded;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.annotation.NonNull;

import static androidx.room.ForeignKey.CASCADE;

@Entity(primaryKeys = {"uuid", "major", "minor"},
        foreignKeys = @ForeignKey(
                entity = StorageFloor.class,
                parentColumns = {"buildingId", "number"},
                childColumns = {"buildingId", "floorNumber"},
                onDelete = CASCADE),
        indices = @Index({"buildingId", "floorNumber"}))
public class StorageBeacon {

    private final String   buildingId;
    private final int    floorNumber;
    @NonNull
    private final String uuid;
    private final String levelId;
    private final int    major;
    private final int    minor;

    @NonNull
    @Embedded
    private final StorageCoordinate coordinate;

    public StorageBeacon(String buildingId, int floorNumber, @NonNull String uuid, String levelId, int major, int minor,
                         @NonNull StorageCoordinate coordinate) {
        this.buildingId = buildingId;
        this.floorNumber = floorNumber;
        this.uuid = uuid;
        this.levelId = levelId;
        this.major = major;
        this.minor = minor;
        this.coordinate = coordinate;
    }

    public String getBuildingId() {
        return buildingId;
    }

    public int getFloorNumber() {
        return floorNumber;
    }

    @NonNull
    public String getUuid() {
        return uuid;
    }

    public int getMajor() {
        return major;
    }

    public int getMinor() {
        return minor;
    }

    @NonNull
    public StorageCoordinate getCoordinate() {
        return coordinate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final StorageBeacon that = (StorageBeacon) o;

        return buildingId == that.buildingId
                && floorNumber == that.floorNumber
                && major == that.major
                && minor == that.minor
                && uuid.equals(that.uuid)
                && coordinate.equals(that.coordinate);
    }

    @Override
    public int hashCode() {
        int result = (int) (buildingId.hashCode() ^ (buildingId.hashCode() >>> 32));
        result = 31 * result + floorNumber;
        result = 31 * result + uuid.hashCode();
        result = 31 * result + major;
        result = 31 * result + minor;
        result = 31 * result + coordinate.hashCode();
        return result;
    }

    public String getLevelId() {
        return levelId;
    }
}
