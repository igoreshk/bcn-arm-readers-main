package com.epam.beacons.storage.entities;

import androidx.room.Embedded;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.annotation.NonNull;

import org.jetbrains.annotations.NotNull;

import static androidx.room.ForeignKey.CASCADE;

@Entity(primaryKeys = {"buildingId", "number"},
        foreignKeys = @ForeignKey(
                entity = StorageBuilding.class,
                parentColumns = "entityId",
                childColumns = "buildingId",
                onDelete = CASCADE),
        indices = @Index("buildingId"))
public class StorageFloor {

    @NonNull
    private final String entityId;
    @NonNull
    private final String buildingId;
    private final int number;
    @NonNull
    private final String image;
    private final Double distance;
    @NonNull
    @Embedded(prefix = "south_west")
    private final StorageCoordinate overlaySouthWestBound;
    @NonNull
    @Embedded(prefix = "north_east")
    private final StorageCoordinate overlayNorthEastBound;

    public StorageFloor(@NotNull String entityId, int number, @NotNull String buildingId, @NonNull String image, double distance, @NonNull StorageCoordinate overlaySouthWestBound,
                        @NonNull StorageCoordinate overlayNorthEastBound) {
        this.entityId = entityId;
        this.buildingId = buildingId;
        this.number = number;
        this.image = image;
        this.distance = distance;
        this.overlaySouthWestBound = overlaySouthWestBound;
        this.overlayNorthEastBound = overlayNorthEastBound;
    }

    @NotNull
    public String getEntityId() {
        return entityId;
    }

    @NotNull
    public String getBuildingId() {
        return buildingId;
    }

    public int getNumber() {
        return number;
    }

    public Double getDistance() { return distance; }

    @NonNull
    public StorageCoordinate getOverlaySouthWestBound() {
        return overlaySouthWestBound;
    }

    @NonNull
    public StorageCoordinate getOverlayNorthEastBound() {
        return overlayNorthEastBound;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final StorageFloor that = (StorageFloor) o;

        return buildingId == that.buildingId
                && number == that.number
                && Double.compare(that.distance, distance) == 0;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = (int) (buildingId.length() ^ (buildingId.length() >>> 32));
        result = 31 * result + number;
        temp = Double.doubleToLongBits(distance);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @NonNull
    public String getImage() {
        return image;
    }
}
