package com.epam.beacons.storage.cache

import com.epam.beacons.Beacon
import com.epam.beacons.repository.cache.UserFloorBeaconsCache
import io.reactivex.Completable
import io.reactivex.Maybe
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Stores a [list] of [Beacon] objects and provides API to work with it.
 */

@Singleton
class UserFloorBeaconsCacheImpl @Inject constructor() : UserFloorBeaconsCache {
    private val list = mutableListOf<Beacon>()

    /**
     * Wraps up the [list] of data with Maybe and returns it. Ensures explicitly the return type is nonnull.
     * @return [Maybe] observable of [list] of objects
     */
    override fun get(): Maybe<List<Beacon>> =
            Maybe.fromCallable { list.toList() }
                    .filter { it.isNotEmpty() }

    /**
     * Replaces internal list of objects with new [list].
     * @param list - list of [Beacon] to replace the existing one with
     * @return [Completable] of the result of replacement action
     */
    override fun put(list: List<Beacon>): Completable = Completable.fromAction {
        this.list.clear()
        this.list.addAll(list)
    }

    /**
     * Clears the list of data by calling [MutableList.clear]. Ensures explicitly the return type is nonnull.
     * @return [Completable] of the clear action
     */
    override fun clear(): Completable = Completable.fromAction { list.clear() }
}
