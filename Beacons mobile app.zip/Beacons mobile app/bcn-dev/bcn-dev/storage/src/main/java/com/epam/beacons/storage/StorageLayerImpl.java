package com.epam.beacons.storage;

import android.database.sqlite.SQLiteConstraintException;
import androidx.annotation.NonNull;

import com.epam.beacons.Beacon;
import com.epam.beacons.Building;
import com.epam.beacons.Floor;
import com.epam.beacons.FloorData;
import com.epam.beacons.Gate;
import com.epam.beacons.Graph;
import com.epam.beacons.Measurement;
import com.epam.beacons.Place;
import com.epam.beacons.repository.StorageLayer;
import com.epam.beacons.storage.entities.StorageGate;
import com.epam.beacons.storage.mappers.from.StorageBeaconToBeaconMapper;
import com.epam.beacons.storage.mappers.from.StorageBuildingToBuildingMapper;
import com.epam.beacons.storage.mappers.from.StorageFloorToFloorMapper;
import com.epam.beacons.storage.mappers.from.StorageGateToGateMapper;
import com.epam.beacons.storage.mappers.from.StorageMeasurementToMeasurementMapper;
import com.epam.beacons.storage.mappers.from.StoragePlaceToPlaceMapper;
import com.epam.beacons.storage.mappers.from.StorageVerticesAndEdgesToGraphMapper;
import com.epam.beacons.storage.mappers.to.BeaconToStorageBeaconMapper;
import com.epam.beacons.storage.mappers.to.BuildingToStorageBuildingMapper;
import com.epam.beacons.storage.mappers.to.EdgeToStorageEdgeMapper;
import com.epam.beacons.storage.mappers.to.FloorToStorageFloorMapper;
import com.epam.beacons.storage.mappers.to.GateToStorageBoundMapper;
import com.epam.beacons.storage.mappers.to.GateToStorageGateMapper;
import com.epam.beacons.storage.mappers.to.MeasurementToStorageMeasurementMapper;
import com.epam.beacons.storage.mappers.to.PlaceIdToStoragePlaceInFavoritesMapper;
import com.epam.beacons.storage.mappers.to.PlaceIdToStoragePlaceInHistoryMapper;
import com.epam.beacons.storage.mappers.to.PlaceToStoragePlaceMapper;
import com.epam.beacons.storage.mappers.to.VertexToStorageVertexMapper;
import com.epam.beacons.tools.Logger;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Maybe;

@Singleton
public class StorageLayerImpl implements StorageLayer {

    @NonNull
    private static final String LOG_TAG       = StorageLayerImpl.class.getSimpleName();

    @NonNull
    private final AppDatabase                            appDatabase;
    @NonNull
    private final BuildingToStorageBuildingMapper        buildingToStorageBuildingMapper;
    @NonNull
    private final FloorToStorageFloorMapper              floorToStorageFloorMapper;
    @NonNull
    private final VertexToStorageVertexMapper            vertexToStorageVertexMapper;
    @NonNull
    private final EdgeToStorageEdgeMapper                edgeToStorageEdgeMapper;
    @NonNull
    private final BeaconToStorageBeaconMapper            beaconToStorageBeaconMapper;
    @NonNull
    private final PlaceToStoragePlaceMapper              placeToStoragePlaceMapper;
    @NonNull
    private final PlaceIdToStoragePlaceInHistoryMapper   placeIdToStoragePlaceInHistoryMapper;
    @NonNull
    private final PlaceIdToStoragePlaceInFavoritesMapper placeIdToStoragePlaceInFavoritesMapper;
    @NonNull
    private final GateToStorageBoundMapper              gateToStorageBoundMapper;
    @NonNull
    private final GateToStorageGateMapper               gateToStorageGateMapper;
    @NonNull
    private final StorageBuildingToBuildingMapper       storageBuildingToBuildingMapper;
    @NonNull
    private final StorageBeaconToBeaconMapper           storageBeaconToBeaconMapper;
    @NonNull
    private final StorageFloorToFloorMapper             storageFloorToFloorMapper;
    @NonNull
    private final StoragePlaceToPlaceMapper             storagePlaceToPlaceMapper;
    @NonNull
    private final MeasurementToStorageMeasurementMapper measurementToStorageMeasurementMapper;
    @NonNull
    private final StorageMeasurementToMeasurementMapper storageMeasurementToMeasurementMapper;
    @NonNull
    private final StorageGateToGateMapper               storageGateToGateMapper;
    @NonNull
    private final StorageVerticesAndEdgesToGraphMapper  storageVerticesAndEdgesToGraphMapper;
    @NonNull
    private final Logger                                logger;
    private final int                                   historyLimit;

    @Inject
    public StorageLayerImpl(@NonNull AppDatabase appDatabase,
                            @NonNull BuildingToStorageBuildingMapper buildingToStorageBuildingMapper,
                            @NonNull FloorToStorageFloorMapper floorToStorageFloorMapper,
                            @NonNull VertexToStorageVertexMapper vertexToStorageVertexMapper,
                            @NonNull EdgeToStorageEdgeMapper edgeToStorageEdgeMapper,
                            @NonNull BeaconToStorageBeaconMapper beaconToStorageBeaconMapper,
                            @NonNull PlaceToStoragePlaceMapper placeToStoragePlaceMapper,
                            @NonNull PlaceIdToStoragePlaceInHistoryMapper placeIdToStoragePlaceInHistoryMapper,
                            @NonNull PlaceIdToStoragePlaceInFavoritesMapper placeIdToStoragePlaceInFavoritesMapper,
                            @NonNull GateToStorageBoundMapper gateToStorageBoundMapper,
                            @NonNull StorageBuildingToBuildingMapper storageBuildingToBuildingMapper,
                            @NonNull StorageBeaconToBeaconMapper storageBeaconToBeaconMapper,
                            @NonNull StorageFloorToFloorMapper storageFloorToFloorMapper,
                            @NonNull StoragePlaceToPlaceMapper storagePlaceToPlaceMapper,
                            @NonNull MeasurementToStorageMeasurementMapper measurementToStorageMeasurementMapper,
                            @NonNull StorageMeasurementToMeasurementMapper storageMeasurementToMeasurementMapper,
                            @NonNull GateToStorageGateMapper gateToStorageGateMapper,
                            @NonNull StorageGateToGateMapper storageGateToGateMapper,
                            @NonNull StorageVerticesAndEdgesToGraphMapper storageVerticesAndEdgesToGraphMapper,
                            @NonNull Logger logger,
                            int historyLimit) {
        this.appDatabase = appDatabase;
        this.buildingToStorageBuildingMapper = buildingToStorageBuildingMapper;
        this.floorToStorageFloorMapper = floorToStorageFloorMapper;
        this.vertexToStorageVertexMapper = vertexToStorageVertexMapper;
        this.edgeToStorageEdgeMapper = edgeToStorageEdgeMapper;
        this.beaconToStorageBeaconMapper = beaconToStorageBeaconMapper;
        this.placeToStoragePlaceMapper = placeToStoragePlaceMapper;
        this.placeIdToStoragePlaceInHistoryMapper = placeIdToStoragePlaceInHistoryMapper;
        this.placeIdToStoragePlaceInFavoritesMapper = placeIdToStoragePlaceInFavoritesMapper;
        this.gateToStorageBoundMapper = gateToStorageBoundMapper;
        this.storageBuildingToBuildingMapper = storageBuildingToBuildingMapper;
        this.storageBeaconToBeaconMapper = storageBeaconToBeaconMapper;
        this.storageFloorToFloorMapper = storageFloorToFloorMapper;
        this.storagePlaceToPlaceMapper = storagePlaceToPlaceMapper;
        this.measurementToStorageMeasurementMapper = measurementToStorageMeasurementMapper;
        this.storageMeasurementToMeasurementMapper = storageMeasurementToMeasurementMapper;
        this.gateToStorageGateMapper = gateToStorageGateMapper;
        this.storageGateToGateMapper = storageGateToGateMapper;
        this.storageVerticesAndEdgesToGraphMapper = storageVerticesAndEdgesToGraphMapper;
        this.logger = logger;
        this.historyLimit = historyLimit;
    }

    //First of all buildings must be saved, then floors, then other entities
    @NonNull
    @Override
    public Completable saveBuildings(@NonNull List<Building> buildings) {
        return Completable.fromAction(() -> {
            appDatabase.buildingDao().deleteAll();
            appDatabase.buildingDao()
                       .insert(buildingToStorageBuildingMapper.map(buildings));
        })
                          .doOnError(throwable -> logger.e(LOG_TAG, throwable.getMessage(), throwable));
    }

    @NonNull
    @Override
    public Maybe<List<Building>> getBuildings() {
        return appDatabase.buildingDao()
                          .getAll()
                          .map(storageBuildingToBuildingMapper::map);
    }

    @NonNull
    @Override
    public Completable saveFloorsData(@NonNull List<FloorData> floorsWithGraph, String buildingId) {
        return Completable.fromAction(() -> {
            // entities for every building will be deleted onCascade when buildingDao().deleteAll() is called
            appDatabase.placeDao().delete(buildingId);
            appDatabase.beaconDao().delete(buildingId);
            appDatabase.floorDao().delete(buildingId);
            appDatabase.edgeDao().delete(buildingId);
            appDatabase.vertexDao().delete(buildingId);

            for (FloorData floorData : floorsWithGraph) {
                final Floor floor = floorData.getFloor();
                final Graph graph = floorData.getGraph();
                final int floorNumber = floor.getNumber();

                appDatabase.floorDao().insert(floorToStorageFloorMapper.map(floor));
                appDatabase.beaconDao().insert(beaconToStorageBeaconMapper.map(buildingId, floorNumber, floor.getBeacons()));
                appDatabase.placeDao().insert(placeToStoragePlaceMapper.map(buildingId, floorNumber, floor.getPlaces()));
                appDatabase.vertexDao().insert(vertexToStorageVertexMapper.map(buildingId, floorNumber, graph.getVertices()));
                appDatabase.edgeDao().insert(edgeToStorageEdgeMapper.map(buildingId, floorNumber, graph.getEdges()));
            }
        }).doOnError(throwable -> {
            if (throwable instanceof SQLiteConstraintException) {
                logger.e(LOG_TAG, "There are no buildings in DB, save them first", throwable);
            } else {
                logger.e(LOG_TAG, throwable.getMessage(), throwable);
            }
        });
    }

    @NonNull
    @Override
    public Maybe<List<Floor>> getFloors(String buildingId) {
        return appDatabase.floorDao()
                          .getFloorNumbers(buildingId)
                          .flattenAsObservable(floorNumbers -> floorNumbers)
                          .flatMapMaybe(floorNumber -> getFloor(buildingId, floorNumber))
                          .toList()
                          .toMaybe();
    }

    @NonNull
    @Override
    public Maybe<Floor> getFloor(String buildingId, int floorNumber) {
        return Maybe.defer(() -> Maybe.zip(
                appDatabase.floorDao().get(buildingId, floorNumber),
                appDatabase.beaconDao().get(buildingId, floorNumber),
                appDatabase.placeDao().get(buildingId, floorNumber),
                appDatabase.placeInHistoryDao().get(buildingId),
                appDatabase.placeInFavoritesDao().get(buildingId),
                storageFloorToFloorMapper::map
        ));
    }

    @NonNull
    @Override
    public Maybe<Graph> getGraph(String buildingId, int floorNumber) {
        return Maybe.zip(
                appDatabase.vertexDao().get(buildingId, floorNumber),
                appDatabase.edgeDao().get(buildingId, floorNumber),
                ((storageVertices, storageEdges) ->
                        storageVerticesAndEdgesToGraphMapper.map(buildingId, floorNumber, storageVertices, storageEdges))
        );
    }

    @NonNull
    @Override
    public Maybe<List<Beacon>> getBeacons(String buildingId, int floorNumber) {
        return appDatabase.beaconDao()
                          .get(buildingId, floorNumber)
                          .map(storageBeaconToBeaconMapper::map);

    }

    @NonNull
    @Override
    public Maybe<List<Beacon>> getBeacons(String buildingId) {
        return appDatabase.beaconDao()
                          .get(buildingId)
                          .map(storageBeaconToBeaconMapper::map);
    }

    @NonNull
    @Override
    public Maybe<List<Beacon>> getBeacons(String buildingId, @NonNull List<Integer> floorNumbers) {
        return appDatabase.beaconDao()
                          .get(buildingId, floorNumbers)
                          .map(storageBeaconToBeaconMapper::map);
    }

    @NonNull
    @Override
    public Maybe<List<Place>> getPlaces(String buildingId) {
        return Maybe.defer(() -> Maybe.zip(
                appDatabase.placeDao().get(buildingId),
                appDatabase.placeInHistoryDao().get(buildingId),
                appDatabase.placeInFavoritesDao().get(buildingId),
                storagePlaceToPlaceMapper::map
        ));
    }

    @NonNull
    @Override
    public Maybe<Place> getPlace(String buildingId, String searchItemId) {
        return Maybe.defer(() -> Maybe.zip(
                appDatabase.placeDao().getById(searchItemId),
                appDatabase.placeInHistoryDao().get(buildingId),
                appDatabase.placeInFavoritesDao().get(buildingId),
                storagePlaceToPlaceMapper::map
        ));
    }

    @NonNull
    @Override
    public Maybe<List<Place>> getFavoritePlaces(String buildingId) {
        return Maybe.defer(() -> Maybe.zip(
                appDatabase.placeDao().getFavoritePlaces(buildingId),
                appDatabase.placeInHistoryDao().get(buildingId),
                storagePlaceToPlaceMapper::mapFavorites
        ));
    }

    @NonNull
    @Override
    public Maybe<List<String>> getFavoritesIds(String buildingId) {
        return appDatabase.placeInFavoritesDao()
                          .get(buildingId);
    }

    @NonNull
    @Override
    public Maybe<List<Place>> getHistoryPlaces(String buildingId) {
        return Maybe.defer(() -> Maybe.zip(
                appDatabase.placeDao().getHistoryPlaces(buildingId),
                appDatabase.placeInFavoritesDao().get(buildingId),
                storagePlaceToPlaceMapper::mapHistory
        ));
    }

    @NonNull
    @Override
    public Completable addToHistory(String buildingId, String placeId) {
        return Completable.fromAction(
                () -> appDatabase.placeInHistoryDao()
                                 .insert(placeIdToStoragePlaceInHistoryMapper.map(buildingId, placeId)))
                          .andThen(appDatabase.placeInHistoryDao().count(buildingId))
                          .filter(count -> count > historyLimit)
                          .flatMapCompletable(overLimit -> Completable.fromAction(() -> appDatabase.placeInHistoryDao().deleteOldest(buildingId)));
    }

    @NonNull
    @Override
    public Completable addToFavorites(String buildingId, String placeId) {
        return Completable.fromAction(
                () -> appDatabase.placeInFavoritesDao()
                                 .insert(placeIdToStoragePlaceInFavoritesMapper.map(buildingId, placeId))
        );
    }

    @NonNull
    @Override
    public Completable removeFromFavorites(String buildingId, String placeId) {
        return Completable.fromAction(() -> appDatabase.placeInFavoritesDao().delete(buildingId, placeId));
    }

    @NonNull
    @Override
    public Completable saveGates(@NonNull List<Gate> gates, String buildingId) {
        return Completable.fromAction(() -> {
            // bounds will be deleted onCascade when deleting gate by buildingId
            appDatabase.gateDao().delete(buildingId);

            appDatabase.gateDao()
                       .insert(gateToStorageGateMapper.map(gates));
            appDatabase.boundDao()
                       .insert(gateToStorageBoundMapper.map(gates));
        });
    }

    @NonNull
    @Override
    public Maybe<List<Gate>> getGates(String buildingId) {
        return appDatabase.gateDao()
                          .get(buildingId)
                          .flattenAsObservable(storageGates -> storageGates)
                          .map(StorageGate::getId)
                          .flatMapMaybe(this::getGate)
                          .toList()
                          .toMaybe();
    }

    @NonNull
    @Override
    public Completable saveMeasurements(@NonNull List<Measurement> measurements) {
        return Completable.fromAction(() -> appDatabase.measurementDao()
                                                       .insert(measurementToStorageMeasurementMapper.map(measurements)));
    }

    @NonNull
    @Override
    public Maybe<List<Measurement>> getMeasurements() {
        return appDatabase.measurementDao()
                          .getAll()
                          .map(storageMeasurementToMeasurementMapper::map);
    }

    @NonNull
    @Override
    public Completable deleteMeasurements(int rssi, int limit) {
        return Completable.fromAction(
                () -> appDatabase.measurementDao().delete(rssi, limit));
    }

    @NonNull
    private Maybe<Gate> getGate(long gateId) {
        return Maybe.defer(() -> Maybe.zip(
                appDatabase.gateDao().getById(gateId),
                appDatabase.boundDao().get(gateId),
                storageGateToGateMapper::map
        ));
    }
}
