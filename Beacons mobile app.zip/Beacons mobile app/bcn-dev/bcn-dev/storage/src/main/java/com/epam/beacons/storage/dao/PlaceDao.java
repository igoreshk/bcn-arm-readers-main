package com.epam.beacons.storage.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.epam.beacons.storage.entities.StoragePlace;

import java.util.List;

import io.reactivex.Maybe;

@Dao
public interface PlaceDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(List<StoragePlace> storagePlaces);

    @Query("SELECT * FROM storagePlace WHERE buildingId = :buildingId")
    Maybe<List<StoragePlace>> get(String buildingId);

    @Query("SELECT * FROM storagePlace WHERE buildingId = :buildingId AND floorNumber = :floorNumber")
    Maybe<List<StoragePlace>> get(String buildingId, int floorNumber);

    @Query("SELECT * FROM storagePlace WHERE id = :id")
    Maybe<StoragePlace> getById(String id);

    @Query("SELECT id, storagePlace.buildingId, floorNumber, type, description, latitude, longitude " +
            "FROM storagePlace " +
            "INNER JOIN storagePlaceInFavorites ON storagePlace.id = storagePlaceInFavorites.placeId " +
            "WHERE storagePlace.buildingId = :buildingId")
    Maybe<List<StoragePlace>> getFavoritePlaces(String buildingId);

    @Query("SELECT id, storagePlace.buildingId, floorNumber, type, description, latitude, longitude " +
            "FROM storagePlace " +
            "INNER JOIN storagePlaceInHistory ON storagePlace.id = storagePlaceInHistory.placeId " +
            "WHERE storagePlace.buildingId=:buildingId " +
            "ORDER BY storagePlaceInHistory.timestamp DESC")
    Maybe<List<StoragePlace>> getHistoryPlaces(String buildingId);

    @Query("DELETE FROM storagePlace")
    void deleteAll();

    @Query("DELETE FROM storagePlace WHERE buildingId = :buildingId")
    void delete(String buildingId);
}
