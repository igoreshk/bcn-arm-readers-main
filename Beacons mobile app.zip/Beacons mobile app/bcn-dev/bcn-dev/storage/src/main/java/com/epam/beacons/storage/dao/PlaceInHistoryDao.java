package com.epam.beacons.storage.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.epam.beacons.storage.entities.StoragePlaceInHistory;

import java.util.List;

import io.reactivex.Maybe;

@Dao
public interface PlaceInHistoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(StoragePlaceInHistory storagePlaceInHistory);

    @Query("SELECT count (placeId) FROM storagePlaceInHistory WHERE buildingId = :buildingId")
    Maybe<Integer> count(String buildingId);

    @Query("SELECT placeId FROM storagePlaceInHistory WHERE buildingId = :buildingId")
    Maybe<List<String>> get(String buildingId);

    @Query("DELETE FROM storagePlaceInHistory WHERE buildingId = :buildingId AND placeId = :placeId")
    void delete(String buildingId, long placeId);

    @Query("DELETE FROM storagePlaceInHistory WHERE placeId IN " +
            "(SELECT placeId FROM storagePlaceInHistory WHERE buildingId = :buildingId ORDER BY timestamp ASC LIMIT 1)")
    void deleteOldest(String buildingId);

    @Query("DELETE FROM storagePlaceInHistory")
    void deleteAll();
}
