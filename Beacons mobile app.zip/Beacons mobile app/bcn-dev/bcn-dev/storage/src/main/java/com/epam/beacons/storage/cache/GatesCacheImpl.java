package com.epam.beacons.storage.cache;

import androidx.annotation.NonNull;

import com.epam.beacons.Gate;
import com.epam.beacons.repository.cache.GatesCache;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Maybe;

@Singleton
public class GatesCacheImpl implements GatesCache {

    @NonNull
    private List<Gate> cache = new ArrayList<>();

    @Inject
    GatesCacheImpl() { // default constructor for dagger
    }

    @NonNull
    @Override
    public Maybe<List<Gate>> get() {
        return Maybe.fromCallable(() -> cache)
                    .filter(gates -> !gates.isEmpty());
    }

    @NonNull
    @Override
    public Completable put(@NonNull List<Gate> gates) {
        return Completable.fromAction(() -> cache = gates);
    }

    @NonNull
    @Override
    public Completable clear() {
        return Completable.fromAction(() -> cache.clear());
    }
}
