package com.epam.beacons.storage.cache

import com.epam.beacons.Graph
import com.epam.beacons.repository.cache.GraphsCache
import io.reactivex.Completable
import io.reactivex.Maybe
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GraphsCacheImpl @Inject constructor() : GraphsCache {
    private val map = HashMap<Int, Graph>()

    override fun get(floorNumber: Int): Maybe<Graph> {
        val graph = map[floorNumber]
        return if (graph != null) Maybe.fromCallable { graph } else Maybe.empty()
    }

    override fun clear(): Completable = Completable.fromAction { map.clear() }

    override fun put(graph: Graph): Completable = Completable.fromAction { map[graph.floorNumber] = graph }
}
