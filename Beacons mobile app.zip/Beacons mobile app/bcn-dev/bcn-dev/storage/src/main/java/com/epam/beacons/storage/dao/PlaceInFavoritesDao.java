package com.epam.beacons.storage.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.epam.beacons.storage.entities.StoragePlaceInFavorites;

import java.util.List;

import io.reactivex.Maybe;

@Dao
public interface PlaceInFavoritesDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(StoragePlaceInFavorites storagePlaceInFavorites);

    @Query("SELECT placeId FROM storagePlaceInFavorites WHERE buildingId = :buildingId")
    Maybe<List<String>> get(String buildingId);

    @Query("DELETE FROM storagePlaceInFavorites WHERE buildingId = :buildingId AND placeId = :placeId")
    void delete(String buildingId, String placeId);

    @Query("DELETE FROM storagePlaceInFavorites")
    void deleteAll();
}
