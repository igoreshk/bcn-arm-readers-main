package com.epam.beacons.storage.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.epam.beacons.storage.entities.StorageEdge;

import java.util.List;

import io.reactivex.Maybe;

@Dao
public interface EdgeDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(List<StorageEdge> storageEdges);

    @Query("SELECT * FROM storageEdge WHERE buildingId = :buildingId AND floorNumber = :floorNumber")
    Maybe<List<StorageEdge>> get(String buildingId, int floorNumber);

    @Query("DELETE FROM storageEdge")
    void deleteAll();

    @Query("DELETE FROM storageEdge WHERE buildingId = :buildingId")
    void delete(String buildingId);
}
