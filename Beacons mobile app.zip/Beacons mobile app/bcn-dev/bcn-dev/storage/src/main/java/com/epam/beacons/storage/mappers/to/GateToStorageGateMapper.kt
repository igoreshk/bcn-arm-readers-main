package com.epam.beacons.storage.mappers.to

import com.epam.beacons.Gate
import com.epam.beacons.storage.entities.StorageGate
import com.epam.beacons.tools.Mapper

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GateToStorageGateMapper @Inject constructor() : Mapper<Gate, StorageGate>() {

    override fun map(from: Gate) = StorageGate(from.id, from.buildingId, from.image, from.type)
}
