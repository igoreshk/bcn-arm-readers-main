package com.epam.beacons.storage.entities

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.epam.beacons.Coordinate

@Entity
data class StorageBuilding(@PrimaryKey val entityId: String,
                           val address:  String?,
                           @Embedded val coordinate: StorageCoordinate,
                           val width: Double?,
                           val height: Double?,
                           val name: String?,
                           val phoneNumber: String?,
                           val workingHours: String?,
                           val createdBy:String?,
                           val icon:String?)

