package com.epam.beacons.storage.cache

import com.epam.beacons.Floor
import com.epam.beacons.repository.cache.FloorNumbersCache
import io.reactivex.Completable
import io.reactivex.Maybe
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FloorNumbersCacheImpl @Inject constructor() : FloorNumbersCache {

    private val list = mutableListOf<Int>()

    override fun put(numbers: List<Floor>): Completable = Completable.fromAction {
        numbers.forEach { list.add(it.number) }
    }

    override fun get(): Maybe<List<Int>> = Maybe.fromCallable { list }

    override fun clear(): Completable = Completable.fromAction { list.clear() }
}
