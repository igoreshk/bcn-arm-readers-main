package com.epam.beacons.storage.cache;

import androidx.annotation.NonNull;

import com.epam.beacons.Place;
import com.epam.beacons.repository.cache.FavoritePlacesCache;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Maybe;
import io.reactivex.Observable;
import io.reactivex.Single;

@Singleton
public class FavoritePlacesCacheImpl implements FavoritePlacesCache {

    @NonNull
    private List<Place> favorites    = new ArrayList<>();
    @NonNull
    private List<String>  favoritesIds = new ArrayList<>();

    private boolean initialized = false;

    @Inject
    FavoritePlacesCacheImpl() { // default constructor for dagger
    }

    @NonNull
    @Override
    public Maybe<List<Place>> get() {
        return Maybe.fromCallable(() -> favorites)
                    .filter(places -> !places.isEmpty());
    }

    @NonNull
    @Override
    public Maybe<List<String>> getIds() {
        return Maybe.fromCallable(() -> favoritesIds)
                    .filter(ids -> !ids.isEmpty());
    }

    @NonNull
    @Override
    public Completable put(@NonNull List<Place> places) {
        return Observable.fromCallable(() -> this.favorites = places)
                         .flatMapIterable(favorites -> favorites)
                         .map(Place::getId)
                         .filter(ids -> !favoritesIds.contains(ids))
                         .toList()
                         .doOnSuccess(ids -> {
                             favoritesIds.addAll(ids);
                             initialized = true;
                         })
                         .toCompletable();
    }

    @NonNull
    @Override
    public Completable put(@NonNull Place place) {
        return Completable.fromAction(() -> {
            favorites.remove(place);
            favorites.add(place);
            favoritesIds.remove(place.getId());
            favoritesIds.add(place.getId());
        });
    }

    @NonNull
    @Override
    public Completable putIds(@NonNull List<String> ids) {
        return Completable.fromAction(() -> this.favoritesIds = ids);
    }

    @NonNull
    @Override
    public Completable remove(String placeId) {
        return Observable.fromIterable(favorites)
                         .filter(place -> place.getId() != placeId)
                         .toList()
                         .doOnSuccess(places -> this.favorites = places)
                         .toCompletable()
                         .doOnComplete(() -> {
                             favoritesIds.remove(placeId);
                             initialized = true;
                         });
    }

    @NonNull
    @Override
    public Completable clear() {
        return Completable.fromAction(() -> {
            favorites.clear();
            favoritesIds.clear();
            initialized = false;
        });
    }

    @NonNull
    @Override
    public Single<Boolean> isEmpty() {
        return Single.fromCallable(() -> favorites.isEmpty());
    }

    @NonNull
    @Override
    public Single<Boolean> isInitialized() {
        return Single.fromCallable(() -> initialized);
    }
}
