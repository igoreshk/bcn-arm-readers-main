package com.epam.beacons.storage.mappers.to

import com.epam.beacons.storage.entities.StoragePlaceInFavorites
import com.epam.beacons.tools.MapperWithBuildingId
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PlaceIdToStoragePlaceInFavoritesMapper @Inject constructor() : MapperWithBuildingId<String, StoragePlaceInFavorites>() {

    override fun map(buildingId: String, from: String) = StoragePlaceInFavorites(buildingId, from)
}
