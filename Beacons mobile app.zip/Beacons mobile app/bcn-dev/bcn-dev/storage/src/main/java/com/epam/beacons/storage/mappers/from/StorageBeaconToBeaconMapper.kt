package com.epam.beacons.storage.mappers.from

import com.epam.beacons.Beacon
import com.epam.beacons.storage.entities.StorageBeacon
import com.epam.beacons.tools.Mapper

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StorageBeaconToBeaconMapper @Inject constructor(
        private val coordinateMapper: StorageCoordinateToCoordinateMapper
) : Mapper<StorageBeacon, Beacon>() {

    override fun map(from: StorageBeacon) = Beacon(
            from.uuid, from.major, from.minor, from.levelId,
            from.floorNumber, coordinateMapper.map(from.coordinate)
    )
}
