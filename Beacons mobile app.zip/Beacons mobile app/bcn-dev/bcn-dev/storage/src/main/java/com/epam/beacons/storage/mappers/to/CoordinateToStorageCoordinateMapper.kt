package com.epam.beacons.storage.mappers.to

import com.epam.beacons.Coordinate
import com.epam.beacons.storage.entities.StorageCoordinate
import com.epam.beacons.tools.Mapper

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CoordinateToStorageCoordinateMapper @Inject constructor() : Mapper<Coordinate, StorageCoordinate>() {

    override fun map(from: Coordinate) = StorageCoordinate(from.latitude, from.longitude)
}
