package com.epam.beacons.storage.mappers.to

import com.epam.beacons.Beacon
import com.epam.beacons.storage.entities.StorageBeacon
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
@Suppress("UnsafeCallOnNullableType")
class BeaconToStorageBeaconMapper @Inject constructor(
        private val coordinateMapper: CoordinateToStorageCoordinateMapper
) : StorageMapper<Beacon, StorageBeacon>() {

    override fun map(buildingId: String, floorNumber: Int, from: Beacon) =
            StorageBeacon(buildingId, floorNumber, from.uuid, from.levelId, from.major,
                    from.minor, coordinateMapper.map(from.coordinate!!))
}
