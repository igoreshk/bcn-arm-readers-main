package com.epam.beacons.storage.mappers.from

import com.epam.beacons.Measurement
import com.epam.beacons.storage.entities.StorageMeasurement
import com.epam.beacons.tools.Mapper
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StorageMeasurementToMeasurementMapper @Inject constructor() : Mapper<StorageMeasurement, Measurement>() {

    override fun map(from: StorageMeasurement) = Measurement(from.rssi, from.distance, from.timestamp)
}
