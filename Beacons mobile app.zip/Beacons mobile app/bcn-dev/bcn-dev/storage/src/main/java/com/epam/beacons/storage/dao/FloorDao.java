package com.epam.beacons.storage.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.epam.beacons.storage.entities.StorageFloor;

import java.util.List;

import io.reactivex.Maybe;

@Dao
public interface FloorDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(StorageFloor storageFloor);

    @Query("SELECT * FROM storageFloor WHERE buildingId = :buildingId")
    Maybe<List<StorageFloor>> get(String buildingId);

    @Query("SELECT number FROM storageFloor WHERE buildingId = :buildingId")
    Maybe<List<Integer>> getFloorNumbers(String buildingId);

    @Query("SELECT * FROM storageFloor WHERE buildingId = :buildingId AND number = :floorNumber")
    Maybe<StorageFloor> get(String buildingId, int floorNumber);

    @Query("DELETE FROM storageFloor")
    void deleteAll();

    @Query("DELETE FROM storageFloor WHERE buildingId = :buildingId")
    void delete(String buildingId);
}
