package com.epam.beacons.storage.mappers.to

import com.epam.beacons.Gate
import com.epam.beacons.storage.entities.StorageBound

import java.util.ArrayList

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
@Suppress("UnsafeCallOnNullableType")
class GateToStorageBoundMapper @Inject constructor(private val coordinateMapper: CoordinateToStorageCoordinateMapper) {

    fun map(gates: List<Gate>): List<StorageBound> {
        val storageBounds = ArrayList<StorageBound>()
        gates.forEach { gate ->
            storageBounds.addAll(gate.bounds.keys.map { floorNumber ->
                StorageBound(gate.id, floorNumber, coordinateMapper.map(gate.bounds[floorNumber]!!))
            })
        }
        return storageBounds
    }
}
