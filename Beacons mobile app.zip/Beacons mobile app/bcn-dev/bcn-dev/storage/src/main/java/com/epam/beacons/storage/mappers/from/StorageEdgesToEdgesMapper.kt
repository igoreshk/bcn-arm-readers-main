package com.epam.beacons.storage.mappers.from

import android.util.LongSparseArray

import com.epam.beacons.Edge
import com.epam.beacons.Vertex
import com.epam.beacons.storage.entities.StorageEdge
import com.epam.beacons.storage.entities.StorageVertex

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StorageEdgesToEdgesMapper @Inject constructor(private val vertexMapper: StorageVertexToVertexMapper) {

    fun map(storageEdges: List<StorageEdge>, storageVertices: List<StorageVertex>): List<Edge> {
        val vertexMap = LongSparseArray<Vertex>()
        storageVertices.forEach { vertex -> vertexMap.put(vertex.entityId.toLong(), vertexMapper.map(vertex)) }

        return storageEdges.map { Edge(vertexMap.get(it.vertex1Id.toLong()), vertexMap.get(it.vertex2Id.toLong()), it.weight) }
    }
}
