package com.epam.beacons.storage.cache

import com.epam.beacons.Beacon
import com.epam.beacons.repository.cache.BeaconsCache
import io.reactivex.Completable
import io.reactivex.Maybe
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BeaconsCacheImpl @Inject constructor() : BeaconsCache {

    private val cache = HashMap<Int, List<Beacon>>()

    override fun getBeacons(floorNumbers: List<Int>): Maybe<List<Beacon>> =
            Maybe.fromCallable { cache.filter { floorNumbers.contains(it.key) }.values.flatten() }
                    .filter { it.isNotEmpty() }

    override fun getFloorNumbers(): Maybe<List<Int>> = Maybe.fromCallable { cache.keys.toList() }
            .filter { it.isNotEmpty() }

    override fun put(beacons: List<Beacon>): Completable = Completable.fromAction { cache.putAll(beacons.groupBy { it.floorNumber }) }

    override fun clear(): Completable = Completable.fromAction { cache.clear() }
}
