package com.epam.beacons.storage.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.epam.beacons.storage.entities.StorageBeacon;

import java.util.List;

import io.reactivex.Maybe;

@Dao
public interface BeaconDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(List<StorageBeacon> storageBeacons);

    @Query("SELECT * FROM storageBeacon WHERE buildingId = :buildingId AND floorNumber = :floorNumber")
    Maybe<List<StorageBeacon>> get(String buildingId, int floorNumber);

    @Query("SELECT * FROM storageBeacon WHERE buildingId = :buildingId")
    Maybe<List<StorageBeacon>> get(String buildingId);

    @Query("SELECT * FROM storageBeacon WHERE buildingId = :buildingId AND floorNumber IN(:floorNumbers)")
    Maybe<List<StorageBeacon>> get(String buildingId, List<Integer> floorNumbers);

    @Query("DELETE FROM storageBeacon")
    void deleteAll();

    @Query("DELETE FROM storageBeacon WHERE buildingId = :buildingId")
    void delete(String buildingId);
}
