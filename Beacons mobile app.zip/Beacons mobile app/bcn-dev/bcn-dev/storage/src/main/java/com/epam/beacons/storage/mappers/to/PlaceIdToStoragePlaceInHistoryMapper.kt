package com.epam.beacons.storage.mappers.to

import com.epam.beacons.storage.entities.StoragePlaceInHistory
import com.epam.beacons.tools.MapperWithBuildingId
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PlaceIdToStoragePlaceInHistoryMapper @Inject constructor() : MapperWithBuildingId<String, StoragePlaceInHistory>() {

    override fun map(buildingId: String, from: String) = StoragePlaceInHistory(buildingId, from, System.currentTimeMillis())
}
