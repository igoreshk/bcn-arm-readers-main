package com.epam.beacons.storage.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.epam.beacons.storage.entities.StorageVertex;

import java.util.List;

import io.reactivex.Maybe;

@Dao
public interface VertexDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(List<StorageVertex> vertices);

    @Query("SELECT * FROM storageVertex WHERE buildingId = :buildingId AND floorNumber = :floorNumber")
    Maybe<List<StorageVertex>> get(String buildingId, int floorNumber);

    @Query("DELETE FROM storageVertex")
    void deleteAll();

    @Query("DELETE FROM storageVertex WHERE buildingId = :buildingId")
    void delete(String buildingId);
}
