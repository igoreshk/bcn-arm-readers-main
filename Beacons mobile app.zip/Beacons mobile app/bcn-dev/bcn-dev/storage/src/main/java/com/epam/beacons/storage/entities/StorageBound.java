package com.epam.beacons.storage.entities;

import androidx.room.Embedded;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.annotation.NonNull;

import static androidx.room.ForeignKey.CASCADE;

@Entity(primaryKeys = {"gateId", "floorNumber"},
        foreignKeys = @ForeignKey(
                entity = StorageGate.class,
                parentColumns = "id",
                childColumns = "gateId",
                onDelete = CASCADE),
        indices = @Index("gateId"))
public class StorageBound {
    private final long gateId;
    private final int  floorNumber;

    @NonNull
    @Embedded
    private final StorageCoordinate coordinate;

    public StorageBound(long gateId, int floorNumber, @NonNull StorageCoordinate coordinate) {
        this.gateId = gateId;
        this.floorNumber = floorNumber;
        this.coordinate = coordinate;
    }

    public long getGateId() {
        return gateId;
    }

    public int getFloorNumber() {
        return floorNumber;
    }

    @NonNull
    public StorageCoordinate getCoordinate() {
        return coordinate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final StorageBound that = (StorageBound) o;

        return gateId == that.gateId
                && floorNumber == that.floorNumber
                && coordinate.equals(that.coordinate);
    }

    @Override
    public int hashCode() {
        int result = (int) (gateId ^ (gateId >>> 32));
        result = 31 * result + floorNumber;
        result = 31 * result + coordinate.hashCode();
        return result;
    }
}
