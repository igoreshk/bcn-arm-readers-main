package com.epam.beacons.storage.entities;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import static androidx.room.ForeignKey.CASCADE;

@Entity(foreignKeys = @ForeignKey(
        entity = StorageBuilding.class,
        parentColumns = "entityId",
        childColumns = "buildingId",
        onDelete = CASCADE),
        indices = @Index("buildingId"))
public class StorageGate {

    @PrimaryKey
    private final long   id;
    private final String   buildingId;
    @Nullable
    private final String image;
    @NonNull
    private final String type;

    public StorageGate(long id, String buildingId, @Nullable String image, @NonNull String type) {
        this.id = id;
        this.buildingId = buildingId;
        this.image = image;
        this.type = type;
    }

    public long getId() {
        return id;
    }

    @Nullable
    public String getImage() {
        return image;
    }

    @NonNull
    public String getType() {
        return type;
    }

    public String getBuildingId() {
        return buildingId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final StorageGate that = (StorageGate) o;

        return id == that.id && buildingId == that.buildingId && type.equals(that.type);
    }

    @Override
    public int hashCode() {
        int result = (int) (id ^ (id >>> 32));
        result = 31 * result + (int) (buildingId.length() ^ (buildingId.length() >> 32));
        result = 31 * result + type.hashCode();
        return result;
    }
}
