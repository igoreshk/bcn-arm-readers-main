package com.epam.beacons.storage.mappers.to

import com.epam.beacons.Building
import com.epam.beacons.storage.entities.StorageBuilding
import com.epam.beacons.tools.Mapper

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BuildingToStorageBuildingMapper @Inject constructor(
        private val coordinateMapper: CoordinateToStorageCoordinateMapper
) : Mapper<Building, StorageBuilding>() {

    override fun map(from: Building) =
            StorageBuilding(from.entityId, from.address, coordinateMapper.map(from.coordinate),
                    from.width, from.height,
                    from.name, from.phoneNumber, from.workingHours, from.createdBy, from.icon)
}
