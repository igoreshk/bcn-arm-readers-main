package com.epam.beacons.storage.mappers.to

import com.epam.beacons.Measurement
import com.epam.beacons.storage.entities.StorageMeasurement
import com.epam.beacons.tools.Mapper
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MeasurementToStorageMeasurementMapper @Inject constructor() : Mapper<Measurement, StorageMeasurement>() {

    override fun map(from: Measurement) = StorageMeasurement(from.rssi, from.distance, from.timestamp)
}
