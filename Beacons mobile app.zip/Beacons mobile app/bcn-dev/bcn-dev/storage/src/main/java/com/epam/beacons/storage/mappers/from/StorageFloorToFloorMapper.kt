package com.epam.beacons.storage.mappers.from

import com.epam.beacons.Floor
import com.epam.beacons.storage.entities.StorageBeacon
import com.epam.beacons.storage.entities.StorageFloor
import com.epam.beacons.storage.entities.StoragePlace
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StorageFloorToFloorMapper @Inject constructor(
    private val beaconMapper: StorageBeaconToBeaconMapper,
    private val placeMapper: StoragePlaceToPlaceMapper,
    private val coordinateMapper: StorageCoordinateToCoordinateMapper
) {

    fun map(
        storageFloor: StorageFloor,
        storageBeacons: List<StorageBeacon>,
        storagePlaces: List<StoragePlace>,
        historyPlacesIds: List<String>,
        favoritePlacesIds: List<String>
    ) =
        Floor(
            storageFloor.entityId,
            storageFloor.number,
            storageFloor.buildingId,
            beaconMapper.map(storageBeacons),
            placeMapper.map(storagePlaces, historyPlacesIds, favoritePlacesIds),
            storageFloor.image,
            storageFloor.distance,
            coordinateMapper.map(storageFloor.overlaySouthWestBound),
            coordinateMapper.map(storageFloor.overlayNorthEastBound)
        )
}
