package com.epam.beacons.storage.mappers.from

import com.epam.beacons.Place
import com.epam.beacons.storage.entities.StoragePlace
import com.epam.beacons.tools.Mapper

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StoragePlaceToPlaceMapper @Inject constructor(
        private val coordinateMapper: StorageCoordinateToCoordinateMapper
) : Mapper<StoragePlace, Place>() {

    override fun map(from: StoragePlace) = Place(from.id, from.type, from.description, coordinateMapper.map(from.coordinate), from.floorNumber)

    fun map(from: StoragePlace, historyPlacesIds: List<String>, favoritePlacesIds: List<String>) = map(from).apply {
        this.isInHistory = historyPlacesIds.contains(this.id)
        this.isFavorite = favoritePlacesIds.contains(this.id)
    }

    fun map(from: List<StoragePlace>, historyPlacesIds: List<String>, favoritePlacesIds: List<String>) =
            from.map { map(it, historyPlacesIds, favoritePlacesIds) }

    fun mapFavorites(from: List<StoragePlace>, historyPlacesIds: List<String>) =
            from.map { map(it, historyPlacesIds, emptyList()).apply { this.isFavorite = true } }

    fun mapHistory(from: List<StoragePlace>, favoritePlacesIds: List<String>) =
            from.map { map(it, emptyList(), favoritePlacesIds).apply { this.isInHistory = true } }
}
