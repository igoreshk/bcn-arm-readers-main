package com.epam.beacons.storage.mappers.from

import com.epam.beacons.Coordinate
import com.epam.beacons.storage.entities.StorageCoordinate
import com.epam.beacons.tools.Mapper

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StorageCoordinateToCoordinateMapper @Inject constructor() : Mapper<StorageCoordinate, Coordinate>() {

    override fun map(from: StorageCoordinate) = Coordinate(from.latitude, from.longitude)
}
