package com.epam.beacons.storage.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.epam.beacons.storage.entities.StorageBound;

import java.util.List;

import io.reactivex.Maybe;

@Dao
public interface BoundDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(List<StorageBound> bounds);

    @Query("SELECT * FROM storageBound WHERE gateId = :gateId")
    Maybe<List<StorageBound>> get(long gateId);

    @Query("DELETE FROM storageBound")
    void deleteAll();
}
