package com.epam.beacons.storage.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.epam.beacons.storage.entities.StorageBuilding;

import java.util.List;

import io.reactivex.Maybe;

@Dao
public interface BuildingDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(List<StorageBuilding> storageBuildings);

    @Query("SELECT * FROM storageBuilding")
    Maybe<List<StorageBuilding>> getAll();

    @SuppressWarnings("SameParameterValue")
    @Query("SELECT * FROM storageBuilding WHERE entityId = :id")
    Maybe<StorageBuilding> getById(String id);

    @Query("DELETE FROM storageBuilding")
    void deleteAll();
}
