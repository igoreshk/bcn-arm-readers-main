package com.epam.beacons.storage.entities;

import androidx.room.Embedded;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.jetbrains.annotations.NotNull;

import static androidx.room.ForeignKey.CASCADE;

@Entity(foreignKeys = @ForeignKey(
        entity = StorageFloor.class,
        parentColumns = {"buildingId", "number"},
        childColumns = {"buildingId", "floorNumber"},
        onDelete = CASCADE),
        indices = @Index({"buildingId", "floorNumber"}))
public class StoragePlace {

    @PrimaryKey
    @NonNull
    private final String id;

    private final String buildingId;
    private final int  floorNumber;

    @NonNull
    private final String type;
    @NonNull
    private final String description;

    @NonNull
    @Embedded
    private final StorageCoordinate coordinate;

    public StoragePlace(String id, String buildingId, int floorNumber, @NonNull String type,
                        @NonNull String description, @NonNull StorageCoordinate coordinate) {
        this.id = id;
        this.buildingId = buildingId;
        this.floorNumber = floorNumber;
        this.type = type;
        this.description = description;
        this.coordinate = coordinate;
    }

    @NotNull
    public String getId() {
        return id;
    }

    public String getBuildingId() {
        return buildingId;
    }

    public int getFloorNumber() {
        return floorNumber;
    }

    @NonNull
    public String getType() {
        return type;
    }

    @NonNull
    public String getDescription() {
        return description;
    }

    @NonNull
    public StorageCoordinate getCoordinate() {
        return coordinate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final StoragePlace that = (StoragePlace) o;

        return id.equals(that.id)
                && buildingId.equals(that.buildingId)
                && floorNumber == that.floorNumber
                && type.equals(that.type)
                && description.equals(that.description)
                && coordinate.equals(that.coordinate);
    }

    @Override
    public int hashCode() {
        int result = (int) (id.hashCode() ^ (id.hashCode() >>> 32));
        result = 31 * result + (int) (buildingId.hashCode() ^ (buildingId.hashCode() >>> 32));
        result = 31 * result + floorNumber;
        result = 31 * result + type.hashCode();
        result = 31 * result + description.hashCode();
        result = 31 * result + coordinate.hashCode();
        return result;
    }
}
