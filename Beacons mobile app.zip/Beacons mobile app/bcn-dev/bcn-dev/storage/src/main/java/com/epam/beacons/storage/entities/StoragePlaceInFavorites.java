package com.epam.beacons.storage.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class StoragePlaceInFavorites {

    private final String buildingId;
    @PrimaryKey
    @NonNull
    private final String placeId;

    public StoragePlaceInFavorites(String buildingId, String placeId) {
        this.buildingId = buildingId;
        this.placeId = placeId;
    }

    public String getBuildingId() {
        return buildingId;
    }

    public String getPlaceId() {
        return placeId;
    }
}
