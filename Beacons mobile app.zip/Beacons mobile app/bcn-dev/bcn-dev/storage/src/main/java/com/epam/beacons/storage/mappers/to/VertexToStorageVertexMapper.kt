package com.epam.beacons.storage.mappers.to

import com.epam.beacons.Vertex
import com.epam.beacons.storage.entities.StorageVertex

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VertexToStorageVertexMapper @Inject constructor(
        private val coordinateMapper: CoordinateToStorageCoordinateMapper
) : StorageMapper<Vertex, StorageVertex>() {

    override fun map(buildingId: String, floorNumber: Int, from: Vertex) =
            StorageVertex(from.id, buildingId, floorNumber, coordinateMapper.map(from.coordinate!!))
}
