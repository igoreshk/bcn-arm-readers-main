package com.epam.beacons.storage.entities;

import androidx.room.Embedded;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;

import static androidx.room.ForeignKey.CASCADE;

@Entity(foreignKeys = @ForeignKey(
        entity = StorageFloor.class,
        parentColumns = {"buildingId", "number"},
        childColumns = {"buildingId", "floorNumber"},
        onDelete = CASCADE),
        indices = @Index({"buildingId", "floorNumber"}))
public class StorageVertex {

    @PrimaryKey
    @NonNull
    private final String entityId;

    private final String buildingId;
    private final int  floorNumber;

    @NonNull
    @Embedded
    private final StorageCoordinate coordinate;

    public StorageVertex(String entityId, String buildingId, int floorNumber,
                         @NonNull StorageCoordinate coordinate) {
        this.entityId = entityId;
        this.buildingId = buildingId;
        this.floorNumber = floorNumber;
        this.coordinate = coordinate;
    }

    public String  getEntityId() {
        return entityId;
    }

    public String getBuildingId() {
        return buildingId;
    }

    public int getFloorNumber() {
        return floorNumber;
    }

    @NonNull
    public StorageCoordinate getCoordinate() {
        return coordinate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final StorageVertex that = (StorageVertex) o;

        return entityId == that.entityId && buildingId == that.buildingId
                && floorNumber == that.floorNumber
                && coordinate.equals(that.coordinate);
    }

    @Override
    public int hashCode() {
        int result = (int) (entityId.hashCode() ^ (entityId.hashCode() >>> 32));
        result = 31 * result + (int) (buildingId.hashCode() ^ (buildingId.hashCode() >>> 32));
        result = 31 * result + floorNumber;
        result = 31 * result + coordinate.hashCode();
        return result;
    }
}
