package com.epam.beacons.storage.mappers.from

import com.epam.beacons.Vertex
import com.epam.beacons.storage.entities.StorageVertex
import com.epam.beacons.tools.Mapper

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StorageVertexToVertexMapper @Inject constructor(
        private val coordinateMapper: StorageCoordinateToCoordinateMapper
) : Mapper<StorageVertex, Vertex>() {

    override fun map(from: StorageVertex) = Vertex(from.entityId, coordinateMapper.map(from.coordinate))
}
