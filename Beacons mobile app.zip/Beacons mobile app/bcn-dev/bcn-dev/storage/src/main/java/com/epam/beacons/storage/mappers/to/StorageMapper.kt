package com.epam.beacons.storage.mappers.to

abstract class StorageMapper<in From, out To> {

    abstract fun map(buildingId: String, floorNumber: Int, from: From): To

    fun map(buildingId: String, floorNumber: Int, from: List<From>) = from.map { map(buildingId, floorNumber, it) }
}
