package com.epam.beacons.storage.cache

import com.epam.beacons.Place
import com.epam.beacons.repository.cache.HistoryPlacesCache
import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Single
import java.util.ArrayList
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HistoryPlacesCacheImpl @Inject constructor(private val cacheCapacity: Int) : HistoryPlacesCache {

    private var history: MutableList<Place> = ArrayList()

    override fun get(): Maybe<List<Place>> = Maybe.fromCallable<List<Place>> { history }
            .filter { places -> places.isNotEmpty() }

    override fun put(places: MutableList<Place>): Completable = Completable.fromAction { history = places }

    override fun put(place: Place): Completable = Completable.fromAction {
        history.remove(place)
        history.add(0, place)
        val size = history.size
        if (size > cacheCapacity) {
            history.removeAt(size - 1)
        }
    }

    override fun clear(): Completable = Completable.fromAction { history.clear() }

    override fun isEmpty(): Single<Boolean> = Single.fromCallable { history.isEmpty() }

    override fun updateFavorites(favIds: Maybe<List<String>>): Completable = get()
            .flattenAsObservable { places -> places }
            .flatMapCompletable { place ->
                favIds.flattenAsObservable { ids -> ids }
                        .filter { id -> place.id == id }
                        .toList()
                        .doOnSuccess { ids -> place.isFavorite = !ids.isEmpty() }
                        .toCompletable()
            }
}
