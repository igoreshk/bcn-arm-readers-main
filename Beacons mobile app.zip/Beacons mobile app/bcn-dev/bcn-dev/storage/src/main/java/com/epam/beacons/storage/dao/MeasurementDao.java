package com.epam.beacons.storage.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.epam.beacons.storage.entities.StorageMeasurement;

import java.util.List;

import io.reactivex.Maybe;

@Dao
public interface MeasurementDao {
    @Insert
    void insert(List<StorageMeasurement> storageMeasurements);

    @Query("SELECT * FROM storageMeasurement ORDER BY timestamp ASC")
    Maybe<List<StorageMeasurement>> getAll();

    @Query("DELETE FROM storageMeasurement WHERE rssi=:rssi AND timestamp IN" +
            "(SELECT timestamp FROM storageMeasurement WHERE rssi=:rssi ORDER BY timestamp ASC LIMIT :limit)")
    void delete(int rssi, int limit);
}