package com.epam.beacons.storage.cache;

import androidx.annotation.NonNull;

import com.epam.beacons.Place;
import com.epam.beacons.repository.cache.PlacesCache;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Maybe;

@Singleton
public class PlacesCacheImpl implements PlacesCache {
    @NonNull
    private List<Place> cache = new ArrayList<>();

    @Inject
    PlacesCacheImpl() { // default constructor for dagger
    }

    @NonNull
    @Override
    public Maybe<List<Place>> get() {
        return Maybe.fromCallable(() -> cache)
                    .filter(cache -> !cache.isEmpty());
    }

    @NonNull
    @Override
    public Maybe<Place> getById(String id) {
        return get()
                .flattenAsObservable(places -> places)
                .filter(place -> place.getId().equals(id))
                .firstElement();
    }

    @NonNull
    @Override
    public Completable put(@NonNull Place place) {
        return Completable.fromAction(() -> {
            if (!cache.contains(place)) {
                cache.add(place);
            }
        });
    }

    @NonNull
    @Override
    public Completable put(@NonNull List<Place> places) {
        return Completable.fromAction(() -> cache = places);
    }

    @NonNull
    @Override
    public Completable clear() {
        return Completable.fromAction(() -> cache.clear());
    }

    @NonNull
    @Override
    public Completable updateFavorites(@NonNull Maybe<List<String>> favIds) {
        return get()
                .flattenAsObservable(places -> places)
                .flatMapCompletable(place -> favIds.flattenAsObservable(ids -> ids)
                                                   .filter(id -> place.getId() == id)
                                                   .toList()
                                                   .doOnSuccess(list -> place.setFavorite(!list.isEmpty()))
                                                   .toCompletable()
                );
    }
}
