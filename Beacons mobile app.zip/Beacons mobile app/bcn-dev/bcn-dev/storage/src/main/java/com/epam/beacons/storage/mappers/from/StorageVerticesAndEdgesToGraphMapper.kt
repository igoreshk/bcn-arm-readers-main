package com.epam.beacons.storage.mappers.from

import com.epam.beacons.Graph
import com.epam.beacons.storage.entities.StorageEdge
import com.epam.beacons.storage.entities.StorageVertex
import javax.inject.Inject

class StorageVerticesAndEdgesToGraphMapper @Inject constructor(
        private val vertexMapper: StorageVertexToVertexMapper,
        private val edgesMapper: StorageEdgesToEdgesMapper
) {

    fun map(buildingId: String,
            floorNumber: Int,
            storageVertices: List<StorageVertex>,
            storageEdges: List<StorageEdge>) =
            Graph(buildingId,
                    floorNumber,
                    vertexMapper.map(storageVertices),
                    edgesMapper.map(storageEdges, storageVertices))
}
