package com.epam.beacons.storage.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class StorageMeasurement {
    private final int    rssi;
    private final double distance;
    private final long   timestamp;
    @PrimaryKey(autoGenerate = true)
    private       long   id;

    public StorageMeasurement(int rssi, double distance, long timestamp) {
        this.rssi = rssi;
        this.distance = distance;
        this.timestamp = timestamp;
    }

    public int getRssi() {
        return rssi;
    }

    public double getDistance() {
        return distance;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final StorageMeasurement that = (StorageMeasurement) o;

        return id == that.id &&
                rssi == that.rssi &&
                Double.compare(that.distance, distance) == 0 &&
                timestamp == that.timestamp;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = (int) (id ^ (id >>> 32));
        result = 31 * result + rssi;
        temp = Double.doubleToLongBits(distance);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + (int) (timestamp ^ (timestamp >>> 32));
        return result;
    }
}