package com.epam.beacons.storage.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.epam.beacons.storage.entities.StorageGate;

import java.util.List;

import io.reactivex.Maybe;

@Dao
public interface GateDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(List<StorageGate> storageGates);

    @Query("SELECT * FROM storageGate WHERE id = :id")
    Maybe<StorageGate> getById(long id);

    @Query("SELECT * FROM storageGate WHERE buildingId = :buildingId")
    Maybe<List<StorageGate>> get(String buildingId);

    @Query("DELETE FROM storageGate")
    void deleteAll();

    @Query("DELETE FROM storageGate WHERE buildingId = :buildingId")
    void delete(String buildingId);
}
