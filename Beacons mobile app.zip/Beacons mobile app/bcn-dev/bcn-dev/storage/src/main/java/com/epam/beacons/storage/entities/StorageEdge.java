package com.epam.beacons.storage.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;

import static androidx.room.ForeignKey.CASCADE;

@Entity(primaryKeys = {"vertex1Id", "vertex2Id"},
        foreignKeys = @ForeignKey(
                entity = StorageFloor.class,
                parentColumns = {"buildingId", "number"},
                childColumns = {"buildingId", "floorNumber"},
                onDelete = CASCADE),
        indices = @Index({"buildingId", "floorNumber"}))
public class StorageEdge {

    private final String  buildingId;
    private final int   floorNumber;
    private final float weight;
    @NonNull
    private final String  vertex1Id;
    @NonNull
    private final String  vertex2Id;

    public StorageEdge(String buildingId, int floorNumber, float weight, String vertex1Id, String vertex2Id) {
        this.buildingId = buildingId;
        this.floorNumber = floorNumber;
        this.weight = weight;
        this.vertex1Id = vertex1Id;
        this.vertex2Id = vertex2Id;
    }

    public String getBuildingId() {
        return buildingId;
    }

    public int getFloorNumber() {
        return floorNumber;
    }

    public float getWeight() {
        return weight;
    }

    public String getVertex1Id() {
        return vertex1Id;
    }

    public String getVertex2Id() {
        return vertex2Id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final StorageEdge that = (StorageEdge) o;

        return buildingId == that.buildingId
                && floorNumber == that.floorNumber
                && Float.compare(that.weight, weight) == 0
                && vertex1Id == that.vertex1Id
                && vertex2Id == that.vertex2Id;
    }

    @Override
    public int hashCode() {
        int result = (int) (buildingId.hashCode() ^ (buildingId.hashCode() >>> 32));
        result = 31 * result + floorNumber;
        result = 31 * result + (Float.compare(weight, +0.0f) != 0 ? Float.floatToIntBits(weight) : 0);
        result = 31 * result + (int) (vertex1Id.hashCode() ^ (vertex1Id.hashCode() >>> 32));
        result = 31 * result + (int) (vertex2Id.hashCode() ^ (vertex2Id.hashCode() >>> 32));
        return result;
    }
}
