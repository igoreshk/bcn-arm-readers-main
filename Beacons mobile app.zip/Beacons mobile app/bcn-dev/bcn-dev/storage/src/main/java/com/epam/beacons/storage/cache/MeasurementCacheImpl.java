package com.epam.beacons.storage.cache;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;
import android.util.SparseArray;

import com.epam.beacons.Measurement;
import com.epam.beacons.repository.cache.MeasurementCache;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Maybe;

@Singleton
public class MeasurementCacheImpl implements MeasurementCache {

    @VisibleForTesting
    static final int MAX_LIST_SIZE = 100;

    @NonNull
    private SparseArray<List<Measurement>> cache = new SparseArray<>();

    @Inject
    MeasurementCacheImpl() { // empty constructor for dagger
    }

    @NonNull
    @Override
    public Maybe<List<Measurement>> get(int key) {
        return Maybe.fromCallable(() -> cache.get(key));
    }

    @NonNull
    @Override
    public Completable put(@NonNull List<Measurement> measurements) {
        return Completable.fromAction(() -> {
            for (Measurement m : measurements) {
                List<Measurement> list = cache.get(m.getRssi());
                if (list != null) {
                    list.add(m);
                } else {
                    list = new ArrayList<>();
                    list.add(m);
                    cache.put(m.getRssi(), list);
                }
            }
        });
    }

    @Override
    public boolean removeMeasurements(@NonNull List<Measurement> list, int amountToRemove) {
        if (list.size() > MAX_LIST_SIZE) {
            for (int i = 0; i < amountToRemove; i++) {
                list.remove(0);
            }
            return true;
        }
        return false;
    }

    @Override
    public int size() {
        return cache.size();
    }
}