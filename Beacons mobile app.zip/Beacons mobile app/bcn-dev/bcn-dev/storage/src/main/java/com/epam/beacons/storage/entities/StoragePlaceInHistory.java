package com.epam.beacons.storage.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class StoragePlaceInHistory {

    private final String buildingId;
    @PrimaryKey
    @NonNull
    private final String placeId;
    private final long timestamp;

    public StoragePlaceInHistory(String buildingId, String placeId, long timestamp) {
        this.buildingId = buildingId;
        this.placeId = placeId;
        this.timestamp = timestamp;
    }

    public String getBuildingId() {
        return buildingId;
    }

    public String getPlaceId() {
        return placeId;
    }

    public long getTimestamp() {
        return timestamp;
    }
}
