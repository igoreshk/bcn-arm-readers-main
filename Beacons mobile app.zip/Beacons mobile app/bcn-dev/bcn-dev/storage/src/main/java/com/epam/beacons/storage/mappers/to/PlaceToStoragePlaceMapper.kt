package com.epam.beacons.storage.mappers.to

import com.epam.beacons.Place
import com.epam.beacons.storage.entities.StoragePlace

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PlaceToStoragePlaceMapper @Inject constructor(
        private val coordinateMapper: CoordinateToStorageCoordinateMapper
) : StorageMapper<Place, StoragePlace>() {

    override fun map(buildingId: String, floorNumber: Int, from: Place) =
            StoragePlace(from.id, buildingId, floorNumber, from.type.toString(),
                    from.description, coordinateMapper.map(from.coordinate))
}
