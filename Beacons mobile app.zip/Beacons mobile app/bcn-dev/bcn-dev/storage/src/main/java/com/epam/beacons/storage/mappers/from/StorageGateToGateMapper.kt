package com.epam.beacons.storage.mappers.from

import android.annotation.SuppressLint
import com.epam.beacons.Coordinate
import com.epam.beacons.Gate
import com.epam.beacons.storage.entities.StorageBound
import com.epam.beacons.storage.entities.StorageGate
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StorageGateToGateMapper @Inject constructor(private val coordinateMapper: StorageCoordinateToCoordinateMapper) {

    @SuppressLint("UseSparseArrays")
    fun map(storageGate: StorageGate, storageBounds: List<StorageBound>): Gate {
        val bounds = HashMap<Int, Coordinate>()
        storageBounds.forEach { bounds[it.floorNumber] = coordinateMapper.map(it.coordinate) }
        return Gate(storageGate.id, storageGate.buildingId, storageGate.image, storageGate.type, bounds)
    }
}
