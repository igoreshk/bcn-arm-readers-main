package com.epam.beacons.storage.mappers.from

import com.epam.beacons.Building
import com.epam.beacons.storage.entities.StorageBuilding
import com.epam.beacons.tools.Mapper
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StorageBuildingToBuildingMapper @Inject constructor(
    private val coordinateMapper: StorageCoordinateToCoordinateMapper
) : Mapper<StorageBuilding, Building>() {

    override fun map(from: StorageBuilding) = Building(
        from.entityId, from.address, coordinateMapper.map(from.coordinate), from.width, from.height,
        from.name,
        from.phoneNumber,
        from.workingHours,
        from.createdBy,
        from.icon
    )
}
