package com.epam.beacons.storage.mappers.to

import com.epam.beacons.Floor
import com.epam.beacons.storage.entities.StorageFloor
import com.epam.beacons.tools.Mapper

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FloorToStorageFloorMapper @Inject constructor(
        private val coordinateMapper: CoordinateToStorageCoordinateMapper
) : Mapper<Floor, StorageFloor>() {

    override fun map(from: Floor) =
            StorageFloor(
                from.entityId, from.number, from.buildingId, from.image,
                from.distance, coordinateMapper.map(from.overlaySouthWestBound), coordinateMapper.map(from.overlayNorthEastBound)
            )
}
