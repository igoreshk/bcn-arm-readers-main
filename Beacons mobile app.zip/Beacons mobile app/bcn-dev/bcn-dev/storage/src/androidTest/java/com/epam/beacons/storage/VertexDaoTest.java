package com.epam.beacons.storage;

import android.database.sqlite.SQLiteConstraintException;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.epam.beacons.storage.dao.VertexDao;
import com.epam.beacons.storage.entities.StorageCoordinate;
import com.epam.beacons.storage.entities.StorageVertex;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class VertexDaoTest extends BaseDaoTest {

    private VertexDao           vertexDao;
    private List<StorageVertex> storageVertexList;
    private List<StorageVertex> vertices;
    private List<StorageVertex> newVertices;

    @Before
    @Override
    public void setUp() {
        super.setUp();
        vertexDao = appDatabase.vertexDao();
        storageVertexList = new ArrayList<>();
        storageVertexList.add(new StorageVertex(VERTEX_1_ID, BUILDING_ID, FLOOR_NUMBER, storageCoordinate));
        storageVertexList.add(new StorageVertex(VERTEX_2_ID, BUILDING_ID, NEW_FLOOR_NUMBER, storageCoordinate));
        storageVertexList.add(new StorageVertex(VERTEX_3_ID, NEW_BUILDING_ID, NEW_FLOOR_NUMBER, storageCoordinate));
        vertices = Collections.singletonList(new StorageVertex(VERTEX_1_ID, BUILDING_ID, FLOOR_NUMBER, storageCoordinate));
        newVertices = Collections.singletonList(new StorageVertex(VERTEX_1_ID, NEW_BUILDING_ID, NEW_FLOOR_NUMBER, storageCoordinate));
    }

    @Test(expected = SQLiteConstraintException.class)
    public void testSavingVertexWithoutFloorAndBuilding() {
        vertexDao.insert(storageVertexList);
    }

    @SuppressWarnings("ConstantConditions")
    @Test(expected = SQLiteConstraintException.class)
    public void testSavingVertexWithNullCoordinate() {
        StorageCoordinate nullCoordinate = null;
        StorageVertex badVertex = new StorageVertex(VERTEX_1_ID, BUILDING_ID, FLOOR_NUMBER, nullCoordinate);
        storageVertexList.add(badVertex);
        vertexDao.insert(storageVertexList);
    }

    @Test
    public void testInsertAndGet() {
        insertFloorsAndBuildings();
        vertexDao.insert(storageVertexList);
        vertexDao.get(BUILDING_ID, FLOOR_NUMBER).test().assertValue(vertices);
    }

    @Test(expected = NullPointerException.class)
    public void testInsertNull() {
        vertexDao.insert(null);
    }

    @Test
    public void testConflictStrategy() {
        insertFloorsAndBuildings();
        storageVertexList.addAll(newVertices);
        vertexDao.insert(storageVertexList);
        vertexDao.get(BUILDING_ID, FLOOR_NUMBER).test().assertValue(storageVertices -> !storageVertices.containsAll(vertices));
        vertexDao.get(NEW_BUILDING_ID, NEW_FLOOR_NUMBER).test().assertValue(storageVertices -> storageVertices.containsAll(newVertices));
    }

    @Test
    public void testDeleteAll() {
        insertFloorsAndBuildings();
        vertexDao.insert(storageVertexList);
        vertexDao.deleteAll();
        vertexDao.get(BUILDING_ID, FLOOR_NUMBER).test().assertValue(List::isEmpty);
    }

    @Test
    public void testDelete() {
        insertFloorsAndBuildings();
        vertexDao.insert(storageVertexList);
        vertexDao.delete(NEW_BUILDING_ID);
        vertexDao.get(NEW_BUILDING_ID, FLOOR_NUMBER).test().assertValue(List::isEmpty);
        vertexDao.get(BUILDING_ID, FLOOR_NUMBER).test().assertValue(storageVertices -> storageVertices.containsAll(vertices));
    }
}
