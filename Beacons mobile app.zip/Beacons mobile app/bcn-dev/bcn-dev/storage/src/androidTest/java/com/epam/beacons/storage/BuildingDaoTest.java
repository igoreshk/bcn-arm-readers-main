package com.epam.beacons.storage;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.epam.beacons.storage.entities.StorageBuilding;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class BuildingDaoTest extends BaseDaoTest {

    private StorageBuilding storageBuilding;

    @Before
    @Override
    public void setUp() {
        super.setUp();
        storageBuilding = new StorageBuilding(BUILDING_ID, BUILDING_NAME, BUILDING_ICON_URL, BUILDING_DESCRIPTION, storageCoordinate, BUILDING_ADDRESS, BUILDING_PHONE_NUMBER, BUILDING_WORKING_HOURS);
    }

    @Test
    public void testConflictStrategy() {
        buildingDao.insert(storageBuildingList);
        StorageBuilding newBuilding = new StorageBuilding(BUILDING_ID, "new", BUILDING_ICON_URL, BUILDING_DESCRIPTION, storageCoordinate, BUILDING_ADDRESS, BUILDING_PHONE_NUMBER, BUILDING_WORKING_HOURS);
        storageBuildingList.clear();
        storageBuildingList.add(newBuilding);
        buildingDao.insert(storageBuildingList);
        buildingDao.getById(BUILDING_ID).test().assertValue(newBuilding);
    }

    @Test
    public void testGetById() {
        buildingDao.insert(storageBuildingList);
        buildingDao.getById(BUILDING_ID).test().assertValue(storageBuilding);
    }

    @Test(expected = NullPointerException.class)
    public void testInsertNull() {
        buildingDao.insert(null);
    }

    @Test
    public void testGetAll() {
        buildingDao.insert(storageBuildingList);
        buildingDao.getAll().test().assertValue(storageBuildings -> storageBuildings.containsAll(storageBuildingList)
                && storageBuildings.size() == storageBuildingList.size());
    }

    @Test
    public void testDelete() {
        buildingDao.insert(storageBuildingList);
        buildingDao.deleteAll();
        buildingDao.getAll().test().assertValue(List::isEmpty);
    }
}
