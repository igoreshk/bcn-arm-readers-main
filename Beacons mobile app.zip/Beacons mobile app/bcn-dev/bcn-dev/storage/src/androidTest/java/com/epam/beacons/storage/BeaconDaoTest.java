package com.epam.beacons.storage;

import android.database.sqlite.SQLiteConstraintException;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.epam.beacons.storage.dao.BeaconDao;
import com.epam.beacons.storage.entities.StorageBeacon;
import com.epam.beacons.storage.entities.StorageCoordinate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class BeaconDaoTest extends BaseDaoTest {

    private static final int    MAJOR  = 1;
    private static final int    MINOR  = 2;
    private static final String UUID   = "uuid";
    private static final int    MAJOR1 = 3;
    private static final int    MINOR1 = 4;
    private static final String UUID1  = "uuid1";
    private static final int    MAJOR2 = 5;
    private static final int    MINOR2 = 6;
    private static final String UUID2  = "uuid2";
    private BeaconDao           beaconDao;
    private List<StorageBeacon> storageBeaconList;
    private List<StorageBeacon> beacons;

    @Before
    @Override
    public void setUp() {
        super.setUp();
        beaconDao = appDatabase.beaconDao();
        final StorageBeacon beacon = new StorageBeacon(BUILDING_ID, FLOOR_NUMBER, UUID, MAJOR, MINOR, storageCoordinate);
        storageBeaconList = new ArrayList<>();
        storageBeaconList.add(beacon);
        storageBeaconList.add(new StorageBeacon(NEW_BUILDING_ID, NEW_FLOOR_NUMBER, UUID1, MAJOR1, MINOR1, storageCoordinate));
        storageBeaconList.add(new StorageBeacon(NEW_BUILDING_ID, NEW_FLOOR_NUMBER, UUID2, MAJOR2, MINOR2, storageCoordinate));
        beacons = Collections.singletonList(beacon);
    }

    @Test(expected = SQLiteConstraintException.class)
    public void testSavingBeaconsWithoutBuildingsAndFloors() {
        beaconDao.insert(storageBeaconList);
    }

    @SuppressWarnings("ConstantConditions")
    @Test(expected = SQLiteConstraintException.class)
    public void testSavingBeaconsWithNullUuid() {
        String nullUuid = null;
        insertFloorsAndBuildings();
        StorageBeacon badBcn = new StorageBeacon(BUILDING_ID, FLOOR_NUMBER, nullUuid, MAJOR, MINOR, storageCoordinate);
        storageBeaconList.add(badBcn);
        beaconDao.insert(storageBeaconList);
    }

    @SuppressWarnings("ConstantConditions")
    @Test(expected = SQLiteConstraintException.class)
    public void testSavingBeaconsWithNullCoordinate() {
        StorageCoordinate nullCoordinate = null;
        insertFloorsAndBuildings();
        StorageBeacon badBcn = new StorageBeacon(BUILDING_ID, FLOOR_NUMBER, UUID, MAJOR, MINOR, nullCoordinate);
        storageBeaconList.add(badBcn);
        beaconDao.insert(storageBeaconList);
    }

    @Test
    public void testInsertAndGetByFloorNumber() {
        insertFloorsAndBuildings();
        beaconDao.insert(storageBeaconList);
        beaconDao.get(BUILDING_ID, FLOOR_NUMBER).test().assertValue(beacons);
    }

    @Test
    public void testInsertAndGetByFloorNumbers() {
        insertFloorsAndBuildings();
        beaconDao.insert(storageBeaconList);
        beaconDao.get(BUILDING_ID, Collections.singletonList(FLOOR_NUMBER)).test().assertValue(beacons);
    }

    @Test
    public void testInsertAndGetByBuildingId() {
        insertFloorsAndBuildings();
        beaconDao.insert(storageBeaconList);
        beaconDao.get(BUILDING_ID).test().assertValue(beacons);
    }

    @Test
    public void testConflictStrategy() {
        insertFloorsAndBuildings();
        beaconDao.insert(storageBeaconList);
        StorageBeacon newBeacon = new StorageBeacon(NEW_BUILDING_ID, NEW_FLOOR_NUMBER, UUID, MAJOR, MINOR, storageCoordinate);
        storageBeaconList.clear();
        storageBeaconList.add(newBeacon);
        beaconDao.insert(storageBeaconList);
        beaconDao.get(BUILDING_ID, FLOOR_NUMBER).test().assertValue(List::isEmpty);
    }

    @Test(expected = NullPointerException.class)
    public void testInsertNull() {
        beaconDao.insert(null);
    }

    @Test
    public void testDeleteAll() {
        insertFloorsAndBuildings();
        beaconDao.insert(storageBeaconList);
        beaconDao.deleteAll();
        beaconDao.get(BUILDING_ID, FLOOR_NUMBER).test().assertValue(List::isEmpty);
    }

    @Test
    public void testDelete() {
        insertFloorsAndBuildings();
        beaconDao.insert(storageBeaconList);
        beaconDao.delete(NEW_BUILDING_ID);
        beaconDao.get(NEW_BUILDING_ID, FLOOR_NUMBER).test().assertValue(List::isEmpty);
        beaconDao.get(BUILDING_ID, FLOOR_NUMBER).test().assertValue(storageBeacons -> storageBeacons.containsAll(beacons));
    }
}
