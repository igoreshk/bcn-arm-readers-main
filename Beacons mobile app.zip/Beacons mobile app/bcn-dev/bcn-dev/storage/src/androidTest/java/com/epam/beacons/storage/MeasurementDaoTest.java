package com.epam.beacons.storage;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.epam.beacons.storage.dao.MeasurementDao;
import com.epam.beacons.storage.entities.StorageMeasurement;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Arrays;
import java.util.List;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class MeasurementDaoTest extends BaseDaoTest {
    private static final int    RSSI     = -80;
    private static final double DISTANCE = 10.0;

    private MeasurementDao           measurementDao;
    private List<StorageMeasurement> measurements;
    private List<StorageMeasurement> measurementsSorted;

    @Before
    @Override
    public void setUp() {
        super.setUp();
        measurementDao = appDatabase.measurementDao();

        measurements = Arrays.asList(
                new StorageMeasurement(RSSI, DISTANCE, 2),
                new StorageMeasurement(RSSI, DISTANCE, 1)

        );

        measurementsSorted = Arrays.asList(measurements.get(1), measurements.get(0));
        measurementsSorted.get(0).setId(1);
        measurementsSorted.get(1).setId(2);
    }

    @Test(expected = NullPointerException.class)
    public void testInsertNull() {
        measurementDao.insert(null);
    }

    @Test
    public void testInsertAndGetAll() {
        measurementDao.insert(measurements);

        measurementDao.getAll().test().assertValue(measurementsSorted);
    }

    @Test
    public void testDelete() {
        measurementDao.insert(measurements);

        measurementDao.delete(RSSI, 2);
        measurementDao.getAll().test().assertValue(List::isEmpty);
    }
}
