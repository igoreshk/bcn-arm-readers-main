package com.epam.beacons.storage;

import android.database.sqlite.SQLiteConstraintException;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.epam.beacons.storage.dao.EdgeDao;
import com.epam.beacons.storage.entities.StorageEdge;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class EdgeDaoTest extends BaseDaoTest {

    private static final int WEIGHT = 5;
    private EdgeDao           edgeDao;
    private List<StorageEdge> storageEdgeList;
    private List<StorageEdge> edges;

    @Before
    @Override
    public void setUp() {
        super.setUp();
        edgeDao = appDatabase.edgeDao();
        storageEdgeList = new ArrayList<>();

        storageEdgeList.add(new StorageEdge(BUILDING_ID, FLOOR_NUMBER, WEIGHT, VERTEX_1_ID, VERTEX_2_ID));
        storageEdgeList.add(new StorageEdge(NEW_BUILDING_ID, NEW_FLOOR_NUMBER, WEIGHT, VERTEX_2_ID, VERTEX_1_ID));
        edges = Collections.singletonList(new StorageEdge(BUILDING_ID, FLOOR_NUMBER, WEIGHT, VERTEX_1_ID, VERTEX_2_ID));
    }

    @Test(expected = SQLiteConstraintException.class)
    public void testSavingEdgesWithoutBuildingAndFloor() {
        edgeDao.insert(storageEdgeList);
    }

    @Test
    public void testInsertAndGet() {
        insertFloorsAndBuildings();
        edgeDao.insert(storageEdgeList);
        edgeDao.get(BUILDING_ID, FLOOR_NUMBER).test().assertValue(edges);
    }

    @Test(expected = NullPointerException.class)
    public void testInsertNull() {
        edgeDao.insert(null);
    }

    @Test
    public void testConflictStrategy() {
        insertFloorsAndBuildings();
        edgeDao.insert(storageEdgeList);
        StorageEdge newEdge = new StorageEdge(NEW_BUILDING_ID, NEW_FLOOR_NUMBER, WEIGHT, VERTEX_1_ID, VERTEX_2_ID);
        storageEdgeList.clear();
        storageEdgeList.add(newEdge);
        edgeDao.insert(storageEdgeList);
        edgeDao.get(BUILDING_ID, FLOOR_NUMBER).test().assertValue(List::isEmpty);
        edgeDao.get(NEW_BUILDING_ID, NEW_FLOOR_NUMBER).test().assertValue(storageEdges -> storageEdges.containsAll(storageEdgeList));
    }

    @Test
    public void testDeleteAll() {
        insertFloorsAndBuildings();
        edgeDao.insert(storageEdgeList);

        edgeDao.deleteAll();
        edgeDao.get(BUILDING_ID, FLOOR_NUMBER).test().assertValue(List::isEmpty);
    }

    @Test
    public void testDelete() {
        insertFloorsAndBuildings();
        edgeDao.insert(storageEdgeList);
        edgeDao.delete(NEW_BUILDING_ID);
        edgeDao.get(NEW_BUILDING_ID, FLOOR_NUMBER).test().assertValue(List::isEmpty);
        edgeDao.get(BUILDING_ID, FLOOR_NUMBER).test().assertValue(storageEdges -> storageEdges.containsAll(edges));
    }
}
