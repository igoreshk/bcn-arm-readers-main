package com.epam.beacons.storage;

import android.database.sqlite.SQLiteConstraintException;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.epam.beacons.storage.dao.PlaceDao;
import com.epam.beacons.storage.dao.PlaceInFavoritesDao;
import com.epam.beacons.storage.dao.PlaceInHistoryDao;
import com.epam.beacons.storage.entities.StorageCoordinate;
import com.epam.beacons.storage.entities.StoragePlace;
import com.epam.beacons.storage.entities.StoragePlaceInFavorites;
import com.epam.beacons.storage.entities.StoragePlaceInHistory;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class PlaceDaoTest extends BaseDaoTest {

    private static final String TYPE                    = "type";
    private static final String DESCRIPTION             = "desc";
    private static final long   HISTORY_PLACE_ID        = 1L;
    private static final long   HISTORY_PLACE_ID_2      = 4L;
    private static final long   FAVORITE_PLACE_ID       = 2L;
    private static final long   USUAL_PLACE_ID          = 3L;
    private static final long   ID_FOR_HISTORY_BUILDING = 42L;
    private static final int    HISTORY_SIZE            = 5;

    private PlaceDao            placeDao;
    private PlaceInHistoryDao   placeInHistoryDao;
    private PlaceInFavoritesDao placeInFavoritesDao;
    private List<StoragePlace>  storagePlaceList;
    private List<StoragePlace>  places;
    private List<StoragePlace>  hist;
    private StoragePlace        favoritePlace;

    @Before
    @Override
    public void setUp() {
        super.setUp();
        placeDao = appDatabase.placeDao();
        placeInHistoryDao = appDatabase.placeInHistoryDao();
        placeInFavoritesDao = appDatabase.placeInFavoritesDao();
        storagePlaceList = new ArrayList<>();
        final StoragePlace historyPlace = new StoragePlace(HISTORY_PLACE_ID, BUILDING_ID, FLOOR_NUMBER, TYPE, DESCRIPTION, storageCoordinate);
        favoritePlace = new StoragePlace(FAVORITE_PLACE_ID, NEW_BUILDING_ID, NEW_FLOOR_NUMBER, TYPE, DESCRIPTION, storageCoordinate);
        final StoragePlace usualPlace = new StoragePlace(USUAL_PLACE_ID, NEW_BUILDING_ID, FLOOR_NUMBER, TYPE, DESCRIPTION, storageCoordinate);
        final StoragePlaceInHistory storagePlaceInHistory = new StoragePlaceInHistory(BUILDING_ID, HISTORY_PLACE_ID, 1);
        final StoragePlaceInFavorites storagePlaceInFavorites = new StoragePlaceInFavorites("NEW_BUILDING_ID", FAVORITE_PLACE_ID);
        hist = Collections.singletonList(historyPlace);
        storagePlaceList.add(historyPlace);
        storagePlaceList.add(favoritePlace);
        storagePlaceList.add(usualPlace);
        placeInHistoryDao.insert(storagePlaceInHistory);
        placeInFavoritesDao.insert(storagePlaceInFavorites);
        places = Collections.singletonList(historyPlace);
    }

    @Test(expected = SQLiteConstraintException.class)
    public void testSavingPlaceWithoutFloorAndBuilding() {
        placeDao.insert(storagePlaceList);
    }

    @SuppressWarnings("ConstantConditions")
    @Test(expected = SQLiteConstraintException.class)
    public void testSavingPlaceWithNullCoordinate() {
        StorageCoordinate badCoord = null;
        StoragePlace badSP = new StoragePlace(USUAL_PLACE_ID, BUILDING_ID, FLOOR_NUMBER, TYPE, DESCRIPTION, badCoord);
        storagePlaceList.add(badSP);
        placeDao.insert(storagePlaceList);
    }

    @Test
    public void testInsertAndGetByBuildingId() {
        insertFloorsAndBuildings();
        placeDao.insert(storagePlaceList);
        placeDao.get(BUILDING_ID)
                .test()
                .assertValue(places);
    }

    @Test
    public void testInsertAndGetPlace() {
        insertFloorsAndBuildings();
        placeDao.insert(storagePlaceList);
        placeDao.getById(2L)
                .test()
                .assertValue(favoritePlace);
    }

    @Test
    public void testInsertAndGetByBuildingIdAndFloor() {
        insertFloorsAndBuildings();
        placeDao.insert(storagePlaceList);
        placeDao.get(BUILDING_ID, FLOOR_NUMBER)
                .test()
                .assertValue(places);
    }

    @Test
    public void testDeleteAll() {
        insertFloorsAndBuildings();
        placeDao.insert(storagePlaceList);
        placeDao.deleteAll();
        placeDao.get(BUILDING_ID, FLOOR_NUMBER)
                .test()
                .assertValue(List::isEmpty);
    }

    @Test
    public void testConflictStrategy() {
        insertFloorsAndBuildings();
        placeDao.insert(storagePlaceList);
        StoragePlace newPlace = new StoragePlace(USUAL_PLACE_ID, BUILDING_ID, FLOOR_NUMBER, TYPE, "new", storageCoordinate);
        storagePlaceList.clear();
        storagePlaceList.add(newPlace);
        placeDao.insert(storagePlaceList);
        placeDao.getById(USUAL_PLACE_ID)
                .test()
                .assertValue(newPlace);
    }

    @Test(expected = NullPointerException.class)
    public void testInsertNull() {
        placeDao.insert(null);
    }

    @Test
    public void testFavoritePlaces() {
        insertFloorsAndBuildings();
        List<StoragePlace> favs = Collections.singletonList(favoritePlace);
        placeDao.insert(storagePlaceList);
        placeDao.getFavoritePlaces(NEW_BUILDING_ID)
                .test()
                .assertValue(favs);
    }

    @Test
    public void testHistoryPlaces() {
        insertFloorsAndBuildings();
        placeDao.insert(storagePlaceList);
        placeDao.getHistoryPlaces(BUILDING_ID)
                .test()
                .assertValue(hist);
    }

    @Test
    public void testHistoryCount() {
        insertFloorsAndBuildings();
        placeInHistoryDao.count(BUILDING_ID)
                         .test()
                         .assertValue(1);
    }

    @Test
    public void testHistoryCountUnchanged() {
        insertFloorsAndBuildings();
        placeInHistoryDao.insert(new StoragePlaceInHistory(ID_FOR_HISTORY_BUILDING, HISTORY_PLACE_ID_2, 2));
        placeInHistoryDao.count(BUILDING_ID)
                         .test()
                         .assertValue(1);
    }

    @Test
    public void testCountForEmptyHistory() {
        insertFloorsAndBuildings();
        placeInHistoryDao.count(ID_FOR_HISTORY_BUILDING)
                         .test()
                         .assertValue(0);
    }

    @Test
    public void testDeleteOldestInHistory() {
        insertFloorsAndBuildings();
        for (int i = 0; i <= HISTORY_SIZE; i++) {
            placeInHistoryDao.insert(new StoragePlaceInHistory(ID_FOR_HISTORY_BUILDING, i, i));
        }
        placeInHistoryDao.deleteOldest(ID_FOR_HISTORY_BUILDING);
        placeInHistoryDao.get(ID_FOR_HISTORY_BUILDING)
                         .test()
                         .assertValue(ids -> ids.size() == HISTORY_SIZE && !ids.contains(0L));
    }

    @Test
    public void testDeleteAllHistory() {
        insertFloorsAndBuildings();
        placeDao.insert(storagePlaceList);
        placeInHistoryDao.deleteAll();
        placeDao.getHistoryPlaces(BUILDING_ID)
                .test()
                .assertValue(List::isEmpty);
    }

    @Test
    public void testDeleteAllFavorites() {
        insertFloorsAndBuildings();
        placeDao.insert(storagePlaceList);
        placeInFavoritesDao.deleteAll();
        placeDao.getFavoritePlaces(NEW_BUILDING_ID)
                .test()
                .assertValue(List::isEmpty);
    }

    @Test
    public void testDelete() {
        insertFloorsAndBuildings();
        placeDao.insert(storagePlaceList);
        placeDao.delete(NEW_BUILDING_ID);
        placeDao.get(NEW_BUILDING_ID, FLOOR_NUMBER)
                .test()
                .assertValue(List::isEmpty);
        placeDao.get(BUILDING_ID, FLOOR_NUMBER)
                .test()
                .assertValue(storagePlaces -> storagePlaces.containsAll(places));
    }

    @Test
    public void testDeleteSingleFavorite() {
        insertFloorsAndBuildings();
        placeDao.insert(storagePlaceList);
        placeInFavoritesDao.delete(NEW_BUILDING_ID, FAVORITE_PLACE_ID);
        placeDao.getFavoritePlaces(NEW_BUILDING_ID)
                .test()
                .assertValue(storagePlaces -> !storagePlaces.contains(favoritePlace));
    }

    @Test
    public void testDeleteSingleHistory() {
        insertFloorsAndBuildings();
        placeDao.insert(storagePlaceList);
        placeInHistoryDao.delete(BUILDING_ID, HISTORY_PLACE_ID);
        placeDao.getHistoryPlaces(BUILDING_ID)
                .test()
                .assertValue(storagePlaces -> !storagePlaces.contains(hist.get(0)));
    }
}
