package com.epam.beacons.storage;

import android.database.sqlite.SQLiteConstraintException;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.epam.beacons.storage.entities.StorageCoordinate;
import com.epam.beacons.storage.entities.StorageFloor;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Arrays;
import java.util.List;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class FloorDaoTest extends BaseDaoTest {

    private StorageFloor       storageFloor;
    private List<StorageFloor> floors;

    @Before
    @Override
    public void setUp() {
        super.setUp();
        storageFloor = new StorageFloor(BUILDING_ID, FLOOR_NUMBER, FLOOR_IMAGE_URL, FLOOR_WIDTH, FLOOR_HEIGHT, storageCoordinate, storageCoordinate);
        floors = Arrays.asList(
                new StorageFloor(BUILDING_ID, FLOOR_NUMBER, FLOOR_IMAGE_URL, FLOOR_WIDTH, FLOOR_HEIGHT, storageCoordinate, storageCoordinate),
                new StorageFloor(BUILDING_ID, NEW_FLOOR_NUMBER, FLOOR_IMAGE_URL, FLOOR_WIDTH, FLOOR_HEIGHT, storageCoordinate, storageCoordinate)
        );
    }

    @Test(expected = SQLiteConstraintException.class)
    public void testSavingFloorsWithoutFloorAndBuilding() {
        for (StorageFloor storageFloor : storageFloorList) {
            floorDao.insert(storageFloor);
        }
    }

    @SuppressWarnings("ConstantConditions")
    @Test(expected = SQLiteConstraintException.class)
    public void testSavingFloorWithNullImgURL() {
        String badImg = null;
        buildingDao.insert(storageBuildingList);
        StorageFloor badStorageFloor = new StorageFloor(BUILDING_ID, FLOOR_NUMBER, badImg, FLOOR_WIDTH, FLOOR_HEIGHT, storageCoordinate, storageCoordinate);
        storageFloorList.add(badStorageFloor);
        for (StorageFloor storageFloor : storageFloorList) {
            floorDao.insert(storageFloor);
        }
    }

    @SuppressWarnings("ConstantConditions")
    @Test(expected = SQLiteConstraintException.class)
    public void testSavingFloorWithNullCoordinates() {
        StorageCoordinate nullCoordinate = null;
        buildingDao.insert(storageBuildingList);
        StorageFloor badStorageFloor = new StorageFloor(BUILDING_ID, FLOOR_NUMBER, FLOOR_IMAGE_URL, FLOOR_WIDTH, FLOOR_HEIGHT, nullCoordinate, nullCoordinate);
        storageFloorList.add(badStorageFloor);
        for (StorageFloor storageFloor : storageFloorList) {
            floorDao.insert(storageFloor);
        }
    }

    @Test(expected = NullPointerException.class)
    public void testInsertNull() {
        floorDao.insert(null);
    }

    @Test
    public void testInsertAndGet() {
        insertFloorsAndBuildings();
        floorDao.get(BUILDING_ID, FLOOR_NUMBER).test().assertValue(storageFloor);
        floorDao.get(BUILDING_ID).test().assertValue(storageFloors -> floors.containsAll(storageFloors) && storageFloors.size() == floors.size());
    }

    @Test
    public void testConflictStrategy() {
        insertFloorsAndBuildings();
        StorageFloor newFloor = new StorageFloor(BUILDING_ID, FLOOR_NUMBER, "new", FLOOR_WIDTH, FLOOR_HEIGHT, storageCoordinate, storageCoordinate);
        storageFloorList.clear();
        storageFloorList.add(newFloor);
        for (StorageFloor storageFloor : storageFloorList) {
            floorDao.insert(storageFloor);
        }
        floorDao.get(BUILDING_ID, FLOOR_NUMBER).test().assertValue(newFloor);
    }


    @Test
    public void testDeleteAll() {
        insertFloorsAndBuildings();

        floorDao.deleteAll();
        floorDao.get(BUILDING_ID).test().assertValue(List::isEmpty);
    }

    @Test
    public void testDelete() {
        insertFloorsAndBuildings();

        floorDao.delete(NEW_BUILDING_ID);
        floorDao.get(NEW_BUILDING_ID).test().assertValue(List::isEmpty);
        floorDao.get(BUILDING_ID).test().assertValue(storageFloors -> storageFloors.containsAll(floors));
    }
}
