package com.epam.beacons.storage

import android.database.sqlite.SQLiteConstraintException
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.epam.beacons.storage.dao.BoundDao
import com.epam.beacons.storage.dao.GateDao
import com.epam.beacons.storage.entities.StorageBound
import com.epam.beacons.storage.entities.StorageCoordinate
import com.epam.beacons.storage.entities.StorageGate
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4::class)
class GateAndBoundDaoTest : BaseDaoTest() {
    private lateinit var gateDao: GateDao
    private lateinit var boundDao: BoundDao
    private lateinit var gates: MutableList<StorageGate>
    private lateinit var oldBuildingGates: List<StorageGate>
    private lateinit var newBuildingGates: List<StorageGate>
    private lateinit var bounds: MutableList<StorageBound>
    private lateinit var firstGateBounds: List<StorageBound>
    private lateinit var secondGateBounds: List<StorageBound>
    private val firstCoordinate: StorageCoordinate = StorageCoordinate(1.0, 1.0)
    private val secondCoordinate: StorageCoordinate = StorageCoordinate(2.0, 2.0)

    @Before
    override fun setUp() {
        super.setUp()

        gateDao = appDatabase.gateDao()
        boundDao = appDatabase.boundDao()

        gates = mutableListOf(StorageGate(ID_1, BUILDING_ID, IMAGE_1, TYPE_ELEVATOR),
                StorageGate(ID_2, BUILDING_ID, IMAGE_2, TYPE_STAIRS),
                StorageGate(ID_3, NEW_BUILDING_ID, IMAGE_1, TYPE_ELEVATOR),
                StorageGate(ID_4, NEW_BUILDING_ID, IMAGE_2, TYPE_STAIRS))

        oldBuildingGates = listOf(gates[0], gates[1])
        newBuildingGates = listOf(gates[2], gates[3])

        bounds = mutableListOf(StorageBound(ID_1, FLOOR_NUMBER_1, firstCoordinate),
                StorageBound(ID_1, FLOOR_NUMBER_2, secondCoordinate),
                StorageBound(ID_2, FLOOR_NUMBER_1, firstCoordinate),
                StorageBound(ID_2, FLOOR_NUMBER_2, secondCoordinate),
                StorageBound(ID_3, FLOOR_NUMBER_1, firstCoordinate))

        firstGateBounds = listOf(bounds[0], bounds[1])
        secondGateBounds = listOf(bounds[2], bounds[3])
    }

    @Test
    fun testInsertAndGetGatesByBuildingId() {
        prepareGates()

        gateDao.get(NEW_BUILDING_ID).test().assertValue(newBuildingGates)
    }

    @Test
    fun testInsertAndGetGateById() {
        prepareGates()

        gateDao.getById(ID_4).test().assertValue(gates[3])
    }

    @Test
    fun testGatesConflictStrategy() {
        insertFloorsAndBuildings()

        gateDao.insert(oldBuildingGates)

        gateDao.insert(listOf(StorageGate(ID_1, BUILDING_ID, IMAGE_1, TYPE_UNKNOWN)))

        gateDao.getById(ID_1).test().assertValue({ it.type == TYPE_UNKNOWN })
        gateDao.get(BUILDING_ID).test().assertValue({ it.size == 2 })
    }

    @Test(expected = SQLiteConstraintException::class)
    fun testInsertGatesWithoutBuilding() {
        gateDao.insert(gates)
    }

    @Test(expected = SQLiteConstraintException::class)
    fun testInsertGateWithNullImage() {
        gateDao.insert(listOf(StorageGate(ID_2, BUILDING_ID, null, TYPE_STAIRS)))
    }

    @Test(expected = NullPointerException::class)
    fun testInsertNullGates() {
        gateDao.insert(null)
    }

    @Test
    fun testDeleteAllGates() {
        prepareGates()

        gateDao.deleteAll()

        gateDao.get(BUILDING_ID).test().assertValue(emptyList())
        gateDao.get(NEW_BUILDING_ID).test().assertValue(emptyList())
    }

    @Test
    fun testDeleteGatesByBuildingId() {
        prepareGates()

        gateDao.delete(BUILDING_ID)

        gateDao.get(BUILDING_ID).test().assertValue(emptyList())
        gateDao.get(NEW_BUILDING_ID).test().assertValue(newBuildingGates)
    }

    @Test
    fun testInsertAndGetBoundsByGateId() {
        prepareBounds()

        boundDao.get(ID_1).test().assertValue(firstGateBounds)
    }

    @Test(expected = SQLiteConstraintException::class)
    fun testInsertBoundWithNonexistentGateId() {
        prepareGates()

        boundDao.insert(listOf(StorageBound(FAKE_GATE_ID, FLOOR_NUMBER_1, firstCoordinate)))
    }

    @Test(expected = SQLiteConstraintException::class)
    fun testInsertBoundWithoutGates() {
        boundDao.insert(bounds)
    }

    @Test(expected = NullPointerException::class)
    fun testInsertNullBounds() {
        boundDao.insert(null)
    }

    @Test
    fun testBoundsConflictStrategy() {
        prepareBounds()

        boundDao.insert(listOf(StorageBound(ID_3, FLOOR_NUMBER_1, secondCoordinate)))

        boundDao.get(ID_3).test().assertValue({ it.size == 1 && it[0].coordinate == secondCoordinate })
    }

    @Test
    fun testDeleteAllBounds() {
        prepareBounds()

        boundDao.deleteAll()

        boundDao.get(ID_1).test().assertValue(emptyList())
        boundDao.get(ID_2).test().assertValue(emptyList())
    }

    private fun prepareGates() {
        insertFloorsAndBuildings()

        gateDao.insert(gates)
    }

    private fun prepareBounds() {
        prepareGates()

        boundDao.insert(bounds)
    }

    companion object {
        const val ID_1 = 1L
        const val ID_2 = 2L
        const val ID_3 = 3L
        const val ID_4 = 4L
        const val TYPE_ELEVATOR = "elevator"
        const val TYPE_STAIRS = "stairs"
        const val TYPE_UNKNOWN = "unknown"
        const val IMAGE_1 = "image1"
        const val IMAGE_2 = "image2"

        const val FAKE_GATE_ID = Long.MIN_VALUE
        const val FLOOR_NUMBER_1 = 1
        const val FLOOR_NUMBER_2 = 2
    }
}
