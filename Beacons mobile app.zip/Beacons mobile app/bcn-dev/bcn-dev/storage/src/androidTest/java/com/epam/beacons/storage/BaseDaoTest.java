package com.epam.beacons.storage;

import androidx.room.Room;
import android.content.Context;
import androidx.test.platform.app.InstrumentationRegistry;

import com.epam.beacons.storage.dao.BuildingDao;
import com.epam.beacons.storage.dao.FloorDao;
import com.epam.beacons.storage.entities.StorageBuilding;
import com.epam.beacons.storage.entities.StorageCoordinate;
import com.epam.beacons.storage.entities.StorageFloor;

import org.junit.After;
import org.junit.Before;

import java.util.ArrayList;
import java.util.List;

public abstract class BaseDaoTest {

    static final         long   BUILDING_ID            = 22L;
    static final         long   NEW_BUILDING_ID        = 1L;
    static final         int    FLOOR_NUMBER           = 15;
    static final         int    NEW_FLOOR_NUMBER       = 1;
    static final         String BUILDING_NAME          = "name";
    static final         String BUILDING_ICON_URL      = "icon_url";
    static final         String BUILDING_DESCRIPTION   = "desc";
    static final         String BUILDING_ADDRESS       = "address";
    static final         String BUILDING_PHONE_NUMBER  = "number";
    static final         String BUILDING_WORKING_HOURS = "hours";
    static final         String FLOOR_IMAGE_URL        = "img_url";
    static final         int    FLOOR_WIDTH            = 3;
    static final         int    FLOOR_HEIGHT           = 9;
    static final         long   VERTEX_1_ID            = 1L;
    static final         long   VERTEX_2_ID            = 2L;
    static final         long   VERTEX_3_ID            = 3L;
    private static final int    LATITUDE               = 12;
    private static final int    LONGITUDE              = 12;

    BuildingDao buildingDao;
    FloorDao    floorDao;
    AppDatabase appDatabase;

    StorageCoordinate     storageCoordinate;
    List<StorageFloor>    storageFloorList;
    List<StorageBuilding> storageBuildingList;

    @Before
    public void setUp() {
        storageCoordinate = new StorageCoordinate(LATITUDE, LONGITUDE);

        storageFloorList = new ArrayList<>();
        storageFloorList.add(new StorageFloor(BUILDING_ID, FLOOR_NUMBER, FLOOR_IMAGE_URL, FLOOR_WIDTH, FLOOR_HEIGHT, storageCoordinate, storageCoordinate));
        storageFloorList.add(new StorageFloor(NEW_BUILDING_ID, FLOOR_NUMBER, FLOOR_IMAGE_URL, FLOOR_WIDTH, FLOOR_HEIGHT, storageCoordinate, storageCoordinate));
        storageFloorList.add(new StorageFloor(BUILDING_ID, NEW_FLOOR_NUMBER, FLOOR_IMAGE_URL, FLOOR_WIDTH, FLOOR_HEIGHT, storageCoordinate, storageCoordinate));
        storageFloorList.add(new StorageFloor(NEW_BUILDING_ID, NEW_FLOOR_NUMBER, FLOOR_IMAGE_URL, FLOOR_WIDTH, FLOOR_HEIGHT, storageCoordinate, storageCoordinate));

        storageBuildingList = new ArrayList<>();
        storageBuildingList.add(new StorageBuilding(BUILDING_ID, BUILDING_NAME, BUILDING_ICON_URL, BUILDING_DESCRIPTION, storageCoordinate, BUILDING_ADDRESS, BUILDING_PHONE_NUMBER, BUILDING_WORKING_HOURS));
        storageBuildingList.add(new StorageBuilding(NEW_BUILDING_ID, BUILDING_NAME, BUILDING_ICON_URL, BUILDING_DESCRIPTION, storageCoordinate, BUILDING_ADDRESS, BUILDING_PHONE_NUMBER, BUILDING_WORKING_HOURS));

        Context appContext = InstrumentationRegistry.getTargetContext();
        appDatabase = Room.inMemoryDatabaseBuilder(appContext.getApplicationContext(), AppDatabase.class).build();
        buildingDao = appDatabase.buildingDao();
        floorDao = appDatabase.floorDao();
    }

    void insertFloorsAndBuildings() {
        buildingDao.insert(storageBuildingList);
        for (StorageFloor storageFloor : storageFloorList) {
            floorDao.insert(storageFloor);
        }
    }

    @After
    public void closeDB() {
        appDatabase.close();
    }
}
