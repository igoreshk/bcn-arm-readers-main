package com.epam.beacons.storage.mappers.from;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Place;
import com.epam.beacons.storage.entities.StorageCoordinate;
import com.epam.beacons.storage.entities.StoragePlace;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class StoragePlaceToPlaceMapperTest {

    @Mock
    private StorageCoordinateToCoordinateMapper coordinateMapper;
    @InjectMocks
    private StoragePlaceToPlaceMapper           placeMapper;

    private final StoragePlace storagePlace;
    private final Place        expectedPlace;

    public StoragePlaceToPlaceMapperTest(StoragePlace storagePlace, Place expectedPlace) {
        this.storagePlace = storagePlace;
        this.expectedPlace = expectedPlace;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        new StoragePlace("0", "1", 2,
                                         "type", "description",
                                         new StorageCoordinate(1, 2)
                        ),
                        new Place("0", "type", "description",
                                  new Coordinate(1, 2), 2
                        )
                },
                {
                        new StoragePlace("5", "3", 1,
                                         "anotherType", "anotherDescription",
                                         new StorageCoordinate(3, 4)
                        ),
                        new Place("5", "anotherType", "anotherDescription",
                                  new Coordinate(3, 4), 1
                        )
                },
                {
                        new StoragePlace("50", "10", 11,
                                         "anotherType2", "anotherDescription2",
                                         new StorageCoordinate(5, 6)
                        ),
                        new Place("50", "anotherType2", "anotherDescription2",
                                  new Coordinate(5, 6), 11
                        )
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(coordinateMapper.map(storagePlace.getCoordinate()))
                .thenAnswer(invocation -> {
                    final StorageCoordinate storageCoordinate = invocation.getArgument(0);
                    return new Coordinate(storageCoordinate.getLatitude(), storageCoordinate.getLongitude());
                });
    }

    @Test
    public void testMap() {
        assertEqualsForAllFields(expectedPlace, placeMapper.map(storagePlace));
    }

    @Test
    public void testMapOnList() {
        final List<Place> places = placeMapper.map(Collections.singletonList(storagePlace));
        assertEquals(1, places.size());
        assertEqualsForAllFields(expectedPlace, places.get(0));
    }

    private void assertEqualsForAllFields(Place expectedPlace, Place place) {
        assertEquals(expectedPlace, place);
        assertEquals(expectedPlace.getId(), place.getId());
        assertEquals(expectedPlace.getCoordinate(), place.getCoordinate());
        assertEquals(expectedPlace.getDescription(), place.getDescription());
        assertEquals(expectedPlace.getFloorNumber(), place.getFloorNumber());
        assertEquals(expectedPlace.getType(), place.getType());
        assertEquals(expectedPlace.isFavorite(), place.isFavorite());
        assertEquals(expectedPlace.isInHistory(), place.isInHistory());
    }
}
