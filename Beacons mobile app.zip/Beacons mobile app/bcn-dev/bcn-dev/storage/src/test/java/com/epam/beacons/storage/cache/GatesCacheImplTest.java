package com.epam.beacons.storage.cache;

import com.epam.beacons.Gate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class GatesCacheImplTest {
    private final static List<Gate> EMPTY_FAKE_GATES = Collections.emptyList();

    private List<Gate> fakeGates;

    @InjectMocks
    private GatesCacheImpl gatesCacheImpl;

    @Before
    public void setUp() {
        fakeGates = new ArrayList<>();
        fakeGates.add(new Gate(1, "2", "image1", "type1", Collections.emptyMap()));
        fakeGates.add(new Gate(2, "3", "image2", "type2", Collections.emptyMap()));
        fakeGates.add(new Gate(3, "4", "image3", "type3", Collections.emptyMap()));
    }

    @Test
    public void testGetCompletion() {
        gatesCacheImpl.get()
                      .test()
                      .assertNoValues()
                      .assertComplete();
    }

    @Test
    public void testGet() {
        gatesCacheImpl.put(fakeGates)
                      .andThen(gatesCacheImpl.get())
                      .test()
                      .assertValue(fakeGates)
                      .assertComplete();
    }

    @Test
    public void testGetOnEmptyList() {
        gatesCacheImpl.put(EMPTY_FAKE_GATES)
                      .andThen(gatesCacheImpl.get())
                      .test()
                      .assertNoValues()
                      .assertComplete();
    }

    @Test
    public void testPutOnListWithManyElem() {
        gatesCacheImpl.put(fakeGates)
                      .test()
                      .assertComplete();
    }

    @Test
    public void testPutOnListWithOneElem() {
        gatesCacheImpl.put(fakeGates.subList(0, 1))
                      .test()
                      .assertComplete();
    }

    @Test
    public void testPutOnEmptyList() {
        gatesCacheImpl.put(fakeGates)
                      .test()
                      .assertComplete();
    }

    @Test
    public void testClearCompletion() {
        gatesCacheImpl.clear()
                      .test()
                      .assertComplete();
    }

    @Test
    public void testClear() {
        gatesCacheImpl.put(fakeGates)
                      .andThen(gatesCacheImpl.clear())
                      .andThen(gatesCacheImpl.get())
                      .test()
                      .assertNoValues()
                      .assertComplete();
    }
}
