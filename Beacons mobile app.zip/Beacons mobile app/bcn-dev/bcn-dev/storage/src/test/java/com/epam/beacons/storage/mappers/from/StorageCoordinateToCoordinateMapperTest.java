package com.epam.beacons.storage.mappers.from;

import com.epam.beacons.Coordinate;
import com.epam.beacons.storage.entities.StorageCoordinate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class StorageCoordinateToCoordinateMapperTest {

    @InjectMocks
    private StorageCoordinateToCoordinateMapper coordinateMapper;

    private final StorageCoordinate storageCoordinate;
    private final Coordinate        expectedCoordinate;

    public StorageCoordinateToCoordinateMapperTest(StorageCoordinate storageCoordinate,
                                                   Coordinate expectedCoordinate) {
        this.storageCoordinate = storageCoordinate;
        this.expectedCoordinate = expectedCoordinate;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        new StorageCoordinate(0, 0),
                        new Coordinate(0, 0)
                },
                {
                        new StorageCoordinate(-5, 5),
                        new Coordinate(-5, 5)
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testMap() {
        assertEqualsForAllFields(expectedCoordinate, coordinateMapper.map(storageCoordinate));
    }

    @Test
    public void testMapOnList() {
        final List<Coordinate> coordinates = coordinateMapper.map(Collections.singletonList(storageCoordinate));
        assertEquals(1, coordinates.size());
        assertEqualsForAllFields(expectedCoordinate, coordinates.get(0));
    }

    private void assertEqualsForAllFields(Coordinate expectedCoordinate, Coordinate coordinate) {
        assertEquals(expectedCoordinate, coordinate);
        assertEquals(expectedCoordinate.getLatitude(), coordinate.getLatitude(), 0);
        assertEquals(expectedCoordinate.getLongitude(), coordinate.getLongitude(), 0);
        assertEquals(expectedCoordinate.getErrorRadius(), coordinate.getErrorRadius(), 0);
        assertEquals(expectedCoordinate.getTimestamp(), coordinate.getTimestamp());
    }
}
