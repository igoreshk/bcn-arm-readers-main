package com.epam.beacons.storage.mappers.to;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Gate;
import com.epam.beacons.storage.entities.StorageBound;
import com.epam.beacons.storage.entities.StorageCoordinate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class GateToStorageBoundMapperTest {

    @Mock
    private CoordinateToStorageCoordinateMapper coordinateMapper;
    @InjectMocks
    private GateToStorageBoundMapper            gateToStorageBoundMapper;

    private final List<Gate> gates;
    private final List<StorageBound> expected;

    public GateToStorageBoundMapperTest(List<Gate> gates, List<StorageBound> expected) {
        this.gates = gates;
        this.expected = expected;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        Collections.emptyList(),
                        Collections.emptyList()
                },
                {
                        Collections.singletonList(
                                new Gate(1, "2", "image", "type",
                                         new HashMap<Integer, Coordinate>() {{
                                             put(6, new Coordinate(1, 2));
                                         }}
                                )
                        ),
                        Collections.singletonList(
                                new StorageBound(1, 6, new StorageCoordinate(1, 2))
                        )
                },
                {
                        Collections.singletonList(
                                new Gate(2, "3", null, "type2",
                                         new HashMap<Integer, Coordinate>() {{
                                             put(7, new Coordinate(3, 4));
                                         }}
                                )
                        ),
                        Collections.singletonList(
                                new StorageBound(2, 7, new StorageCoordinate(3, 4))
                        )
                },
                {
                        Arrays.asList(
                                new Gate(3, "4", "image3", "type3",
                                         new HashMap<Integer, Coordinate>() {{
                                             put(7, new Coordinate(5, 6));
                                             put(8, new Coordinate(7, 8));
                                             put(9, new Coordinate(9, 10));
                                         }}
                                ),
                                new Gate(4, "5", "image4", "type4",
                                         new HashMap<Integer, Coordinate>() {{
                                             put(10, new Coordinate(11, 12));
                                             put(11, new Coordinate(13, 14));
                                             put(12, new Coordinate(15, 16));
                                         }}
                                )
                        ),
                        Arrays.asList(
                                new StorageBound(3, 7, new StorageCoordinate(5, 6)),
                                new StorageBound(3, 8, new StorageCoordinate(7, 8)),
                                new StorageBound(3, 9, new StorageCoordinate(9, 10)),
                                new StorageBound(4, 10, new StorageCoordinate(11, 12)),
                                new StorageBound(4, 11, new StorageCoordinate(13, 14)),
                                new StorageBound(4, 12, new StorageCoordinate(15, 16))
                        )
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(coordinateMapper.map(any(Coordinate.class)))
                .thenAnswer(invocation -> {
                    final Coordinate coordinate = invocation.getArgument(0);
                    return new StorageCoordinate(coordinate.getLatitude(), coordinate.getLongitude());
                });
    }

    @Test
    public void testMap() {
        final List<StorageBound> storageBounds = gateToStorageBoundMapper.map(gates);
        assertEquals(expected, storageBounds);
        final int maxSize = Math.max(expected.size(), storageBounds.size());
        for (int i = 0; i < maxSize; i++) {
            assertEqualsForAllFields(expected.get(i), storageBounds.get(i));
        }
    }

    private void assertEqualsForAllFields(StorageBound expected, StorageBound bound) {
        assertEquals(expected, bound);
        assertEquals(expected.getGateId(), bound.getGateId());
        assertEquals(expected.getCoordinate(), bound.getCoordinate());
        assertEquals(expected.getFloorNumber(), bound.getFloorNumber());
    }
}
