package com.epam.beacons.storage.mappers.to;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Edge;
import com.epam.beacons.Vertex;
import com.epam.beacons.storage.entities.StorageEdge;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class EdgeToStorageEdgeMapperTest {

    @InjectMocks
    private EdgeToStorageEdgeMapper edgeMapper;

    private final String        buildingId;
    private final int         floorNumber;
    private final Edge        edge;
    private final StorageEdge expected;

    public EdgeToStorageEdgeMapperTest(String buildingId, int floorNumber,
                                       Edge edge, StorageEdge expected) {
        this.buildingId = buildingId;
        this.floorNumber = floorNumber;
        this.edge = edge;
        this.expected = expected;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        1, 5,
                        new Edge(
                                new Vertex("0", new Coordinate(1, 2)),
                                new Vertex("1", new Coordinate(3, 4)),
                                1.5f
                        ),
                        new StorageEdge("1", 5, 1.5f, "0", "1")
                },
                {
                        0, 0,
                        new Edge(
                                new Vertex("10", new Coordinate(5, 6)),
                                new Vertex("11", new Coordinate(7, 8)),
                                11.5f
                        ),
                        new StorageEdge("0", 0, 11.5f, "10", "11")
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testMap() {
        assertEqualsForAllFields(expected, edgeMapper.map(buildingId, floorNumber, edge));
    }

    @Test
    public void testMapOnList() {
        final List<StorageEdge> storageEdges = edgeMapper.map(
                buildingId, floorNumber, Collections.singletonList(edge));
        assertEquals(1, storageEdges.size());
        assertEqualsForAllFields(expected, storageEdges.get(0));
    }

    private void assertEqualsForAllFields(StorageEdge expected, StorageEdge edge) {
        assertEquals(expected, edge);
        assertEquals(expected.getBuildingId(), edge.getBuildingId());
        assertEquals(expected.getFloorNumber(), edge.getFloorNumber());
        assertEquals(expected.getVertex1Id(), edge.getVertex1Id());
        assertEquals(expected.getVertex2Id(), edge.getVertex2Id());
    }
}
