package com.epam.beacons.storage.cache

import com.epam.beacons.Measurement
import io.reactivex.Maybe
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE)
class MeasurementCacheImplTest {

    private val cache: MeasurementCacheImpl = MeasurementCacheImpl()

    @Test
    fun testGet() {
        val measurements = listOf(Measurement(KEY_ONE, 10.0, 10))

        cache.put(measurements)
                .andThen(cache.get(KEY_ONE))
                .test()
                .assertComplete()
                .assertValue(measurements)
    }

    @Test
    fun testPutWithExistingKey() {
        val oldMeasurements = listOf(Measurement(KEY_ONE, 10.2, 12))
        val newMeasurements = listOf(Measurement(KEY_ONE, 10.3, 14))

        cache.put(oldMeasurements)
                .andThen(cache.put(newMeasurements))
                .andThen(cache.get(KEY_ONE))
                .test()
                .assertComplete()
                .assertValue(oldMeasurements + newMeasurements)
    }

    @Test
    fun testPutWithNewKey() {
        val oldMeasurements = listOf(Measurement(KEY_ONE, 10.2, 12))
        val differentMeasurements = listOf(Measurement(KEY_TWO, 10.2, 12))

        cache.put(oldMeasurements)
                .andThen(cache.put(differentMeasurements))
                .test()
                .assertComplete()

        cache.get(KEY_ONE)
                .test()
                .assertComplete()
                .assertValue(oldMeasurements)

        cache.get(KEY_TWO)
                .test()
                .assertComplete()
                .assertValue(differentMeasurements)
    }

    @Test
    fun testSize() {
        val sizedList = listOf(
                Measurement(KEY_ONE, 10.2, 12),
                Measurement(KEY_ONE, 10.2, 12),
                Measurement(KEY_TWO, 1.2, 12))

        cache.put(sizedList)
                .andThen(Maybe.fromCallable { cache.size() })
                .test()
                .assertValue(2)
    }

    @Test
    fun testWhenOverSized() {
        val overSizedListMeasurements: MutableList<Measurement> = mutableListOf()
        overSizedListMeasurements.apply {
            for (i in 1..MeasurementCacheImpl.MAX_LIST_SIZE + 1) {
                add(Measurement(KEY_ONE, 20.2, 10))
            }
        }

        assertTrue(cache.removeMeasurements(overSizedListMeasurements, MEASUREMENT_LIST_LIMIT))
    }

    @Test
    fun testWhenNotOverSized() {
        val acceptableSizedListMeasurements: MutableList<Measurement> = mutableListOf()
        acceptableSizedListMeasurements.apply {
            for (i in 1..MeasurementCacheImpl.MAX_LIST_SIZE) {
                add(Measurement(KEY_ONE, 20.2, 10))
            }
        }

        assertFalse(cache.removeMeasurements(acceptableSizedListMeasurements, MEASUREMENT_LIST_LIMIT))
    }

    @Test
    fun testListMeasurementsWasRemovedWhenListOverSized() {
        val overSizedMeasurementsList: MutableList<Measurement> = mutableListOf()
        overSizedMeasurementsList.apply {
            for (i in 1..MeasurementCacheImpl.MAX_LIST_SIZE + 1) {
                add(Measurement(KEY_ONE, 20.0, i.toLong()))
            }
        }
        val sizeBeforeCut = overSizedMeasurementsList.size
        cache.removeMeasurements(overSizedMeasurementsList, MEASUREMENT_LIST_LIMIT)
        val sizeAfterCut = overSizedMeasurementsList.size

        assertTrue(sizeAfterCut < sizeBeforeCut)
    }

    companion object {
        private const val KEY_ONE = 42
        private const val KEY_TWO = 50
        private const val MEASUREMENT_LIST_LIMIT = 30
    }
}
