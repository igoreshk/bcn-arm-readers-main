package com.epam.beacons.storage.mappers.to;

import com.epam.beacons.Beacon;
import com.epam.beacons.Coordinate;
import com.epam.beacons.storage.entities.StorageBeacon;
import com.epam.beacons.storage.entities.StorageCoordinate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class BeaconToStorageBeaconMapperTest {

    @Mock
    private CoordinateToStorageCoordinateMapper coordinateMapper;
    @InjectMocks
    private BeaconToStorageBeaconMapper         beaconMapper;

    private final String          buildingId;
    private final int           floorNumber;
    private final Beacon        beacon;
    private final StorageBeacon expected;

    public BeaconToStorageBeaconMapperTest(String buildingId, int floorNumber,
                                           Beacon beacon, StorageBeacon expected) {
        this.buildingId = buildingId;
        this.floorNumber = floorNumber;
        this.beacon = beacon;
        this.expected = expected;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        1, 5,
                        new Beacon("uuid", 1, 1, "1", new Coordinate(0, 0)),
                        new StorageBeacon("1", 5, "uuid", "1",1, 1,
                                          new StorageCoordinate(0, 0)
                        )
                },
                {
                        10, 7,
                        new Beacon("another", 50, 70, "1", new Coordinate(10, 5)),
                        new StorageBeacon("10", 7, "another","1", 50, 70,
                                          new StorageCoordinate(10, 5)
                        )
                }
        });
    }

    @Before
    @SuppressWarnings("ConstantConditions")
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(coordinateMapper.map(beacon.getCoordinate()))
                .thenAnswer(invocation -> {
                    final Coordinate coordinate = invocation.getArgument(0);
                    return new StorageCoordinate(coordinate.getLatitude(), coordinate.getLongitude());
                });
    }

    @Test
    public void testMap() {
        assertEqualsForAllFields(expected, beaconMapper.map(buildingId, floorNumber, beacon));
    }

    @Test
    public void testMapOnList() {
        final List<StorageBeacon> storageBeacons = beaconMapper.map(
                buildingId, floorNumber, Collections.singletonList(beacon));
        assertEquals(1, storageBeacons.size());
        assertEqualsForAllFields(expected, storageBeacons.get(0));
    }

    private void assertEqualsForAllFields(StorageBeacon expected, StorageBeacon beacon) {
        assertEquals(expected, beacon);
        assertEquals(expected.getUuid(), beacon.getUuid());
        assertEquals(expected.getMajor(), beacon.getMajor());
        assertEquals(expected.getMinor(), beacon.getMinor());
        assertEquals(expected.getCoordinate(), beacon.getCoordinate());
        assertEquals(expected.getBuildingId(), beacon.getBuildingId());
        assertEquals(expected.getFloorNumber(), beacon.getFloorNumber());
    }
}
