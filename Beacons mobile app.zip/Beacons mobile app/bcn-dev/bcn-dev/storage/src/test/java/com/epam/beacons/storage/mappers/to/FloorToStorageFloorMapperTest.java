package com.epam.beacons.storage.mappers.to;

import com.epam.beacons.Beacon;
import com.epam.beacons.Coordinate;
import com.epam.beacons.Floor;
import com.epam.beacons.Place;
import com.epam.beacons.storage.entities.StorageCoordinate;
import com.epam.beacons.storage.entities.StorageFloor;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class FloorToStorageFloorMapperTest {

    @Mock
    private CoordinateToStorageCoordinateMapper coordinateMapper;
    @InjectMocks
    private FloorToStorageFloorMapper           floorMapper;

    private final Floor floor;
    private final StorageFloor expected;

    public FloorToStorageFloorMapperTest(Floor floor, StorageFloor expected) {
        this.floor = floor;
        this.expected = expected;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        new Floor(
                                "1", 2, "1",
                                Arrays.asList(
                                        new Beacon("uuid1", 1, 1, "1", new Coordinate(5, 6)),
                                        new Beacon("uuid2", 2, 2, "1", new Coordinate(7, 8))
                                ),
                                Arrays.asList(
                                        new Place("0", "type1", "description1",
                                                  new Coordinate(9, 10), 2
                                        ),
                                        new Place("1", "type2", "description2",
                                                  new Coordinate(11, 12), 2
                                        )
                                ),
                                "url1",
                                50,
                                new Coordinate(1, 2),
                                new Coordinate(3, 4)
                        ),
                        new StorageFloor("1", 2, "url1", "50", 70,
                                         new StorageCoordinate(1, 2),
                                         new StorageCoordinate(3, 4)
                        )
                },
                {
                        new Floor(
                                "10", 20, "1",
                                Collections.emptyList(),
                                Collections.emptyList(),
                                "url2",
                                500,
                                new Coordinate(5, 6),
                                new Coordinate(7, 8)
                        ),
                        new StorageFloor("10", 20, "url2", "500", 700,
                                         new StorageCoordinate(5, 6),
                                         new StorageCoordinate(7, 8)
                        )
                },
                {
                        new Floor(
                                "100", 200, "1",
                                Arrays.asList(
                                        new Beacon("uuid3", 3, 3, "1", new Coordinate(27, 28)),
                                        new Beacon("uuid4", 4, 4, "1",  new Coordinate(29, 30))
                                ),
                                Arrays.asList(
                                        new Place("2", "type2", "description2",
                                                  new Coordinate(31, 32), 40
                                        ),
                                        new Place("3", "type3", "description3",
                                                  new Coordinate(33, 34), 40
                                        )
                                ),
                                "url3",
                                60,
                                new Coordinate(9, 10),
                                new Coordinate(11, 12)
                        ),
                        new StorageFloor("100", 200, "url3", "60", 80,
                                         new StorageCoordinate(9, 10),
                                         new StorageCoordinate(11, 12)
                        )
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(coordinateMapper.map(any(Coordinate.class)))
                .thenAnswer(invocation -> {
                    final Coordinate coordinate = invocation.getArgument(0);
                    return new StorageCoordinate(coordinate.getLatitude(), coordinate.getLongitude());
                });
    }

    @Test
    public void testMap() {
        assertEqualsForAllFields(expected, floorMapper.map(floor));
    }

    @Test
    public void testMapOnList() {
        final List<StorageFloor> storageFloors = floorMapper.map(Collections.singletonList(floor));
        assertEquals(1, storageFloors.size());
        assertEqualsForAllFields(expected, storageFloors.get(0));
    }

    private void assertEqualsForAllFields(StorageFloor expected, StorageFloor floor) {
        assertEquals(expected, floor);
        assertEquals(expected.getBuildingId(), floor.getBuildingId());
        assertEquals(expected.getNumber(), floor.getNumber());
        assertEquals(expected.getOverlayNorthEastBound(), floor.getOverlayNorthEastBound());
        assertEquals(expected.getOverlaySouthWestBound(), floor.getOverlaySouthWestBound());
    }
}
