package com.epam.beacons.storage.mappers.to;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Place;
import com.epam.beacons.storage.entities.StorageCoordinate;
import com.epam.beacons.storage.entities.StoragePlace;

import org.jetbrains.annotations.NotNull;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class PlaceToStoragePlaceMapperTest {

    @Mock
    private CoordinateToStorageCoordinateMapper coordinateMapper;
    @InjectMocks
    private PlaceToStoragePlaceMapper           placeMapper;

    private final String         buildingId;
    private final int          floorNumber;
    private final Place        place;
    private final StoragePlace expected;

    public PlaceToStoragePlaceMapperTest(String buildingId, int floorNumber,
                                         Place place, StoragePlace expected) {
        this.buildingId = buildingId;
        this.floorNumber = floorNumber;
        this.place = place;
        this.expected = expected;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        1, 2,
                        new Place("0", "type", "description",
                                  new Coordinate(1, 2), 2
                        ),
                        new StoragePlace("0", "1", 2,
                                         "type", "description",
                                         new StorageCoordinate(1, 2)
                        )
                },
                {
                        3, 4,
                        new Place("5", "anotherType", "anotherDescription",
                                  new Coordinate(3, 4), 1
                        ),
                        new StoragePlace("5", "3", 4,
                                         "anotherType", "anotherDescription",
                                         new StorageCoordinate(3, 4)
                        )
                },
                {
                        5, 6,
                        new Place("50", "anotherType2", "anotherDescription2",
                                  new Coordinate(5, 6), 11
                        ),
                        new StoragePlace("50", "5", 6,
                                         "anotherType2", "anotherDescription2",
                                         new StorageCoordinate(5, 6)
                        )
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(coordinateMapper.map(place.getCoordinate()))
                .thenAnswer(invocation -> {
                    final Coordinate coordinate = invocation.getArgument(0);
                    return new StorageCoordinate(coordinate.getLatitude(), coordinate.getLongitude());
                });
    }

    @Test
    public void testMap() {
        assertEqualsForAllFields(expected, placeMapper.map(buildingId, floorNumber, place));
    }

    @Test
    public void testMapOnList() {
        final List<StoragePlace> storagePlaces = placeMapper.map(
                buildingId, floorNumber, Collections.singletonList(place));
        assertEquals(1, storagePlaces.size());
        assertEqualsForAllFields(expected, storagePlaces.get(0));
    }

    private void assertEqualsForAllFields(StoragePlace expected, StoragePlace place) {
        assertEquals(expected, place);
        assertEquals(expected.getBuildingId(), place.getBuildingId());
        assertEquals(expected.getFloorNumber(), place.getFloorNumber());
        assertEquals(expected.getCoordinate(), place.getCoordinate());
        assertEquals(expected.getDescription(), place.getDescription());
        assertEquals(expected.getId(), place.getId());
        assertEquals(expected.getType(), place.getType());
    }
}
