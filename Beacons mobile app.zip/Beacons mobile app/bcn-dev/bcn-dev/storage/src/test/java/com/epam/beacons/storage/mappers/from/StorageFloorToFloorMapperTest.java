package com.epam.beacons.storage.mappers.from;

import com.epam.beacons.Beacon;
import com.epam.beacons.Coordinate;
import com.epam.beacons.Floor;
import com.epam.beacons.Place;
import com.epam.beacons.storage.entities.StorageBeacon;
import com.epam.beacons.storage.entities.StorageCoordinate;
import com.epam.beacons.storage.entities.StorageFloor;
import com.epam.beacons.storage.entities.StoragePlace;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class StorageFloorToFloorMapperTest {

    @Mock
    private StorageBeaconToBeaconMapper         beaconMapper;
    @Mock
    private StoragePlaceToPlaceMapper           placeMapper;
    @Mock
    private StorageCoordinateToCoordinateMapper coordinateMapper;
    @InjectMocks
    private StorageFloorToFloorMapper           floorMapper;

    private final StorageFloor        storageFloor;
    private final List<StorageBeacon> storageBeacons;
    private final List<StoragePlace>  storagePlaces;
    private final List<String>          historyPlacesIds;
    private final List<String>          favoritePlacesIds;
    private final Floor               expectedFloor;

    public StorageFloorToFloorMapperTest(StorageFloor storageFloor, List<StorageBeacon> storageBeacons,
                                         List<StoragePlace> storagePlaces, List<String> historyPlacesIds,
                                         List<String> favoritePlacesIds, Floor expectedFloor) {
        this.storageFloor = storageFloor;
        this.storageBeacons = storageBeacons;
        this.storagePlaces = storagePlaces;
        this.historyPlacesIds = historyPlacesIds;
        this.favoritePlacesIds = favoritePlacesIds;
        this.expectedFloor = expectedFloor;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        new StorageFloor("10", 20, "url2", "60", 80,
                                         new StorageCoordinate(19, 20),
                                         new StorageCoordinate(21, 22)
                        ),
                        Collections.emptyList(),
                        Collections.emptyList(),
                        Collections.emptyList(),
                        Collections.emptyList(),
                        new Floor("10", 20,"1",
                                  Collections.emptyList(),
                                  Collections.emptyList(),
                                  "url2",
                                  60,
                                  new Coordinate(19, 20),
                                  new Coordinate(21, 22)
                        )
                },
                {
                        new StorageFloor("1", 2, "url1", "50", 70,
                                         new StorageCoordinate(1, 2),
                                         new StorageCoordinate(3, 4)
                        ),
                        Arrays.asList(
                                new StorageBeacon("1", 2, "uuid1", "1", 1, 1,
                                                  new StorageCoordinate(5, 6)
                                ),
                                new StorageBeacon("1", 2, "uuid2", "2", 2, 1,
                                                  new StorageCoordinate(7, 8)
                                )
                        ),
                        Arrays.asList(
                                new StoragePlace("0", "1", 2,
                                                 "type1", "description1",
                                                 new StorageCoordinate(9, 10)
                                ),
                                new StoragePlace("1", "1", 2,
                                                 "type2", "description2",
                                                 new StorageCoordinate(11, 12)
                                )
                        ),
                        Collections.emptyList(),
                        Collections.emptyList(),
                        new Floor("1", 2, "1",
                                  Arrays.asList(
                                          new Beacon("uuid1", 1, 1,"1", new Coordinate(5, 6)),
                                          new Beacon("uuid2", 2, 2, "1", new Coordinate(7, 8))
                                  ),

                                  Arrays.asList(
                                          new Place("0", "type1", "description1",
                                                    new Coordinate(9, 10), 2
                                          ),
                                          new Place("1", "type2", "description2",
                                                    new Coordinate(11, 12), 2
                                          )
                                  ),
                                  "url1",
                                  50,
                                  new Coordinate(1, 2),
                                  new Coordinate(3, 4)
                        )
                },
                {
                        new StorageFloor("30", 40, "url3", "70", 90,
                                         new StorageCoordinate(23, 24),
                                         new StorageCoordinate(25, 26)
                        ),
                        Arrays.asList(
                                new StorageBeacon("30", 40, "uuid3", "3", 3, 1,
                                                  new StorageCoordinate(27, 28)
                                ),
                                new StorageBeacon("30", 40, "uuid4", "4", 4, 1,
                                                  new StorageCoordinate(29, 30)
                                )
                        ),
                        Arrays.asList(
                                new StoragePlace("2", "30", 40,
                                                 "type3", "description3",
                                                 new StorageCoordinate(31, 32)
                                ),
                                new StoragePlace("3", "30", 40,
                                                 "type4", "description4",
                                                 new StorageCoordinate(33, 34)
                                )
                        ),
                        Collections.emptyList(),
                        Collections.emptyList(),
                        new Floor("30", 40, "1",
                                  Arrays.asList(
                                          new Beacon("uuid3", 3, 3, "1", new Coordinate(27, 28)),
                                          new Beacon("uuid4", 4, 4, "1", new Coordinate(29, 30))
                                  ),

                                  Arrays.asList(
                                          new Place("2", "type2", "description2",
                                                    new Coordinate(31, 32), 40
                                          ),
                                          new Place("3", "type3", "description3",
                                                    new Coordinate(33, 34), 40
                                          )
                                  ),
                                  "url3",
                                  70,
                                  new Coordinate(23, 24),
                                  new Coordinate(25, 26)
                        )
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        when(beaconMapper.map(storageBeacons)).thenReturn(expectedFloor.getBeacons());
        when(placeMapper.map(storagePlaces, historyPlacesIds, favoritePlacesIds)).thenReturn(expectedFloor.getPlaces());
        when(coordinateMapper.map(any(StorageCoordinate.class)))
                .thenAnswer(invocation -> {
                    final StorageCoordinate storageCoordinate = invocation.getArgument(0);
                    return new Coordinate(storageCoordinate.getLatitude(), storageCoordinate.getLongitude());
                });
    }

    @Test
    public void testMap() {
        final Floor floor = floorMapper.map(storageFloor, storageBeacons, storagePlaces,
                                            historyPlacesIds, favoritePlacesIds
        );
        assertEquals(expectedFloor, floor);
        assertEquals(expectedFloor.getBuildingId(), floor.getBuildingId());
        assertEquals(expectedFloor.getNumber(), floor.getNumber());
        assertEquals(expectedFloor.getBeacons(), floor.getBeacons());
        assertEquals(expectedFloor.getPlaces(), floor.getPlaces());
        assertEquals(expectedFloor.getImage(), floor.getImage());
        assertEquals(expectedFloor.getOverlayNorthEastBound(), floor.getOverlayNorthEastBound());
        assertEquals(expectedFloor.getOverlaySouthWestBound(), floor.getOverlaySouthWestBound());
    }
}
