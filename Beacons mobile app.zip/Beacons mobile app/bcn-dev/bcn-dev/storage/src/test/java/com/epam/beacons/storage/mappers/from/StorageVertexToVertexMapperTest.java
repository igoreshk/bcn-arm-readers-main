package com.epam.beacons.storage.mappers.from;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Vertex;
import com.epam.beacons.storage.entities.StorageCoordinate;
import com.epam.beacons.storage.entities.StorageVertex;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class StorageVertexToVertexMapperTest {

    @Mock
    private StorageCoordinateToCoordinateMapper coordinateMapper;
    @InjectMocks
    private StorageVertexToVertexMapper         vertexMapper;

    private final StorageVertex storageVertex;
    private final Vertex        expectedVertex;

    public StorageVertexToVertexMapperTest(StorageVertex storageVertex, Vertex expectedVertex) {
        this.storageVertex = storageVertex;
        this.expectedVertex = expectedVertex;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        new StorageVertex("0", "1", 2,
                                          new StorageCoordinate(1, 2)
                        ),
                        new Vertex("0", new Coordinate(1, 2))
                },
                {
                        new StorageVertex("1", "2", 3,
                                          new StorageCoordinate(3, 4)
                        ),
                        new Vertex("1", new Coordinate(3, 4))
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(coordinateMapper.map(storageVertex.getCoordinate()))
                .thenAnswer(invocation -> {
                    final StorageCoordinate storageCoordinate = invocation.getArgument(0);
                    return new Coordinate(storageCoordinate.getLatitude(), storageCoordinate.getLongitude());
                });
    }

    @Test
    public void testMap() {
        assertEqualsForAllFields(expectedVertex, vertexMapper.map(storageVertex));
    }

    @Test
    public void testMapOnList() {
        final List<Vertex> vertices = vertexMapper.map(Collections.singletonList(storageVertex));
        assertEquals(1, vertices.size());
        assertEqualsForAllFields(expectedVertex, vertices.get(0));
    }

    private void assertEqualsForAllFields(Vertex expectedVertex, Vertex vertex) {
        assertEquals(expectedVertex, vertex);
        assertEquals(expectedVertex.getId(), vertex.getId());
        assertEquals(expectedVertex.getCoordinate(), vertex.getCoordinate());
    }
}
