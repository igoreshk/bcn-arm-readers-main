package com.epam.beacons.storage.mappers.from;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Edge;
import com.epam.beacons.Vertex;
import com.epam.beacons.storage.entities.StorageCoordinate;
import com.epam.beacons.storage.entities.StorageEdge;
import com.epam.beacons.storage.entities.StorageVertex;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.robolectric.ParameterizedRobolectricTestRunner;
import org.robolectric.annotation.Config;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(ParameterizedRobolectricTestRunner.class)
@Config(manifest = Config.NONE)
public class StorageEdgesToEdgesMapperTest {

    @Mock
    private StorageVertexToVertexMapper vertexMapper;
    @InjectMocks
    private StorageEdgesToEdgesMapper   edgesMapper;

    private final List<StorageEdge>   storageEdges;
    private final List<StorageVertex> storageVertices;
    private final List<Edge>          expectedEdges;

    public StorageEdgesToEdgesMapperTest(List<StorageEdge> storageEdges,
                                         List<StorageVertex> storageVertices,
                                         List<Edge> expectedEdges) {
        this.storageEdges = storageEdges;
        this.storageVertices = storageVertices;
        this.expectedEdges = expectedEdges;
    }

    @ParameterizedRobolectricTestRunner.Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        Collections.emptyList(),
                        Collections.emptyList(),
                        Collections.emptyList()
                },
                {
                        Arrays.asList(
                                new StorageEdge("1", 2, 3, "0", "1"),
                                new StorageEdge("1", 2, 4, "1", "2"),
                                new StorageEdge("1", 2, 5, "0", "2")
                        ),
                        Arrays.asList(
                                new StorageVertex("0", "1", 2, new StorageCoordinate(10, 11)),
                                new StorageVertex("1", "1", 2, new StorageCoordinate(12, 13)),
                                new StorageVertex("2", "1", 2, new StorageCoordinate(14, 15))
                        ),
                        Arrays.asList(
                                new Edge(
                                        new Vertex("0", new Coordinate(10, 11)),
                                        new Vertex("1", new Coordinate(12, 13)),
                                        3.0f
                                ),
                                new Edge(
                                        new Vertex("1", new Coordinate(12, 13)),
                                        new Vertex("2", new Coordinate(14, 15)),
                                        4f
                                ),
                                new Edge(
                                        new Vertex("0", new Coordinate(10, 11)),
                                        new Vertex("2", new Coordinate(14, 15)),
                                        5f
                                )
                        )
                },
                {
                        Arrays.asList(
                                new StorageEdge("5", 7, 3, "0", "1"),
                                new StorageEdge("5", 7, 4, "1", "2"),
                                new StorageEdge("5", 7, 5, "2", "3"),
                                new StorageEdge("5", 7, 6, "3", "4"),
                                new StorageEdge("5", 7, 7, "4", "5"),
                                new StorageEdge("5", 7, 8, "5", "6"),
                                new StorageEdge("5", 7, 9, "3", "5")
                        ),
                        Arrays.asList(
                                new StorageVertex("0", "5", 7, new StorageCoordinate(1, 2)),
                                new StorageVertex("1", "5", 7, new StorageCoordinate(3, 4)),
                                new StorageVertex("2", "5", 7, new StorageCoordinate(5, 6)),
                                new StorageVertex("3", "5", 7, new StorageCoordinate(7, 8)),
                                new StorageVertex("4", "5", 7, new StorageCoordinate(9, 10)),
                                new StorageVertex("5", "5", 7, new StorageCoordinate(11, 12)),
                                new StorageVertex("6", "5", 7, new StorageCoordinate(13, 14))
                        ),
                        Arrays.asList(
                                new Edge(
                                        new Vertex("0", new Coordinate(1, 2)),
                                        new Vertex("1", new Coordinate(3, 4)),
                                        3f
                                ),
                                new Edge(
                                        new Vertex("1", new Coordinate(3, 4)),
                                        new Vertex("2", new Coordinate(5, 6)),
                                        4f
                                ),
                                new Edge(
                                        new Vertex("2", new Coordinate(5, 6)),
                                        new Vertex("3", new Coordinate(7, 8)),
                                        5f
                                ),
                                new Edge(
                                        new Vertex("3", new Coordinate(7, 8)),
                                        new Vertex("4", new Coordinate(9, 10)),
                                        6f
                                ),
                                new Edge(
                                        new Vertex("4", new Coordinate(9, 10)),
                                        new Vertex("5", new Coordinate(11, 12)),
                                        7f
                                ),
                                new Edge(
                                        new Vertex("5", new Coordinate(11, 12)),
                                        new Vertex("6", new Coordinate(13, 14)),
                                        8f
                                ),
                                new Edge(
                                        new Vertex("3", new Coordinate(7, 8)),
                                        new Vertex("5", new Coordinate(11, 12)),
                                        9f
                                )
                        )
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(vertexMapper.map(any(StorageVertex.class)))
                .thenAnswer(invocation -> {
                    final StorageVertex storageVertex = invocation.getArgument(0);
                    final StorageCoordinate storageCoordinate = storageVertex.getCoordinate();
                    return new Vertex(
                            storageVertex.getEntityId(),
                            new Coordinate(storageCoordinate.getLatitude(), storageCoordinate.getLongitude())
                    );
                });
    }

    @Test
    public void testMap() {
        final List<Edge> edges = edgesMapper.map(storageEdges, storageVertices);
        assertEquals(expectedEdges, edges);
        final int maxSize = Math.max(expectedEdges.size(), edges.size());
        for (int i = 0; i < maxSize; i++) {
            assertEqualsForAllFields(expectedEdges.get(i).getSource(), edges.get(i).getSource());
            assertEqualsForAllFields(expectedEdges.get(i).getDestination(), edges.get(i).getDestination());
            assertEquals(expectedEdges.get(i).getWeight(), edges.get(i).getWeight(), 0);
        }
    }

    private void assertEqualsForAllFields(Vertex expectedVertex, Vertex vertex) {
        assertEquals(expectedVertex, vertex);
        assertEquals(expectedVertex.getId(), vertex.getId());
        assertEquals(expectedVertex.getCoordinate(), vertex.getCoordinate());
    }
}
