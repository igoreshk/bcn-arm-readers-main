package com.epam.beacons.storage.cache

import com.epam.beacons.Coordinate
import com.epam.beacons.Floor
import org.junit.Test

class FloorNumbersCacheImplTest {

    private val cache = FloorNumbersCacheImpl()

    private val fakeFloors = listOf(Floor("1", 1, "2", listOf(), listOf(), "imageUrl", 0.0, Coordinate(0.0, 0.0), Coordinate(0.0, 0.0)),
        Floor("1", 2, "2", listOf(), listOf(), "imageUrl", 0.0, Coordinate(0.0, 0.0), Coordinate(0.0, 0.0)),
        Floor("1", 3, "2", listOf(), listOf(), "imageUrl", 0.0, Coordinate(0.0, 0.0), Coordinate(0.0, 0.0)))

    private val fakeNumbers = listOf(1, 2, 3)

    @Test
    fun `test put and get number`() {
        cache.put(fakeFloors)
                .andThen(cache.get())
                .test()
                .assertValue(fakeNumbers)
    }

    @Test
    fun `test clear`() {
        cache.put(fakeFloors)
                .andThen(cache.clear())
                .test()
                .assertNoValues()
    }
}
