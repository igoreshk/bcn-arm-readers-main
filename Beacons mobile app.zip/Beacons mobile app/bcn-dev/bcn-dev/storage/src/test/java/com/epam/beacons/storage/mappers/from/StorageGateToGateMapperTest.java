package com.epam.beacons.storage.mappers.from;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Gate;
import com.epam.beacons.storage.entities.StorageBound;
import com.epam.beacons.storage.entities.StorageCoordinate;
import com.epam.beacons.storage.entities.StorageGate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class StorageGateToGateMapperTest {

    @Mock
    private StorageCoordinateToCoordinateMapper coordinateMapper;
    @InjectMocks
    private StorageGateToGateMapper             gateMapper;

    private final StorageGate storageGate;
    private final List<StorageBound> storageBounds;
    private final Gate expectedGate;

    public StorageGateToGateMapperTest(StorageGate storageGate, List<StorageBound> storageBounds,
                                       Gate expectedGate) {
        this.storageGate = storageGate;
        this.storageBounds = storageBounds;
        this.expectedGate = expectedGate;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        new StorageGate(1, "2", "image", "type"),
                        Collections.singletonList(
                                new StorageBound(1, 5, new StorageCoordinate(1, 2))
                        ),
                        new Gate(1, "2", "image", "type",
                                 new HashMap<Integer, Coordinate>() {{
                                     put(5, new Coordinate(1, 2));
                                 }}
                        )
                },
                {
                        new StorageGate(2, "3", null, "type2"),
                        Collections.singletonList(
                                new StorageBound(2, 7, new StorageCoordinate(3, 4))
                        ),
                        new Gate(2, "3", null, "type2",
                                 new HashMap<Integer, Coordinate>() {{
                                     put(7, new Coordinate(3, 4));
                                 }}
                        )
                },
                {
                        new StorageGate(3, "4", "image3", "type3"),
                        Collections.emptyList(),
                        new Gate(3, "4", "image3", "type3",
                                 new HashMap<>()
                        )
                },
                {
                        new StorageGate(4, "5", "image4", "type4"),
                        Arrays.asList(
                                new StorageBound(4, 8, new StorageCoordinate(5, 6)),
                                new StorageBound(4, 10, new StorageCoordinate(7, 8)),
                                new StorageBound(4, 42, new StorageCoordinate(9, 10))
                        ),
                        new Gate(4, "5", "image4", "type4",
                                 new HashMap<Integer, Coordinate>() {{
                                     put(8, new Coordinate(5, 6));
                                     put(10, new Coordinate(7, 8));
                                     put(42, new Coordinate(9, 10));
                                 }}
                        )
                },
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(coordinateMapper.map(any(StorageCoordinate.class)))
                .thenAnswer(invocation -> {
                    final StorageCoordinate storageCoordinate = invocation.getArgument(0);
                    return new Coordinate(storageCoordinate.getLatitude(), storageCoordinate.getLongitude());
                });
    }

    @Test
    public void testMap() {
        assertEqualsForAllFields(expectedGate, gateMapper.map(storageGate, storageBounds));
    }

    private void assertEqualsForAllFields(Gate expectedGate, Gate gate) {
        assertEquals(expectedGate, gate);
        assertEquals(expectedGate.getId(), gate.getId());
        assertEquals(expectedGate.getBuildingId(), gate.getBuildingId());
        assertEquals(expectedGate.getBounds(), gate.getBounds());
        assertEquals(expectedGate.getImage(), gate.getImage());
        assertEquals(expectedGate.getType(), gate.getType());
    }
}
