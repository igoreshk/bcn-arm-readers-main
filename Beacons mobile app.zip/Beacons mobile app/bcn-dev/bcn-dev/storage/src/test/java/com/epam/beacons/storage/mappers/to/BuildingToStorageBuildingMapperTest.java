package com.epam.beacons.storage.mappers.to;

import com.epam.beacons.Building;
import com.epam.beacons.Coordinate;
import com.epam.beacons.storage.entities.StorageBuilding;
import com.epam.beacons.storage.entities.StorageCoordinate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class BuildingToStorageBuildingMapperTest {

    @Mock
    private CoordinateToStorageCoordinateMapper coordinateMapper;
    @InjectMocks
    private BuildingToStorageBuildingMapper buildingMapper;

    private final Building building;
    private final StorageBuilding expected;

    public BuildingToStorageBuildingMapperTest(Building building, StorageBuilding expected) {
        this.building = building;
        this.expected = expected;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        new Building("1", "name", new Coordinate(0, 0),
                                1.0, 1.0,
                                "iconUrl", "description", "address",
                                "phone", "hours"
                        ),
                        new StorageBuilding("1", "name", new StorageCoordinate(0, 0),
                                1.0, 1.0, "iconUrl", "description",
                                "address",
                                "phone", "hours"
                        )
                },
                {
                        new Building("10", "anotherName", new Coordinate(5, 7),
                                1.0, 1.0,
                                "anotherIconUrl", "anotherDescription", "anotherAddress",
                                "anotherPhone", "anotherHours"
                        ),
                        new StorageBuilding("10", "anotherName", new StorageCoordinate(5, 7),
                                1.0, 1.0, "anotherIconUrl", "anotherDescription",
                                "anotherAddress",
                                "anotherPhone", "anotherHours"
                        )
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(coordinateMapper.map(building.getCoordinate()))
                .thenAnswer(invocation -> {
                    final Coordinate coordinate = invocation.getArgument(0);
                    return new StorageCoordinate(coordinate.getLatitude(), coordinate.getLongitude());
                });
    }

    @Test
    public void testMap() {
        assertEqualsForAllFields(expected, buildingMapper.map(building));
    }

    @Test
    public void testMapOnList() {
        final List<StorageBuilding> storageBuildings = buildingMapper.map(Collections.singletonList(building));
        assertEquals(1, storageBuildings.size());
        assertEqualsForAllFields(expected, storageBuildings.get(0));
    }

    private void assertEqualsForAllFields(StorageBuilding expected, StorageBuilding building) {
        assertEquals(expected, building);
        assertEquals(expected.getEntityId(), building.getEntityId());
        assertEquals(expected.getName(), building.getName());
        assertEquals(expected.getCoordinate(), building.getCoordinate());
    }
}
