package com.epam.beacons.storage.mappers.from;

import com.epam.beacons.Building;
import com.epam.beacons.Coordinate;
import com.epam.beacons.storage.entities.StorageBuilding;
import com.epam.beacons.storage.entities.StorageCoordinate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class StorageBuildingToBuildingMapperTest {

    @Mock
    private StorageCoordinateToCoordinateMapper coordinateMapper;
    @InjectMocks
    private StorageBuildingToBuildingMapper     buildingMapper;

    private final StorageBuilding storageBuilding;
    private final Building        expectedBuilding;

    public StorageBuildingToBuildingMapperTest(StorageBuilding storageBuilding, Building expectedBuilding) {
        this.storageBuilding = storageBuilding;
        this.expectedBuilding = expectedBuilding;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        new StorageBuilding("1", "name",  new StorageCoordinate(0, 0), 1.0,1.0, "iconUrl", "description",
                                            "address",
                                            "phone", "hours"
                        ),
                        new Building("1", "name", new Coordinate(0, 0), 1.0,1.0,
                                     "iconUrl", "description", "address",
                                     "phone", "hours"
                        ),
                },
                {
                        new StorageBuilding("10", "anotherName", new StorageCoordinate(5, 7),1.0,1.0,"anotherIconUrl", "anotherDescription",
                                             "anotherAddress",
                                            "anotherPhone", "anotherHours"
                        ),
                        new Building("10", "anotherName", new Coordinate(5, 7),1.0,1.0,
                                     "anotherIconUrl", "anotherDescription", "anotherAddress",
                                     "anotherPhone", "anotherHours"
                        )
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(coordinateMapper.map(storageBuilding.getCoordinate()))
                .thenAnswer(invocation -> {
                    final StorageCoordinate storageCoordinate = invocation.getArgument(0);
                    return new Coordinate(storageCoordinate.getLatitude(), storageCoordinate.getLongitude());
                });
    }

    @Test
    public void testMap() {
        assertEqualsForAllFields(expectedBuilding, buildingMapper.map(storageBuilding));
    }

    @Test
    public void testMapOnList() {
        final List<Building> buildings = buildingMapper.map(Collections.singletonList(storageBuilding));
        assertEquals(1, buildings.size());
        assertEqualsForAllFields(expectedBuilding, buildings.get(0));
    }

    private void assertEqualsForAllFields(Building expectedBuilding, Building building) {
        assertEquals(expectedBuilding, building);
        assertEquals(expectedBuilding.getEntityId(), building.getEntityId());
        assertEquals(expectedBuilding.getCoordinate(), building.getCoordinate());
        assertEquals(expectedBuilding.getName(), building.getName());
        assertEquals(expectedBuilding.getIcon(), building.getIcon());
    }
}
