package com.epam.beacons.storage.mappers.to;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Vertex;
import com.epam.beacons.storage.entities.StorageCoordinate;
import com.epam.beacons.storage.entities.StorageVertex;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class VertexToStorageVertexMapperTest {

    @Mock
    private CoordinateToStorageCoordinateMapper coordinateMapper;
    @InjectMocks
    private VertexToStorageVertexMapper         vertexMapper;

    private final String          buildingId;
    private final int           floorNumber;
    private final Vertex        vertex;
    private final StorageVertex expected;

    public VertexToStorageVertexMapperTest(String buildingId, int floorNumber,
                                           Vertex vertex, StorageVertex expected) {
        this.buildingId = buildingId;
        this.floorNumber = floorNumber;
        this.vertex = vertex;
        this.expected = expected;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        1, 2,
                        new Vertex("0", new Coordinate(1, 2)),
                        new StorageVertex("0", "1", 2,
                                          new StorageCoordinate(1, 2)
                        )
                },
                {
                        3, 4,
                        new Vertex("1", new Coordinate(3, 4)),
                        new StorageVertex("1", "3", 4,
                                          new StorageCoordinate(3, 4)
                        )
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(coordinateMapper.map(vertex.getCoordinate()))
                .thenAnswer(invocation -> {
                    final Coordinate coordinate = invocation.getArgument(0);
                    return new StorageCoordinate(coordinate.getLatitude(), coordinate.getLongitude());
                });
    }

    @Test
    public void testMap() {
        assertEqualsForAllFields(expected, vertexMapper.map(buildingId, floorNumber, vertex));
    }

    @Test
    public void testMapOnList() {
        final List<StorageVertex> storageVertices = vertexMapper.map(
                buildingId, floorNumber, Collections.singletonList(vertex));
        assertEquals(1, storageVertices.size());
        assertEqualsForAllFields(expected, storageVertices.get(0));
    }

    private void assertEqualsForAllFields(StorageVertex expected, StorageVertex vertex) {
        assertEquals(expected, vertex);
        assertEquals(expected.getBuildingId(), vertex.getBuildingId());
        assertEquals(expected.getFloorNumber(), vertex.getFloorNumber());
        assertEquals(expected.getCoordinate(), vertex.getCoordinate());
        assertEquals(expected.getEntityId(), vertex.getEntityId());
    }
}
