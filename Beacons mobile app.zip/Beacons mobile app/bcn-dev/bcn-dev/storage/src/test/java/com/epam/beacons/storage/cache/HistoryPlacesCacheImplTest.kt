package com.epam.beacons.storage.cache

import com.epam.beacons.Coordinate
import com.epam.beacons.Place
import io.reactivex.Maybe
import org.junit.Test

class HistoryPlacesCacheImplTest {

    private val cache = HistoryPlacesCacheImpl(5)
    private val coordinate = Coordinate(1.0, 1.0)
    private val singlePlaceOne = Place("0L", TYPE, DESCRIPTION, coordinate, FLOOR)
    private val fakePlaces = mutableListOf(
            Place("1L", TYPE, DESCRIPTION, coordinate, FLOOR),
            Place("2L", TYPE, DESCRIPTION, coordinate, FLOOR),
            Place("3L", TYPE, DESCRIPTION, coordinate, FLOOR),
            Place("4L", TYPE, DESCRIPTION, coordinate, FLOOR),
            Place("5L", TYPE, DESCRIPTION, coordinate, FLOOR),
            Place("6L", TYPE, DESCRIPTION, coordinate, FLOOR)
    )

    @Test
    fun `test bulk put and get`() {
        cache.put(fakePlaces)
                .andThen(cache.get())
                .test()
                .assertComplete()
                .assertValue(fakePlaces)
    }

    @Test
    fun `test single value put and get`() {
        cache.put(singlePlaceOne)
                .andThen(cache.get())
                .test()
                .assertValue(listOf(singlePlaceOne))
    }

    @Test
    fun `single put deletes oldest Place if capacity limit reached`() {
        cache.put(singlePlaceOne)
                .andThen(cache.put(fakePlaces[0]))
                .andThen(cache.put(fakePlaces[1]))
                .andThen(cache.put(fakePlaces[2]))
                .andThen(cache.put(fakePlaces[3]))
                .andThen(cache.put(fakePlaces[4]))
                .andThen(cache.put(fakePlaces[5]))
                .andThen(cache.get())
                .test()
                .assertValues(listOf(fakePlaces[5], fakePlaces[4], fakePlaces[3], fakePlaces[2], fakePlaces[1]))
    }

    @Test
    fun `test clear cache`() {
        cache.put(fakePlaces)
                .andThen(cache.clear())
                .test()
                .assertNoValues()
    }

    @Test
    fun `test cache empty`() {
        cache.isEmpty
                .test()
                .assertValue(true)
    }

    @Test
    fun `test cache not empty`() {
        cache.put(singlePlaceOne)
                .andThen(cache.isEmpty)
                .test()
                .assertValue(false)
    }

    @Test
    fun `test update favorites`() {
        cache.put(fakePlaces)
                .andThen(cache.updateFavorites(Maybe.fromCallable { mutableListOf(fakePlaces[0].id, fakePlaces[2].id) }))
                .andThen(cache.get())
                .test()
                .assertValue { it[0].isFavorite && it[2].isFavorite && (it - it[0] - it[2]).none { it.isFavorite } }
    }

    companion object {
        private const val FLOOR = 1
        private const val TYPE = "type"
        private const val DESCRIPTION = "description"
    }
}
