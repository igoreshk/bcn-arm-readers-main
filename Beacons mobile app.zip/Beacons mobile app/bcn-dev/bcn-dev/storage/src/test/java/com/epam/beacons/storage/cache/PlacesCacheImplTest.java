package com.epam.beacons.storage.cache;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Place;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.reactivex.Maybe;

@RunWith(MockitoJUnitRunner.class)
public class PlacesCacheImplTest {

    private List<Place> fakePlaces;

    @InjectMocks
    private PlacesCacheImpl placesCache;

    @Before
    public void setUp() {
        fakePlaces = new ArrayList<>();
        fakePlaces.add(new Place("1", "type1", "description1", new Coordinate(1, 2), 5));
        fakePlaces.add(new Place("2", "type2", "description2", new Coordinate(3, 4), 7));
        fakePlaces.add(new Place("2", "type3", "description3", new Coordinate(5, 6), 9));
    }

    @Test
    public void testPutAndGet() {
        placesCache.put(fakePlaces)
                   .andThen(placesCache.get())
                   .test()
                   .assertValue(fakePlaces);
    }

    @Test
    public void testPutSinglePlace() {
        placesCache.put(fakePlaces)
                   .andThen(placesCache.put(new Place("3", "", "", new Coordinate(5, 5), 8)))
                   .andThen(placesCache.get())
                   .test()
                   .assertValue(places -> places.size() == 4)
                   .assertValue(places -> places.get(3).getId().equals("3"));

    }

    @Test
    public void testPutEmptyList() {
        placesCache.put(Collections.emptyList())
                   .andThen(placesCache.get())
                   .test()
                   .assertNoValues();
    }

    @Test
    public void testPutSamePlaceNotAllowed() {
        placesCache.put(fakePlaces)
                   .andThen(placesCache.put(fakePlaces.get(0)))
                   .andThen(placesCache.get())
                   .test()
                   .assertValue(places -> places.size() == 3);
    }

    @Test
    public void testGetById() {
        placesCache.put(fakePlaces)
                   .andThen(placesCache.getById("2"))
                   .test()
                   .assertValue(fakePlaces.get(1));
    }

    @Test
    public void testClear() {
        placesCache.put(fakePlaces)
                   .andThen(placesCache.clear())
                   .andThen(placesCache.get())
                   .test()
                   .assertNoValues()
                   .assertComplete();
    }

    @Test
    public void testUpdateFavorites() {
        placesCache.put(fakePlaces)
                   .andThen(placesCache.updateFavorites(Maybe.fromCallable(() -> Collections.singletonList(fakePlaces.get(0).getId()))))
                   .andThen(placesCache.get())
                   .test()
                   .assertValue(places -> places.get(0).isFavorite() && !places.get(1).isFavorite());
    }
}
