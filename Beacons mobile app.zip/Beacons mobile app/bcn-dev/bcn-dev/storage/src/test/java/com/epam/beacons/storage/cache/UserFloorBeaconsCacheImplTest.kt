package com.epam.beacons.storage.cache

import com.epam.beacons.Beacon
import com.epam.beacons.Coordinate
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.InjectMocks
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class UserFloorBeaconsCacheImplTest {

    private val emptyBeacons = emptyList<Beacon>()

    private val fakeBeacons = listOf(
        Beacon("uuid1", 1, 1, "1", Coordinate(1.0, 1.0)),
        Beacon("uuid2", 2, 2, "1", Coordinate(2.0, 2.0)),
        Beacon("uuid3", 3, 3, "1", Coordinate(3.0, 3.0))
    )

    @InjectMocks
    private lateinit var cache: UserFloorBeaconsCacheImpl

    @Test
    fun testGetCompletion() {
        cache.get()
            .test()
            .assertNoValues()
            .assertComplete()
    }

    @Test
    fun testPutCompletion() {
        cache.put(fakeBeacons)
            .test()
            .assertComplete()
    }

    @Test
    fun testGetEmptyList() {
        cache.put(emptyBeacons)
            .andThen(cache.get())
            .test()
            .assertNoValues()
            .assertComplete()
    }

    @Test
    fun testPutAndGet() {
        cache.put(fakeBeacons)
            .andThen(cache.get())
            .test()
            .assertValue(fakeBeacons)
            .assertComplete()
    }

    @Test
    fun testPutAndGetListWithOneItem() {
        cache.put(fakeBeacons.subList(0, 1))
            .andThen(cache.get())
            .test()
            .assertValue(fakeBeacons.subList(0, 1))
            .assertComplete()
    }

    @Test
    fun testPutAndGetEmptyList() {
        cache.put(emptyBeacons)
            .andThen(cache.get())
            .test()
            .assertNoValues()
            .assertComplete()
    }

    @Test
    fun testClearCompletion() {
        cache.clear()
            .test()
            .assertComplete()
    }

    @Test
    fun testClear() {
        cache.put(fakeBeacons)
            .andThen(cache.clear())
            .andThen(cache.get())
            .test()
            .assertNoValues()
            .assertComplete()
    }
}
