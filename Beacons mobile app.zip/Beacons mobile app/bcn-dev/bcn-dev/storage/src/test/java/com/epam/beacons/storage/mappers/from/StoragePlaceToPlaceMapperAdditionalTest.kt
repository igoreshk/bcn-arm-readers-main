package com.epam.beacons.storage.mappers.from

import com.epam.beacons.Coordinate
import com.epam.beacons.Place
import com.epam.beacons.storage.KotlinMockito.anyNonNull
import com.epam.beacons.storage.KotlinMockito.whn
import com.epam.beacons.storage.entities.StorageCoordinate
import com.epam.beacons.storage.entities.StoragePlace
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class StoragePlaceToPlaceMapperAdditionalTest {

    private val storagePlaces = listOf(
            StoragePlace("0", "42", 0, "type0", "description0", StorageCoordinate(0.0, 0.0)),
            StoragePlace("1", "42", 1, "type1", "description1", StorageCoordinate(1.0, 1.0)),
            StoragePlace("2", "42", 2, "type2", "description2", StorageCoordinate(2.0, 2.0)),
            StoragePlace("3", "42", 3, "type3", "description3", StorageCoordinate(3.0, 3.0)),
            StoragePlace("4", "42", 4, "type4", "description4", StorageCoordinate(4.0, 4.0)))
    private val expectedPlaces = listOf(
            Place("0", "type0", "description0", Coordinate(0.0, 0.0), 0),
            Place("1", "type1", "description1", Coordinate(1.0, 1.0), 1),
            Place("2", "type2", "description2", Coordinate(2.0, 2.0), 2),
            Place("3", "type3", "description3", Coordinate(3.0, 3.0), 3),
            Place("4", "type4", "description4", Coordinate(4.0, 4.0), 4))
    private val favoritesIds = listOf("0L", "2L")
    private val historyIds = listOf("1L", "3L")
    private val storageFavorites = storagePlaces.filter { favoritesIds.contains(it.id) }
    private val storageHistory = storagePlaces.filter { historyIds.contains(it.id) }
    private val expectedFavorites = expectedPlaces.filter { favoritesIds.contains(it.id) }
    private val expectedHistory = expectedPlaces.filter { historyIds.contains(it.id) }

    @Mock
    private lateinit var storageCoordinateToCoordinateMapper: StorageCoordinateToCoordinateMapper
    @InjectMocks
    private lateinit var storagePlaceToPlaceMapper: StoragePlaceToPlaceMapper

    @Before
    fun setUp() {
        whn(storageCoordinateToCoordinateMapper.map(anyNonNull<StorageCoordinate>())).thenAnswer {
            val coord = it.getArgument<StorageCoordinate>(0)
            Coordinate(coord.latitude, coord.longitude)
        }
    }

    @Test
    fun testMapWithHistoryAndFavoritesIds() {
        val place = storagePlaceToPlaceMapper.map(storagePlaces[4], historyIds, favoritesIds)
        assertEquals(expectedPlaces[4], place)
        assertFalse(place.isFavorite)
        assertFalse(place.isInHistory)

        val placeInFavorites = storagePlaceToPlaceMapper.map(storagePlaces[0], historyIds, favoritesIds)
        assertEquals(expectedPlaces[0], placeInFavorites)
        assertTrue(placeInFavorites.isFavorite)
        assertFalse(placeInFavorites.isInHistory)

        val placeInHistory = storagePlaceToPlaceMapper.map(storagePlaces[1], historyIds, favoritesIds)
        assertEquals(expectedPlaces[1], placeInHistory)
        assertFalse(placeInHistory.isFavorite)
        assertTrue(placeInHistory.isInHistory)
    }

    @Test
    fun testMapWithHistoryAndFavoritesIdsOnList() {
        val places = storagePlaceToPlaceMapper.map(storagePlaces, historyIds, favoritesIds)
        assertEquals(expectedPlaces, places)
        assertTrue(places.filter { favoritesIds.contains(it.id) }.all { it.isFavorite } &&
                places.filterNot { favoritesIds.contains(it.id) }.none { it.isFavorite } &&
                places.filter { historyIds.contains(it.id) }.all { it.isInHistory } &&
                places.filterNot { historyIds.contains(it.id) }.none { it.isInHistory }
        )
    }

    @Test
    fun testMapFavorites() {
        val places = storagePlaceToPlaceMapper.mapFavorites(storageFavorites, historyIds)
        assertEquals(expectedFavorites, places)
        assertTrue(places.all { it.isFavorite } &&
                places.filter { historyIds.contains(it.id) }.all { it.isInHistory } &&
                places.filterNot { historyIds.contains(it.id) }.none { it.isInHistory }
        )
    }

    @Test
    fun testMapHistory() {
        val places = storagePlaceToPlaceMapper.mapHistory(storageHistory, favoritesIds)
        assertEquals(expectedHistory, places)
        assertTrue(places.filter { favoritesIds.contains(it.id) }.all { it.isFavorite } &&
                places.filterNot { favoritesIds.contains(it.id) }.none { it.isFavorite } &&
                places.all { it.isInHistory }
        )
    }
}
