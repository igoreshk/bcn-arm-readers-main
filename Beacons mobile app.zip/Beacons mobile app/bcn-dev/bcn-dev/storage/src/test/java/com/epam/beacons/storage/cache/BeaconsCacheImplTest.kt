package com.epam.beacons.storage.cache

import com.epam.beacons.Beacon
import com.epam.beacons.Coordinate
import org.junit.Test

class BeaconsCacheImplTest {

    private var beaconsCache = BeaconsCacheImpl()

    private val floorNumbers = listOf(FLOOR_NUMBER_0, FLOOR_NUMBER_1, FLOOR_NUMBER_2)
    private val beacons = listOf(
            Beacon("uuid1", 1, 1, "FLOOR_NUMBER_0", Coordinate(1.0, 1.0)),
            Beacon("uuid2", 2, 2, "FLOOR_NUMBER_0", Coordinate(2.0, 2.0)),
            Beacon("uuid3", 3, 3, "FLOOR_NUMBER_1", Coordinate(3.0, 3.0)),
            Beacon("uuid4", 4, 4, "FLOOR_NUMBER_1", Coordinate(4.0, 4.0)),
            Beacon("uuid5", 5, 5, "FLOOR_NUMBER_2", Coordinate(5.0, 5.0))
    )
    private val beaconsFromFloorNumber0 = beacons.filter { it.floorNumber == FLOOR_NUMBER_0 }
    private val beaconsFromFloorNumber1 = beacons.filter { it.floorNumber == FLOOR_NUMBER_1 }

    @Test
    fun testGetBeaconsWhenNothingWasSaved() {
        beaconsCache.getBeacons(floorNumbers)
                .test()
                .assertComplete()
                .assertNoValues()
    }

    @Test
    fun testGetFloorNumbersWhenNothingWasSaved() {
        beaconsCache.getFloorNumbers()
                .test()
                .assertComplete()
                .assertNoValues()
    }

    @Test
    fun testGetBeaconsAfterEmptyBeaconsListWasSaved() {
        beaconsCache.put(emptyList())
                .andThen(beaconsCache.getBeacons(floorNumbers))
                .test()
                .assertComplete()
                .assertNoValues()
    }

    @Test
    fun testGetFloorNumbersAfterEmptyBeaconsListWasSaved() {
        beaconsCache.put(emptyList())
                .andThen(beaconsCache.getFloorNumbers())
                .test()
                .assertComplete()
                .assertNoValues()
    }

    @Test
    fun testGetAllBeaconsAfterPutAllBeacons() {
        beaconsCache.put(beacons)
                .andThen(beaconsCache.getBeacons(floorNumbers))
                .test()
                .assertComplete()
                .assertValue(beacons)
    }

    @Test
    fun testGetFloorNumbersAfterPutAllBeacons() {
        beaconsCache.put(beacons)
                .andThen(beaconsCache.getFloorNumbers())
                .test()
                .assertComplete()
                .assertValue(floorNumbers)
    }

    @Test
    fun testGetSomeBeaconsAfterPutAllBeacons() {
        beaconsCache.put(beacons)
                .andThen(beaconsCache.getBeacons(listOf(FLOOR_NUMBER_0, FLOOR_NUMBER_1)))
                .test()
                .assertComplete()
                .assertValue(beaconsFromFloorNumber0 + beaconsFromFloorNumber1)
    }

    @Test
    fun testGetBeaconsFromOneFloorAfterPutAllBeacons() {
        beaconsCache.put(beacons)
                .andThen(beaconsCache.getBeacons(listOf(FLOOR_NUMBER_1)))
                .test()
                .assertComplete()
                .assertValue(beaconsFromFloorNumber1)
    }

    @Test
    fun testGetAllBeaconsAfterPutSomeBeacons() {
        beaconsCache.put(beaconsFromFloorNumber0)
                .andThen(beaconsCache.getBeacons(floorNumbers))
                .test()
                .assertComplete()
                .assertValue(beaconsFromFloorNumber0)
    }

    @Test
    fun testGetFloorNumbersAfterPutSomeBeacons() {
        beaconsCache.put(beaconsFromFloorNumber0)
                .andThen(beaconsCache.getFloorNumbers())
                .test()
                .assertComplete()
                .assertValue(listOf(FLOOR_NUMBER_0))
    }

    @Test
    fun testGetBeaconsFromOneFloorAfterPutBeaconsFromOtherFloor() {
        beaconsCache.put(beaconsFromFloorNumber0)
                .andThen(beaconsCache.getBeacons(listOf(FLOOR_NUMBER_1)))
                .test()
                .assertComplete()
                .assertNoValues()
    }

    @Test
    fun testClear() {
        beaconsCache.put(beacons)
                .andThen(beaconsCache.clear())
                .andThen(beaconsCache.getBeacons(floorNumbers))
                .test()
                .assertComplete()
                .assertNoValues()
    }

    @Test
    fun testClearWhenNothingWasSaved() {
        beaconsCache.clear()
                .andThen(beaconsCache.getBeacons(floorNumbers))
                .test()
                .assertComplete()
                .assertNoValues()
    }

    companion object {
        const val FLOOR_NUMBER_0 = 0
        const val FLOOR_NUMBER_1 = 1
        const val FLOOR_NUMBER_2 = 2
    }
}
