package com.epam.beacons.storage.mappers.from;

import com.epam.beacons.Beacon;
import com.epam.beacons.Coordinate;
import com.epam.beacons.storage.entities.StorageBeacon;
import com.epam.beacons.storage.entities.StorageCoordinate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(Parameterized.class)
public class StorageBeaconToBeaconMapperTest {

    @Mock
    private StorageCoordinateToCoordinateMapper coordinateMapper;
    @InjectMocks
    private StorageBeaconToBeaconMapper         beaconMapper;

    private final StorageBeacon storageBeacon;
    private final Beacon        expectedBeacon;

    public StorageBeaconToBeaconMapperTest(StorageBeacon storageBeacon, Beacon expectedBeacon) {
        this.storageBeacon = storageBeacon;
        this.expectedBeacon = expectedBeacon;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        new StorageBeacon("0", 0, "uuid", "1", 1,1,
                                          new StorageCoordinate(0, 0)
                        ),
                        new Beacon("uuid", 1, 1, "1", new Coordinate(0, 0))
                },
                {
                        new StorageBeacon("10", 100, "another", "50", 50, 70,
                                          new StorageCoordinate(10, 5)
                        ),
                        new Beacon("another", 50, 70, "1", new Coordinate(10, 5))
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        when(coordinateMapper.map(storageBeacon.getCoordinate()))
                .thenAnswer(invocation -> {
                    final StorageCoordinate storageCoordinate = invocation.getArgument(0);
                    return new Coordinate(storageCoordinate.getLatitude(), storageCoordinate.getLongitude());
                });
    }

    @Test
    public void testMap() {
        assertEqualsForAllFields(expectedBeacon, beaconMapper.map(storageBeacon));
    }

    @Test
    public void testMapOnList() {
        final List<Beacon> beacons = beaconMapper.map(Collections.singletonList(storageBeacon));
        assertEquals(1, beacons.size());
        assertEqualsForAllFields(expectedBeacon, beacons.get(0));
    }

    private void assertEqualsForAllFields(Beacon expectedBeacon, Beacon beacon) {
        assertEquals(expectedBeacon, beacon);
        assertEquals(expectedBeacon.getUuid(), beacon.getUuid());
        assertEquals(expectedBeacon.getMajor(), beacon.getMajor());
        assertEquals(expectedBeacon.getMinor(), beacon.getMinor());
        assertEquals(expectedBeacon.getCoordinate(), beacon.getCoordinate());
        assertEquals(expectedBeacon.getRssi(), beacon.getRssi());
        assertEquals(expectedBeacon.getTxPower(), beacon.getTxPower(), 0);
    }
}
