package com.epam.beacons.storage.mappers.to;

import com.epam.beacons.Coordinate;
import com.epam.beacons.storage.entities.StorageCoordinate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class CoordinateToStorageCoordinateMapperTest {

    @InjectMocks
    private CoordinateToStorageCoordinateMapper coordinateMapper;

    private final Coordinate        coordinate;
    private final StorageCoordinate expected;

    public CoordinateToStorageCoordinateMapperTest(Coordinate coordinate, StorageCoordinate expected) {
        this.coordinate = coordinate;
        this.expected = expected;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        new Coordinate(0, 0),
                        new StorageCoordinate(0, 0)
                },
                {
                        new Coordinate(-5, 5),
                        new StorageCoordinate(-5, 5)
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testMap() {
        assertEqualsForAllFields(expected, coordinateMapper.map(coordinate));
    }

    @Test
    public void testMapOnList() {
        final List<StorageCoordinate> storageCoordinates = coordinateMapper.map(
                Collections.singletonList(coordinate));
        assertEquals(1, storageCoordinates.size());
        assertEqualsForAllFields(expected, storageCoordinates.get(0));
    }

    private void assertEqualsForAllFields(StorageCoordinate expected, StorageCoordinate coordinate) {
        assertEquals(expected, coordinate);
        assertEquals(expected.getLatitude(), coordinate.getLatitude(), 0);
        assertEquals(expected.getLongitude(), coordinate.getLongitude(), 0);
    }
}
