package com.epam.beacons.storage.cache

import com.epam.beacons.Coordinate
import com.epam.beacons.Place
import org.junit.Test

class FavoritePlacesCacheImplTest {

    private val cache = FavoritePlacesCacheImpl()
    private val fakePlaces = arrayListOf(
            Place("0", "type0", "desc0", Coordinate(1.0, 2.0), 1),
            Place("1", "type1", "desc1", Coordinate(5.0, 7.0), 2),
            Place("2", "type2", "desc2", Coordinate(1.1, 29.0), 3),
            Place("3", "type3", "desc3", Coordinate(1.5, 25.0), 4),
            Place("4", "type4", "desc4", Coordinate(1.60, 2.50), 5)
    )
    private val fakePlacesIds = fakePlaces.map { it.id }

    @Test
    fun `test put and get place`() {
        cache.put(fakePlaces[0])
                .andThen(cache.get())
                .test()
                .assertValue(listOf(fakePlaces[0]))
                .assertComplete()

        assertIsInitialized(false)
    }

    @Test
    fun `test put and get places`() {
        cache.put(fakePlaces)
                .andThen(cache.get())
                .test()
                .assertValues(fakePlaces)
                .assertComplete()

        cache.ids.test()
                .assertValues(fakePlacesIds)
                .assertComplete()

        assertIsInitialized(true)
    }

    @Test
    fun `test put and get places ids`() {
        cache.putIds(fakePlacesIds)
                .andThen(cache.ids)
                .test()
                .assertValues(fakePlacesIds)
                .assertComplete()

        assertIsInitialized(false)
    }

    @Test
    fun `test remove place by id`() {
        cache.put(fakePlaces[0])
                .andThen(cache.put(fakePlaces[1]))
                .andThen(cache.remove("0"))
                .andThen(cache.get())
                .test()
                .assertValue(listOf(fakePlaces[1]))
                .assertComplete()

        cache.ids.test()
                .assertValue(listOf(fakePlacesIds[1]))
                .assertComplete()

        assertIsInitialized(true)
    }

    @Test
    fun `test put same place twice without duplicate`() {
        cache.put(fakePlaces[0])
                .andThen(cache.put(fakePlaces[0]))
                .andThen(cache.get())
                .test()
                .assertValue(listOf(fakePlaces[0]))
                .assertComplete()

        assertIsInitialized(false)
    }

    @Test
    fun `test clear place list`() {
        cache.put(fakePlaces)
                .andThen(cache.clear())
                .andThen(cache.get())
                .test()
                .assertNoValues()
                .assertComplete()

        assertIsInitialized(false)
    }

    @Test
    fun `test is place list empty`() {
        cache.put(emptyList())
                .andThen(cache.isEmpty)
                .test()
                .assertValue({ it })
                .assertComplete()

        assertIsInitialized(true)
    }

    @Test
    fun `test remove nonexistent place`() {
        cache.put(fakePlaces[0])
                .andThen(cache.remove("1"))
                .andThen(cache.get())
                .test()
                .assertValue(listOf(fakePlaces[0]))
                .assertComplete()

        assertIsInitialized(true)
    }

    @Test
    fun `test get empty ids`() {
        cache.ids
                .test()
                .assertNoValues()
                .assertComplete()

        assertIsInitialized(false)
    }

    @Test
    fun `test get empty places`() {
        cache.get()
                .test()
                .assertNoValues()
                .assertComplete()

        assertIsInitialized(false)
    }

    private fun assertIsInitialized(initialized: Boolean) {
        cache.isInitialized
                .test()
                .assertValue { it == initialized }
                .assertComplete()
    }
}
