package com.epam.beacons.storage.mappers.to;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Gate;
import com.epam.beacons.storage.entities.StorageGate;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class GateToStorageGateMapperTest {

    @InjectMocks
    private GateToStorageGateMapper gateMapper;

    private final Gate gate;
    private final StorageGate expected;

    public GateToStorageGateMapperTest(Gate gate, StorageGate expected) {
        this.gate = gate;
        this.expected = expected;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        new Gate(1, "2", "image", "type",
                                 new HashMap<Integer, Coordinate>() {{
                                     put(5, new Coordinate(1, 2));
                                 }}
                        ),
                        new StorageGate(1, "2", "image", "type")
                },
                {
                        new Gate(2, "3", null, "type2",
                                 new HashMap<Integer, Coordinate>() {{
                                     put(6, new Coordinate(3, 4));
                                 }}
                        ),
                        new StorageGate(2, "3", null, "type2")
                },
                {
                        new Gate(3, "4", "image4", "type4",
                                 new HashMap<Integer, Coordinate>() {{
                                     put(7, new Coordinate(5, 6));
                                     put(8, new Coordinate(7, 8));
                                     put(9, new Coordinate(9, 10));
                                 }}
                        ),
                        new StorageGate(3, "4", "image4", "type4")
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testMap() {
        assertEqualsForAllFields(expected, gateMapper.map(gate));
    }

    @Test
    public void testMapOnList() {
        final List<StorageGate> storageGates = gateMapper.map(Collections.singletonList(gate));
        assertEquals(1, storageGates.size());
        assertEqualsForAllFields(expected, storageGates.get(0));
    }

    private void assertEqualsForAllFields(StorageGate expected, StorageGate gate) {
        assertEquals(expected, gate);
        assertEquals(expected.getId(), gate.getId());
        assertEquals(expected.getBuildingId(), gate.getBuildingId());
        assertEquals(expected.getImage(), gate.getImage());
        assertEquals(expected.getType(), gate.getType());
    }
}
