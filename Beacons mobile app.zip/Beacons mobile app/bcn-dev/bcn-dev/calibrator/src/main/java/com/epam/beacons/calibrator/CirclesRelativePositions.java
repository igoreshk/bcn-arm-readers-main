package com.epam.beacons.calibrator;

public enum CirclesRelativePositions {
    NO_INTERSECTION, ONE_POINT_INTERSECTION, INTERSECTION_AREA
}
