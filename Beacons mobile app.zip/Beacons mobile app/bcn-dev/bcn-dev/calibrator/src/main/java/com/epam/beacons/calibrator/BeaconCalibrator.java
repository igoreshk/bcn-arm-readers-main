package com.epam.beacons.calibrator;

import androidx.annotation.NonNull;

import com.epam.beacons.Beacon;
import com.epam.beacons.Coordinate;
import com.epam.beacons.Pivot;
import com.epam.beacons.calibrator.exceptions.BeaconsWithoutCoordinatesException;
import com.epam.beacons.calibrator.exceptions.InsufficientBeaconsCountException;
import com.epam.beacons.distance.DistanceCalculator;
import com.epam.beacons.tools.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Completable;

@Singleton
public class BeaconCalibrator {
    @NonNull
    private static final String LOG_TAG = BeaconCalibrator.class.getSimpleName();

    private static final int    BEACONS_COUNT       = 3;
    private static final double DELTA               = 1e-3;
    private static final int    MAX_ITERATIONS      = 100;
    private static final int    HIGH_TXPOWER_BORDER = 0;
    private static final int    LOW_TXPOWER_BORDER  = -200;
    private static final double TX_POWER_NOT_FOUND  = Double.NaN;

    @NonNull
    private final DistanceCalculator distanceCalculator;
    @NonNull
    private final Logger             logger;

    private double txPowerApproximation = 0;
    private long   approximationsCount  = 0;

    @Inject
    BeaconCalibrator(@NonNull DistanceCalculator distanceCalculator, @NonNull Logger logger) {
        this.distanceCalculator = distanceCalculator;
        this.logger = logger;
    }

    /* All beacons should have the same txPower */
    @NonNull
    public List<Beacon> calibrateTxPower(@NonNull List<Beacon> beacons) {
        if (beacons.size() < BEACONS_COUNT) {
            logger.w(LOG_TAG, String.format(
                    Locale.ENGLISH,
                    "Beacons list should contain %d items to make txPower approximation",
                    BEACONS_COUNT
            ));
            return adjustTxPower(beacons);
        }

        List<Beacon> accountedBeacons = new ArrayList<>(beacons);
        Collections.sort(accountedBeacons);
        accountedBeacons = accountedBeacons.subList(0, BEACONS_COUNT);

        final List<Coordinate> coords = new ArrayList<>(BEACONS_COUNT);
        for (Beacon beacon : accountedBeacons) {
            Coordinate coordinate = beacon.getCoordinate();
            if (coordinate == null) {
                logger.w(LOG_TAG, "Beacons should have coordinates to make txPower approximation");
                return adjustTxPower(beacons);
            }
            coords.add(coordinate);
        }

        // check of each pair
        for (int i = 0; i < BEACONS_COUNT; i++) {
            for (int j = i + 1; j < BEACONS_COUNT; j++) {
                if (coords.get(i).equals(coords.get(j))) {
                    logger.w(LOG_TAG, "Beacons should have unique coordinates to make txPower approximation");
                    return adjustTxPower(beacons);
                }
            }
        }

        final double txPower = approximateTxPower(accountedBeacons);

        if (isTxPowerFound(txPower)) {
            txPowerApproximation = (approximationsCount * txPowerApproximation + txPower) / ++approximationsCount;
        }

        return adjustTxPower(beacons);
    }

    @NonNull
    public Completable resetApproximation() {
        return Completable.fromAction(() -> {
            txPowerApproximation = 0;
            approximationsCount = 0;
        });
    }

    private double approximateTxPower(@NonNull List<Beacon> beacons) {
        if (beacons.size() < BEACONS_COUNT) {
            throw new InsufficientBeaconsCountException();
        }

        final List<Pivot> pivots = new ArrayList<>();
        for (Beacon beacon : beacons) {
            if (beacon.getCoordinate() == null) {
                throw new BeaconsWithoutCoordinatesException();
            }
            pivots.add(new Pivot(beacon.getCoordinate(), 0));
        }

        double highTxPower = HIGH_TXPOWER_BORDER;
        double lowTxpower = LOW_TXPOWER_BORDER;
        double currentTxPower;

        for (int iteration = 0; iteration < MAX_ITERATIONS; iteration++) {
            currentTxPower = lowTxpower + (highTxPower - lowTxpower) / 2;
            for (int i = 0; i < BEACONS_COUNT; i++) {
                final double distance = distanceCalculator.calculateDistance(
                        currentTxPower,
                        beacons.get(i).getRssi()
                );
                if (distance < 0) {
                    throw new IllegalStateException("Distance to beacon can not be negative");
                }
                pivots.get(i).setDistance(distance);
            }
            final CirclesRelativePositions position = getCirclesRelativePosition(pivots, true);
            switch (position) {
                case ONE_POINT_INTERSECTION:
                    return currentTxPower;
                case NO_INTERSECTION:
                    lowTxpower = currentTxPower;
                    break;
                case INTERSECTION_AREA:
                    highTxPower = currentTxPower;
                    break;
                default:
                    break;
            }
            iteration++;
        }

        return TX_POWER_NOT_FOUND;
    }

    @NonNull
    private List<Beacon> adjustTxPower(@NonNull List<Beacon> beacons) {
        if (Double.compare(txPowerApproximation, 0) != 0) {
            for (Beacon beacon : beacons) {
                beacon.setTxPower(txPowerApproximation);
            }
        }
        return beacons;
    }

    @NonNull
    private CirclesRelativePositions getCirclesRelativePosition(@NonNull List<Pivot> pivots,
                                                                boolean isFirstCall) {
        if (pivots.size() < BEACONS_COUNT) {
            throw new InsufficientBeaconsCountException();
        }

        final Pivot pivot1 = pivots.get(0);
        final Pivot pivot2 = isFirstCall ? pivots.get(1) : pivots.get(2);
        final Pivot pivot3 = isFirstCall ? pivots.get(2) : pivots.get(1);

        if (haveNoIntersectionInPairs(pivots)) {
            return CirclesRelativePositions.NO_INTERSECTION;
        }

        final List<Coordinate> intersectionPoints = getCirclesIntersectionPoints(pivot1, pivot2);

        if (intersectionPoints.isEmpty()) {
            return CirclesRelativePositions.INTERSECTION_AREA;
        }

        for (Coordinate coord : intersectionPoints) {
            if (isPointOnCircle(coord, pivot3) && isPointInTriangle(coord, pivots)) {
                return CirclesRelativePositions.ONE_POINT_INTERSECTION;
            }
        }

        for (Coordinate coord : intersectionPoints) {
            if (isPointInCircle(coord, pivot3)) {
                return CirclesRelativePositions.INTERSECTION_AREA;
            }
        }

        return isFirstCall ? getCirclesRelativePosition(pivots, false) :
                CirclesRelativePositions.NO_INTERSECTION;
    }

    private boolean isPointInCircle(@NonNull Coordinate coordinate, @NonNull Pivot pivot) {
        return getDistanceBetween(coordinate, pivot.getCoordinate()) < pivot.getDistance();
    }

    private boolean isPointOnCircle(@NonNull Coordinate coordinate, @NonNull Pivot pivot) {
        return areEqual(
                pivot.getDistance(),
                getDistanceBetween(pivot.getCoordinate(), coordinate)
        );
    }

    private boolean haveNoIntersectionInPairs(@NonNull List<Pivot> pivots) {
        for (int i = 0; i < pivots.size(); i++) {
            for (int j = i + 1; j < pivots.size(); j++) {
                if (haveIntersection(pivots.get(i), pivots.get(j))) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean haveIntersection(@NonNull Pivot pivot1, @NonNull Pivot pivot2) {
        return getDistanceBetween(pivot1.getCoordinate(), pivot2.getCoordinate()) <
                pivot1.getDistance() + pivot2.getDistance();
    }

    private boolean areCirclesNested(@NonNull Pivot pivot1, @NonNull Pivot pivot2) {
        return getDistanceBetween(pivot1.getCoordinate(), pivot2.getCoordinate()) <
                Math.abs(pivot1.getDistance() - pivot2.getDistance());
    }

    @NonNull
    private List<Coordinate> getCirclesIntersectionPoints(@NonNull Pivot pivot1,
                                                          @NonNull Pivot pivot2) {
        if (areCirclesNested(pivot1, pivot2)) {
            return Collections.emptyList();
        }

        final Coordinate coord1 = pivot1.getCoordinate();
        final Coordinate coord2 = pivot2.getCoordinate();
        final double x1 = coord1.getLatitude();
        final double y1 = coord1.getLongitude();
        final double x2 = coord2.getLatitude();
        final double y2 = coord2.getLongitude();
        final double r1 = pivot1.getDistance();
        final double r2 = pivot2.getDistance();

        final double dist = getDistanceBetween(coord1, coord2);

        final double a = (r1 * r1 - r2 * r2 + dist * dist) / (2 * dist);
        final double xc = x1 + a * (x2 - x1) / dist;
        final double yc = y1 + a * (y2 - y1) / dist;

        if (areEqual(a, r1)) {
            return Collections.singletonList(new Coordinate(xc, yc));
        }

        final double h = Math.sqrt(r1 * r1 - a * a);

        final double xr1 = xc + h * (y2 - y1) / dist;
        final double yr1 = yc - h * (x2 - x1) / dist;
        final double xr2 = xc - h * (y2 - y1) / dist;
        final double yr2 = yc + h * (x2 - x1) / dist;

        return Arrays.asList(
                new Coordinate(xr1, yr1),
                new Coordinate(xr2, yr2)
        );
    }

    private boolean isPointInTriangle(@NonNull Coordinate coordinate, @NonNull List<Pivot> pivots) {
        if (pivots.size() < BEACONS_COUNT) {
            throw new InsufficientBeaconsCountException();
        }

        final Coordinate vertex1 = pivots.get(0).getCoordinate();
        final Coordinate vertex2 = pivots.get(1).getCoordinate();
        final Coordinate vertex3 = pivots.get(2).getCoordinate();

        final double areaABC = getTriangleArea(vertex1, vertex2, vertex3);
        final double areaABD = getTriangleArea(vertex1, vertex2, coordinate);
        final double areaBCD = getTriangleArea(vertex2, vertex3, coordinate);
        final double areaACD = getTriangleArea(vertex1, vertex3, coordinate);

        return areEqual(areaABD + areaBCD + areaACD, areaABC);
    }

    private double getTriangleArea(@NonNull Coordinate coordinate1,
                                   @NonNull Coordinate coordinate2,
                                   @NonNull Coordinate coordinate3) {
        final double xA = coordinate1.getLatitude();
        final double yA = coordinate1.getLongitude();
        final double xB = coordinate2.getLatitude();
        final double yB = coordinate2.getLongitude();
        final double xC = coordinate3.getLatitude();
        final double yC = coordinate3.getLongitude();

        final double xAB = xB - xA;
        final double yAB = yB - yA;
        final double xAC = xC - xA;
        final double yAC = yC - yA;

        return Math.abs((xAB * yAC - xAC * yAB) / 2);
    }

    private double getDistanceBetween(@NonNull Coordinate coordinate1,
                                      @NonNull Coordinate coordinate2) {
        return Math.sqrt(
                Math.pow(coordinate2.getLatitude() - coordinate1.getLatitude(), 2) +
                        Math.pow(coordinate2.getLongitude() - coordinate1.getLongitude(), 2));
    }

    private boolean areEqual(double first, double second) {
        return Math.abs(first - second) <= DELTA;
    }

    private boolean isTxPowerFound(double txPower) {
        return !Double.isNaN(txPower);
    }
}
