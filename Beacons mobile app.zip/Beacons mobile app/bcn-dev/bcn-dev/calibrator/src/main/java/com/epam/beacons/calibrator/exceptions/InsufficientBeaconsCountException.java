package com.epam.beacons.calibrator.exceptions;

@SuppressWarnings("unused")
public class InsufficientBeaconsCountException extends IllegalStateException {
    public InsufficientBeaconsCountException() {
        super();
    }

    public InsufficientBeaconsCountException(String s) {
        super(s);
    }

    public InsufficientBeaconsCountException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public InsufficientBeaconsCountException(Throwable throwable) {
        super(throwable);
    }
}
