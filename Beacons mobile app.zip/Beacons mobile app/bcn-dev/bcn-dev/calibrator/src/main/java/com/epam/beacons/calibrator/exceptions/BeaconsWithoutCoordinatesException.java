package com.epam.beacons.calibrator.exceptions;

@SuppressWarnings("unused")
public class BeaconsWithoutCoordinatesException extends IllegalStateException {
    public BeaconsWithoutCoordinatesException() {
        super();
    }

    public BeaconsWithoutCoordinatesException(String s) {
        super(s);
    }

    public BeaconsWithoutCoordinatesException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public BeaconsWithoutCoordinatesException(Throwable throwable) {
        super(throwable);
    }
}
