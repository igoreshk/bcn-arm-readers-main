package com.epam.beacons.calibrator;

import com.epam.beacons.Beacon;
import com.epam.beacons.Coordinate;
import com.epam.beacons.distance.DistanceCalculator;
import com.epam.beacons.tools.Logger;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static java.lang.Math.abs;
import static org.junit.Assert.assertTrue;

@RunWith(Parameterized.class)
public class BeaconCalibratorTest {

    private static final double DELTA = 1e-3;

    private static final DistanceCalculator mockedDistanceCalculator =
            (referenceSignal, currentSignal) -> currentSignal / referenceSignal;
    @Mock
    private Logger logger;

    private final List<Beacon>     beacons;
    private final List<Coordinate> coordinates;
    private final double           expectedTxPower;

    public BeaconCalibratorTest(List<Beacon> beacons,
                                List<Coordinate> coordinates,
                                double expectedTxPower) {
        this.beacons = beacons;
        this.coordinates = coordinates;
        this.expectedTxPower = expectedTxPower;
    }

    // tool for graphical representation: desmos.com/calculator
    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        Arrays.asList(
                                new Beacon("b1", 1, 1, -50, -55),
                                new Beacon("b2", 2, 2, -50, -58),
                                new Beacon("b3", 3, 3, -50, -60)
                        ),
                        Arrays.asList(
                                new Coordinate(3, 2),
                                new Coordinate(1, 2),
                                new Coordinate(1, 1)
                        ),
                        -51.416
                },
                {
                        Arrays.asList(
                                new Beacon("b3", 3, 3, -50, -100500),
                                new Beacon("b1", 1, 1, -50, -55),
                                new Beacon("b2", 2, 2, -50, -58),
                                new Beacon("b3", 3, 3, -50, -60)
                        ),
                        Arrays.asList(
                                new Coordinate(100, 100),
                                new Coordinate(3, 2),
                                new Coordinate(1, 2),
                                new Coordinate(1, 1)
                        ),
                        -51.416
                },
                {
                        Arrays.asList(
                                new Beacon("b1", 1, 1, -50, -55),
                                new Beacon("b2", 2, 2, -50, -55),
                                new Beacon("b3", 3, 3, -50, -55)
                        ),
                        Arrays.asList(
                                new Coordinate(0, 0),
                                new Coordinate(10, 10),
                                new Coordinate(0, 10)
                        ),
                        -7.778
                },
                {
                        Arrays.asList(
                                new Beacon("b1", 1, 1, -50, -90),
                                new Beacon("b2", 1, 2, -50, -91),
                                new Beacon("b3", 2, 1, -50, -92)
                        ),
                        Arrays.asList(
                                new Coordinate(3, 2),
                                new Coordinate(1, 2),
                                new Coordinate(1, 1)
                        ),
                        -81.396
                },
                {
                        Arrays.asList(
                                new Beacon("b1", 1, 1, -70, -2),
                                new Beacon("b2", 1, 2, -70, -2),
                                new Beacon("b3", 2, 1, -70, -2)
                        ),
                        Arrays.asList(
                                new Coordinate(3, 2),
                                new Coordinate(1, 2),
                                new Coordinate(1, 1)
                        ),
                        -1.789
                },
                {
                        Arrays.asList(
                                new Beacon("b1", 1, 1, -40, -45),
                                new Beacon("b2", 1, 2, -40, -50),
                                new Beacon("b3", 2, 1, -40, -51)
                        ),
                        Arrays.asList(
                                new Coordinate(-5, -3),
                                new Coordinate(15, 21),
                                new Coordinate(-17, 16)
                        ),
                        -2.872
                },
                {
                        Arrays.asList(
                                new Beacon("b1", 1, 1, -40, -1),
                                new Beacon("b2", 1, 2, -40, -2),
                                new Beacon("b3", 2, 1, -40, -3)
                        ),
                        Arrays.asList(
                                new Coordinate(-5, -3),
                                new Coordinate(15, 21),
                                new Coordinate(-17, 16)
                        ),
                        -40
                },
                {
                        Arrays.asList(
                                new Beacon("b1", 1, 1, -40, -60),
                                new Beacon("b2", 1, 2, -40, -45),
                                new Beacon("b3", 2, 1, -40, -59)
                        ),
                        Arrays.asList(
                                new Coordinate(1, 1),
                                new Coordinate(1, 2),
                                new Coordinate(7, 7)
                        ),
                        -40
                },
                {
                        Arrays.asList(
                                new Beacon("b1", 1, 1, -40, -1),
                                new Beacon("b2", 1, 2, -40, -100500),
                                new Beacon("b3", 2, 1, -40, -100500)
                        ),
                        Arrays.asList(
                                new Coordinate(3, 2),
                                new Coordinate(1, 2),
                                new Coordinate(1, 1)
                        ),
                        -40
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        for (int i = 0; i < beacons.size(); i++) {
            beacons.get(i).setCoordinate(coordinates.get(i));
        }
    }

    @Test
    public void testBeaconCalibrator() {
        BeaconCalibrator calibrator = new BeaconCalibrator(mockedDistanceCalculator, logger);
        List<Beacon> result = calibrator.calibrateTxPower(beacons);
        for (Beacon beacon : result) {
            assertTrue(abs(expectedTxPower - beacon.getTxPower()) < DELTA);
        }
    }
}
