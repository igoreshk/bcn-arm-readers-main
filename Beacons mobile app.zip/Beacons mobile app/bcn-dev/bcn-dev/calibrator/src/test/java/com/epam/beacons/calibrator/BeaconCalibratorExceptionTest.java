package com.epam.beacons.calibrator;

import com.epam.beacons.Beacon;
import com.epam.beacons.Coordinate;
import com.epam.beacons.distance.DistanceCalculator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BeaconCalibratorExceptionTest {

    @Mock
    private DistanceCalculator distanceCalculator;
    @InjectMocks
    private BeaconCalibrator   calibrator;

    private static final List<Beacon>     beacons     = Arrays.asList(
            new Beacon("b1", 1, 1, -50, -55),
            new Beacon("b2", 2, 2, -50, -58),
            new Beacon("b3", 3, 3, -50, -60)
    );
    private static final List<Coordinate> coordinates = Arrays.asList(
            new Coordinate(3, 2),
            new Coordinate(1, 2),
            new Coordinate(1, 1)
    );

    @Before
    public void setUp() {
        for (int i = 0; i < beacons.size(); i++) {
            beacons.get(i).setCoordinate(coordinates.get(i));
        }
    }

    @Test(expected = IllegalStateException.class)
    public void testNegativeDistances() {
        when(distanceCalculator.calculateDistance(anyDouble(), anyDouble()))
                .thenReturn(-1.0);

        calibrator.calibrateTxPower(beacons);
    }
}
