package com.epam.beacons.calibrator;

import com.epam.beacons.Beacon;
import com.epam.beacons.Coordinate;
import com.epam.beacons.tools.Logger;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;

@RunWith(Parameterized.class)
public class BeaconCalibratorErrorsTest {

    @Mock
    private Logger           logger;
    @InjectMocks
    private BeaconCalibrator calibrator;

    private final List<Beacon>     beacons;
    private final List<Coordinate> coordinates;

    public BeaconCalibratorErrorsTest(List<Beacon> beacons, List<Coordinate> coordinates) {
        this.beacons = beacons;
        this.coordinates = coordinates;
    }

    @Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {
                        // beacons count < 3
                        Arrays.asList(
                                new Beacon("b1", 1, 1, -50, -50),
                                new Beacon("b2", 2, 2, -50, -50)
                        ),
                        Arrays.asList(
                                new Coordinate(1, 1),
                                new Coordinate(2, 2)
                        )
                },
                {
                        // beacons without coordinates
                        Arrays.asList(
                                new Beacon("b1", 1, 1, -50, -50),
                                new Beacon("b2", 2, 2, -50, -50),
                                new Beacon("b3", 3, 3, -50, -50)
                        ),
                        Collections.emptyList()
                },
                {
                        // beacons with non-unique coordinates
                        Arrays.asList(
                                new Beacon("b1", 1, 1, -50, -50),
                                new Beacon("b2", 2, 2, -50, -50),
                                new Beacon("b3", 3, 3, -50, -50)
                        ),
                        Arrays.asList(
                                new Coordinate(1, 1),
                                new Coordinate(1, 1),
                                new Coordinate(1, 1)
                        )
                }
        });
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        int minSize = Math.min(beacons.size(), coordinates.size());
        for (int i = 0; i < minSize; i++) {
            beacons.get(i).setCoordinate(coordinates.get(i));
        }
    }

    @Test
    public void testBeaconCalibratorErrors() {
        List<Beacon> result = calibrator.calibrateTxPower(
                // we need new instance because calibrator can change initial list
                new ArrayList<>(beacons));

        // check if logger was called
        verify(logger).w(anyString(), anyString());

        assertEquals(beacons, result);
        for (int i = 0; i < beacons.size(); i++) {
            // we need additional checks because equals() of Beacon compares only by uuid, major, minor
            assertEquals(beacons.get(i).getTxPower(), result.get(i).getTxPower(), 0);
            assertEquals(beacons.get(i).getRssi(), result.get(i).getRssi());
            if (coordinates.size() > i) {
                assertEquals(coordinates.get(i), result.get(i).getCoordinate());
            }
        }
    }
}
