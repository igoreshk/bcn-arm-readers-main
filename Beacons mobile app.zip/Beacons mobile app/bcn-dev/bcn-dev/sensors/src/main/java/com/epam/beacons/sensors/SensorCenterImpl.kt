package com.epam.beacons.sensors

import com.epam.beacons.kalman.SensorCenter
import io.reactivex.Observable
import io.reactivex.Observable.combineLatest
import io.reactivex.functions.Function3
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The implementation gets raw sensors data from [Sensors], smoothes it with [SensorSmoother] and applies [AccelerationResolver] to smoothed data.
 */
@Singleton
class SensorCenterImpl @Inject constructor(
        private val listener: SensorsListener,
        private val accelerationResolver: AccelerationResolver,
        private val sensorSmoother: SensorSmoother
) : SensorCenter {

    override fun getSensorData(): Observable<FloatArray> = combineLatest(
            sensorSmoother.smooth(listener.getLinearAccel()),
            sensorSmoother.smooth(listener.getMagnetic()),
            sensorSmoother.smooth(listener.getGravity()),
            Function3<FloatArray, FloatArray, FloatArray, FloatArray> { l, m, g -> accelerationResolver.getAccelInEarthSystem(l, m, g) })
}
