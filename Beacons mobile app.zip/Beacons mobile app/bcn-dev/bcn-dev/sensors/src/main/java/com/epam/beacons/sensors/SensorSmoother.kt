package com.epam.beacons.sensors

import com.epam.beacons.sensors.utils.addTo
import io.reactivex.Observable
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Smooths frequent values coming from [Sensors] by getting an average value of them in a period equals to the interval between
 * incoming data from non-frequent source.
 */
@Singleton
class SensorSmoother @Inject constructor(private val scanningPeriod: Long) {

    /**
     * Buffers incoming raw data for [scanningPeriod] milliseconds and then provides average value.
     */
    fun smooth(input: Observable<FloatArray>): Observable<FloatArray> = input.buffer(scanningPeriod, TimeUnit.MILLISECONDS)
            .map {
                val tempArr = FloatArray(NUMBER_OF_SENSORS)
                it.forEach { arr -> arr addTo tempArr }
                for (el in tempArr) {
                    val ind = tempArr.indexOf(el)
                    tempArr[ind] = el / it.size
                }
                tempArr
            }

    companion object {
        const val NUMBER_OF_SENSORS = 3
    }
}
