package com.epam.beacons.sensors.utils

import android.opengl.Matrix

fun FloatArray.invert(): FloatArray {
    val output = FloatArray(this.size)
    Matrix.invertM(output, 0, this, 0)
    return output
}

infix fun FloatArray.addTo(output: FloatArray) {
    indices.forEach { i -> output[i] += this[i] }
}
