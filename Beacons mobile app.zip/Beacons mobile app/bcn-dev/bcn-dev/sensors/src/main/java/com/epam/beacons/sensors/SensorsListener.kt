package com.epam.beacons.sensors

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Custom listener for sensors events only. Simply puts all incoming values from sensors into subjects' onNext().
 * Sends data without any processing.
 */
@Singleton
class SensorsListener @Inject constructor() : SensorEventListener {

    private val linearAccelSubject: PublishSubject<FloatArray> = PublishSubject.create<FloatArray>()
    private val gravitySubject: PublishSubject<FloatArray> = PublishSubject.create<FloatArray>()
    private val magneticSubject: PublishSubject<FloatArray> = PublishSubject.create<FloatArray>()

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) { // empty implementation
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_LINEAR_ACCELERATION -> linearAccelSubject.onNext(event.values)
            Sensor.TYPE_GRAVITY -> gravitySubject.onNext(event.values)
            Sensor.TYPE_MAGNETIC_FIELD -> magneticSubject.onNext(event.values)
            else -> return
        }
    }

    /**
     * @return [linearAccelSubject] as [Observable]
     */
    fun getLinearAccel(): Observable<FloatArray> = linearAccelSubject

    /**
     * @return [gravitySubject] as [Observable]
     */
    fun getGravity(): Observable<FloatArray> = gravitySubject

    /**
     * @return [magneticSubject] as [Observable]
     */
    fun getMagnetic(): Observable<FloatArray> = magneticSubject
}
