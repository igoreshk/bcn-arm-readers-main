package com.epam.beacons.sensors

import android.hardware.Sensor
import android.hardware.SensorManager
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Contains three sensors inside, responsible their register, unregister actions.
 */
@Singleton
class Sensors @Inject constructor(private val sensorManager: SensorManager?, private val listener: SensorsListener) {

    private val sensorLinAccel = sensorManager?.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
    private val sensorGravity = sensorManager?.getDefaultSensor(Sensor.TYPE_GRAVITY)
    private val sensorMaget = sensorManager?.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    /**
     * If [sensorManager] exists in the device, then registers listener for given sensors.
     */
    fun registerListeners() {
        sensorManager?.apply {
            registerListener(listener, sensorLinAccel, SensorManager.SENSOR_DELAY_NORMAL)
            registerListener(listener, sensorGravity, SensorManager.SENSOR_DELAY_NORMAL)
            registerListener(listener, sensorMaget, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    /**
     * If [sensorManager] exists in the device, then unregisters listener for given sensors.
     */
    fun unregisterListeners() {
        sensorManager?.apply {
            unregisterListener(listener, sensorLinAccel)
            unregisterListener(listener, sensorGravity)
            unregisterListener(listener, sensorMaget)
        }
    }
}
