package com.epam.beacons.sensors

import android.hardware.SensorManager
import android.opengl.Matrix
import com.epam.beacons.sensors.utils.invert
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Converts data from linear acceleration, gyroscope and magnetometer to acceleration by North, East and down.
 */
@Singleton
class AccelerationResolver @Inject constructor() {

    fun getAccelInEarthSystem(linAccelValues: FloatArray, magneticValues: FloatArray, gravityValues: FloatArray): FloatArray {
        val matrixR = FloatArray(MATRIX_SIZE)
        val matrixI = FloatArray(MATRIX_SIZE)
        val earthAccel = FloatArray(VECTOR_SIZE)
        val linAccelVector = FloatArray(VECTOR_SIZE)
        SensorManager.getRotationMatrix(matrixR, matrixI, gravityValues, magneticValues)
        val inverted = matrixR.invert()
        linAccelValues.indices.forEach { linAccelVector[it] = linAccelValues[it] }
        Matrix.multiplyMV(earthAccel, 0, inverted, 0, linAccelVector, 0)
        return earthAccel
    }

    private companion object {
        const val MATRIX_SIZE = 16
        const val VECTOR_SIZE = 4
    }
}
