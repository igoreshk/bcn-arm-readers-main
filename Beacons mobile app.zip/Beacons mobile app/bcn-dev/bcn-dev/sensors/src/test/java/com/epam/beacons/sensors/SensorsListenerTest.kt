package com.epam.beacons.sensors

import io.reactivex.Observable
import org.junit.Assert.assertTrue
import org.junit.Test

class SensorsListenerTest {

    private val listener = SensorsListener()

    @Test
    fun onAccuracyChanged() {
        listener.onAccuracyChanged(null, 0)
    }

    @Test
    fun testGetLinearAccel() {
        assertTrue(listener.getLinearAccel() is Observable<FloatArray>)
    }

    @Test
    fun testGetGravity() {
        assertTrue(listener.getGravity() is Observable<FloatArray>)
    }

    @Test
    fun testGetMagnetic() {
        assertTrue(listener.getMagnetic() is Observable<FloatArray>)
    }
}
