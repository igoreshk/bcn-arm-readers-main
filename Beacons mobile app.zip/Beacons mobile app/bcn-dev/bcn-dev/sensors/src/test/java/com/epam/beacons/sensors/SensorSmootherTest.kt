package com.epam.beacons.sensors

import io.reactivex.Observable
import org.junit.Assert.assertTrue
import org.junit.Test

class SensorSmootherTest {

    private val sensorSmoother = SensorSmoother(3000)

    @Test
    fun testSmooth() {
        val first = floatArrayOf(1f, 1f, 1f)
        val second = floatArrayOf(1.5f, 1.5f, 1.5f)
        val third = floatArrayOf(5f, 5f, 5f)
        val expected = floatArrayOf(2.5f, 2.5f, 2.5f)
        val subscriber = sensorSmoother.smooth(Observable.just(first, second, third))
                .test()
                .assertValueCount(1)
                .assertNoErrors()
        assertTrue(subscriber.values()[0] contentEquals expected)
    }
}
