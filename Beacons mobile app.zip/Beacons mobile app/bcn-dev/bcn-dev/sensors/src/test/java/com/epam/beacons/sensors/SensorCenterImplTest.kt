package com.epam.beacons.sensors

import com.epam.beacons.sensors.KotlinMockito.whn
import io.reactivex.Observable
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito.times
import org.mockito.Mockito.verify
import org.powermock.core.classloader.annotations.PrepareForTest
import org.powermock.modules.junit4.PowerMockRunner

@RunWith(PowerMockRunner::class)
@PrepareForTest(SensorsListener::class, AccelerationResolver::class, SensorSmoother::class)
class SensorCenterImplTest {

    @Mock
    private lateinit var accelerationResolver: AccelerationResolver
    @Mock
    private lateinit var listener: SensorsListener
    @Mock
    private lateinit var sensorSmoother: SensorSmoother

    @InjectMocks
    private lateinit var sensorCenterImpl: SensorCenterImpl

    @Test
    fun testGetSensorData() {
        val testArray = floatArrayOf(5f, 5f, 5f)
        val testArrayObservable = Observable.just(testArray)
        whn(listener.getLinearAccel()).thenReturn(testArrayObservable)
        whn(listener.getGravity()).thenReturn(testArrayObservable)
        whn(listener.getMagnetic()).thenReturn(testArrayObservable)
        whn(sensorSmoother.smooth(testArrayObservable)).thenReturn(testArrayObservable)
        whn(accelerationResolver.getAccelInEarthSystem(testArray, testArray, testArray)).thenReturn(testArray)
        sensorCenterImpl.getSensorData()
                .test()
                .assertValue(testArray)
        verify(sensorSmoother, times(3)).smooth(testArrayObservable)
    }
}
