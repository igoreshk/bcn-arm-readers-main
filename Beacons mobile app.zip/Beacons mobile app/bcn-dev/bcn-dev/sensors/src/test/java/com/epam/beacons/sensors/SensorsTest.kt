package com.epam.beacons.sensors

import android.hardware.SensorEventListener
import android.hardware.SensorManager
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.any
import org.mockito.ArgumentMatchers.anyInt
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito.times
import org.mockito.Mockito.verify
import org.powermock.core.classloader.annotations.PrepareForTest
import org.powermock.modules.junit4.PowerMockRunner

@RunWith(PowerMockRunner::class)
@PrepareForTest(SensorsListener::class, SensorManager::class)
class SensorsTest {

    @Mock
    private lateinit var sensorManager: SensorManager
    @Mock
    private lateinit var listener: SensorsListener

    @InjectMocks
    private lateinit var sensors: Sensors

    @Test
    fun testRegisterListeners() {
        sensors.registerListeners()
        verify(sensorManager, times(3)).registerListener(any(SensorEventListener::class.java), any(), anyInt())
    }

    @Test
    fun testUnregisterListeners() {
        sensors.unregisterListeners()
        verify(sensorManager, times(3)).unregisterListener(any(SensorEventListener::class.java), any())
    }

    @Test
    fun testRegisterListenersWithNullManager() {
        sensors = Sensors(null, listener)
        sensors.registerListeners()
        verify(sensorManager, times(0)).registerListener(any(SensorEventListener::class.java), any(), anyInt())
    }

    @Test
    fun testUnregisterListenersWithNullManager() {
        sensors = Sensors(null, listener)
        sensors.unregisterListeners()
        verify(sensorManager, times(0)).unregisterListener(any(SensorEventListener::class.java), any())
    }
}
