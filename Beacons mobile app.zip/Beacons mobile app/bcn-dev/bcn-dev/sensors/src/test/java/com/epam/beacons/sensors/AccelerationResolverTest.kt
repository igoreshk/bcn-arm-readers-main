package com.epam.beacons.sensors

import android.hardware.SensorManager
import android.opengl.Matrix
import org.hamcrest.CoreMatchers.equalTo
import org.junit.Assert.assertThat
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.any
import org.mockito.ArgumentMatchers.anyInt
import org.mockito.internal.verification.VerificationModeFactory.times
import org.powermock.api.mockito.PowerMockito.mockStatic
import org.powermock.api.mockito.PowerMockito.verifyStatic
import org.powermock.core.classloader.annotations.PrepareForTest
import org.powermock.modules.junit4.PowerMockRunner

@RunWith(PowerMockRunner::class)
@PrepareForTest(SensorManager::class, Matrix::class)
class AccelerationResolverTest {

    private val accelerationResolver = AccelerationResolver()

    @Test
    fun testGetAccelInEarthSystem() {
        val linAccel = floatArrayOf(2f, 2f, 2f)
        val magnetic = floatArrayOf(1f, 1f, 1f)
        val gravity = floatArrayOf(3f, 3f, 3f)
        mockStatic(SensorManager::class.java)
        mockStatic(Matrix::class.java)

        val actual = accelerationResolver.getAccelInEarthSystem(linAccel, magnetic, gravity)

        assertThat(actual.size, equalTo(4))
        verifyStatic(SensorManager::class.java, times(1))
        SensorManager.getRotationMatrix(any(), any(), any(), any())
        verifyStatic(Matrix::class.java, times(1))
        Matrix.invertM(any(FloatArray::class.java), anyInt(), any(FloatArray::class.java), anyInt())
    }
}
