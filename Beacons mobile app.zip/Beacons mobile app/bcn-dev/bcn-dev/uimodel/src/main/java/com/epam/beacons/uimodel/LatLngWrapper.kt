package com.epam.beacons.uimodel

import com.google.android.gms.maps.model.LatLng

class LatLngWrapper(val latLng: LatLng) {
    constructor(lat: Double, lon: Double) : this(LatLng(lat, lon))

    var additionalRadius: Double = 0.0

    val latitude
        get() = latLng.latitude

    val longitude
        get() = latLng.longitude
}
