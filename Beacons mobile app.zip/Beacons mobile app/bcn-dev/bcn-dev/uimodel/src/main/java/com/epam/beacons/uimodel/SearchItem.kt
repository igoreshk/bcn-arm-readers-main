package com.epam.beacons.uimodel

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class SearchItem(
        val id: Long,
        var icon: String,
        val title: String,
        val secondaryTitle: String,
        val marked: Boolean
) : Parcelable
