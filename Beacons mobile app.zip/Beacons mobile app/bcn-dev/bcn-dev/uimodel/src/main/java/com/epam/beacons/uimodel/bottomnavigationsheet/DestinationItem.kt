package com.epam.beacons.uimodel.bottomnavigationsheet

import com.google.android.gms.maps.model.LatLng

data class DestinationItem @JvmOverloads constructor(
        val description: String = DEFAULT_DESCRIPTION,
        var latLng: LatLng = DEFAULT_DESTINATION,
        val distance: Int = 0,
        val placeId: String = EMPTY_PLACE_ID,
        var isFavorite: Boolean = false
) {
    companion object {
        val DEFAULT_DESTINATION = LatLng(Double.MAX_VALUE, Double.MAX_VALUE)
        const val EMPTY_PLACE_ID = "DEFAULT"
        const val DEFAULT_DESCRIPTION = "unknown"
    }
}
