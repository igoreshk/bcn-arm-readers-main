package com.epam.beacons.uimodel

import android.graphics.Bitmap
import com.google.android.gms.maps.model.LatLng

class FloorImage(
        var image: Bitmap,
        val height: Float = 0f,
        val width: Float = 0f,
        var southWestBound: LatLng = LatLng(Double.MAX_VALUE, Double.MAX_VALUE),
        var northEastBound: LatLng = LatLng(Double.MAX_VALUE, Double.MAX_VALUE),
        val position: LatLng = LatLng(Double.MAX_VALUE, Double.MAX_VALUE)
) {
    var needToUpdate: Boolean = true
    var needToUpdateSize: Boolean = true
}
