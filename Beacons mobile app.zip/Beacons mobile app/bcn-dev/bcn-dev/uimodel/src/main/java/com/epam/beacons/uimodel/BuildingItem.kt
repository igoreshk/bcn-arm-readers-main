package com.epam.beacons.uimodel

class BuildingItem(val id: String,
                   val address: String?,
                   val width: Double?,
                   val height: Double?,
                   val name: String?,
                   val phoneNumber: String?,
                   val workingHours: String?)
