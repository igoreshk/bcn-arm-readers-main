package com.epam.beacons.uimodel

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class FloorSelectorItem(
        val number: Int,
        val title: String,
        var active: Boolean,
        var alpha: Int = 255
) : Parcelable

