package com.epam.beacons.uimodel

enum class RecordStateModel {
    DATA_EMPTY,
    RECORDING,
    STOPPED,
    SAVED,
    FILE_OPENING,
    FILE_OPENED
}
