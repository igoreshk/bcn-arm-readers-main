package com.epam.beacons.uimodel

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class BookmarkItem(
        val id: String,
        var icon: String,
        val title: String,
        val secondaryTitle: String
) : Parcelable
