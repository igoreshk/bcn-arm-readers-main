package com.epam.beacons.uimodel.bottomnavigationsheet

data class RouteItem(val distance: Int = 0,
                val type: Type = Type.PLACE,
                val destOrientation: DestOrientation = DestOrientation.NONE) {

    enum class Type {
        PLACE,
        LEFT,
        RIGHT
    }

    enum class DestOrientation {
        LEFT,
        RIGHT,
        FORWARD,
        NONE
    }
}
