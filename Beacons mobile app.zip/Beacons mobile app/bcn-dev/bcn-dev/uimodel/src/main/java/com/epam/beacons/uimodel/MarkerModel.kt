package com.epam.beacons.uimodel

import androidx.annotation.DrawableRes
import com.google.android.gms.maps.model.MarkerOptions

data class MarkerModel(val markerOptions : MarkerOptions, @DrawableRes val id: Int)
