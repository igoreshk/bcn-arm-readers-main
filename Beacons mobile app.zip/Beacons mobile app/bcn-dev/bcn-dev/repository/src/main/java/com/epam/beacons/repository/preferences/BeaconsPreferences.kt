package com.epam.beacons.repository.preferences

import io.reactivex.Completable
import io.reactivex.Maybe

interface BeaconsPreferences {

    fun isDebugDrawAllowed(): Maybe<Boolean>

    fun isSimpleLocationMode(): Maybe<Boolean>

    fun saveDebugDrawPreference(value: Boolean): Completable

    fun saveLocationMode(value: Boolean): Completable
}
