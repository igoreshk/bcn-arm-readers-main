package com.epam.beacons.repository.cache;

import androidx.annotation.NonNull;

import com.epam.beacons.Place;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Maybe;
import io.reactivex.Single;

public interface FavoritePlacesCache {

    @NonNull
    Maybe<List<Place>> get();

    @NonNull
    Maybe<List<String>> getIds();

    @NonNull
    Completable put(@NonNull List<Place> places);

    @NonNull
    Completable put(@NonNull Place place);

    @NonNull
    Completable putIds(@NonNull List<String> ids);

    @NonNull
    Completable remove(String placeId);

    @NonNull
    Completable clear();

    @NonNull
    Single<Boolean> isEmpty();

    @NonNull
    Single<Boolean> isInitialized();
}
