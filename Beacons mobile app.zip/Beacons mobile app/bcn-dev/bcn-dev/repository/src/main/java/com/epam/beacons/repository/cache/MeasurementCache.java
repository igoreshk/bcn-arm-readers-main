package com.epam.beacons.repository.cache;

import androidx.annotation.NonNull;

import com.epam.beacons.Measurement;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Maybe;

public interface MeasurementCache {

    @NonNull
    Maybe<List<Measurement>> get(int key);

    @NonNull
    Completable put(@NonNull List<Measurement> measurements);

    int size();

    /**
     * Removes amount of measurements equal <code>measurementLimit</code> from <code>measurements</code>
     *
     * @param measurements   input list of measurements
     * @param amountToRemove amount of measurements to remove if list is over sized
     * @return <code>true</code> if remove operation was performed, <code>false</code> otherwise
     */
    boolean removeMeasurements(@NonNull List<Measurement> measurements, int amountToRemove);
}