package com.epam.beacons.repository.cache;

import androidx.annotation.NonNull;

import com.epam.beacons.Gate;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Maybe;

public interface GatesCache {
    @NonNull
    Maybe<List<Gate>> get();

    @NonNull
    Completable put(@NonNull List<Gate> gates);

    @NonNull
    Completable clear();
}
