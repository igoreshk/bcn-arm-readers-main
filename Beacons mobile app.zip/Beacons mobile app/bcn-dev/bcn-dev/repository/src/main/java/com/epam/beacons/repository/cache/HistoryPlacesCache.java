package com.epam.beacons.repository.cache;

import androidx.annotation.NonNull;

import com.epam.beacons.Place;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Maybe;
import io.reactivex.Single;

public interface HistoryPlacesCache {

    @NonNull
    Maybe<List<Place>> get();

    @NonNull
    Completable put(@NonNull List<Place> places);

    @NonNull
    Completable put(@NonNull Place place);

    @NonNull
    Completable clear();

    @NonNull
    Single<Boolean> isEmpty();

    @NonNull
    Completable updateFavorites(@NonNull Maybe<List<String>> favIds);
}
