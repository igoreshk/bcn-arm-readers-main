package com.epam.beacons.repository;

import androidx.annotation.NonNull;

import com.epam.beacons.Place;
import com.epam.beacons.repository.cache.FavoritePlacesCache;
import com.epam.beacons.tools.adapters.DisposableCompletableObserverAdapter;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Maybe;

@Singleton
public class FavoritesRepo {

    @NonNull
    private final StorageLayer        storageLayer;
    @NonNull
    private final FavoritePlacesCache favoritesCache;

    @Inject
    FavoritesRepo(@NonNull StorageLayer storageLayer, @NonNull FavoritePlacesCache favoritesCache) {
        this.storageLayer = storageLayer;
        this.favoritesCache = favoritesCache;
    }

    @NonNull
    public Maybe<List<Place>> getFavorites(String buildingId) {
        return favoritesCache.get()
                             .switchIfEmpty(getSavedFavorites(buildingId));
    }

    @NonNull
    public Maybe<List<String>> getFavoritesIds(String buildingId) {
        return favoritesCache.getIds()
                             .switchIfEmpty(getSavedFavoritesIds(buildingId));
    }

    @NonNull
    public Completable addToFavorites(String buildingId, String placeId) {
        return storageLayer.addToFavorites(buildingId, placeId)
                           .andThen(putToCache(buildingId, placeId));
    }

    @NonNull
    public Completable removeFromFavorites(String buildingId, String placeId) {
        return storageLayer.removeFromFavorites(buildingId, placeId)
                           .andThen(favoritesCache.remove(placeId));
    }

    @NonNull
    public Completable clearCache() {
        return favoritesCache.clear();
    }

    @NonNull
    private Completable putToCache(String buildingId, String placeId) {
        return favoritesCache.isEmpty()
                             .flatMap(isEmpty -> isEmpty ?
                                     getSavedFavorites(buildingId).toSingle() :
                                     storageLayer.getPlace(buildingId, placeId)
                                                 .doOnSuccess(place -> favoritesCache.put(place)
                                                                                     .subscribe(new DisposableCompletableObserverAdapter() {}))
                                                 .toSingle())
                             .toCompletable();
    }

    @NonNull
    private Maybe<List<Place>> getSavedFavorites(String buildingId) {
        return storageLayer.getFavoritePlaces(buildingId)
                           .doOnSuccess(places -> favoritesCache.put(places)
                                                                .subscribe(new DisposableCompletableObserverAdapter() {}));
    }

    @NonNull
    private Maybe<List<String>> getSavedFavoritesIds(String buildingId) {
        return storageLayer.getFavoritesIds(buildingId)
                           .doOnSuccess(ids -> favoritesCache.putIds(ids)
                                                             .subscribe(new DisposableCompletableObserverAdapter() {}));
    }
}
