package com.epam.beacons.repository.cache

import com.epam.beacons.Floor
import io.reactivex.Completable
import io.reactivex.Maybe

interface FloorNumbersCache {

    fun get(): Maybe<List<Int>>

    fun put(numbers: List<Floor>): Completable

    fun clear(): Completable
}
