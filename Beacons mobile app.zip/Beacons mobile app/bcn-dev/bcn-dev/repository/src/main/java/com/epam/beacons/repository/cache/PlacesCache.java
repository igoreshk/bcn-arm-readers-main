package com.epam.beacons.repository.cache;

import androidx.annotation.NonNull;

import com.epam.beacons.Place;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Maybe;

public interface PlacesCache {
    @NonNull
    Maybe<List<Place>> get();

    @NonNull
    Maybe<Place> getById(String id);

    @NonNull
    Completable put(@NonNull Place place);

    @NonNull
    Completable put(@NonNull List<Place> places);

    @NonNull
    Completable clear();

    @NonNull
    Completable updateFavorites(@NonNull Maybe<List<String>> favIds);
}