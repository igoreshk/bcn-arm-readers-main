package com.epam.beacons.repository.cache

import com.epam.beacons.Beacon
import io.reactivex.Completable
import io.reactivex.Maybe

interface BeaconsCache {
    fun getBeacons(floorNumbers: List<Int>): Maybe<List<Beacon>>

    fun getFloorNumbers(): Maybe<List<Int>>

    fun put(beacons: List<Beacon>): Completable

    fun clear(): Completable
}
