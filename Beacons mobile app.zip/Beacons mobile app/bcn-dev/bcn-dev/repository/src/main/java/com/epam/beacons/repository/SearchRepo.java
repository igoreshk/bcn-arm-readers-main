package com.epam.beacons.repository;

import androidx.annotation.NonNull;

import com.epam.beacons.Place;
import com.epam.beacons.repository.cache.FavoritePlacesCache;
import com.epam.beacons.repository.cache.HistoryPlacesCache;
import com.epam.beacons.repository.cache.PlacesCache;
import com.epam.beacons.tools.adapters.DisposableCompletableObserverAdapter;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Maybe;

@Singleton
public class SearchRepo {

    @NonNull
    private final StorageLayer        storageLayer;
    @NonNull
    private final PlacesCache         placesCache;
    @NonNull
    private final HistoryPlacesCache  historyCache;
    @NonNull
    private final FavoritePlacesCache favoritePlacesCache;

    @Inject
    SearchRepo(@NonNull StorageLayer storageLayer,
               @NonNull PlacesCache placesCache,
               @NonNull HistoryPlacesCache historyCache,
               @NonNull FavoritePlacesCache favoritePlacesCache) {
        this.storageLayer = storageLayer;
        this.placesCache = placesCache;
        this.historyCache = historyCache;
        this.favoritePlacesCache = favoritePlacesCache;
    }

    @NonNull
    public Maybe<List<Place>> getPlaces(String buildingId) {
        return placesCache.get()
                          .zipWith(
                                  favoritePlacesCache.isInitialized().toMaybe(),
                                  (places, initialized) -> {
                                      if (initialized) {
                                          placesCache.updateFavorites(favoritePlacesCache.getIds())
                                                     .subscribe(new DisposableCompletableObserverAdapter() {});
                                      }
                                      return places;
                                  }
                          )
                          .switchIfEmpty(getSavedPlaces(buildingId));
    }

    @NonNull
    public Maybe<Place> getPlace(String buildingId, String searchItemId) {
        return placesCache.getById(searchItemId)
                          .switchIfEmpty(getSavedPlace(buildingId, searchItemId));
    }

    @NonNull
    public Maybe<List<Place>> getHistory(String buildingId) {
        return historyCache.get()
                           .zipWith(
                                   favoritePlacesCache.isInitialized().toMaybe(),
                                   (history, initialized) -> {
                                       if (initialized) {
                                           historyCache.updateFavorites(favoritePlacesCache.getIds())
                                                      .subscribe(new DisposableCompletableObserverAdapter() {});
                                       }
                                       return history;
                                   }
                           )
                           .switchIfEmpty(getSavedHistory(buildingId));
    }

    @NonNull
    public Completable addToHistory(String buildingId, String placeId) {
        return storageLayer.addToHistory(buildingId, placeId)
                           .andThen(putToHistoryCache(buildingId, placeId));
    }

    @NonNull
    public Completable clearPlacesCaches() {
        return Completable.mergeArray(
                placesCache.clear(),
                historyCache.clear()
        );
    }

    @NonNull
    private Maybe<List<Place>> getSavedPlaces(String buildingId) {
        return storageLayer.getPlaces(buildingId)
                           .doOnSuccess(places -> placesCache.put(places)
                                                             .subscribe(new DisposableCompletableObserverAdapter() {}));
    }

    @NonNull
    private Maybe<Place> getSavedPlace(String buildingId, String searchItemId) {
        return storageLayer.getPlace(buildingId, searchItemId)
                           .doOnSuccess(place -> placesCache.put(place)
                                                            .subscribe(new DisposableCompletableObserverAdapter() {}));
    }

    @NonNull
    private Maybe<List<Place>> getSavedHistory(String buildingId) {
        return storageLayer.getHistoryPlaces(buildingId)
                           .doOnSuccess(places -> historyCache.put(places)
                                                              .subscribe(new DisposableCompletableObserverAdapter() {}));
    }

    @NonNull
    private Completable putToHistoryCache(String buildingId, String placeId) {
        return historyCache.isEmpty()
                           .flatMap(isEmpty -> isEmpty ?
                                   getSavedHistory(buildingId).toSingle() :
                                   storageLayer.getPlace(buildingId, placeId)
                                               .doOnSuccess(place -> historyCache.put(place)
                                                                                 .subscribe(new DisposableCompletableObserverAdapter() {}))
                                               .toSingle())
                           .toCompletable();
    }
}
