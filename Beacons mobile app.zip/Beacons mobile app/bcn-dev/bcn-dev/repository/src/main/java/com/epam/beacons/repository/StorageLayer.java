package com.epam.beacons.repository;

import androidx.annotation.NonNull;

import com.epam.beacons.Beacon;
import com.epam.beacons.Building;
import com.epam.beacons.Floor;
import com.epam.beacons.FloorData;
import com.epam.beacons.Gate;
import com.epam.beacons.Graph;
import com.epam.beacons.Measurement;
import com.epam.beacons.Place;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Maybe;

/**
 * Following the clean architecture guides this interface must be
 * located in storage module, because it is the lowest module
 * and it must not know anything about higher repository module.
 * But android platform has some limitations: because of repository is
 * a java module and storage is an android module, the dependency
 * of storage module can't be added into repository module.
 * But it can be done conversely, so for now it's the only way to
 * bind these two modules together.
 */
public interface StorageLayer {
    @NonNull
    Completable saveBuildings(@NonNull List<Building> buildings);

    @NonNull
    Maybe<List<Building>> getBuildings();

    @NonNull
    Completable saveFloorsData(@NonNull List<FloorData> floors, String buildingId);

    @NonNull
    Maybe<List<Floor>> getFloors(String buildingId);

    @NonNull
    Maybe<Floor> getFloor(String buildingId, int floorNumber);

    @NonNull
    Maybe<Graph> getGraph(String buildingId, int floorNumber);

    @NonNull
    Maybe<List<Beacon>> getBeacons(String buildingId, int floorNumber);

    @NonNull
    Maybe<List<Beacon>> getBeacons(String buildingId);

    @NonNull
    Maybe<List<Beacon>> getBeacons(String buildingId, @NonNull List<Integer> floorNumbers);

    @NonNull
    Maybe<List<Place>> getPlaces(String buildingId);

    @NonNull
    Maybe<Place> getPlace(String buildingId, String searchItemId);

    @NonNull
    Maybe<List<Place>> getFavoritePlaces(String buildingId);

    @NonNull
    Maybe<List<String>> getFavoritesIds(String buildingId);

    @NonNull
    Maybe<List<Place>> getHistoryPlaces(String buildingId);

    @NonNull
    Completable addToHistory(String buildingId, String placeId);

    @NonNull
    Completable addToFavorites(String buildingId, String placeId);

    @NonNull
    Completable removeFromFavorites(String buildingId, String placeId);

    @NonNull
    Completable saveGates(@NonNull List<Gate> gates, String buildingId);

    @NonNull
    Maybe<List<Gate>> getGates(String buildingId);

    @NonNull
    Completable saveMeasurements(@NonNull List<Measurement> measurements);

    @NonNull
    Maybe<List<Measurement>> getMeasurements();

    @NonNull
    Completable deleteMeasurements(int rssi, int limit);
}
