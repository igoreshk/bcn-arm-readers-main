package com.epam.beacons.repository;

import androidx.annotation.NonNull;

import com.epam.beacons.Beacon;
import com.epam.beacons.Building;
import com.epam.beacons.Floor;
import com.epam.beacons.FloorData;
import com.epam.beacons.Gate;
import com.epam.beacons.repository.cache.FloorNumbersCache;
import com.epam.beacons.repository.cache.GatesCache;
import com.epam.beacons.repository.exceptions.NoDataOnServerException;
import com.epam.beacons.repository.preferences.BeaconsPreferences;
import com.epam.beacons.tools.adapters.DisposableCompletableObserverAdapter;
import com.rest.api.RestLayer;
import com.epam.beacons.Track;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Maybe;
import jdk.vm.ci.code.site.Call;

@Singleton
public class DataRepo {

    @NonNull
    private final RestLayer restLayer;
    @NonNull
    private final StorageLayer storageLayer;
    @NonNull
    private final BeaconsPreferences beaconsPreferences;
    @NonNull
    private final GatesCache gatesCache;
    @NonNull
    private final FloorNumbersCache floorNumbersCache;

    @Inject
    public DataRepo(@NonNull RestLayer restLayer,
                    @NonNull StorageLayer storageLayer,
                    @NonNull BeaconsPreferences beaconsPreferences,
                    @NonNull GatesCache gatesCache,
                    @NonNull FloorNumbersCache floorNumbersCache) {
        this.restLayer = restLayer;
        this.storageLayer = storageLayer;
        this.beaconsPreferences = beaconsPreferences;
        this.gatesCache = gatesCache;
        this.floorNumbersCache = floorNumbersCache;
    }

    @NonNull
    public Maybe<List<Building>> getBuildingsAnyway() {

        return getNetworkBuildings()
                .onErrorResumeNext(Maybe.empty())
                .switchIfEmpty(getSavedBuildings())
                .switchIfEmpty(Maybe.error(new ConnectException()));
    }

    @NonNull
    public Maybe<List<Building>> getRecentBuildings() {
        return getNetworkBuildings()
                .onErrorResumeNext(this::getError)
             //   .filter(buildings -> !buildings.isEmpty())
                .switchIfEmpty(Maybe.error(new NoDataOnServerException()));
    }

    @NonNull
    private Maybe<List<Building>> getNetworkBuildings() {
        return restLayer.getBuildings()
                .doOnSuccess(buildings -> storageLayer.saveBuildings(buildings)
                        .subscribe(new DisposableCompletableObserverAdapter() {}));
    }

    @NonNull
    private Maybe<List<Building>> getSavedBuildings() {
        return storageLayer.getBuildings()
                .filter(buildings -> !buildings.isEmpty());
    }

    @NonNull
    public Maybe<List<Floor>> getFloors(String buildingId) {
        return restLayer.getFloorsWithGraphs(buildingId)
                .doOnSuccess(floors -> storageLayer.saveFloorsData(floors, buildingId)
                        .subscribe(new DisposableCompletableObserverAdapter() {
                        })
                )
                .flattenAsObservable(floors -> floors)
                .map(FloorData::getFloor)
                .toList()
                .toMaybe()
                .onErrorResumeNext(Maybe.empty())
                .filter(floors -> !floors.isEmpty())
                .switchIfEmpty(getSavedFloors(buildingId))
                .doOnSuccess(floors -> floorNumbersCache.put(floors)
                        .subscribe(new DisposableCompletableObserverAdapter() {
                        }))
                .switchIfEmpty(Maybe.error(new ConnectException()));
    }

    @NonNull
    public Maybe<List<Integer>> getFloorNumbers() {
        return floorNumbersCache.get();
    }

    @NonNull
    private Maybe<List<Floor>> getSavedFloors(String buildingId) {
        return storageLayer.getFloors(buildingId)
                .filter(floors -> !floors.isEmpty());
    }

    @NonNull
    public Maybe<List<Gate>> getGates(String buildingId) {
        return restLayer.getGates(buildingId)
                .doOnSuccess(gates -> storageLayer.saveGates(gates, buildingId)
                        .subscribe(new DisposableCompletableObserverAdapter() {
                        }))
                .doOnSuccess(gates -> gatesCache.put(gates)
                        .subscribe(new DisposableCompletableObserverAdapter() {
                        }));
           //     .onErrorResumeNext(Maybe.empty())
             //   .filter(gates -> !gates.isEmpty())
             //   .switchIfEmpty(getSavedGates(buildingId))
         //       .switchIfEmpty(Maybe.error(new ConnectException()));
    }

    @NonNull
    public Maybe<List<Gate>> getGates(String buildingId, int floorNumber) {
        return getSavedGates(buildingId).flattenAsObservable(gates -> gates)
                .filter(gate -> gate.getBounds().containsKey(floorNumber))
                .toList()
                .toMaybe();
    }

    @NonNull
    public Maybe<List<Gate>> getSavedGates(String buildingId) {
        return gatesCache.get()
                .switchIfEmpty(storageLayer.getGates(buildingId)
                        .doOnSuccess(gates -> gatesCache.put(gates)
                                .subscribe(new DisposableCompletableObserverAdapter() {
                                })));
    }

    @NonNull
    private Maybe getError(@NonNull Throwable throwable) {
        if (throwable instanceof SocketTimeoutException) {
            return Maybe.error(throwable);
        }
        if (throwable instanceof ConnectException) {
            return Maybe.error(throwable);
        }
        return Maybe.empty();
    }

    @NonNull
    public Maybe<Floor> getFloor(String buildingId, int floorNumber) {
        return storageLayer.getFloor(buildingId, floorNumber);
    }

    @NonNull
    public Maybe<Boolean> switchAndGetDebugValue() {
        return beaconsPreferences.isDebugDrawAllowed()
                .map(value -> !value)
                .doOnSuccess(value -> beaconsPreferences.saveDebugDrawPreference(value)
                        .subscribe(new DisposableCompletableObserverAdapter() {
                        }));
    }

    @NonNull
    public Maybe<Boolean> isSimpleLocationMode() {
        return beaconsPreferences.isSimpleLocationMode();
    }

    @NonNull
    public Maybe<Boolean> getDebugAllowanceValue() {
        return beaconsPreferences.isDebugDrawAllowed();
    }

    public Maybe<Boolean> switchAndGetSimpleLocationMode() {
        return isSimpleLocationMode()
                .map(value -> !value)
                .doOnSuccess(value -> beaconsPreferences.saveLocationMode(value)
                        .subscribe(new DisposableCompletableObserverAdapter() {
                        }));
    }

    @NonNull
    public Completable clearGatesCache() {
        return gatesCache.clear();
    }

    @NonNull
    public Completable clearFloorNumbersCache() {
        return floorNumbersCache.clear();
    }

    public @NonNull
    Completable postTracks(List<Track> tracks) {
        return restLayer.postTracks(tracks);
    }
}
