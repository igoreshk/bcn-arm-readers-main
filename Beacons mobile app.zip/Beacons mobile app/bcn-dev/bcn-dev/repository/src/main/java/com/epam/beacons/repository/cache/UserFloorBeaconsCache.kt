package com.epam.beacons.repository.cache

import com.epam.beacons.Beacon
import io.reactivex.Completable
import io.reactivex.Maybe

interface UserFloorBeaconsCache {
    fun put(list: List<Beacon>): Completable

    fun get(): Maybe<List<Beacon>>

    fun clear(): Completable
}
