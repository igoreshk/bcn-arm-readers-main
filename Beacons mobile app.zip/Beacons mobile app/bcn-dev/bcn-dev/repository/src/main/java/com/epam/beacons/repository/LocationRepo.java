package com.epam.beacons.repository;

import androidx.annotation.NonNull;

import com.epam.beacons.Beacon;
import com.epam.beacons.Measurement;
import com.epam.beacons.repository.cache.BeaconsCache;
import com.epam.beacons.repository.cache.MeasurementCache;
import com.epam.beacons.repository.cache.UserFloorBeaconsCache;
import com.epam.beacons.tools.adapters.DisposableCompletableObserverAdapter;
import com.epam.beacons.tools.adapters.DisposableMaybeObserverAdapter;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Maybe;
import io.reactivex.Observable;

@Singleton
public class LocationRepo {
    @NonNull
    private final StorageLayer          storageLayer;
    @NonNull
    private final UserFloorBeaconsCache userFloorBeaconsCache;
    @NonNull
    private final BeaconsCache          beaconsCache;
    @NonNull
    private final MeasurementCache      measurementsCache;

    private final int measurementsLimit;

    public LocationRepo(@NonNull StorageLayer storageLayer,
                        @NonNull UserFloorBeaconsCache userFloorBeaconsCache,
                        @NonNull BeaconsCache beaconsCache,
                        @NonNull MeasurementCache measurementsCache,
                        int measurementsLimit) {
        this.storageLayer = storageLayer;
        this.userFloorBeaconsCache = userFloorBeaconsCache;
        this.beaconsCache = beaconsCache;
        this.measurementsCache = measurementsCache;
        this.measurementsLimit = measurementsLimit;
    }

    @NonNull
    public Maybe<List<Beacon>> getBeacons(String buildingId, int floorNumber) {
        return userFloorBeaconsCache.get()
                                    .filter(beacons -> checkBelonging(beacons, floorNumber))
                                    .switchIfEmpty(storageLayer.getBeacons(buildingId, floorNumber)
                                                               .doOnSuccess(beacons -> userFloorBeaconsCache
                                                                       .put(beacons)
                                                                       .subscribe(new DisposableCompletableObserverAdapter() {})));
    }

    @NonNull
    public Maybe<List<Beacon>> getBeacons(String buildingId, @NonNull List<Integer> floorNumbers) {
        return beaconsCache.getFloorNumbers()
                           .defaultIfEmpty(new ArrayList<>())
                           .flatMap(cachedNumbers -> Maybe.zip(
                                   Observable.fromIterable(cachedNumbers)
                                             .filter(floorNumbers::contains)
                                             .toList()
                                             .toMaybe()
                                             .flatMap(beaconsCache::getBeacons)
                                             .defaultIfEmpty(new ArrayList<>()),
                                   Observable.fromIterable(floorNumbers)
                                             .filter(number -> !cachedNumbers.contains(number))
                                             .toList()
                                             .toMaybe()
                                             .flatMap(notCachedNumbers -> storageLayer.getBeacons(buildingId, notCachedNumbers))
                                             .doOnSuccess(storageBeacons -> beaconsCache.put(storageBeacons)
                                                                                        .subscribe(new DisposableCompletableObserverAdapter() {}))
                                             .defaultIfEmpty(new ArrayList<>()),
                                   (beaconsFromCache, beaconsFromStorage) -> {
                                       final List<Beacon> result = new ArrayList<>(beaconsFromCache);
                                       result.addAll(beaconsFromStorage);
                                       return result;
                                   }
                           ));
    }

    @NonNull
    public Maybe<List<Beacon>> getBeacons(String buildingId) {
        return storageLayer.getBeacons(buildingId);
    }

    @NonNull
    public Completable putMeasurements(@NonNull List<Measurement> measurements) {
        return measurementsCache.put(measurements)
                                .andThen(storageLayer.saveMeasurements(measurements));
    }

    @NonNull
    public Completable initMeasurements() {
        return Completable.fromAction(() -> {
            if (measurementsCache.size() == 0) {
                storageLayer.getMeasurements()
                            .doOnSuccess(measurements ->
                                                 measurementsCache.put(measurements)
                                                                  .subscribe(new DisposableCompletableObserverAdapter() {}))
                            .subscribe(new DisposableMaybeObserverAdapter<List<Measurement>>() {});
            }
        });
    }

    @NonNull
    public Maybe<List<Measurement>> getMeasurements(int rssi) {
        return measurementsCache.get(rssi)
                                .filter(measurements -> !measurements.isEmpty())
                                .switchIfEmpty(Maybe.fromCallable(ArrayList::new));
    }

    @NonNull
    public Completable updateMeasurements(int rssi, @NonNull List<Measurement> measurements) {
        return Completable.fromAction(() -> {
            if (measurementsCache.removeMeasurements(measurements, measurementsLimit)) {
                storageLayer.deleteMeasurements(rssi, measurementsLimit)
                            .subscribe(new DisposableCompletableObserverAdapter() {});
            }
        });
    }

    @NonNull
    public Completable clearUserFloorBeaconsCache() {
        return userFloorBeaconsCache.clear();
    }

    @NonNull
    public Completable clearBeaconsCache() {
        return beaconsCache.clear();
    }

    private boolean checkBelonging(@NonNull List<Beacon> beacons, int floor) {
        for (Beacon beacon : beacons) {
            if (beacon.getFloorNumber() != floor) {
                return false;
            }
        }
        return true;
    }
}
