package com.epam.beacons.repository.cache

import com.epam.beacons.Graph
import io.reactivex.Completable
import io.reactivex.Maybe

interface GraphsCache {
    fun get(floorNumber: Int): Maybe<Graph>

    fun put(graph: Graph): Completable

    fun clear(): Completable
}
