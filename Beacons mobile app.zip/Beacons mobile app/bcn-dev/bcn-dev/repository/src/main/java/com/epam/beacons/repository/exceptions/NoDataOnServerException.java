package com.epam.beacons.repository.exceptions;

public class NoDataOnServerException extends RuntimeException {
    public NoDataOnServerException() {
    }

    public NoDataOnServerException(String s) {
        super(s);
    }
}
