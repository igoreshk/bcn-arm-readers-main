package com.epam.beacons.repository

import com.epam.beacons.Graph
import com.epam.beacons.repository.cache.GraphsCache
import com.epam.beacons.tools.adapters.DisposableCompletableObserverAdapter
import io.reactivex.Maybe
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RoutingRepo @Inject constructor(private val graphsCache: GraphsCache, private val storageLayer: StorageLayer) {

    fun getGraph(buildingId: String, floorNumber: Int): Maybe<Graph> = graphsCache.get(floorNumber)
            .switchIfEmpty(getSavedGraph(buildingId, floorNumber))

    fun clearGraphsCache() = graphsCache.clear()

    private fun getSavedGraph(buildingId: String, floorNumber: Int) = storageLayer.getGraph(buildingId, floorNumber)
            .doOnSuccess {
                graphsCache.put(it)
                        .subscribe(object : DisposableCompletableObserverAdapter() {})
            }
}
