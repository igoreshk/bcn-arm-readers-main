package com.epam.beacons.repository

import com.epam.beacons.Beacon
import com.epam.beacons.Coordinate
import com.epam.beacons.repository.KotlinMockito.whn
import com.epam.beacons.repository.cache.BeaconsCache
import com.epam.beacons.repository.cache.MeasurementCache
import com.epam.beacons.repository.cache.UserFloorBeaconsCache
import io.reactivex.Completable
import io.reactivex.Maybe
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.anyList
import org.mockito.ArgumentMatchers.anyLong
import org.mockito.Mock
import org.mockito.Mockito.times
import org.mockito.Mockito.verify
import org.mockito.junit.MockitoJUnitRunner
import java.util.Collections

@RunWith(MockitoJUnitRunner::class)
//TODO: EPMLSTRBCA-124 - на данный момент протестирован только метод getBeacons(long buildingId, List<Integer> floorNumbers)
class LocationRepoTest {

    @Mock
    private lateinit var storageLayer: StorageLayer
    @Mock
    private lateinit var userFloorBeaconsCache: UserFloorBeaconsCache
    @Mock
    private lateinit var beaconsCache: BeaconsCache
    @Mock
    private lateinit var measurementCache: MeasurementCache

    private lateinit var locationRepo: LocationRepo

    private val beacons = listOf(
            Beacon("uuid1", 1, 1, FLOOR_NUMBER_0, Coordinate(1.0, 1.0)),
            Beacon("uuid2", 2, 2, FLOOR_NUMBER_0, Coordinate(2.0, 2.0)),
            Beacon("uuid3", 3, 3, FLOOR_NUMBER_1, Coordinate(3.0, 3.0)),
            Beacon("uuid4", 4, 4, FLOOR_NUMBER_1, Coordinate(4.0, 4.0)))
    private val floorNumbers = listOf(FLOOR_NUMBER_0, FLOOR_NUMBER_1)

    @Before
    fun setUp() {
        locationRepo = LocationRepo(storageLayer, userFloorBeaconsCache, beaconsCache, measurementCache, MEASUREMENTS_LIST)
    }

    @Test
    fun testGetBeaconsByFloorNumbersWhenNoBeaconsInCache() {
        whn(beaconsCache.getFloorNumbers()).thenReturn(Maybe.empty())
        whn(beaconsCache.getBeacons(Collections.emptyList())).thenReturn(Maybe.empty())
        whn(storageLayer.getBeacons(BUILDING_ID, floorNumbers)).thenReturn(Maybe.fromCallable { beacons })
        whn(beaconsCache.put(beacons)).thenReturn(Completable.complete())

        locationRepo.getBeacons(BUILDING_ID, floorNumbers)
                .test()
                .assertComplete()
                .assertValue(beacons)

        verify(beaconsCache, times(1)).put(beacons)
    }

    @Test
    fun testGetBeaconsByFloorNumbersWhenAllBeaconsInCache() {
        whn(beaconsCache.getFloorNumbers()).thenReturn(Maybe.fromCallable { floorNumbers })
        whn(beaconsCache.getBeacons(floorNumbers)).thenReturn(Maybe.fromCallable { beacons })
        whn(storageLayer.getBeacons(anyLong(), anyList())).thenReturn(Maybe.empty())

        locationRepo.getBeacons(BUILDING_ID, floorNumbers)
                .test()
                .assertComplete()
                .assertValue(beacons)

        verify(beaconsCache, times(0)).put(anyList())
    }

    @Test
    fun testGetBeaconsByFloorNumbersWhenSomeBeaconsInCache() {
        val beaconsFromFloorNumber0 = beacons.filter { it.floorNumber == FLOOR_NUMBER_0 }
        val beaconsFromFloorNumber1 = beacons.filter { it.floorNumber == FLOOR_NUMBER_1 }

        whn(beaconsCache.getFloorNumbers()).thenReturn(Maybe.fromCallable { listOf(FLOOR_NUMBER_0) })
        whn(beaconsCache.getBeacons(listOf(FLOOR_NUMBER_0))).thenReturn(Maybe.fromCallable { beaconsFromFloorNumber0 })
        whn(storageLayer.getBeacons(anyLong(), anyList())).thenReturn(Maybe.empty())
        whn(storageLayer.getBeacons(BUILDING_ID, listOf(FLOOR_NUMBER_1))).thenReturn(Maybe.fromCallable { beaconsFromFloorNumber1 })
        whn(beaconsCache.put(beaconsFromFloorNumber1)).thenReturn(Completable.complete())

        locationRepo.getBeacons(BUILDING_ID, floorNumbers)
                .test()
                .assertComplete()
                .assertValue(beacons)

        verify(beaconsCache, times(1)).put(beaconsFromFloorNumber1)
    }

    companion object {
        const val MEASUREMENTS_LIST = 30
        const val BUILDING_ID = 42L
        const val FLOOR_NUMBER_0 = 0
        const val FLOOR_NUMBER_1 = 1
    }
}
