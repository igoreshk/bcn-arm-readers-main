package com.epam.beacons.repository

import com.epam.beacons.Graph
import com.epam.beacons.repository.KotlinMockito.whn
import com.epam.beacons.repository.cache.GraphsCache
import io.reactivex.Completable
import io.reactivex.Maybe
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito.verify
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class RoutingRepoTest {

    private val floorNumber = 1
    private val buildingId = 1L

    private val graph = Graph(buildingId, floorNumber, emptyList(), emptyList())

    private val graphMaybe = Maybe.fromCallable { graph }

    @Mock
    private lateinit var graphsCache: GraphsCache
    @Mock
    private lateinit var storageLayer: StorageLayer
    @InjectMocks
    private lateinit var routingRepo: RoutingRepo

    @Test
    fun testGetGraph() {
        whn(graphsCache.get(floorNumber)).thenReturn(graphMaybe)
        whn(storageLayer.getGraph(buildingId, floorNumber)).thenReturn(Maybe.empty())
        routingRepo.getGraph(buildingId, floorNumber)
                .test()
                .assertValue(graph)
                .assertComplete()
    }

    @Test
    fun testGetGraphFromCache() {
        whn(graphsCache.get(floorNumber)).thenReturn(Maybe.empty())
        whn(storageLayer.getGraph(buildingId, floorNumber)).thenReturn(graphMaybe)
        whn(graphsCache.put(graph)).thenReturn(Completable.complete())
        routingRepo.getGraph(buildingId, floorNumber)
                .test()
                .assertValue(graph)
                .assertComplete()
        verify(graphsCache).put(graph)
    }

    @Test
    fun testClearGraphsCache() {
        whn(graphsCache.clear()).thenReturn(Completable.complete())
        routingRepo.clearGraphsCache()
                .test()
                .assertComplete()
        verify(graphsCache).clear()
    }
}
