package com.epam.beacons.repository

import org.mockito.Mockito
import org.mockito.stubbing.OngoingStubbing

object KotlinMockito {

    /**
     * Wrapper method just to simplify calling from kotlin
     */
    fun <T> whn(methodCall: T): OngoingStubbing<T> = Mockito.`when`(methodCall)
}
