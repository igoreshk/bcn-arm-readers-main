package com.epam.beacons.navigation;

import androidx.annotation.NonNull;

import com.epam.beacons.Edge;
import com.epam.beacons.Graph;
import com.epam.beacons.Vertex;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class DijkstraAlgorithm {

    @NonNull
    private final List<Edge>          edges          = new ArrayList<>();
    @NonNull
    private final List<Vertex>        settledNodes   = new ArrayList<>();
    @NonNull
    private final List<Vertex>        unsettledNodes = new ArrayList<>();
    @NonNull
    private final Map<Vertex, Vertex> ancestors      = new HashMap<>();
    @NonNull
    private final Map<Vertex, Float>  distance       = new HashMap<>();

    @Inject
    DijkstraAlgorithm() { // default constructor for dagger
    }

    @NonNull
    public List<Vertex> getPath(@NonNull Graph graph,
                                @NonNull Vertex source,
                                @NonNull Vertex destination) {
        init(graph);

        distance.put(source, 0f);
        unsettledNodes.add(source);
        while (!unsettledNodes.isEmpty()) {
            final Vertex node = getMinimum(unsettledNodes);
            settledNodes.add(node);
            unsettledNodes.remove(node);
            findMinimalDistances(node);
        }
        return getPath(destination);
    }

    private void init(@NonNull Graph graph) {
        edges.clear();
        settledNodes.clear();
        unsettledNodes.clear();
        ancestors.clear();
        distance.clear();

        edges.addAll(graph.getEdges());
    }

    private void findMinimalDistances(@NonNull Vertex node) {
        for (Vertex target : getNeighbors(node)) {
            if (getShortestDistance(target) > getShortestDistance(node) + getDistance(node, target)) {
                distance.put(target, getShortestDistance(node) + getDistance(node, target));
                ancestors.put(target, node);
                unsettledNodes.add(target);
            }
        }
    }

    private float getDistance(@NonNull Vertex node, @NonNull Vertex target) {
        for (Edge edge : edges) {
            if (edge.getSource().equals(node) && edge.getDestination().equals(target) ||
                    edge.getDestination().equals(node) && edge.getSource().equals(target)) {
                return edge.getWeight();
            }
        }
        throw new IllegalStateException("Error in graph state, check the consistency of vertices and edges");
    }

    @NonNull
    private List<Vertex> getNeighbors(@NonNull Vertex node) {
        final List<Vertex> neighbors = new ArrayList<>();
        for (Edge edge : edges) {
            if (edge.getSource().equals(node) && isNotSettled(edge.getDestination())) {
                neighbors.add(edge.getDestination());
            }
            if (edge.getDestination().equals(node) && isNotSettled(edge.getSource())) {
                neighbors.add(edge.getSource());
            }
        }
        return neighbors;
    }

    @NonNull
    private Vertex getMinimum(@NonNull List<Vertex> vertices) {
        Vertex minimum = vertices.get(0);
        for (Vertex vertex : vertices) {
            if (getShortestDistance(vertex) < getShortestDistance(minimum)) {
                minimum = vertex;
            }
        }
        return minimum;
    }

    private boolean isNotSettled(@NonNull Vertex vertex) {
        return !settledNodes.contains(vertex);
    }

    private float getShortestDistance(@NonNull Vertex destination) {
        return distance.containsKey(destination) ? distance.get(destination) : Float.MAX_VALUE;
    }

    @NonNull
    private List<Vertex> getPath(@NonNull Vertex destination) {
        final List<Vertex> path = new ArrayList<>();
        if (ancestors.get(destination) == null) {
            return Collections.emptyList();
        }
        Vertex step = destination;
        path.add(step);
        while (ancestors.get(step) != null) {
            step = ancestors.get(step);
            path.add(step);
        }
        Collections.reverse(path);
        return path;
    }
}
