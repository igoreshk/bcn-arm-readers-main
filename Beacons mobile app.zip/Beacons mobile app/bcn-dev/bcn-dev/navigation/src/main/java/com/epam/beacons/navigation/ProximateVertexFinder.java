package com.epam.beacons.navigation;

import androidx.annotation.NonNull;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Graph;
import com.epam.beacons.Vertex;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class ProximateVertexFinder {

    @Inject
    ProximateVertexFinder() { //default constructor for dagger
    }

    @NonNull
    public Vertex findProximateVertex(@NonNull Graph graph, @NonNull Coordinate location) {
        double minDistance = Double.MAX_VALUE;
        Vertex proximateVertex = null;
        for (Vertex vertex : graph.getVertices()) {
            final double distanceToVertex = Math.sqrt(
                    Math.pow((vertex.getCoordinate().getLatitude() - location.getLatitude()), 2) +
                            Math.pow((vertex.getCoordinate().getLongitude() - location.getLongitude()), 2));
            if (distanceToVertex < minDistance) {
                minDistance = distanceToVertex;
                proximateVertex = vertex;
            }
        }
        if (proximateVertex == null) {
            throw new IllegalStateException("Path to the point can't be found");
        }
        return proximateVertex;
    }
}
