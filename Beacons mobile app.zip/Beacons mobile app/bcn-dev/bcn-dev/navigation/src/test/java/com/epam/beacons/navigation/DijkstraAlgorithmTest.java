package com.epam.beacons.navigation;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Edge;
import com.epam.beacons.Graph;
import com.epam.beacons.Vertex;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class DijkstraAlgorithmTest {

    private DijkstraAlgorithm dijkstra;
    private Graph             graph;
    private Vertex            source;
    private Vertex            destination;
    private List<Vertex>      expectedPath;
    private List<Vertex>      expectedPathBack;

    @Before
    public void setUp() {
        dijkstra = new DijkstraAlgorithm();

        final List<Vertex> vertices = new ArrayList<>();
        for (int i = 0; i < 11; i++) {
            vertices.add(new Vertex(i, new Coordinate(0, 0)));
        }

        final List<Edge> edges = new ArrayList<>(Arrays.asList(
                new Edge(vertices.get(0), vertices.get(1), 85f),
                new Edge(vertices.get(0), vertices.get(2), 217f),
                new Edge(vertices.get(0), vertices.get(4), 173.5f),
                new Edge(vertices.get(2), vertices.get(6), 186f),
                new Edge(vertices.get(2), vertices.get(7), 103.4f),
                new Edge(vertices.get(3), vertices.get(7), 183f),
                new Edge(vertices.get(5), vertices.get(8), 250f),
                new Edge(vertices.get(8), vertices.get(9), 84f),
                new Edge(vertices.get(7), vertices.get(9), 167.33f),
                new Edge(vertices.get(4), vertices.get(9), 502f),
                new Edge(vertices.get(9), vertices.get(10), 40f),
                new Edge(vertices.get(1), vertices.get(10), 600.9999f)
        ));
        graph = new Graph(0, 0, vertices, edges);

        source = vertices.get(0);
        destination = vertices.get(10);
        expectedPath = new ArrayList<>(Arrays.asList(
                vertices.get(0),
                vertices.get(2),
                vertices.get(7),
                vertices.get(9),
                vertices.get(10)
        ));
        expectedPathBack = new ArrayList<>(expectedPath);
        Collections.reverse(expectedPathBack);
    }

    @Test
    public void testGetPath() {
        final List<Vertex> path = dijkstra.getPath(graph, source, destination);
        assertEquals(expectedPath, path);
    }

    @Test
    public void testGetPathBack() {
        final List<Vertex> pathBack = dijkstra.getPath(graph, destination, source);
        assertEquals(expectedPathBack, pathBack);
    }
}
