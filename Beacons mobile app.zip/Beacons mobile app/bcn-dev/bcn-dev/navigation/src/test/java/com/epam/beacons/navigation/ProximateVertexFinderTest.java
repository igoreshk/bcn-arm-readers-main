package com.epam.beacons.navigation;

import com.epam.beacons.Coordinate;
import com.epam.beacons.Graph;
import com.epam.beacons.Vertex;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class ProximateVertexFinderTest {

    private final ProximateVertexFinder proximateVertexFinder = new ProximateVertexFinder();
    private Graph      graph;
    private Coordinate coordinate;
    private Vertex     expectedVertex;

    @Before
    public void setUp() {
        coordinate = new Coordinate(0, 0);
        expectedVertex = new Vertex(2, new Coordinate(1, 0));

        final List<Vertex> vertices = Arrays.asList(
                new Vertex(1, new Coordinate(1, 1)),
                expectedVertex,
                new Vertex(3, new Coordinate(1, 2))
        );
        graph = new Graph(0, 0, vertices, Collections.emptyList());
    }

    @Test
    public void testFindProximateVertex() {
        final Vertex vertex = proximateVertexFinder.findProximateVertex(graph, coordinate);
        assertEquals(expectedVertex, vertex);
    }
}
