#!/bin/bash

JOB_URL=$1
VERSION=$2

if [[ $# -ne 2 ]]
then 
    echo "Script for calculating next version of app release"
    echo "Usage: $0 [job_url] [version]" 
    exit 1
fi

BRANCH=`echo $JOB_URL | rev | awk -F'/' '{print $2}' | rev `
URL=`echo $JOB_URL | rev | cut -f 2 -d  '/' --complement | rev`


function get_last_version(){
   version=`curl -v --silent $2$1/lastSuccessfulBuild/consoleText 2>&1 | grep 'PversionName' | grep 'build' | awk '{print $6}' | awk -F= '{print $2}'`
   echo "$version"
}


function increment_release(){
   
    version=`echo $1 | awk -F. '{print $1}'` 
    release=`echo $1 | awk -F. '{print $2}'` 
    mod=0 

    if [[ $VERSION == $version ]]; then
        release=$((release+1))

    else
        version=$VERSION
        release=0
    fi

    echo "$version.$release.$mod"
}

function increment_modification(){
    version=`echo $1 | awk -F. '{print $1}'` 
    release=`echo $1 | awk -F. '{print $2}'` 
    mod=`echo $1 | awk -F. '{print $3}'`   
    mod=$((mod+1))

    echo "$version.$release.$mod"
}


case "$BRANCH" in
    "master")
         MASTER_VER=`get_last_version master $URL`
    
        if [[ $MASTER_VER == "" ]]; then
            MASTER_VER="0.0.0"
        fi
        increment_release $MASTER_VER 
        ;;
    *) 
        BRANCH_REL=`get_last_version $BRANCH $URL`
        MASTER_REL=`get_last_version master $URL`
        if [[ $MASTER_REL == "" ]]; then
            MASTER_REL="0.0.0"
        fi

        if [[ $BRANCH_REL == "" ]]; then
            BRANCH_REL=$MASTER_REL
        fi

        branch_version=`echo $BRANCH_REL | awk -F. '{print $1}'`
        branch_release=`echo $BRANCH_REL | awk -F. '{print $2}'`

        master_version=`echo $MASTER_REL | awk -F. '{print $1}'`
        master_release=`echo $MASTER_REL | awk -F. '{print $2}'`


        if [[ $master_version == $branch_version ]] && [[ $master_release == $branch_release ]]; then
            increment_modification $BRANCH_REL
        else
            increment_modification $MASTER_REL
        fi ;;
esac 

