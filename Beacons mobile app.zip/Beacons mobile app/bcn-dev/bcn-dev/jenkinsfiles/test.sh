#!/bin/bash

echo "New master build with version = 0"
./getversion.sh http://10.66.240.217:8080/job/BCN/job/IBeacon/job/IBeaconPipelineTest/job/master/  0

echo "New dev build with version = 0"
./getversion.sh http://10.66.240.217:8080/job/BCN/job/IBeacon/job/IBeaconPipelineTest/job/dev/  0 

echo "New master build with version = 1"
./getversion.sh http://10.66.240.217:8080/job/BCN/job/IBeacon/job/IBeaconPipelineTest/job/master/  1

echo "New dev build with version = 1"
./getversion.sh http://10.66.240.217:8080/job/BCN/job/IBeacon/job/IBeaconPipelineTest/job/dev/  1

echo "New 106-2 build with version = 0"
./getversion.sh http://10.66.240.217:8080/job/BCN/job/IBeacon/job/IBeaconPipelineTest/job/106-2/  0

echo "New 106-2 build with version = 1"
./getversion.sh http://10.66.240.217:8080/job/BCN/job/IBeacon/job/IBeaconPipelineTest/job/106-2/  1


echo "New 106 build with version = 0"
./getversion.sh http://10.66.240.217:8080/job/BCN/job/IBeacon/job/IBeaconPipelineTest/job/106/  0

echo "New 106 build with version = 1"
./getversion.sh http://10.66.240.217:8080/job/BCN/job/IBeacon/job/IBeaconPipelineTest/job/106/  1


