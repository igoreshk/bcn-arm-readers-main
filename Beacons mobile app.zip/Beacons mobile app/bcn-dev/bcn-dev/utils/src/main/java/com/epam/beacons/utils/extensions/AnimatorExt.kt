package com.epam.beacons.utils.extensions

import android.animation.Animator
import android.animation.AnimatorListenerAdapter

fun Animator.doOnFinish(action: () -> Unit) {
    addListener(object : AnimatorListenerAdapter() {
        override fun onAnimationEnd(animation: Animator?) {
            action()
            removeListener(this)
        }

        override fun onAnimationCancel(animation: Animator?) {
            action()
            removeListener(this)
        }
    })
}

fun Animator.doOnStart(action: () -> Unit) {
    addListener(object : AnimatorListenerAdapter() {
        override fun onAnimationStart(animation: Animator?) {
            action()
            removeListener(this)
        }
    })
}

fun Animator.doOnRepeat(action: () -> Unit) {
    addListener(object : AnimatorListenerAdapter() {
        override fun onAnimationRepeat(animation: Animator?) {
            action()
        }
    })
}

fun Animator.doOnStart(needRemoveListener: Boolean = true, action: () -> Unit) {
    addListener(object : AnimatorListenerAdapter() {
        override fun onAnimationStart(animation: Animator?) {
            action()
            if (needRemoveListener) removeListener(this)
        }
    })
}

fun Animator.doOnFinish(needRemoveListener: Boolean = true, action: () -> Unit) {
    addListener(object : AnimatorListenerAdapter() {
        override fun onAnimationEnd(animation: Animator?) {
            action()
            if (needRemoveListener) removeListener(this)
        }

        override fun onAnimationCancel(animation: Animator?) {
            action()
            if (needRemoveListener) removeListener(this)
        }
    })
}
