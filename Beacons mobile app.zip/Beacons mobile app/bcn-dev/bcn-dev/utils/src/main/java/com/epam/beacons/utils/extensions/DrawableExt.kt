package com.epam.beacons.utils.extensions

import android.graphics.drawable.Drawable
import androidx.core.graphics.drawable.DrawableCompat

fun Drawable.tint(color: Int) = DrawableCompat.setTint(this, color)
