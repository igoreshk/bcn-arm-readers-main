package com.epam.beacons.utils.extensions

import android.content.Context
import android.graphics.drawable.Drawable
import androidx.annotation.ColorInt
import androidx.annotation.ColorRes
import androidx.annotation.DimenRes
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import android.widget.Toast
import com.epam.beacons.utils.R

fun Context.string(@StringRes stingRes: Int): String = getString(stingRes)

@ColorInt
fun Context.color(@ColorRes colorRes: Int): Int = ContextCompat.getColor(this, colorRes)

fun Context.drawable(@DrawableRes drawableRes: Int): Drawable? = ContextCompat.getDrawable(this, drawableRes)

fun Context.drawableOrDefault(@DrawableRes drawableRes: Int, @DrawableRes default: Int = R.drawable.ic_error) =
        this.drawable(drawableRes) ?: this.drawable(default) ?: throw IllegalArgumentException("Default drawable value is null")

fun Context.dimenPx(@DimenRes dimenRes: Int): Int = resources.getDimensionPixelSize(dimenRes)

fun Context.dimenPxFloat(@DimenRes dimenRes: Int): Float = resources.getDimension(dimenRes)

fun Context.toast(@StringRes stringRes: Int, duration: Int = Toast.LENGTH_SHORT) {
    Toast.makeText(this, stringRes, duration).show()
}

fun Context.alphaComponent(@ColorRes colorRes: Int, alpha: Int) = ColorUtils.setAlphaComponent(this.color(colorRes), alpha)

fun Context.getStatusBarHeight(): Int {
    val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
    return if (resourceId > 0) resources.getDimensionPixelSize(resourceId) else 0
}
