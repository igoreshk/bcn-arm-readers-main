package com.epam.beacons.utils.extensions

import android.animation.ObjectAnimator
import android.animation.TimeInterpolator
import android.content.Context
import android.graphics.Rect
import androidx.annotation.LayoutRes
import androidx.core.view.ViewCompat
import android.util.Property
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ViewAnimator

private const val NO_ADDITIONAL_ACTIONS_FLAG = 0
private const val KEYBOARD_VISIBILITY_COEF = 0.15

fun ViewAnimator.show(view: View) {
    if (displayedChild == indexOfChild(view)) {
        return
    }

    displayedChild = indexOfChild(view)
}

fun View.visible(visible: Boolean) {
    visibility = if (visible) View.VISIBLE else View.GONE
}

fun View.isClickableAndFocusable(state: Boolean) {
    isClickable = state
    isFocusable = state
}

fun View.elevation(elevation: Float) {
    ViewCompat.setElevation(this, elevation)
}

fun ViewGroup.inflate(@LayoutRes layout: Int, attachToRoot: Boolean = false): View =
        LayoutInflater.from(this.context).inflate(layout, this, attachToRoot)

fun View.setStatusBarInvisible() {
    systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
}

fun View.toAnimator(
        propertyName: Property<View, Float>,
        propertyValue: Float,
        duration: Long = -1L,
        interpolator: TimeInterpolator? = null
): ObjectAnimator {
    val animator = ObjectAnimator.ofFloat(this, propertyName, propertyValue)
    if (duration > 0L) animator.duration = duration
    interpolator?.let { animator.interpolator = it }
    return animator
}

fun View.doOnLayoutChange(action: () -> Unit) {
    addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
        override fun onLayoutChange(v: View?, l: Int, t: Int, r: Int, b: Int, oL: Int, oT: Int, oR: Int, oB: Int) {
            action()
            removeOnLayoutChangeListener(this)
        }
    })
}

fun View.showKeyboard(visible: Boolean, flag: Int = NO_ADDITIONAL_ACTIONS_FLAG) {
    val inputManager = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
    if (visible) {
        requestFocus()
        isFocusableInTouchMode = true
        inputManager?.showSoftInput(this, flag)
    } else {
        isFocusable = false
        inputManager?.hideSoftInputFromWindow(windowToken, flag)
    }
}

fun View.computeUsableHeight(): Int {
    val rect = Rect()
    getWindowVisibleDisplayFrame(rect)
    return rect.bottom - rect.top
}

fun View.isKeyboardVisible(): Boolean {
    val rect = Rect()
    getWindowVisibleDisplayFrame(rect)
    val keypadHeight = rootView.height - rect.bottom
    return keypadHeight > rootView.height * KEYBOARD_VISIBILITY_COEF
}
