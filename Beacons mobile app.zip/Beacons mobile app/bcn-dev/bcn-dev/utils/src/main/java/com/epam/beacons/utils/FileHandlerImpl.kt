package com.epam.beacons.utils

import com.epam.beacons.Beacon
import com.epam.beacons.Coordinate
import com.epam.beacons.DataUnit
import com.epam.beacons.RecordedData
import com.epam.beacons.interactors.util.FileHandler
import com.epam.beacons.tools.Logger
import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Single
import org.apache.commons.csv.CSVFormat
import org.apache.commons.csv.CSVPrinter
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FileHandlerImpl @Inject constructor(private val logger: Logger, private val file: File?) : FileHandler {

    override fun writeData(data: List<RecordedData>): Completable = Completable.fromAction {
        var writer: OutputStreamWriter? = null
        var printer: CSVPrinter? = null

        try {
            writer = OutputStreamWriter(FileOutputStream(file), CHARSET)
            printer = CSVFormat.DEFAULT
                    .withHeader(UUID, MAJOR, MINOR,
                            TX_POWER, RSSI, DELTA_TIME,
                            AVG_RSSI, DISTANCE,
                            SMOOTH_LAT, SMOOTH_LON,
                            TRILAT_LAT, TRILAT_LON
                    )
                    .print(writer)
            for (recordedData in data) {
                for ((beacon, deltaTime, avgRssi, distance) in recordedData.dataUnits) {
                    writeBeacon(beacon, deltaTime, avgRssi, distance, printer)
                }
                writeCoordinates(recordedData.boundCoord, recordedData.trilaterationCoordinate, printer)
            }
        } finally {
            AppUtils.closeQuietly(printer, writer)
        }
    }.doOnError { e ->
        logger.e(
                LOG_TAG,
                String.format("Can not print to file %s", if (file != null) file.name else UNKNOWN_FILE),
                e
        )
    }

    private fun writeBeacon(b: Beacon, deltaTime: Long, avgRssi: Int, distance: Double, printer: CSVPrinter) {
        printer.printRecord(b.uuid, b.major, b.minor, b.txPower, b.rssi, deltaTime, avgRssi, distance)
        printer.flush()
    }

    private fun writeCoordinates(smoothCoord: Coordinate?, trilatCoord: Coordinate?, printer: CSVPrinter) {
        printer.printRecord(EMPTY_FIELD, EMPTY_FIELD, EMPTY_FIELD,
                EMPTY_FIELD, EMPTY_FIELD, EMPTY_FIELD,
                EMPTY_FIELD, EMPTY_FIELD,
                smoothCoord?.latitude ?: NULL_COORD,
                smoothCoord?.longitude ?: NULL_COORD,
                trilatCoord?.latitude ?: NULL_COORD,
                trilatCoord?.longitude ?: NULL_COORD
        )
        printer.flush()
    }

    override fun getFile(): Maybe<File?> = Maybe.fromCallable { file }
            .switchIfEmpty(Maybe.error(FileNotFoundException()))

    override fun readData(filePath: String): Single<List<RecordedData>> {
        val recordedDataList = mutableListOf<RecordedData>()
        val file = File(filePath)
        val reader = InputStreamReader(FileInputStream(file), CHARSET)
        var dataUnits = mutableListOf<DataUnit>()
        try {
            val records = CSVFormat.EXCEL.withHeader().parse(reader)
            for (record in records) {
                if (record.get(UUID) != EMPTY_FIELD) {
                    dataUnits.add(DataUnit(Beacon(record.get(UUID), record.get(MAJOR).toInt(), record.get(MINOR).toInt(),
                            record.get(TX_POWER).toDouble(), record.get(RSSI).toInt()), record.get(DELTA_TIME).toLong(),
                            record.get(AVG_RSSI).toInt(), record.get(DISTANCE).toDouble()))
                } else {
                    recordedDataList.add(RecordedData(
                            dataUnits,
                            Coordinate(record.get(TRILAT_LAT).toDouble(), record.get(TRILAT_LON).toDouble()),
                            Coordinate(record.get(SMOOTH_LAT).toDouble(), record.get(SMOOTH_LON).toDouble())
                    ))
                    dataUnits = mutableListOf()
                }
            }
        } catch (e: IOException) {
            logger.e(LOG_TAG, "Reading from file error", e)
        } finally {
            AppUtils.closeQuietly(reader)
        }
        return Single.fromCallable { recordedDataList }
    }

    companion object {
        private val LOG_TAG = FileHandlerImpl::class.java.simpleName
        private const val UNKNOWN_FILE = "(file not found)"
        private const val CHARSET = "UTF-8"
        private const val MINOR = "Minor"
        private const val UUID = "Uuid"
        private const val MAJOR = "Major"
        private const val TX_POWER = "TxPower"
        private const val RSSI = "Rssi"
        private const val AVG_RSSI = "AvgRssi"
        private const val DISTANCE = "Distance"
        private const val DELTA_TIME = "Delta time"
        private const val SMOOTH_LAT = "Smooth lat"
        private const val SMOOTH_LON = "Smooth lon"
        private const val TRILAT_LAT = "Trilat lat"
        private const val TRILAT_LON = "Trilat lon"
        private const val EMPTY_FIELD = ""
        private const val NULL_COORD = "Null Coord"
    }
}
