package com.epam.beacons.utils.extensions

import android.net.Uri
import android.os.Environment

private const val PRIMARY_PREFIX = "primary"
private const val COLON_CHAR = ":"
private const val SLASH = "/"
private val externalStoragePath = Environment.getExternalStorageDirectory().toString() + SLASH

/**
 * Required for cutting URI to just file name.
 *
 * In case of a different file explorer we can encounter situation when different
 * URIs returned. For example one file explorer may return storage/emulated/${user_number}/file_name when
 * URI from another might be external_storage/file_name or even external_storage/primary:file_name.
 *
 * @return pure file name.
 */
fun Uri.getExternalPath() = lastPathSegment?.run {
    if (this.split(COLON_CHAR)[0] == PRIMARY_PREFIX) {
        externalStoragePath + this.substring(this.indexOf(COLON_CHAR) + 1)
    } else {
        externalStoragePath + lastPathSegment
    }
}
