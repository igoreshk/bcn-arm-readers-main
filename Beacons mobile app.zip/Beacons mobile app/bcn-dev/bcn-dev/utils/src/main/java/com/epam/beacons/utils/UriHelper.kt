package com.epam.beacons.utils

import android.content.Context
import android.os.Environment
import androidx.core.content.FileProvider
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UriHelper @Inject constructor(private val context: Context) {

    fun getPathFromFile(file: File) = FileProvider.getUriForFile(context, AUTHORITY, file).toString()

    fun getPathFromFile(filePath: String) =
            FileProvider.getUriForFile(context, AUTHORITY, File(Environment.getExternalStorageDirectory().absolutePath, filePath)).toString()

    companion object {
        private const val AUTHORITY = "com.epam.beacons.fileprovider"
    }
}
