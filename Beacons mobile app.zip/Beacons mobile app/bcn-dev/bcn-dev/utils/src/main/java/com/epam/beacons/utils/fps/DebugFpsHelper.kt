package com.epam.beacons.utils.fps

import android.app.Activity
import javax.inject.Singleton

@Singleton
class DebugFpsHelper : FpsHelper {

    override fun show(activity: Activity) {

    }

    override fun hide(activity: Activity) {

    }
}
