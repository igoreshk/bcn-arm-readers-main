package com.epam.beacons.utils;

import android.os.Build;
import androidx.annotation.Nullable;

import java.io.Closeable;
import java.io.IOException;

public class AppUtils {

    private AppUtils() { // private constructor to hide the implicit public one
    }

    public static boolean isO() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O;
    }

    public static void closeQuietly(@Nullable Closeable... closeables) {
        if (closeables == null) {
            return;
        }
        try {
            for (Closeable c : closeables) {
                if (c != null) {
                    c.close();
                }
            }
        } catch (IOException e) {
            // no exception handling
        }
    }
}
