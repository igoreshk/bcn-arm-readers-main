package com.epam.beacons.utils.extensions

import androidx.annotation.ColorRes
import android.view.Window

fun Window.changeStatusBarColor(@ColorRes colorRes: Int) {
    statusBarColor = context.color(colorRes)
}
