package com.epam.beacons.utils.extensions

import android.text.Editable
import android.text.TextWatcher
import android.view.inputmethod.EditorInfo
import android.widget.EditText

private const val EMPTY_TEXT = ""

fun EditText.onTextChange(
        actionBeforeChange: (s: CharSequence?) -> Unit = {},
        actionAfterChange: (s: CharSequence?) -> Unit = {},
        actionOnChange: (s: CharSequence?) -> Unit) {
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            actionBeforeChange(s)
        }

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            actionOnChange(s)
        }

        override fun afterTextChanged(s: Editable?) {
            actionAfterChange(s)
        }
    })
}

fun EditText.onEditorAction(action: (query: CharSequence) -> Unit) {
    setOnEditorActionListener { view, actionId, _ ->
        if (actionId == EditorInfo.IME_ACTION_SEARCH) {
            action(view.text)
            return@setOnEditorActionListener true
        }
        false
    }
}

fun EditText.clear() {
    setText(EMPTY_TEXT)
}
