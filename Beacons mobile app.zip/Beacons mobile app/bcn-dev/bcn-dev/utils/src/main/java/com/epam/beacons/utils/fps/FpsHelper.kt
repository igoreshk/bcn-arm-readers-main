package com.epam.beacons.utils.fps

import android.app.Activity
import javax.inject.Singleton

@Singleton
interface FpsHelper {

    fun show(activity: Activity)

    fun hide(activity: Activity)
}
