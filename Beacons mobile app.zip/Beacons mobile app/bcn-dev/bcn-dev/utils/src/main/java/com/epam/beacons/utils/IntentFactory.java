package com.epam.beacons.utils;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import androidx.annotation.NonNull;


public class IntentFactory {

    @NonNull
    private static final String FILE_TYPE                          = "text/csv";
    @NonNull
    private static final String FILE_TYPE_FOR_ANDROID_FILE_MANAGER = "text/comma-separated-values";

    private IntentFactory() { // private constructor to avoid instance creation
    }

    @NonNull
    public static Intent getEnableBluetoothIntent() {
        return new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
    }

    @NonNull
    public static <T extends Activity> Intent getActivityIntent(Context context, Class<T> activityClass) {
        return new Intent(context, activityClass);
    }

    @NonNull
    public static Intent getShareFileIntent(@NonNull String filePath) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.setType(FILE_TYPE);
        intent.putExtra(Intent.EXTRA_STREAM, Uri.parse(filePath));
        return intent;
    }

    @NonNull
    public static Intent getFileManagerIntent() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType(FILE_TYPE_FOR_ANDROID_FILE_MANAGER);
        return intent;
    }
}
