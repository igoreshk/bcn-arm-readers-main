package com.epam.beacons.utils.fps

import android.app.Activity
import javax.inject.Singleton

@Singleton
class ReleaseFpsHelper : FpsHelper {
    override fun show(activity: Activity) {
        //no-op
    }

    override fun hide(activity: Activity) {
        //no-op
    }
}
