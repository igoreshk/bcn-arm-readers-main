package com.epam.beacons.utils.extensions

import androidx.annotation.IdRes
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity

fun FragmentActivity.replaceFragment(@IdRes containerResId: Int, fragment: Fragment, tag: String? = null) {
    supportFragmentManager.beginTransaction().replace(containerResId, fragment, tag).commit()
}
