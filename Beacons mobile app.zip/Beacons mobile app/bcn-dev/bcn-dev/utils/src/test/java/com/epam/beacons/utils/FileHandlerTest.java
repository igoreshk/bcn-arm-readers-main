package com.epam.beacons.utils;

import android.os.Environment;

import com.epam.beacons.Beacon;
import com.epam.beacons.Coordinate;
import com.epam.beacons.DataUnit;
import com.epam.beacons.RecordedData;
import com.epam.beacons.tools.Logger;
import com.epam.beacons.tools.utils.FilePathProvider;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@RunWith(RobolectricTestRunner.class)
@Config(manifest = Config.NONE)
public class FileHandlerTest {
    @Mock
    private Logger logger;

    private FileHandlerImpl fileHandler;

    private List<RecordedData> recordedDataList;

    private FilePathProvider filePathProvider = new FilePathProvider(Locale.getDefault());

    private File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), filePathProvider.filePath());

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        fileHandler = new FileHandlerImpl(logger, file);

        recordedDataList = new ArrayList<>();
        RecordedData recordedData = new RecordedData();
        recordedData.getDataUnits().add(new DataUnit(new Beacon("uuid", 1, 1, -50, -60), 1));
        recordedData.getDataUnits().add(new DataUnit(new Beacon("uuid", 2, 2, -60, -70), 3));
        recordedData.setBoundCoord(new Coordinate(3, 3));
        recordedData.setTrilaterationCoordinate(new Coordinate(2, 2));
        recordedDataList.add(recordedData);
    }

    @Test
    public void testWriteDataCommonBehaviour() {
        fileHandler.writeData(recordedDataList)
                   .test()
                   .assertSubscribed()
                   .assertComplete();
    }

    @Test
    public void testGetFile() {
        fileHandler.getFile()
                   .test()
                   .assertValue(file);
    }

    @Test
    public void testGetFileError() {
        fileHandler = new FileHandlerImpl(logger, null);

        fileHandler.getFile()
                   .test()
                   .assertError(FileNotFoundException.class);
    }
}
