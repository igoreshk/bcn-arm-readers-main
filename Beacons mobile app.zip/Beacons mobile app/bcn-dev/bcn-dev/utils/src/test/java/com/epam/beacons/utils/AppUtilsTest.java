package com.epam.beacons.utils;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStream;

import static junit.framework.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@RunWith(RobolectricTestRunner.class)
@Config(manifest = Config.NONE)
public class AppUtilsTest {
    @Mock
    private OutputStream outputStream;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    @Config(sdk = 26)
    public void testIsO() {
        assertEquals(AppUtils.isO(), true);
    }

    @Test
    @Config(sdk = 21)
    public void testIsNotO() {
        assertEquals(AppUtils.isO(), false);
    }

    @Test
    public void testCloseQuietly() throws IOException {
        AppUtils.closeQuietly(outputStream);
        verify(outputStream).close();
    }

    @Test
    public void testClosableNullWithNoErrors() {
        AppUtils.closeQuietly((Closeable) null);
    }

    @Test
    public void testClosableException() throws IOException {
        doThrow(new IOException()).when(outputStream).close();
        AppUtils.closeQuietly(outputStream);
        verify(outputStream, never()).write(anyInt());
    }
}