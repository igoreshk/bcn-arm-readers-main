package com.epam.beacons.interactors.util

import com.epam.beacons.Beacon
import com.epam.beacons.Coordinate
import com.epam.beacons.DataUnit
import com.epam.beacons.RecordedData
import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Observable
import java.io.File
import java.util.ArrayList
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Singleton

@Singleton
class RecordHelper(private val fileHandler: FileHandler, private val delayMark: Long) {

    val dataForLoad = ArrayList<LoadDataUnit>()
    val buffer = ConcurrentLinkedQueue<DataUnit>()
    var recordedData = RecordedData()
        private set
    var data = CopyOnWriteArrayList<RecordedData>()
        private set
    var isRecording = false
        private set
    var isPlaying = false
        private set
    private val isFirstBeaconsGroup = AtomicBoolean(true)

    fun startRecording(): Completable = Completable.fromAction {
        isFirstBeaconsGroup.set(true)
        clearAllData()
        isPlaying = false
        isRecording = true
    }

    fun startPlaying(): Completable = Completable.fromAction {
        isRecording = false
        isPlaying = true
    }

    fun setDataFromFile(data: List<RecordedData>) {
        this.data = CopyOnWriteArrayList(data)
        clearTempData()
        prepareDataForLoad()
    }

    fun readDataFromFile(filePath: String) = fileHandler.readData(filePath)

    fun getFile(): Maybe<File?> = fileHandler.getFile()

    fun saveFile(): Completable = fileHandler.writeData(data)

    fun resetRecordHelper(): Completable = Completable.fromAction {
        isPlaying = false
        isRecording = false
        clearAllData()
    }

    fun setRecordingState(recording: Boolean): Completable = Completable.fromAction {
        isRecording = recording
        if (!recording) {
            prepareDataForLoad()
        }
    }

    fun load(): Observable<Beacon> = Observable.fromIterable(dataForLoad)
            .concatMap { loadDataUnit ->
                Observable.just(Beacon(loadDataUnit.beacon))
                        .delay(loadDataUnit.delayMark, TimeUnit.MILLISECONDS)
            }
            .doOnComplete { isPlaying = false }

    fun save(beacon: Beacon) {
        if (!isRecording) {
            return
        }

        buffer.add(DataUnit(Beacon(beacon)))
    }

    fun saveAvgRssi(inputBeacons: List<Beacon>) {
        if (!isRecording) {
            return
        }

        if (!isFirstBeaconsGroup.get()) {
            buffer.peek().deltaTime = delayMark
        } else {
            isFirstBeaconsGroup.set(false)
        }

        if (recordedData.dataUnits.addAll(buffer)) {
            buffer.clear()
        }

        inputBeacons.forEach { beacon ->
            recordedData.dataUnits.forEach {
                if (beacon == it.beacon) {
                    it.avgRssi = beacon.rssi
                }
            }
        }
    }

    fun saveDistanceToBeacon(beacon: Beacon, distance: Double) {
        if (!isRecording) {
            return
        }

        for (dataUnit in recordedData.dataUnits) {
            if (dataUnit.beacon == beacon) {
                dataUnit.distance = distance
            }
        }
    }

    fun saveTrilaterationCoordinate(coordinate: Coordinate?) {
        if (!isRecording) {
            return
        }
        recordedData.trilaterationCoordinate = coordinate
    }

    fun saveBoundAndFinishCycle(coordinate: Coordinate?) {
        if (!isRecording) {
            return
        }
        recordedData.boundCoord = coordinate
        data.add(recordedData)
        recordedData = RecordedData()
    }

    private fun clearTempData() {
        dataForLoad.clear()
        buffer.clear()
    }

    private fun clearAllData() {
        clearTempData()
        data.clear()
        recordedData = RecordedData()
    }

    private fun prepareDataForLoad() {
        data.forEach { it -> it.dataUnits.forEach { dataForLoad.add(LoadDataUnit(it.beacon, it.deltaTime)) } }
    }

    class LoadDataUnit(val beacon: Beacon, val delayMark: Long)
}
