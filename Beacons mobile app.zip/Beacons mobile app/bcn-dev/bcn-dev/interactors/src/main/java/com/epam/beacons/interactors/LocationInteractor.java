package com.epam.beacons.interactors;

import androidx.annotation.NonNull;

import com.epam.beacons.Beacon;
import com.epam.beacons.Coordinate;
import com.epam.beacons.Pivot;
import com.epam.beacons.bounders.DistanceBounder;
import com.epam.beacons.calibrator.BeaconCalibrator;
import com.epam.beacons.distance.BeaconDistanceCalculator;
import com.epam.beacons.distance.BeaconDistanceCalibrator;
import com.epam.beacons.filter.BeaconFilter;
import com.epam.beacons.graphbinder.GraphBinder;
import com.epam.beacons.interactors.shared.BeaconsGetter;
import com.epam.beacons.interactors.shared.FloorDeterminator;
import com.epam.beacons.interactors.util.MeasurementHelper;
import com.epam.beacons.interactors.util.RecordHelper;
import com.epam.beacons.interactors.util.StateHelper;
import com.epam.beacons.locator.TrilaterationSolver;
import com.epam.beacons.repository.DataRepo;
import com.epam.beacons.repository.LocationRepo;
import com.epam.beacons.smoothers.AverageSmoother;
import com.epam.beacons.tools.Logger;
import com.epam.beacons.tools.adapters.DisposableCompletableObserverAdapter;
import com.epam.beacons.tools.adapters.DisposableMaybeObserverAdapter;
import com.epam.beacons.tools.debug.DebugStorage;
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator;
import com.epam.beacons.tools.utils.ScaleFactorCalculator;
import com.epam.beacons.Track;

import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Maybe;
import io.reactivex.Observable;
import io.reactivex.Single;

@Singleton
public class LocationInteractor {
    private static final int    LAUNCH_SCANNING_DELAY = 1000; //solves the problem of incorrect first scans
    private static final double DESTINATION_RADIUS    = 3;
    private static final double DISTANCE_THRESHOLD    = 4;
    private static final String TAG = LocationInteractor.class.getSimpleName();

    @NonNull
    private final BeaconsGetter                beaconsGetter;
    @NonNull
    private final FloorDeterminator            floorDeterminator;
    @NonNull
    private final AverageSmoother              averageSmoother;
    @NonNull
    private final BeaconFilter                 beaconFilter;
    @NonNull
    private final BeaconCalibrator             beaconCalibrator;
    @NonNull
    private final BeaconDistanceCalibrator     distanceCalibrator;
    @NonNull
    private final BeaconDistanceCalculator     distanceCalculator;
    @NonNull
    private final TrilaterationSolver          trilaterationSolver;
    @NonNull
    private final DistanceBounder              distanceBounder;
    @NonNull
    private final LocationRepo                 locationRepo;
    @NonNull
    private final DataRepo                     dataRepo;
    @NonNull
    private final StateHelper                  stateHelper;
    @NonNull
    private final DebugStorage                 debugStorage;
    @NonNull
    private final RecordHelper                 recordHelper;
    @NonNull
    private final MeasurementHelper            measurementHelper;
    @NonNull
    private final GraphBinder                  graphBinder;
    @NonNull
    private final ScaleFactorCalculator        scaleFactorCalculator;
    @NonNull
    private final CoordinateDistanceCalculator coordinateDistanceCalculator;
    @NonNull
    private final Logger logger;

    private final int oneMeterAtEquator;

    @Inject
    public LocationInteractor(@NonNull BeaconsGetter beaconsGetter,
                              @NonNull FloorDeterminator floorDeterminator,
                              @NonNull AverageSmoother averageSmoother,
                              @NonNull BeaconFilter beaconFilter,
                              @NonNull BeaconCalibrator beaconCalibrator,
                              @NonNull BeaconDistanceCalibrator distanceCalibrator,
                              @NonNull BeaconDistanceCalculator distanceCalculator,
                              @NonNull TrilaterationSolver trilaterationSolver,
                              @NonNull DistanceBounder distanceBounder,
                              @NonNull LocationRepo locationRepo,
                              @NonNull DataRepo dataRepo,
                              @NonNull StateHelper stateHelper,
                              @NonNull DebugStorage debugStorage,
                              @NonNull RecordHelper recordHelper,
                              @NonNull MeasurementHelper measurementHelper,
                              @NonNull GraphBinder graphBinder,
                              @NonNull ScaleFactorCalculator scaleFactorCalculator,
                              @NonNull CoordinateDistanceCalculator coordinateDistanceCalculator,
                              @NonNull Logger logger,
                              int oneMeterAtEquator) {
        this.beaconsGetter = beaconsGetter;
        this.floorDeterminator = floorDeterminator;
        this.averageSmoother = averageSmoother;
        this.beaconFilter = beaconFilter;
        this.beaconCalibrator = beaconCalibrator;
        this.distanceCalibrator = distanceCalibrator;
        this.distanceCalculator = distanceCalculator;
        this.trilaterationSolver = trilaterationSolver;
        this.distanceBounder = distanceBounder;
        this.locationRepo = locationRepo;
        this.dataRepo = dataRepo;
        this.stateHelper = stateHelper;
        this.debugStorage = debugStorage;
        this.recordHelper = recordHelper;
        this.measurementHelper = measurementHelper;
        this.graphBinder = graphBinder;
        this.scaleFactorCalculator = scaleFactorCalculator;
        this.coordinateDistanceCalculator = coordinateDistanceCalculator;
        this.oneMeterAtEquator = oneMeterAtEquator;
        this.logger = logger;
    }

    @NonNull
    public Observable<Coordinate> getUserLocation() {
        return getLocatedBeacons().doOnSubscribe(disposable -> determineFloor())
                                  .filter(beacon -> stateHelper.getUserFloor() == stateHelper.getVisibleFloor())
                                  .compose(this::initDistanceCalibration)
                                  // don't use `delaySubscription`, use `delay`: `delay` don't delay error notifications
                                  .delay(LAUNCH_SCANNING_DELAY, TimeUnit.MILLISECONDS)
                                  .compose(this::applyAverageSmoother)
                                  .flatMap(beaconFilter::filterBeacons)
                                  .map(beaconCalibrator::calibrateTxPower)
                                  .compose(this::convertBeaconsToPivots)
                                  .compose(this::trilaterate)
                                  .compose(this::applyDistanceBounder)
                                  .compose(this::saveMeasurements)
                                  .compose(this::scaleCoordinates)
                                  .map(graphBinder::bind)
                                  .compose(this::scaleErrorRadius);
    }

    @NonNull
    public Single<Coordinate> getUserLocationOnce() {
        return getUserLocation().firstOrError();
    }

    @NonNull
    public Observable<Coordinate> getSimpleUserLocation() {
        return getLocatedBeacons().doOnSubscribe(disposable -> determineFloor())
                                  .filter(beacon -> stateHelper.getUserFloor() == stateHelper.getVisibleFloor())
//                                   don't use `delaySubscription`, use `delay`: `delay` don't delay error notifications
                                  .delay(LAUNCH_SCANNING_DELAY, TimeUnit.MILLISECONDS)
                                  .compose(this::applyAverageSmoother)
                                  .compose(this::convertBeaconsToPivotsSimpleLocation)
                                  .compose(this::nearestCoordinate)
                                  .compose(this::scaleCoordinates);
    }

    @NonNull
    public Completable isPlayFinished() {
        return beaconsGetter.getPlayFinished()
                            .andThen(beaconCalibrator.resetApproximation());
    }

    @NonNull
    public Maybe<Double> isDestinationReached(@NonNull Coordinate userLocation, @NonNull Coordinate destination) {
        return Maybe.fromCallable(() -> coordinateDistanceCalculator.calcDistance(userLocation, destination))
                    .filter(distance -> distance < getDistanceThreshold());
    }

    @NonNull
    public Completable postTracks(List<Track> tracks) {
        return dataRepo.postTracks(tracks);
    }

    @NonNull
    private Observable<Beacon> getLocatedBeacons() {
        return Observable.combineLatest(
                beaconsGetter.getBeacons(),
                getLocalBeacons(),
                (beacon, localBeacons) -> {
                    for (Beacon localBeacon : localBeacons) {
                        if (localBeacon.equals(beacon) && localBeacon.getCoordinate() != null) {
                            beacon.setCoordinate(new Coordinate(
                                    localBeacon.getCoordinate().getLatitude() * oneMeterAtEquator,
                                    localBeacon.getCoordinate().getLongitude() * oneMeterAtEquator
                            ));
                            break;
                        }
                    }
                    return beacon;
                }
        )
                         .filter(beacon -> beacon.getCoordinate() != null);
    }

    @NonNull
    private Observable<List<Beacon>> getLocalBeacons() {
        final int userFloor = stateHelper.getUserFloor();
        final int floor = userFloor == StateHelper.UNDEFINED ? stateHelper.getVisibleFloor() : userFloor;
        return locationRepo.getBeacons(stateHelper.getBuildingId(), floor)
                           .toObservable();
    }

    @NonNull
    private Observable<Beacon> initDistanceCalibration(@NonNull Observable<Beacon> beacons) {
        return beacons.doOnNext(beacon -> {
            locationRepo.initMeasurements().subscribe(new DisposableCompletableObserverAdapter() {});
            recordHelper.save(beacon);
        });
    }

    @NonNull
    private Observable<List<Beacon>> applyAverageSmoother(@NonNull Observable<Beacon> input) {
        return input.compose(averageSmoother::smoothBeaconData)
                    .filter(list -> !list.isEmpty())
                    .doOnNext(recordHelper::saveAvgRssi);
    }

    @NonNull
    private Observable<List<Pivot>> convertBeaconsToPivots(@NonNull Observable<List<Beacon>> input) {
        return input.flatMap(beacons -> Observable
                .fromIterable(beacons)
                .flatMapMaybe(beacon -> Maybe.zip(
                        locationRepo.getMeasurements(beacon.getRssi()),
                        locationRepo.getMeasurements(beacon.getRssi() - 1),
                        locationRepo.getMeasurements(beacon.getRssi() + 1),
                        Maybe.fromCallable(() -> beacon),
                        (measurements, nextMeasurements, prevMeasurements, currentBeacon) -> {

                            locationRepo.updateMeasurements(currentBeacon.getRssi(), measurements)
                                        .subscribe(new DisposableCompletableObserverAdapter() {});

                            double distance = distanceCalibrator.calibrateDistance(currentBeacon, measurements,
                                                                                   nextMeasurements, prevMeasurements
                            );

                            recordHelper.saveDistanceToBeacon(currentBeacon, distance);
                            measurementHelper.save(currentBeacon);
                            return new Pivot(currentBeacon.getCoordinate(), distance);
                        }
                ))
                .toList()
                .toObservable())
                    .doOnNext(pivots -> debugStorage.debugPivots(pivots)
                                                    .subscribe(new DisposableCompletableObserverAdapter() {}));
    }

    @NonNull
    private Observable<List<Pivot>> convertBeaconsToPivotsSimpleLocation(@NonNull Observable<List<Beacon>> input) {
        return input.flatMap(beacons -> Observable
                .fromIterable(beacons)
                .map(beacon -> new Pivot(beacon.getCoordinate(), distanceCalculator.calculateDistance(beacon.getTxPower(), beacon.getRssi())))
                .filter(pivot -> pivot.getDistance() < DISTANCE_THRESHOLD)
                .toList()
                .toObservable());
    }

    @NonNull
    private Observable<Coordinate> trilaterate(@NonNull Observable<List<Pivot>> input) {
        return input.map(trilaterationSolver::solve)
                    .doOnNext(recordHelper::saveTrilaterationCoordinate);
    }

    @NonNull
    private Observable<Coordinate> applyDistanceBounder(@NonNull Observable<Coordinate> input) {
        return input.compose(distanceBounder::bound)
                    .doOnNext(recordHelper::saveBoundAndFinishCycle);
    }

    @NonNull
    private Observable<Coordinate> saveMeasurements(@NonNull Observable<Coordinate> input) {
        return input.doOnNext(coordinate -> {
            measurementHelper.save(coordinate);
            locationRepo.putMeasurements(measurementHelper.getMeasurements())
                        .subscribe(new DisposableCompletableObserverAdapter() {});
            measurementHelper.clear();
        });
    }

    @NonNull
    private Observable<Coordinate> scaleCoordinates(@NonNull Observable<Coordinate> input) {
        return input.map(coordinate -> new Coordinate(
                                 coordinate.getLatitude() / oneMeterAtEquator,
                                 coordinate.getLongitude() / oneMeterAtEquator,
                                 coordinate.getErrorRadius() * scaleFactorCalculator.getScaleCoef() / oneMeterAtEquator
                         )
        );
    }

    @NonNull
    private Observable<Coordinate> scaleErrorRadius(@NonNull Observable<Coordinate> input) {
        return input.doOnNext(coordinate -> coordinate.setErrorRadius(coordinate.getErrorRadius() * oneMeterAtEquator));
    }

    private void determineFloor() {
        final int userFloorBeforeDetermination = stateHelper.getUserFloor();
        floorDeterminator.determineAndChangeFloor(
                beaconsGetter.getBeaconsPack(),
                locationRepo.getBeacons(stateHelper.getBuildingId())
        )
                         .doOnSuccess(floorNumber -> {
                             if (userFloorBeforeDetermination == StateHelper.UNDEFINED) {
                                 stateHelper.setVisibleFloor(floorNumber);
                             }
                         })
                         .subscribe(new DisposableMaybeObserverAdapter<Integer>() {});
    }

    @NonNull
    private Observable<Coordinate> nearestCoordinate(@NonNull Observable<List<Pivot>> input) {
        return input.filter(list -> !list.isEmpty())
                    .map(pivots -> {
                        Pivot nearest = pivots.get(0);
                        for (Pivot pivot : pivots) {
                            if (pivot.getDistance() < nearest.getDistance()) {
                                nearest = pivot;
                            }
                        }
                        return nearest.getCoordinate();
                    });
    }

    private double getDistanceThreshold() {
        return DESTINATION_RADIUS * scaleFactorCalculator.getScaleCoef() / oneMeterAtEquator;
    }
}
