package com.epam.beacons.interactors;

import androidx.annotation.NonNull;

import com.epam.beacons.interactors.util.RecordHelper;
import com.epam.beacons.notification.NotificationHelper;
import com.epam.beacons.tools.Logger;

import java.io.File;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Maybe;

@Singleton
public class BeaconsRecorderInteractor {

    private static final String TAG = BeaconsRecorderInteractor.class.getSimpleName();

    @NonNull
    private final RecordHelper       recordHelper;
    @NonNull
    private final NotificationHelper notificationHelper;
    @NonNull
    private final Logger             logger;

    @Inject
    BeaconsRecorderInteractor(@NonNull RecordHelper recordHelper,
                              @NonNull NotificationHelper notificationHelper,
                              @NonNull Logger logger) {
        this.recordHelper = recordHelper;
        this.notificationHelper = notificationHelper;
        this.logger = logger;
    }

    @NonNull
    public Completable startRecording() {
        return recordHelper.startRecording();
    }

    @NonNull
    public Completable stopRecording() {
        return recordHelper.setRecordingState(false)
                           .doOnError(exception -> {
                               if (exception instanceof IllegalStateException) {
                                   logger.i(TAG, exception.getMessage());
                               } else {
                                   logger.e(TAG, "unknown error: ", exception);
                               }
                           });
    }

    @NonNull
    public Completable startPlaying() {
        return recordHelper.startPlaying();
    }

    @NonNull
    public Completable saveToFile() {
        return recordHelper.saveFile()
                           .andThen(notificationHelper.showFileSavedNotification());
    }

    @NonNull
    public Completable updateData(@NonNull String filePath) {
        return recordHelper.readDataFromFile(filePath)
                           .doOnSuccess(recordHelper::setDataFromFile)
                           .toCompletable();
    }

    @NonNull
    public Maybe<File> getFile() {
        return recordHelper.getFile();
    }
}
