package com.epam.beacons.notification;

import androidx.annotation.NonNull;

import com.epam.beacons.IntentData;
import com.epam.beacons.Notification;
import com.epam.beacons.interactors.util.FileHandler;
import com.epam.beacons.tools.adapters.DisposableMaybeObserverAdapter;

import java.io.File;

import javax.inject.Inject;

import io.reactivex.Completable;

public class NotificationHelper {

    private static final String CHANNEL_ID = "beaconsChannel";
    @NonNull
    private final NotificationCenter notificationCenter;
    @NonNull
    private final FileHandler        fileHandler;

    @Inject
    NotificationHelper(@NonNull NotificationCenter notificationCenter, @NonNull FileHandler fileHandler) {
        this.notificationCenter = notificationCenter;
        this.fileHandler = fileHandler;
    }

    public Completable showFileSavedNotification() {
        return Completable.fromAction(
                () -> fileHandler.getFile()
                                 .doOnSuccess(
                                         file -> notificationCenter.showNotification(
                                                 new Notification.Builder(Notification.ImageType.FILE_DOWNLOAD)
                                                         .setTitle(String.format("File %s", file.getName()))
                                                         .setText(String.format("Saved to %s", file.getPath()))
                                                         .setLargeIcon(Notification.ImageType.LAUNCHER_ROUND)
                                                         .setChannelId(CHANNEL_ID)
                                                         .setIntentData(new IntentData(
                                                                 file.getName(),
                                                                 IntentData.ActionType.SHARE_SAVED_FILE,
                                                                 IntentData.IntentType.ACTIVITY
                                                         ))
                                                         .build()
                                         )
                                 ).subscribe(new DisposableMaybeObserverAdapter<File>() {})
        );
    }
}
