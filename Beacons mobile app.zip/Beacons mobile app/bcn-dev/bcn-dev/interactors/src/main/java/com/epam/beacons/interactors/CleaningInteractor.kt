package com.epam.beacons.interactors

import com.epam.beacons.graphbinder.GraphBinderData
import com.epam.beacons.interactors.util.RecordHelper
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.kalman.KalmanData
import com.epam.beacons.repository.DataRepo
import com.epam.beacons.repository.FavoritesRepo
import com.epam.beacons.repository.LocationRepo
import com.epam.beacons.repository.RoutingRepo
import com.epam.beacons.repository.SearchRepo
import com.epam.beacons.tools.CornerHelper
import io.reactivex.Completable
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CleaningInteractor
@Inject constructor(
        private val stateHelper: StateHelper,
        private val locationRepo: LocationRepo,
        private val dataRepo: DataRepo,
        private val routingRepo: RoutingRepo,
        private val searchRepo: SearchRepo,
        private val favoritesRepo: FavoritesRepo,
        private val recordHelper: RecordHelper,
        private val kalmanData: KalmanData,
        private val graphBinderData: GraphBinderData,
        private val cornerHelper: CornerHelper
) {
    fun clearBuildingData(): Completable = Completable.mergeArray(
            Completable.fromAction { stateHelper.userFloor = StateHelper.UNDEFINED },
            locationRepo.clearUserFloorBeaconsCache(),
            locationRepo.clearBeaconsCache(),
            dataRepo.clearGatesCache(),
            dataRepo.clearFloorNumbersCache(),
            routingRepo.clearGraphsCache(),
            searchRepo.clearPlacesCaches(),
            favoritesRepo.clearCache(),
            recordHelper.resetRecordHelper(),
            kalmanData.reset(),
            graphBinderData.clearRoute(),
            graphBinderData.clearGraph(),
            cornerHelper.clear()
    )
}
