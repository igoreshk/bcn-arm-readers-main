package com.epam.beacons.interactors.util;

import androidx.annotation.NonNull;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Observable;
import io.reactivex.subjects.BehaviorSubject;

@Singleton
public class StateHelper {
    public static final int UNDEFINED = Integer.MIN_VALUE;

    private String buildingId;
    private int  visibleFloor;
    private int  scaleFactor;
    private int userFloor = UNDEFINED;

    @NonNull
    private final BehaviorSubject<Integer> visibleFloorSubject = BehaviorSubject.create();

    @Inject
    public StateHelper() { // default constructor for dagger
    }

    public String getBuildingId() {
        return buildingId;
    }

    public void setBuildingId(String  id) {
        buildingId = id;
    }

    public int getVisibleFloor() {
        return visibleFloor;
    }

    public void setVisibleFloor(int number) {
        if (number != visibleFloor) {
            visibleFloor = number;
            visibleFloorSubject.onNext(number);
        }
    }

    public int getScaleFactor() {
        return scaleFactor;
    }

    public void setScaleFactor(int scaleFactor) {
        this.scaleFactor = scaleFactor;
    }

    public int getUserFloor() {
        return userFloor;
    }

    public void setUserFloor(int number) {
        userFloor = number;
    }

    @NonNull
    public Observable<Integer> getFloorNumberObservable() {
        return visibleFloorSubject;
    }
}
