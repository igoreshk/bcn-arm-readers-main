package com.epam.beacons.interactors.util

import com.epam.beacons.RecordedData
import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Single
import java.io.File

interface FileHandler {
    fun readData(filePath: String): Single<List<RecordedData>>

    fun writeData(data: List<RecordedData>): Completable

    fun getFile(): Maybe<File?>
}
