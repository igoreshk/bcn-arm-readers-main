package com.epam.beacons.interactors;

import androidx.annotation.NonNull;

import com.epam.beacons.Beacon;
import com.epam.beacons.Building;
import com.epam.beacons.Floor;
import com.epam.beacons.Gate;
import com.epam.beacons.Graph;
import com.epam.beacons.Pivot;
import com.epam.beacons.graphbinder.GraphBinderData;
import com.epam.beacons.interactors.util.BuildingComparator;
import com.epam.beacons.interactors.util.StateHelper;
import com.epam.beacons.repository.DataRepo;
import com.epam.beacons.repository.RoutingRepo;
import com.epam.beacons.tools.adapters.DisposableMaybeObserverAdapter;
import com.epam.beacons.tools.debug.DebugStorage;
import com.epam.beacons.tools.utils.ScaleFactorCalculator;

import java.util.Collections;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Maybe;
import io.reactivex.Observable;

@Singleton
public class DataInteractor {
    @NonNull
    private final DataRepo              dataRepo;
    @NonNull
    private final RoutingRepo           routingRepo;
    @NonNull
    private final StateHelper           stateHelper;
    @NonNull
    private final BuildingComparator    buildingComparator;
    @NonNull
    private final DebugStorage          debugStorage;
    @NonNull
    private final GraphBinderData       graphBinderData;
    @NonNull
    private final ScaleFactorCalculator scaleFactorCalculator;

    @Inject
    DataInteractor(@NonNull DataRepo dataRepo,
                   @NonNull RoutingRepo routingRepo,
                   @NonNull StateHelper stateHelper,
                   @NonNull BuildingComparator buildingComparator,
                   @NonNull DebugStorage debugStorage,
                   @NonNull GraphBinderData graphBinderData,
                   @NonNull ScaleFactorCalculator scaleFactorCalculator) {
        this.dataRepo = dataRepo;
        this.routingRepo = routingRepo;
        this.stateHelper = stateHelper;
        this.buildingComparator = buildingComparator;
        this.debugStorage = debugStorage;
        this.graphBinderData = graphBinderData;
        this.scaleFactorCalculator = scaleFactorCalculator;
    }

    @NonNull
    public Maybe<List<Building>> downloadBuildingsAnyway() {
        return dataRepo.getBuildingsAnyway();}

    @NonNull
    public Maybe<List<Building>> downloadRecentBuildings() {
        return dataRepo.getRecentBuildings()
                       .doOnSuccess(buildings -> Collections.sort(buildings, buildingComparator));
    }

    @NonNull
    public Maybe<List<Floor>> downloadFloorsAndGates(String buildingId) {
        return downloadFloors(buildingId);}

    @NonNull
    private Maybe<List<Floor>> downloadFloors(String buildingId) {
        return dataRepo.getFloors(buildingId)
                       .doOnSuccess(floors -> {
                           stateHelper.setBuildingId(buildingId);
                           stateHelper.setVisibleFloor(floors.iterator().next().getNumber());
                       });
    }

    @NonNull
    private Maybe<List<Gate>> downloadGates(String buildingId) {
        return dataRepo.getGates(buildingId);
    }

    /**
     * Method calls repositories method that switches cached debug value and returns value it
     *
     * @return switched show debug value wrapped in Single
     */
    @NonNull
    public Maybe<Boolean> switchDebugDrawing() {
        return dataRepo.switchAndGetDebugValue();
    }

    @NonNull
    public Maybe<Boolean> isDebugAllowed() {
        return dataRepo.getDebugAllowanceValue();
    }

    @NonNull
    public Maybe<Boolean> isSimpleLocationMode() {
        return dataRepo.isSimpleLocationMode();
    }

    public Maybe<Boolean> switchAndGetSimpleLocationMode() {
        return dataRepo.switchAndGetSimpleLocationMode();
    }

    @NonNull
    public Maybe<List<Integer>> getFloorNumbers() {
        return dataRepo.getFloorNumbers()
                       .doOnSuccess(Collections::sort);
    }

    @NonNull
    public Observable<Floor> getCurrentFloor() {
        return stateHelper.getFloorNumberObservable()
                          .doOnNext(floorNumber -> routingRepo.getGraph(stateHelper.getBuildingId(), floorNumber)
                                                              .doOnSuccess(graphBinderData::setGraph)
                                                              .subscribe(new DisposableMaybeObserverAdapter<Graph>() {}))
                          .flatMap(floorNumber -> dataRepo.getFloor(stateHelper.getBuildingId(), floorNumber)
                                                          .toObservable())
                          .doOnNext(floor -> scaleFactorCalculator.setScaleCoef(
                                  floor.getDistance(),
                                  floor.getOverlaySouthWestBound(), floor.getOverlayNorthEastBound()
                          ));
    }

    @NonNull
    public Observable<List<Pivot>> getDebugData() {
        return dataRepo.getDebugAllowanceValue()
                       .filter(allowed -> allowed)
                       .flatMapObservable(allowed -> debugStorage.getPivots());
    }

    @NonNull
    public Completable switchFloor(int newFloor) {
        return Completable.fromAction(() -> stateHelper.setVisibleFloor(newFloor));
    }

    @NonNull
    public Completable switchToUserFloor() {
        return Completable.fromAction(() -> {
            int userFloor = stateHelper.getUserFloor();
            if (userFloor != StateHelper.UNDEFINED) {
                stateHelper.setVisibleFloor(userFloor);
            }
        });
    }
}
