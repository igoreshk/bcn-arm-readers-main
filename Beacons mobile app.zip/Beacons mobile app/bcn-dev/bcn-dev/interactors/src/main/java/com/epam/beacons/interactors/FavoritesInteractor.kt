package com.epam.beacons.interactors

import com.epam.beacons.Place
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.repository.FavoritesRepo
import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Single
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FavoritesInteractor @Inject constructor(
        private val favoritesRepo: FavoritesRepo,
        private val stateHelper: StateHelper
) {
    fun getFavorites(): Maybe<List<Place>> = favoritesRepo.getFavorites(stateHelper.buildingId)
            .defaultIfEmpty(emptyList())

    fun switchFavorite(placeId: String): Completable = isFavorite(placeId)
            .flatMapCompletable { if (it) removeFromFavorites(placeId) else addToFavorites(placeId) }

    private fun isFavorite(placeId: String): Single<Boolean> = favoritesRepo.getFavoritesIds(stateHelper.buildingId)
            .defaultIfEmpty(emptyList())
            .map { it.contains(placeId) }
            .toSingle()

    private fun addToFavorites(placeId: String): Completable = favoritesRepo.addToFavorites(stateHelper.buildingId, placeId)

    private fun removeFromFavorites(placeId: String): Completable = favoritesRepo.removeFromFavorites(stateHelper.buildingId, placeId)
}
