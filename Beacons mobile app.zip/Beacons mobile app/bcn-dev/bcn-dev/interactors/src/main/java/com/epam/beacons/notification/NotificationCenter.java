package com.epam.beacons.notification;

import androidx.annotation.NonNull;

import com.epam.beacons.Notification;

public interface NotificationCenter {
    void showNotification(@NonNull Notification notification);

    void dismiss(int notificationId);
}