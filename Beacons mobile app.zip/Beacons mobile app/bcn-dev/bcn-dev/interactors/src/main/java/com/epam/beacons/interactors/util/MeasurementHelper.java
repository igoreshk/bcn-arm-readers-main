package com.epam.beacons.interactors.util;

import androidx.annotation.NonNull;

import com.epam.beacons.Beacon;
import com.epam.beacons.Coordinate;
import com.epam.beacons.Measurement;
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class MeasurementHelper {
    @NonNull
    private List<Measurement>            measurements;
    @NonNull
    private CoordinateDistanceCalculator distanceCalculator;

    @Inject
    MeasurementHelper(@NonNull CoordinateDistanceCalculator distanceCalculator) {
        this.distanceCalculator = distanceCalculator;
        measurements = new ArrayList<>();
    }

    public void save(@NonNull Beacon beacon) {
        measurements.add(new Measurement(beacon.getRssi(), System.currentTimeMillis(), beacon.getCoordinate()));
    }

    public void clear() {
        measurements.clear();
    }

    public void save(@NonNull Coordinate userLocation) {
        final List<Measurement> list = new ArrayList<>();

        for (Measurement measurement : measurements) {
            final double distance = distanceCalculator.calcDistance(userLocation, measurement.getCoordinate());

            if (Double.compare(distance, 0) != 0) {
                measurement.setDistance(distance);
                list.add(measurement);
            }
        }

        measurements = list;
    }

    @NonNull
    public List<Measurement> getMeasurements() {
        return measurements;
    }
}