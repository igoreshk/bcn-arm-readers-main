package com.epam.beacons.interactors.util

import com.epam.beacons.Place
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SearchComparator @Inject constructor() : Comparator<Place> {

    var query: String = ""

    /**
     * Compares its two arguments for order. The conditions are the following by priority:
     * 1. isHistory flag;
     * 2. isFavorite flag;
     * 3. if the place description is digital, doesn't contain anything except numbers;
     * 4. the index of the first occurrence of the specified query;
     * 5. alphabetical sort
     *
     * @param place1 - the first place to be compared
     * @param place2 - the second place to be compared
     * @return a negative integer, zero, or a positive integer as the above mentioned conditions are applied
     */
    override fun compare(place1: Place, place2: Place): Int {
        var result = compareByHistory(place1, place2)
        if (result != 0) {
            return result
        }

        result = compareByFavorite(place1, place2)
        if (result != 0) {
            return result
        }

        val firstDescription = place1.description.toLowerCase()
        val secondDescription = place2.description.toLowerCase()

        result = compareByRegexp(firstDescription, secondDescription)
        if (result != 0) {
            return result
        }

        result = compareByQuery(firstDescription, secondDescription)
        if (result != 0) {
            return result
        }

        return compareAlphabetically(firstDescription, secondDescription)
    }

    private fun compareByFavorite(place1: Place, place2: Place) = place1.isFavorite.compareTo(place2.isFavorite)

    private fun compareByHistory(place1: Place, place2: Place) = place1.isInHistory.compareTo(place2.isInHistory)

    private fun compareByRegexp(firstDescription: String, secondDescription: String) =
            compareBoolean(firstDescription.matches(DIGITS_REGEX), secondDescription.matches(DIGITS_REGEX))

    private fun compareByQuery(firstDescription: String, secondDescription: String) =
            firstDescription.indexOf(query) - secondDescription.indexOf(query)

    private fun compareAlphabetically(firstDescription: String, secondDescription: String) = firstDescription.compareTo(secondDescription)

    private fun compareBoolean(b1: Boolean, b2: Boolean) = if (b1 == b2) 0 else if (b1) 1 else -1

    companion object {
        private val DIGITS_REGEX: Regex = "^[0-9]+$".toRegex()
    }
}
