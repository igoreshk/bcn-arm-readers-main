package com.epam.beacons.bounders

import com.epam.beacons.Coordinate
import com.epam.beacons.tools.debug.DebugStorage
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.TimeProvider
import io.reactivex.Observable
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DistanceBounder
@Inject constructor(private val debugStorage: DebugStorage,
                    private val calculator: CoordinateDistanceCalculator,
                    private val timeProvider: TimeProvider,
                    private val millisecondsLimit: Long) {

    fun bound(input: Observable<Coordinate>): Observable<Coordinate> = input.map { current ->
        current.timestamp = timeProvider.getCurrentSystemTime()
        lastCoordinate?.let {
            if (current.timestamp - it.timestamp > millisecondsLimit) {
                lastCoordinate = null
            }
        }
        lastCoordinate = if (lastCoordinate == null) current else bound(lastCoordinate, current)
        lastCoordinate
    }

    private fun bound(last: Coordinate?, current: Coordinate): Coordinate {
        if (last == null) {
            return current
        }

        val distance = calculator.calcDistance(current, last)
        val maxDistance = maxHumanSpeedMps * (current.timestamp - last.timestamp) / oneSecondInMillis
        var correctedCoordinate = current
        if (distance > maxDistance) {
            val correctedLat = last.latitude + maxDistance / distance * (current.latitude - last.latitude)
            val correctedLon = last.longitude + maxDistance / distance * (current.longitude - last.longitude)
            correctedCoordinate = Coordinate(correctedLat, correctedLon, current.errorRadius)
            correctedCoordinate.timestamp = current.timestamp
        }

        return correctedCoordinate
    }

    companion object {
        private const val maxHumanSpeedMps = 2.0 //7.2 km/h
        private const val oneSecondInMillis = 1000.0
        private var lastCoordinate: Coordinate? = null
    }
}
