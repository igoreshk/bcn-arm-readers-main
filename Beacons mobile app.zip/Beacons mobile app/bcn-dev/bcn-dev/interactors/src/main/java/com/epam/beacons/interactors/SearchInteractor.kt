package com.epam.beacons.interactors

import com.epam.beacons.Place
import com.epam.beacons.interactors.util.SearchComparator
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.repository.SearchRepo
import com.epam.beacons.tools.adapters.DisposableCompletableObserverAdapter
import io.reactivex.Maybe
import io.reactivex.Observable
import io.reactivex.subjects.BehaviorSubject
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SearchInteractor @Inject constructor(
        private val searchRepo: SearchRepo,
        private val stateHelper: StateHelper,
        private val searchComparator: SearchComparator
) {

    val filters: BehaviorSubject<CharSequence> = BehaviorSubject.create<CharSequence>()

    fun getRecentItems(): Maybe<List<Place>> = getHistory()

    fun search(): Observable<List<Place>> = filters
            .debounce(DEBOUNCE_MILLISECONDS, TimeUnit.MILLISECONDS)
            .flatMapMaybe { filter ->
                getPlaces().map { it.filter { it.description.contains(filter, true) } }
                        .doOnSuccess {
                            searchComparator.query = filter.toString()
                            it.sortedWith(searchComparator)
                        }
            }

    fun moveToPlaceAndAddToHistory(placeId: String): Maybe<Place> = searchRepo.getPlace(stateHelper.buildingId, placeId)
            .doOnSuccess {
                stateHelper.visibleFloor = it.floorNumber
                searchRepo.addToHistory(stateHelper.buildingId, it.id)
                        .subscribe(object : DisposableCompletableObserverAdapter() {})
            }

    private fun getPlaces(): Maybe<List<Place>> = searchRepo.getPlaces(stateHelper.buildingId)
            .defaultIfEmpty(emptyList())

    private fun getHistory(): Maybe<List<Place>> = searchRepo.getHistory(stateHelper.buildingId)
            .defaultIfEmpty(emptyList())

    companion object {
        const val DEBOUNCE_MILLISECONDS = 300L
    }
}
