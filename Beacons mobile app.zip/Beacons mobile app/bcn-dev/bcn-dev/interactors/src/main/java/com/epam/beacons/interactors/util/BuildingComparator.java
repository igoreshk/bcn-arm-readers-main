package com.epam.beacons.interactors.util;


import androidx.annotation.NonNull;

import com.epam.beacons.Building;

import java.util.Comparator;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class BuildingComparator implements Comparator<Building> {

    @Inject
    BuildingComparator() { // default constructor for dagger
    }

    @Override
    public int compare(@NonNull Building b1, @NonNull Building b2) {
        return b1.getName().compareTo(b2.getName());
    }
}
