package com.epam.beacons.interactors.shared

import com.epam.beacons.Beacon
import com.epam.beacons.interactors.util.RecordHelper
import com.epam.beacons.scanner.BeaconScanner
import io.reactivex.Maybe
import io.reactivex.Observable
import io.reactivex.subjects.CompletableSubject
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BeaconsGetter @Inject constructor(
        private val recordHelper: RecordHelper,
        private val beaconScanner: BeaconScanner,
        private val scanningPeriodMilliseconds: Long
) {
    var playFinished: CompletableSubject = CompletableSubject.create()
        private set

    fun getBeacons(): Observable<Beacon> =
            if (recordHelper.isPlaying) {
                recordHelper.load()
                        .doOnComplete {
                            playFinished.onComplete()
                            playFinished = CompletableSubject.create()
                        }
            } else {
                beaconScanner.getScannerResults()
            }

    fun getBeaconsPack(): Maybe<List<Beacon>> =
            getBeacons().buffer(scanningPeriodMilliseconds, TimeUnit.MILLISECONDS)
                    .firstElement()
}
