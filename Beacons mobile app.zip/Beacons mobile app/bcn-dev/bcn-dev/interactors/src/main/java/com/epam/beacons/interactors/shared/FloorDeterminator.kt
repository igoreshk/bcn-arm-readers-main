package com.epam.beacons.interactors.shared

import com.epam.beacons.Beacon
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.repository.LocationRepo
import com.epam.beacons.tools.adapters.DisposableCompletableObserverAdapter
import io.reactivex.Maybe
import io.reactivex.functions.BiFunction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FloorDeterminator @Inject constructor(
        private val locationRepo: LocationRepo,
        private val stateHelper: StateHelper
) {
    fun determineAndChangeFloor(scanned: Maybe<List<Beacon>>, known: Maybe<List<Beacon>>): Maybe<Int> =
            Maybe.zip(scanned, known, BiFunction(this::determineFloor))
                    .filter { it != UNDEFINED_FLOOR_NUMBER }
                    .doOnSuccess {
                        stateHelper.userFloor = it
                        locationRepo.clearUserFloorBeaconsCache()
                                .subscribe(object : DisposableCompletableObserverAdapter() {})
                    }

    private fun determineFloor(scanned: List<Beacon>, known: List<Beacon>): Int {
        if (scanned.isEmpty() || known.isEmpty()) {
            return UNDEFINED_FLOOR_NUMBER
        }
        val floorNumbers = HashMap<Int, Int>()

        scanned.forEach { beacon ->
            known.find { it == beacon }?.let {
                floorNumbers[it.floorNumber] = (floorNumbers[it.floorNumber] ?: 0) + 1
            }
        }

        return floorNumbers.maxWith(Comparator { e1, e2 -> e1.value.compareTo(e2.value) })?.key
                ?: UNDEFINED_FLOOR_NUMBER
    }

    companion object {
        private const val UNDEFINED_FLOOR_NUMBER = Int.MIN_VALUE
    }
}
