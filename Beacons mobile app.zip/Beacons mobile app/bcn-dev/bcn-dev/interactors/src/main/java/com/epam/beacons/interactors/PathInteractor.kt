package com.epam.beacons.interactors

import com.epam.beacons.Coordinate
import com.epam.beacons.Gate
import com.epam.beacons.graphbinder.GraphBinderData
import com.epam.beacons.interactors.shared.BeaconsGetter
import com.epam.beacons.interactors.shared.FloorDeterminator
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.navigation.DijkstraAlgorithm
import com.epam.beacons.navigation.ProximateVertexFinder
import com.epam.beacons.repository.DataRepo
import com.epam.beacons.repository.LocationRepo
import com.epam.beacons.repository.RoutingRepo
import com.epam.beacons.tools.CornerHelper
import com.epam.beacons.tools.GateHelper
import com.epam.beacons.tools.adapters.DisposableMaybeObserverAdapter
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.ScaleFactorCalculator
import io.reactivex.Completable
import io.reactivex.Maybe
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PathInteractor @Inject constructor(
        private val dijkstraAlgorithm: DijkstraAlgorithm,
        private val proximateVertexFinder: ProximateVertexFinder,
        private val dataRepo: DataRepo,
        private val locationRepo: LocationRepo,
        private val routingRepo: RoutingRepo,
        private val floorDeterminator: FloorDeterminator,
        private val beaconsGetter: BeaconsGetter,
        private val stateHelper: StateHelper,
        private val gateHelper: GateHelper,
        private val graphBinderData: GraphBinderData,
        private val coordinateDistanceCalculator: CoordinateDistanceCalculator,
        private val scaleFactorCalculator: ScaleFactorCalculator,
        private val cornerHelper: CornerHelper,
        private val oneMeterAtEquator: Int
) {
    fun startRoute(start: Coordinate, destination: Coordinate): Maybe<RouteResult> {
        val floor = stateHelper.visibleFloor
        val userFloor = stateHelper.userFloor

        if (userFloor == StateHelper.UNDEFINED) {
            return Maybe.error(IllegalStateException(ERROR_LOCATION_NOT_FOUND))
        }

        return if (!gateHelper.prepared) {
            dataRepo.getSavedGates(stateHelper.buildingId)
                    .doOnSuccess { gateHelper.prepare(it, destination, floor, userFloor) }
                    .flatMap { startRoute(start, destination, floor, userFloor) }
        } else {
            startRoute(start, destination, floor, userFloor)
        }
    }

    fun endRoute(): Completable = Completable.mergeArray(
            gateHelper.clear(),
            cornerHelper.clear(),
            locationRepo.clearBeaconsCache(),
            graphBinderData.clearRoute())

    private fun startRoute(start: Coordinate, destination: Coordinate, floor: Int, userFloor: Int) = gateHelper.gatesPath(
            floor,
            if (floor == userFloor) start else null,
            destination)
            .flatMap { determineRoute(it.first, it.second) }
            .doOnSuccess { graphBinderData.route = it.route }
            .doOnSubscribe { switchFloorIfNearGate(start) }

    private fun determineRoute(start: Coordinate, destination: Coordinate) = routingRepo.getGraph(stateHelper.buildingId, stateHelper.visibleFloor)
            .map {
                dijkstraAlgorithm.getPath(
                        it,
                        proximateVertexFinder.findProximateVertex(it, start),
                        proximateVertexFinder.findProximateVertex(it, destination))
            }
            .flattenAsObservable { it }
            .map { it.coordinate }
            .toList()
            .doOnSuccess {
                it.removeAt(0) // we need to remove first point in route
                it.add(0, start) // and add user as the first point
            }
            .map { RouteResult(it as List<Coordinate>, destination) }
            .doOnSuccess {
                cornerHelper.prepareData(it.route, destination)
                it.routeDistance = cornerHelper.routeDistance
                it.corners = cornerHelper.corners
                it.destOrientation = cornerHelper.destOrientation
                it.rotation = cornerHelper.rotation
            }
            .toMaybe()

    private fun switchFloorIfNearGate(userLocation: Coordinate) = dataRepo.getGates(stateHelper.buildingId, stateHelper.visibleFloor)
            .flattenAsObservable { it }
            .filter { isNearGate(userLocation, it) }
            .map { it.bounds.keys }
            .flatMapIterable { it }
            .toList()
            .flatMapMaybe {
                floorDeterminator.determineAndChangeFloor(beaconsGetter.getBeaconsPack(), locationRepo.getBeacons(stateHelper.buildingId, it))
                        .doOnSuccess { stateHelper.visibleFloor = it }
            }
            .switchIfEmpty(locationRepo.clearBeaconsCache().toMaybe())
            .subscribe(object : DisposableMaybeObserverAdapter<Int>() {})

    private fun isNearGate(location: Coordinate, gate: Gate): Boolean {
        val gateCoord = gate.bounds[stateHelper.visibleFloor] ?: return false
        return coordinateDistanceCalculator.calcDistance(location, gateCoord) <
                PROXIMITY_RADIUS_IN_METERS * scaleFactorCalculator.scaleCoef / oneMeterAtEquator
    }

    class RouteResult constructor(val route: List<Coordinate>,
                                  val destination: Coordinate,
                                  var routeDistance: Int = 0,
                                  var corners: List<Pair<Int, CornerHelper.Corner>> = listOf(),
                                  var destOrientation: CornerHelper.DestOrientation = CornerHelper.DestOrientation.NONE,
                                  var rotation: Float = 0f)

    companion object {
        private const val PROXIMITY_RADIUS_IN_METERS = 3
        private const val ERROR_LOCATION_NOT_FOUND = "User location not found"
    }
}
