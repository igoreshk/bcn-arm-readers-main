package com.epam.beacons.scanner

interface BluetoothHelper {

    fun isScanning(): Boolean

    fun startScan(callback: Callback)

    fun stopScan(callback: Callback)

    interface Callback {
        fun onResult(scanRecord: ByteArray, rssi: Int)

        fun onStartScanFailed(message: String)

        fun onBluetoothIsOff()

        fun onScanFailed(errorCode: Int)

        fun onScanStopped()
    }
}
