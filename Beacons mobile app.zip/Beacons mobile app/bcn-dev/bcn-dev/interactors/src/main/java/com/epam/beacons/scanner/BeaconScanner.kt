package com.epam.beacons.scanner

import com.epam.beacons.Beacon
import io.reactivex.Observable

interface BeaconScanner {

    fun getScannerResults(): Observable<Beacon>
}
