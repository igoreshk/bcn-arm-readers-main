package com.epam.beacons.smoothers;

import androidx.annotation.NonNull;

import com.epam.beacons.Beacon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.inject.Singleton;

import io.reactivex.Observable;

@Singleton
public class AverageSmoother {
    private final long     interval;
    @NonNull
    private final TimeUnit timeUnit;

    public AverageSmoother(long interval, @NonNull TimeUnit timeUnit) {
        this.interval = interval;
        this.timeUnit = timeUnit;
    }

    @NonNull
    public Observable<List<Beacon>> smoothBeaconData(@NonNull Observable<Beacon> input) {
        return input.buffer(interval, timeUnit)
                    .map(beacons -> {
                        final Map<Beacon, Pair> countedBeacons = new HashMap<>();

                        for (Beacon beacon : beacons) {
                            if (!countedBeacons.containsKey(beacon)) {
                                countedBeacons.put(beacon, new Pair(1, beacon.getRssi()));
                            } else {
                                final Pair cached = countedBeacons.get(beacon);
                                final int count = cached.getCount() + 1;
                                final int rssi = cached.getSummedRssi() + beacon.getRssi();
                                countedBeacons.put(beacon, new Pair(count, rssi));
                            }
                        }

                        for (Map.Entry<Beacon, Pair> entry : countedBeacons.entrySet()) {
                            final Pair cached = entry.getValue();
                            entry.getKey().setRssi(cached.getSummedRssi() / cached.getCount());
                        }

                        return new ArrayList<>(countedBeacons.keySet());
                    });
    }

    private static class Pair {
        private final int count;
        private final int summedRssi;

        Pair(int count, int summedRssi) {
            this.count = count;
            this.summedRssi = summedRssi;
        }

        int getCount() {
            return count;
        }

        int getSummedRssi() {
            return summedRssi;
        }
    }
}
