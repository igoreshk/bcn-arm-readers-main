package com.epam.beacons.interactors.shared

import com.epam.beacons.Beacon
import com.epam.beacons.KotlinMockito.whn
import com.epam.beacons.interactors.util.RecordHelper
import com.epam.beacons.scanner.BeaconScanner
import io.reactivex.Observable
import org.junit.Assert.assertNotEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.verifyNoMoreInteractions
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class BeaconsGetterTest {

    private val beacons = listOf(
            Beacon("uuid1", 1, 1, -55.0, -57),
            Beacon("uuid2", 2, 2, -60.0, -62),
            Beacon("uuid3", 3, 3, -65.0, -67)
    )

    @Mock
    private lateinit var recordHelper: RecordHelper
    @Mock
    private lateinit var beaconScanner: BeaconScanner

    private lateinit var beaconsGetter: BeaconsGetter

    @Before
    fun setUp() {
        beaconsGetter = BeaconsGetter(recordHelper, beaconScanner, scanningPeriodMilliseconds = 3000)
    }

    @Test
    fun testGetBeaconsFromScanner() {
        whn(recordHelper.isPlaying).thenReturn(false)
        whn(beaconScanner.getScannerResults()).thenReturn(Observable.fromIterable(beacons))
        beaconsGetter.getBeacons()
                .test()
                .assertComplete()
                .assertValueSequence(beacons)
    }

    @Test
    fun testGetRecordedBeacons() {
        whn(recordHelper.isPlaying).thenReturn(true)
        whn(recordHelper.load()).thenReturn(Observable.fromIterable(beacons))

        val recordStateSubject = beaconsGetter.playFinished
        val recordStateSubjectObserver = recordStateSubject.test()

        beaconsGetter.getBeacons()
                .test()
                .assertComplete()
                .assertValueSequence(beacons)
        verifyNoMoreInteractions(beaconScanner)

        recordStateSubjectObserver.assertComplete()
        assertNotEquals(beaconsGetter.playFinished, recordStateSubject)
    }

    @Test
    fun testGetBeaconsPack() {
        whn(recordHelper.isPlaying).thenReturn(false)
        whn(beaconScanner.getScannerResults()).thenReturn(Observable.fromIterable(beacons))

        beaconsGetter.getBeaconsPack()
                .test()
                .assertComplete()
                .assertValue(beacons)
    }
}
