package com.epam.beacons.interactors

import com.epam.beacons.Beacon
import com.epam.beacons.Coordinate
import com.epam.beacons.KotlinMockito.anyNonNull
import com.epam.beacons.KotlinMockito.whn
import com.epam.beacons.Measurement
import com.epam.beacons.Pivot
import com.epam.beacons.bounders.DistanceBounder
import com.epam.beacons.calibrator.BeaconCalibrator
import com.epam.beacons.distance.BeaconDistanceCalculator
import com.epam.beacons.distance.BeaconDistanceCalibrator
import com.epam.beacons.filter.BeaconFilter
import com.epam.beacons.graphbinder.GraphBinder
import com.epam.beacons.interactors.shared.BeaconsGetter
import com.epam.beacons.interactors.shared.FloorDeterminator
import com.epam.beacons.interactors.util.MeasurementHelper
import com.epam.beacons.interactors.util.RecordHelper
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.locator.TrilaterationSolver
import com.epam.beacons.repository.LocationRepo
import com.epam.beacons.smoothers.AverageSmoother
import com.epam.beacons.tools.Logger
import com.epam.beacons.tools.debug.DebugStorage
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.ScaleFactorCalculator
import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Observable
import io.reactivex.functions.BiFunction
import io.reactivex.observers.TestObserver
import io.reactivex.plugins.RxJavaPlugins
import io.reactivex.schedulers.TestScheduler
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.any
import org.mockito.ArgumentMatchers.eq
import org.mockito.Mock
import org.mockito.Mockito.verify
import org.mockito.junit.MockitoJUnitRunner
import java.util.concurrent.TimeUnit

@RunWith(MockitoJUnitRunner::class)
class LocationInteractorMainTest {

    private val scheduler = TestScheduler()
    private val beacons = listOf(
            Beacon("uuid1", 1, 1, -55.0, -57),
            Beacon("uuid2", 2, 2, -55.0, -57),
            Beacon("uuid3", 3, 3, -55.0, -57)
    )
    private val beaconsMaybe = Maybe.fromCallable { beacons }
    private val beaconsObservable: Observable<Beacon> = Observable.zip(
            Observable.fromIterable(beacons),
            Observable.interval(100, TimeUnit.MILLISECONDS, scheduler),
            BiFunction { beacon, _ -> beacon }
    )
    private val knownBeacons = listOf(
            Beacon("uuid1", 1, 1, 2, Coordinate(1.0, 1.0)),
            Beacon("uuid2", 2, 2, 2, Coordinate(2.0, 2.0)),
            Beacon("uuid3", 3, 3, 2, Coordinate(3.0, 3.0))
    )
    private val knownBeaconsMaybe = Maybe.fromCallable { knownBeacons }
    private val measurements = listOf(
            Measurement(-57, 1.0, 1)
    )
    private val prevMeasurements = listOf(
            Measurement(-57, 1.0, 1)
    )
    private val nextMeasurements = listOf(
            Measurement(-57, 1.0, 1)
    )
    private val distance = 1.0
    private val pivots = knownBeacons.map {
        Pivot(Coordinate(
                it.coordinate!!.latitude * ONE_METER_AT_EQUATOR,
                it.coordinate!!.longitude * ONE_METER_AT_EQUATOR
        ), distance)
    }
    private val coordinate = Coordinate(5.0, 5.0)
    private val coordinateWithErrorRadius = Coordinate(coordinate.latitude, coordinate.longitude, ERROR_RADIUS)
    private val scaledCoordinate = Coordinate(
            coordinate.latitude / ONE_METER_AT_EQUATOR,
            coordinate.longitude / ONE_METER_AT_EQUATOR
    )
    private val exception = Exception("Moon phase is wrong")

    @Mock
    private lateinit var beaconsGetter: BeaconsGetter
    @Mock
    private lateinit var floorDeterminator: FloorDeterminator
    @Mock
    private lateinit var averageSmoother: AverageSmoother
    @Mock
    private lateinit var beaconFilter: BeaconFilter
    @Mock
    private lateinit var beaconCalibrator: BeaconCalibrator
    @Mock
    private lateinit var distanceCalibrator: BeaconDistanceCalibrator
    @Mock
    private lateinit var distanceCalculator: BeaconDistanceCalculator
    @Mock
    private lateinit var trilaterationSolver: TrilaterationSolver
    @Mock
    private lateinit var distanceBounder: DistanceBounder
    @Mock
    private lateinit var locationRepo: LocationRepo
    @Mock
    private lateinit var stateHelper: StateHelper
    @Mock
    private lateinit var debugStorage: DebugStorage
    @Mock
    private lateinit var recordHelper: RecordHelper
    @Mock
    private lateinit var measurementHelper: MeasurementHelper
    @Mock
    private lateinit var graphBinder: GraphBinder
    @Mock
    private lateinit var scaleFactorCalculator: ScaleFactorCalculator
    @Mock
    private lateinit var coordinateDistanceCalculator: CoordinateDistanceCalculator
    @Mock
    private lateinit var logger: Logger

    private lateinit var locationInteractor: LocationInteractor

    @Before
    fun setUp() {
        locationInteractor = LocationInteractor(beaconsGetter, floorDeterminator, averageSmoother, beaconFilter, beaconCalibrator,
                distanceCalibrator, distanceCalculator, trilaterationSolver, distanceBounder, locationRepo, stateHelper, debugStorage, recordHelper,
                measurementHelper, graphBinder, scaleFactorCalculator, coordinateDistanceCalculator, logger, ONE_METER_AT_EQUATOR)

        whn(stateHelper.buildingId).thenReturn(BUILDING_ID)
        whn(stateHelper.userFloor).thenReturn(FLOOR_NUMBER)
        whn(stateHelper.visibleFloor).thenReturn(FLOOR_NUMBER)

        whn(beaconsGetter.getBeacons()).thenReturn(beaconsObservable)
        whn(locationRepo.getBeacons(BUILDING_ID, FLOOR_NUMBER)).thenReturn(Maybe.fromCallable { knownBeacons })

        whn(locationRepo.initMeasurements()).thenReturn(Completable.complete())

        whn(averageSmoother.smoothBeaconData(anyNonNull()))
                .thenAnswer { it.getArgument<Observable<Beacon>>(0).buffer(beacons.size) }
        whn(beaconFilter.filterBeacons(anyNonNull())).thenAnswer { Observable.fromCallable { it.arguments[0] } }
        whn(beaconCalibrator.calibrateTxPower(beacons)).thenReturn(beacons)

        whn(locationRepo.getMeasurements(beacons[0].rssi)).thenReturn(Maybe.fromCallable { measurements })
        whn(locationRepo.getMeasurements(beacons[0].rssi - 1)).thenReturn(Maybe.fromCallable { nextMeasurements })
        whn(locationRepo.getMeasurements(beacons[0].rssi + 1)).thenReturn(Maybe.fromCallable { prevMeasurements })
        whn(locationRepo.updateMeasurements(beacons[0].rssi, measurements)).thenReturn(Completable.complete())
        whn(distanceCalibrator.calibrateDistance(
                any(Beacon::class.java), eq(measurements), eq(nextMeasurements), eq(prevMeasurements)))
                .thenReturn(distance)

        whn(debugStorage.debugPivots(pivots)).thenReturn(Completable.complete())

        whn(trilaterationSolver.solve(pivots)).thenReturn(coordinateWithErrorRadius)
        whn(distanceBounder.bound(anyNonNull())).thenAnswer { it.arguments[0] }

        whn(measurementHelper.measurements).thenReturn(measurements)
        whn(locationRepo.putMeasurements(measurements)).thenReturn(Completable.complete())

        whn(scaleFactorCalculator.scaleCoef).thenReturn(SCALE_COEF)

        whn(beaconsGetter.getBeaconsPack()).thenReturn(beaconsMaybe)
        whn(locationRepo.getBeacons(BUILDING_ID)).thenReturn(knownBeaconsMaybe)
        whn(floorDeterminator.determineAndChangeFloor(beaconsMaybe, knownBeaconsMaybe))
                .thenReturn(Maybe.fromCallable { FLOOR_NUMBER })

        whn(graphBinder.bind(anyNonNull())).thenAnswer { it.arguments[0] }

        RxJavaPlugins.setComputationSchedulerHandler { scheduler }
    }

    @After
    fun resetScheduler() {
        RxJavaPlugins.setComputationSchedulerHandler(null)
    }

    @Test
    fun testGetUserLocation() {
        getScheduledLocationObserver().assertComplete()
                .assertValue(scaledCoordinate)
        verifyEverything()
    }

    @Test
    fun testErrorRadius() {
        getScheduledLocationObserver().assertComplete()
                .assertValue { it.errorRadius == ERROR_RADIUS * SCALE_COEF }
        verifyEverything()
    }

    @Test
    fun testGetUserLocationIfUserFloorDiffersFromVisibleFloor() {
        whn(stateHelper.visibleFloor).thenReturn(ANOTHER_FLOOR_NUMBER)

        getScheduledLocationObserver().assertComplete()
                .assertNoValues()
    }

    @Test
    fun testGetUserLocationIfKnownBeaconsHaveNullCoordinates() {
        whn(locationRepo.getBeacons(BUILDING_ID, FLOOR_NUMBER))
                .thenReturn(Maybe.fromCallable { knownBeacons.onEach { it.coordinate = null } })

        getScheduledLocationObserver().assertComplete()
                .assertNoValues()
    }

    @Test
    fun testGetUserLocationIfUserFloorWasUndefinedBefore() {
        whn(stateHelper.userFloor).thenReturn(StateHelper.UNDEFINED)

        getScheduledLocationObserver().assertComplete()
                .assertNoValues()

        verify(stateHelper).visibleFloor = FLOOR_NUMBER
    }

    @Test
    fun testGetUserLocationIfFloorDeterminationFailed() {
        whn(floorDeterminator.determineAndChangeFloor(beaconsMaybe, knownBeaconsMaybe))
                .thenReturn(Maybe.error(exception))

        getScheduledLocationObserver().assertComplete()
                .assertValue(scaledCoordinate)

        verifyEverything()
    }

    @Test
    fun testGetUserLocationIfDistanceCalibrationInitFailed() {
        whn(locationRepo.initMeasurements()).thenReturn(Completable.error(exception))

        getScheduledLocationObserver().assertComplete()
                .assertValue(scaledCoordinate)

        verifyEverything()
    }

    @Test
    fun testGetUserLocationIfDistanceCalibrationUpdateFailed() {
        whn(locationRepo.updateMeasurements(beacons[0].rssi, measurements)).thenReturn(Completable.error(exception))

        getScheduledLocationObserver().assertComplete()
                .assertValue(scaledCoordinate)

        verifyEverything()
    }

    @Test
    fun testGetUserLocationIfDistanceCalibrationPutFailed() {
        whn(locationRepo.putMeasurements(measurements)).thenReturn(Completable.error(exception))

        getScheduledLocationObserver().assertComplete()
                .assertValue(scaledCoordinate)

        verifyEverything()
    }

    @Test
    fun testGetUserLocationIfDebugPivotsFailed() {
        whn(debugStorage.debugPivots(pivots)).thenReturn(Completable.error(exception))

        getScheduledLocationObserver().assertComplete()
                .assertValue(scaledCoordinate)

        verifyEverything()
    }

    private fun getScheduledLocationObserver(): TestObserver<Coordinate> {
        val observer = locationInteractor.userLocation
                .subscribeOn(scheduler)
                .test()

        scheduler.advanceTimeBy(2000, TimeUnit.MILLISECONDS)

        return observer
    }

    private fun verifyEverything() {
        beacons.forEach {
            verify(recordHelper).save(it)
            verify(recordHelper).saveDistanceToBeacon(it, distance)
            verify(measurementHelper).save(it)
        }
        verify(recordHelper).saveAvgRssi(beacons)
        verify(debugStorage).debugPivots(pivots)
        verify(recordHelper).saveTrilaterationCoordinate(coordinate)
        verify(recordHelper).saveBoundAndFinishCycle(coordinate)
        verify(measurementHelper).save(coordinate)
        verify(measurementHelper).clear()
        verify(graphBinder).bind(scaledCoordinate)
    }

    companion object {
        const val ONE_METER_AT_EQUATOR = 111320
        const val BUILDING_ID = 1L
        const val FLOOR_NUMBER = 2
        const val ANOTHER_FLOOR_NUMBER = 3
        const val ERROR_RADIUS = 2.0
        const val SCALE_COEF = 3.0
    }
}
