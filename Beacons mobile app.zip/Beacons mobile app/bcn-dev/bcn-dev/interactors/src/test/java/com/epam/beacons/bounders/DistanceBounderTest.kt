package com.epam.beacons.bounders

import com.epam.beacons.Coordinate
import com.epam.beacons.tools.debug.DebugStorage
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.TimeProvider
import io.reactivex.Observable
import io.reactivex.functions.BiFunction
import io.reactivex.schedulers.TestScheduler
import org.junit.Before
import org.junit.Test
import org.mockito.ArgumentMatchers.any
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.MockitoAnnotations
import java.util.concurrent.TimeUnit

class DistanceBounderTest {

    @Mock
    private lateinit var debugStorage: DebugStorage
    @Mock
    private lateinit var calculator: CoordinateDistanceCalculator
    @Mock
    private lateinit var timeProvider: TimeProvider

    private lateinit var distanceBounder: DistanceBounder

    private val first = Coordinate(5.0, 8.0)
    private val second = Coordinate(5.0, 11.0)
    private val third = Coordinate(5.0, 18.0)
    private val expected = Coordinate(5.0, 15.0)

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        distanceBounder = DistanceBounder(debugStorage, calculator, timeProvider, 4000)
    }

    @Test
    fun boundTooLongMovementTest() {
        `when`(timeProvider.getCurrentSystemTime()).thenReturn(0).thenReturn(2000).thenReturn(4000)
        `when`(calculator.calcDistance(any<Coordinate>(), any<Coordinate>())).thenReturn(3.0).thenReturn(7.0)
        val scheduler = TestScheduler()
        val subscriber = distanceBounder.bound(Observable.just(first, second, third)
                .zipWith(Observable.interval(1000, TimeUnit.MILLISECONDS, scheduler),
                        BiFunction { coord: Coordinate, _: Long -> coord }))
                .subscribeOn(scheduler)
                .test()
        subscriber.assertNoValues()
        subscriber.assertNotComplete()
        scheduler.advanceTimeBy(2000, TimeUnit.MILLISECONDS)
        subscriber.assertNoErrors()
        subscriber.assertValueCount(2)
        subscriber.assertValues(first, second)
        scheduler.advanceTimeBy(2000, TimeUnit.MILLISECONDS)
        subscriber.assertNoErrors()
        subscriber.assertValueCount(3)
        subscriber.assertValues(first, second, expected)
    }
}
