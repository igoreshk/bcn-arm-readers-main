package com.epam.beacons.interactors

import com.epam.beacons.Beacon
import com.epam.beacons.Coordinate
import com.epam.beacons.KotlinMockito.anyNonNull
import com.epam.beacons.KotlinMockito.whn
import com.epam.beacons.bounders.DistanceBounder
import com.epam.beacons.calibrator.BeaconCalibrator
import com.epam.beacons.distance.BeaconDistanceCalculator
import com.epam.beacons.distance.BeaconDistanceCalibrator
import com.epam.beacons.filter.BeaconFilter
import com.epam.beacons.graphbinder.GraphBinder
import com.epam.beacons.interactors.shared.BeaconsGetter
import com.epam.beacons.interactors.shared.FloorDeterminator
import com.epam.beacons.interactors.util.MeasurementHelper
import com.epam.beacons.interactors.util.RecordHelper
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.locator.TrilaterationSolver
import com.epam.beacons.repository.LocationRepo
import com.epam.beacons.smoothers.AverageSmoother
import com.epam.beacons.tools.Logger
import com.epam.beacons.tools.debug.DebugStorage
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.ScaleFactorCalculator
import io.reactivex.Maybe
import io.reactivex.Observable
import io.reactivex.functions.BiFunction
import io.reactivex.observers.TestObserver
import io.reactivex.plugins.RxJavaPlugins
import io.reactivex.schedulers.TestScheduler
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.anyDouble
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner
import java.util.concurrent.TimeUnit

@RunWith(MockitoJUnitRunner::class)
class LocationInteractorSimpleModeTest {

    private val scheduler = TestScheduler()
    private val beacons = listOf(
            Beacon("uuid1", 1, 1, -55.0, -60),
            Beacon("uuid2", 2, 2, -55.0, -55),
            Beacon("uuid3", 3, 3, -55.0, -65)
    )
    private val farAwayBeacons = listOf(
            Beacon("uuid1", 1, 1, -55.0, -95),
            Beacon("uuid2", 2, 2, -55.0, -90),
            Beacon("uuid3", 3, 3, -55.0, -95)
    )
    private val beaconsMaybe = Maybe.fromCallable { beacons }
    private val beaconsObservable: Observable<Beacon> = Observable.zip(
            Observable.fromIterable(beacons),
            Observable.interval(100, TimeUnit.MILLISECONDS, scheduler),
            BiFunction { beacon, _ -> beacon }
    )
    private val farAwayBeaconsObservable: Observable<Beacon> = Observable.zip(
            Observable.fromIterable(farAwayBeacons),
            Observable.interval(100, TimeUnit.MILLISECONDS, scheduler),
            BiFunction { beacon, _ -> beacon }
    )
    private val knownBeacons = listOf(
            Beacon("uuid1", 1, 1, 2, Coordinate(1.0, 1.0)),
            Beacon("uuid2", 2, 2, 2, Coordinate(2.0, 2.0)),
            Beacon("uuid3", 3, 3, 2, Coordinate(3.0, 3.0))
    )
    private val knownBeaconsMaybe = Maybe.fromCallable { knownBeacons }

    private val expectedCoordinate = Coordinate(2.0, 2.0)

    private val exception = Exception("Moon phase is wrong")

    @Mock
    private lateinit var beaconsGetter: BeaconsGetter
    @Mock
    private lateinit var floorDeterminator: FloorDeterminator
    @Mock
    private lateinit var averageSmoother: AverageSmoother
    @Mock
    private lateinit var beaconFilter: BeaconFilter
    @Mock
    private lateinit var beaconCalibrator: BeaconCalibrator
    @Mock
    private lateinit var distanceCalibrator: BeaconDistanceCalibrator
    @Mock
    private lateinit var distanceCalculator: BeaconDistanceCalculator
    @Mock
    private lateinit var trilaterationSolver: TrilaterationSolver
    @Mock
    private lateinit var distanceBounder: DistanceBounder
    @Mock
    private lateinit var locationRepo: LocationRepo
    @Mock
    private lateinit var stateHelper: StateHelper
    @Mock
    private lateinit var debugStorage: DebugStorage
    @Mock
    private lateinit var recordHelper: RecordHelper
    @Mock
    private lateinit var measurementHelper: MeasurementHelper
    @Mock
    private lateinit var graphBinder: GraphBinder
    @Mock
    private lateinit var scaleFactorCalculator: ScaleFactorCalculator
    @Mock
    private lateinit var coordinateDistanceCalculator: CoordinateDistanceCalculator
    @Mock
    private lateinit var logger: Logger

    private lateinit var locationInteractor: LocationInteractor

    @Before
    fun setUp() {
        locationInteractor = LocationInteractor(beaconsGetter, floorDeterminator, averageSmoother, beaconFilter, beaconCalibrator,
                distanceCalibrator, distanceCalculator, trilaterationSolver, distanceBounder, locationRepo, stateHelper, debugStorage, recordHelper,
                measurementHelper, graphBinder, scaleFactorCalculator, coordinateDistanceCalculator, logger, ONE_METER_AT_EQUATOR)

        whn(stateHelper.buildingId).thenReturn(BUILDING_ID)
        whn(stateHelper.userFloor).thenReturn(FLOOR_NUMBER)
        whn(stateHelper.visibleFloor).thenReturn(FLOOR_NUMBER)

        whn(beaconsGetter.getBeacons()).thenReturn(beaconsObservable)
        whn(locationRepo.getBeacons(BUILDING_ID, FLOOR_NUMBER)).thenReturn(Maybe.fromCallable { knownBeacons })

        whn(averageSmoother.smoothBeaconData(anyNonNull()))
                .thenAnswer { it.getArgument<Observable<Beacon>>(0).buffer(beacons.size) }

        whn(scaleFactorCalculator.scaleCoef).thenReturn(SCALE_COEF)
        whn(distanceCalculator.calculateDistance(anyDouble(), anyDouble())).thenCallRealMethod()

        whn(beaconsGetter.getBeaconsPack()).thenReturn(beaconsMaybe)
        whn(locationRepo.getBeacons(BUILDING_ID)).thenReturn(knownBeaconsMaybe)
        whn(floorDeterminator.determineAndChangeFloor(beaconsMaybe, knownBeaconsMaybe))
                .thenReturn(Maybe.fromCallable { FLOOR_NUMBER })

        RxJavaPlugins.setComputationSchedulerHandler { scheduler }
    }

    @After
    fun resetScheduler() {
        RxJavaPlugins.setComputationSchedulerHandler(null)
    }

    @Test
    fun testGetUserLocation() {
        getScheduledLocationObserver()
                .assertComplete()
                .assertValue(expectedCoordinate)
    }

    @Test
    fun testGetNoUserLocation() {
        whn(beaconsGetter.getBeacons()).thenReturn(farAwayBeaconsObservable)

        getScheduledLocationObserver()
                .assertComplete()
                .assertNoValues()
    }

    @Test
    fun testGetUserLocationIfUserFloorDiffersFromVisibleFloor() {
        whn(stateHelper.visibleFloor).thenReturn(ANOTHER_FLOOR_NUMBER)

        getScheduledLocationObserver().assertComplete()
                .assertNoValues()
    }

    @Test
    fun testGetUserLocationIfKnownBeaconsHaveNullCoordinates() {
        whn(locationRepo.getBeacons(BUILDING_ID, FLOOR_NUMBER))
                .thenReturn(Maybe.fromCallable { knownBeacons.onEach { it.coordinate = null } })

        getScheduledLocationObserver().assertComplete()
                .assertNoValues()
    }

    @Test
    fun testGetUserLocationIfUserFloorWasUndefinedBefore() {
        whn(stateHelper.userFloor).thenReturn(StateHelper.UNDEFINED)

        getScheduledLocationObserver().assertComplete()
                .assertNoValues()

        Mockito.verify(stateHelper).visibleFloor = FLOOR_NUMBER
    }

    @Test
    fun testGetUserLocationIfFloorDeterminationFailed() {
        whn(floorDeterminator.determineAndChangeFloor(beaconsMaybe, knownBeaconsMaybe))
                .thenReturn(Maybe.error(exception))

        getScheduledLocationObserver().assertComplete()
                .assertValue(expectedCoordinate)
    }

    private fun getScheduledLocationObserver(): TestObserver<Coordinate> {
        val observer = locationInteractor.simpleUserLocation
                .subscribeOn(scheduler)
                .test()

        scheduler.advanceTimeBy(2000, TimeUnit.MILLISECONDS)

        return observer
    }

    companion object {
        const val ONE_METER_AT_EQUATOR = 111320
        const val BUILDING_ID = 1L
        const val FLOOR_NUMBER = 2
        const val ANOTHER_FLOOR_NUMBER = 3
        const val SCALE_COEF = 3.0
    }
}
