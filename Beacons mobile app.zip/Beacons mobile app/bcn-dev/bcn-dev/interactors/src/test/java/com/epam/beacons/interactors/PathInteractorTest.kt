package com.epam.beacons.interactors

import com.epam.beacons.Beacon
import com.epam.beacons.Coordinate
import com.epam.beacons.Edge
import com.epam.beacons.Gate
import com.epam.beacons.Graph
import com.epam.beacons.KotlinMockito.whn
import com.epam.beacons.Vertex
import com.epam.beacons.graphbinder.GraphBinderData
import com.epam.beacons.interactors.shared.BeaconsGetter
import com.epam.beacons.interactors.shared.FloorDeterminator
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.navigation.DijkstraAlgorithm
import com.epam.beacons.navigation.ProximateVertexFinder
import com.epam.beacons.repository.DataRepo
import com.epam.beacons.repository.LocationRepo
import com.epam.beacons.repository.RoutingRepo
import com.epam.beacons.tools.CornerHelper
import com.epam.beacons.tools.GateHelper
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.ScaleFactorCalculator
import io.reactivex.Completable
import io.reactivex.Maybe
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.any
import org.mockito.ArgumentMatchers.eq
import org.mockito.Mock
import org.mockito.Mockito.verify
import org.mockito.Mockito.verifyZeroInteractions
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class PathInteractorTest {

    private val vertices = listOf(
            Vertex(0, Coordinate(0.0, 0.0)),
            Vertex(1, Coordinate(1.0, 1.0)),
            Vertex(2, Coordinate(2.0, 2.0))
    )
    private val edges = listOf(
            Edge(vertices[0], vertices[1], 1F),
            Edge(vertices[1], vertices[2], 1F),
            Edge(vertices[0], vertices[2], 1F)
    )
    private val graph = Graph(BUILDING_ID, FLOOR_NUMBER, vertices, edges)
    private val anotherFloorGraph = Graph(BUILDING_ID, ANOTHER_FLOOR_NUMBER, vertices, edges)
    private val start = Coordinate(40.0, 40.0)
    private val destination = Coordinate(45.0, 47.0)
    private val gates = listOf(
            Gate(0, BUILDING_ID, "image0", "type0", mapOf(
                    2 to Coordinate(0.0, 0.0),
                    3 to Coordinate(0.0, 0.0)
            )),
            Gate(1, BUILDING_ID, "image1", "type1", mapOf(
                    1 to Coordinate(41.0, 42.0),
                    2 to Coordinate(41.0, 42.0)
            ))
    )
    private val beaconsMaybe = Maybe.empty<List<Beacon>>()

    @Mock
    private lateinit var dijkstraAlgorithm: DijkstraAlgorithm
    @Mock
    private lateinit var proximateVertexFinder: ProximateVertexFinder
    @Mock
    private lateinit var dataRepo: DataRepo
    @Mock
    private lateinit var locationRepo: LocationRepo
    @Mock
    private lateinit var routingRepo: RoutingRepo
    @Mock
    private lateinit var floorDeterminator: FloorDeterminator
    @Mock
    private lateinit var beaconsGetter: BeaconsGetter
    @Mock
    private lateinit var stateHelper: StateHelper
    @Mock
    private lateinit var gateHelper: GateHelper
    @Mock
    private lateinit var graphBinderData: GraphBinderData
    @Mock
    private lateinit var cornerHelper: CornerHelper
    @Mock
    private lateinit var coordinateDistanceCalculator: CoordinateDistanceCalculator
    @Mock
    private lateinit var scaleFactorCalculator: ScaleFactorCalculator

    private lateinit var pathInteractor: PathInteractor

    @Before
    fun setUp() {
        pathInteractor = PathInteractor(dijkstraAlgorithm, proximateVertexFinder, dataRepo, locationRepo, routingRepo, floorDeterminator,
                beaconsGetter, stateHelper, gateHelper, graphBinderData, coordinateDistanceCalculator, scaleFactorCalculator,
                cornerHelper, oneMeterAtEquator = 111320)

        whn(stateHelper.buildingId).thenReturn(BUILDING_ID)
        whn(stateHelper.userFloor).thenReturn(FLOOR_NUMBER)

        whn(routingRepo.getGraph(BUILDING_ID, FLOOR_NUMBER)).thenReturn(Maybe.fromCallable { graph })

        whn(proximateVertexFinder.findProximateVertex(any(Graph::class.java), eq(start))).thenReturn(vertices[0])
        whn(dijkstraAlgorithm.getPath(any(Graph::class.java), eq(vertices[0]), eq(vertices[2]))).thenReturn(vertices)

        whn(coordinateDistanceCalculator.calcDistance(any(Coordinate::class.java), any(Coordinate::class.java))).thenReturn(100500.0)
        whn(scaleFactorCalculator.scaleCoef).thenReturn(1.0)

        whn(beaconsGetter.getBeaconsPack()).thenReturn(beaconsMaybe)
        whn(locationRepo.getBeacons(BUILDING_ID, gates[1].bounds.keys.toList())).thenReturn(beaconsMaybe)
        whn(floorDeterminator.determineAndChangeFloor(beaconsMaybe, beaconsMaybe)).thenReturn(Maybe.fromCallable { FLOOR_NUMBER })
        whn(locationRepo.clearBeaconsCache()).thenReturn(Completable.complete())
        whn(graphBinderData.clearRoute()).thenReturn(Completable.complete())
        whn(gateHelper.clear()).thenReturn(Completable.complete())
        whn(cornerHelper.clear()).thenReturn(Completable.complete())
        whn(cornerHelper.routeDistance).thenReturn(1)
        whn(cornerHelper.corners).thenReturn(mutableListOf(1 to CornerHelper.Corner.PLACE))
        whn(cornerHelper.destOrientation).thenReturn(CornerHelper.DestOrientation.NONE)
    }

    @Test
    fun testStartRouteOnOneFloor() {
        val expectedRoute = listOf(start) + vertices.map { it.coordinate } - vertices[0].coordinate

        whn(stateHelper.visibleFloor).thenReturn(FLOOR_NUMBER)
        whn(gateHelper.gatesPath(FLOOR_NUMBER, start, destination)).thenReturn(Maybe.fromCallable { start to destination })
        whn(dataRepo.getSavedGates(BUILDING_ID)).thenReturn(Maybe.fromCallable { gates })
        whn(proximateVertexFinder.findProximateVertex(any(Graph::class.java), eq(destination))).thenReturn(vertices[2])
        whn(coordinateDistanceCalculator.calcDistance(start, gates[1].bounds[1]!!)).thenReturn(0.0)
        whn(dataRepo.getGates(BUILDING_ID, FLOOR_NUMBER)).thenReturn(Maybe.fromCallable { gates })

        gateHelper.prepare(dataRepo.getSavedGates(BUILDING_ID).blockingGet(), destination, FLOOR_NUMBER, FLOOR_NUMBER)
        pathInteractor.startRoute(start, destination)
                .test()
                .assertComplete()
                .assertValue { it.route == expectedRoute && it.destination == destination }

        verify(floorDeterminator).determineAndChangeFloor(beaconsMaybe, beaconsMaybe)
        verify(graphBinderData).route = expectedRoute
    }

    @Test
    fun testStartRouteOnDifferentFloors() {
        val gateCoord = gates[1].bounds[1]!!

        whn(stateHelper.visibleFloor).thenReturn(ANOTHER_FLOOR_NUMBER)
        whn(gateHelper.gatesPath(ANOTHER_FLOOR_NUMBER, null, destination)).thenReturn(Maybe.fromCallable { start to gateCoord })
        whn(dataRepo.getSavedGates(BUILDING_ID)).thenReturn(Maybe.fromCallable { gates })
        whn(proximateVertexFinder.findProximateVertex(any(Graph::class.java), eq(gateCoord))).thenReturn(vertices[2])
        whn(dataRepo.getGates(BUILDING_ID, ANOTHER_FLOOR_NUMBER)).thenReturn(Maybe.fromCallable { gates })
        whn(routingRepo.getGraph(BUILDING_ID, ANOTHER_FLOOR_NUMBER)).thenReturn(Maybe.fromCallable { anotherFloorGraph })

        gateHelper.prepare(dataRepo.getSavedGates(BUILDING_ID).blockingGet(), destination, FLOOR_NUMBER, ANOTHER_FLOOR_NUMBER)

        val expectedRoute = listOf(start, vertices[1].coordinate, vertices[2].coordinate)
        pathInteractor.startRoute(start, destination)
                .test()
                .assertComplete()
                .assertValue { it.route == expectedRoute && it.destination == gateCoord }

        verify(graphBinderData).route = expectedRoute
    }

    @Test
    fun testStartRouteIfNotNearGate() {
        val expectedRoute = listOf(start) + vertices.map { it.coordinate } - vertices[0].coordinate

        whn(stateHelper.visibleFloor).thenReturn(FLOOR_NUMBER)
        whn(gateHelper.gatesPath(FLOOR_NUMBER, start, destination)).thenReturn(Maybe.fromCallable { start to destination })
        whn(dataRepo.getSavedGates(BUILDING_ID)).thenReturn(Maybe.fromCallable { gates })
        whn(proximateVertexFinder.findProximateVertex(any(Graph::class.java), eq(destination))).thenReturn(vertices[2])
        whn(dataRepo.getGates(BUILDING_ID, FLOOR_NUMBER)).thenReturn(Maybe.fromCallable { gates })

        gateHelper.prepare(dataRepo.getSavedGates(BUILDING_ID).blockingGet(), destination, FLOOR_NUMBER, FLOOR_NUMBER)

        pathInteractor.startRoute(start, destination)
                .test()
                .assertComplete()
                .assertValue { it.route == expectedRoute && it.destination == destination }

        verifyZeroInteractions(floorDeterminator)
        verify(locationRepo).clearBeaconsCache()
        verify(graphBinderData).route = expectedRoute
    }

    @Test
    fun userLocationUndefinedThenReturnMaybeError() {
        whn(stateHelper.userFloor).thenReturn(StateHelper.UNDEFINED)

        pathInteractor.startRoute(start, destination)
                .test()
                .assertError(IllegalStateException::class.java)
    }

    @Test
    fun whenGatePathIsEmptyReturnMaybeEmpty() {
        whn(stateHelper.visibleFloor).thenReturn(FLOOR_NUMBER)
        whn(gateHelper.gatesPath(FLOOR_NUMBER, start, destination)).thenReturn(Maybe.empty())
        whn(dataRepo.getSavedGates(BUILDING_ID)).thenReturn(Maybe.fromCallable { gates })
        whn(dataRepo.getGates(BUILDING_ID, FLOOR_NUMBER)).thenReturn(Maybe.fromCallable { gates })

        pathInteractor.startRoute(start, destination)
                .test()
                .assertComplete()
                .assertNoValues()
    }

    @Test
    fun testEndRoute() {
        pathInteractor.endRoute()
                .test()
                .assertComplete()
        verify(locationRepo).clearBeaconsCache()
        verify(graphBinderData).clearRoute()
        verify(cornerHelper).clear()
    }

    companion object {
        const val BUILDING_ID = 1L
        const val FLOOR_NUMBER = 1
        const val ANOTHER_FLOOR_NUMBER = 2
    }
}
