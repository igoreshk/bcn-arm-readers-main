package com.epam.beacons.interactors;

import com.epam.beacons.Building;
import com.epam.beacons.Coordinate;
import com.epam.beacons.Floor;
import com.epam.beacons.Gate;
import com.epam.beacons.Graph;
import com.epam.beacons.Pivot;
import com.epam.beacons.graphbinder.GraphBinderData;
import com.epam.beacons.interactors.util.BuildingComparator;
import com.epam.beacons.interactors.util.StateHelper;
import com.epam.beacons.repository.DataRepo;
import com.epam.beacons.repository.RoutingRepo;
import com.epam.beacons.tools.debug.DebugStorage;
import com.epam.beacons.tools.utils.ScaleFactorCalculator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import io.reactivex.Maybe;
import io.reactivex.Observable;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DataInteractorTest {
    private static final long          BUILDING_ID               = 0;
    private static final int           LAST_FLOOR_NUMBER         = 100000;
    private static final int           FIRST_FLOOR_NUMBER        = -100000;
    private static final int           FLOOR_NUMBER              = 0;
    private static final List<Integer> FAKE_SORTED_FLOOR_NUMBERS = Arrays.asList(1, 5, 7, 8);

    private final List<Building> FAKE_BUILDINGS = Arrays.asList(
            new Building(1, "test1", new Coordinate(1, 2), 1.0, 1.0, "address1", "number1", "hours1", "me")
    );
    private final List<Gate>     FAKE_GATES     = Arrays.asList(
            new Gate(1, BUILDING_ID, "image1", "type1",
                     new HashMap<Integer, Coordinate>() {{
                         put(1, new Coordinate(1, 2));
                     }}
            ),
            new Gate(2, BUILDING_ID, "image2", "type2",
                     new HashMap<Integer, Coordinate>() {{
                         put(2, new Coordinate(3, 4));
                     }}
            ),
            new Gate(3, BUILDING_ID, "image3", "type3",
                     new HashMap<Integer, Coordinate>() {{
                         put(3, new Coordinate(5, 6));
                     }}
            )
    );
    private final List<Floor>    FAKE_FLOORS    = Arrays.asList(
            new Floor(BUILDING_ID, FLOOR_NUMBER,
                      Collections.emptyList(),
                      Collections.emptyList(),
                      "url3",
                      70, 90,
                      new Coordinate(23, 24),
                      new Coordinate(25, 26)
            ),
            new Floor(BUILDING_ID, LAST_FLOOR_NUMBER,
                      Collections.emptyList(),
                      Collections.emptyList(),
                      "url3",
                      70, 90,
                      new Coordinate(23, 24),
                      new Coordinate(25, 26)
            ),
            new Floor(BUILDING_ID, FIRST_FLOOR_NUMBER,
                      Collections.emptyList(),
                      Collections.emptyList(),
                      "url3",
                      70, 90,
                      new Coordinate(23, 24),
                      new Coordinate(25, 26)
            )
    );
    private final List<Pivot>    FAKE_PIVOTS    = Arrays.asList(
            new Pivot(new Coordinate(1, 2), 1),
            new Pivot(new Coordinate(3, 4), 2),
            new Pivot(new Coordinate(5, 6), 3)
    );
    private final Graph          FAKE_GRAPH     = new Graph(BUILDING_ID, FLOOR_NUMBER, new ArrayList<>(), new ArrayList<>());

    private final Maybe<List<Building>>   BUILDINGS_MAYBE         = Maybe.fromCallable(() -> FAKE_BUILDINGS);
    private final Maybe<List<Floor>>      FLOORS_MAYBE            = Maybe.fromCallable(() -> FAKE_FLOORS);
    private final Maybe<List<Gate>>       GATES_MAYBE             = Maybe.fromCallable(() -> FAKE_GATES);
    private final Observable<List<Pivot>> PIVOTS_OBSERVABLE       = Observable.fromCallable(() -> FAKE_PIVOTS);
    private final Observable<Integer>     FLOOR_NUMBER_OBSERVABLE = Observable.fromCallable(() -> FLOOR_NUMBER);
    private final Maybe<Boolean>          BOOLEAN_TRUE_MAYBE      = Maybe.fromCallable(() -> true);
    private final Maybe<List<Integer>>    FAKE_FLOOR_NUMBERS      = Maybe.fromCallable(() -> Arrays.asList(1, 8, 7, 5));

    @Mock
    private DataRepo              repository;
    @Mock
    private RoutingRepo           routingRepo;
    @Mock
    private StateHelper           stateHelper;
    @Mock
    private BuildingComparator    buildingComparator;
    @Mock
    private DebugStorage          debugStorage;
    @Mock
    private GraphBinderData       graphBinderData;
    @Mock
    private ScaleFactorCalculator scaleFactorCalculator;
    @InjectMocks
    private DataInteractor        dataInteractor;

    @Before
    public void setUp() {
        when(stateHelper.getFloorNumberObservable()).thenReturn(FLOOR_NUMBER_OBSERVABLE);
        when(repository.getFloor(BUILDING_ID, FLOOR_NUMBER)).thenReturn(Maybe.fromCallable(() -> FAKE_FLOORS.get(0)));
    }

    @Test
    public void testDownloadBuildingsAnyway() {
        when(repository.getBuildingsAnyway()).thenReturn(BUILDINGS_MAYBE);
        dataInteractor.downloadBuildingsAnyway()
                      .test()
                      .assertValue(FAKE_BUILDINGS)
                      .assertComplete();
        verify(buildingComparator, times(3)).compare(any(Building.class), any(Building.class));
    }

    @Test
    public void testDownloadRecentBuildings() {
        when(repository.getRecentBuildings()).thenReturn(BUILDINGS_MAYBE);
        dataInteractor.downloadRecentBuildings()
                      .test()
                      .assertValue(FAKE_BUILDINGS)
                      .assertComplete();
        verify(buildingComparator, times(3)).compare(any(Building.class), any(Building.class));
    }

    @Test
    public void testDownloadFloorsAndGates() {
        when(repository.getFloors(BUILDING_ID)).thenReturn(FLOORS_MAYBE);
        when(repository.getGates(BUILDING_ID)).thenReturn(GATES_MAYBE);
        dataInteractor.downloadFloorsAndGates(BUILDING_ID)
                      .test()
                      .assertValue(FAKE_GATES)
                      .assertComplete();
        verify(stateHelper).setBuildingId(BUILDING_ID);
        verify(stateHelper).setVisibleFloor(FLOOR_NUMBER);
    }

    @Test
    public void testSwitchDebugDrawing() {
        when(repository.switchAndGetDebugValue()).thenReturn(BOOLEAN_TRUE_MAYBE);
        dataInteractor.switchDebugDrawing()
                      .test()
                      .assertValue(true)
                      .assertComplete();
    }

    @Test
    public void testIsDebugAllowed() {
        when(repository.getDebugAllowanceValue()).thenReturn(BOOLEAN_TRUE_MAYBE);
        dataInteractor.isDebugAllowed()
                      .test()
                      .assertValue(true)
                      .assertComplete();
    }

    @Test
    public void testGetFloorNumbers() {
        when(repository.getFloorNumbers()).thenReturn(FAKE_FLOOR_NUMBERS);
        dataInteractor.getFloorNumbers()
                      .test()
                      .assertValue(FAKE_SORTED_FLOOR_NUMBERS)
                      .assertComplete();
    }

    @Test
    public void testGetCurrentFloor() {
        when(routingRepo.getGraph(BUILDING_ID, FLOOR_NUMBER)).thenReturn(Maybe.fromCallable(() -> FAKE_GRAPH));
        dataInteractor.getCurrentFloor()
                      .test()
                      .assertValue(FAKE_FLOORS.get(0))
                      .assertComplete();
        verify(scaleFactorCalculator).setScaleCoef(
                FAKE_FLOORS.get(0).getWidth(),
                FAKE_FLOORS.get(0).getHeight(),
                FAKE_FLOORS.get(0).getOverlaySouthWestBound(),
                FAKE_FLOORS.get(0).getOverlayNorthEastBound()
        );
        verify(graphBinderData).setGraph(FAKE_GRAPH);
    }

    @Test
    public void testGetDebugData() {
        when(repository.getDebugAllowanceValue()).thenReturn(BOOLEAN_TRUE_MAYBE);
        when(debugStorage.getPivots()).thenReturn(PIVOTS_OBSERVABLE);
        dataInteractor.getDebugData()
                      .test()
                      .assertValue(FAKE_PIVOTS)
                      .assertComplete();
    }

    @Test
    public void testSwitchFloor() {
        dataInteractor.switchFloor(FLOOR_NUMBER)
                      .test()
                      .assertComplete();
        verify(stateHelper).setVisibleFloor(FLOOR_NUMBER);
    }

    @Test
    public void testSwitchToUserFloor() {
        when(stateHelper.getUserFloor()).thenReturn(LAST_FLOOR_NUMBER);

        dataInteractor.switchToUserFloor()
                      .test()
                      .assertComplete();

        verify(stateHelper).setVisibleFloor(LAST_FLOOR_NUMBER);
    }

    @SuppressWarnings("ResultOfMethodCallIgnored")
    @Test
    public void testSwitchToUserFloorUndefined() {
        when(stateHelper.getUserFloor()).thenReturn(StateHelper.UNDEFINED);

        dataInteractor.switchToUserFloor()
                      .test()
                      .assertComplete();

        verify(stateHelper).getUserFloor();
        verifyNoMoreInteractions(stateHelper);
    }

    @Test
    public void testGetLocationMode() {
        when(repository.isSimpleLocationMode()).thenReturn(Maybe.fromCallable(() -> true));

        dataInteractor.isSimpleLocationMode()
                      .test()
                      .assertComplete()
                      .assertValue(true);
    }

    @Test
    public void testSwitchAndGetLocationMode() {
        when(repository.switchAndGetSimpleLocationMode()).thenReturn(Maybe.fromCallable(() -> true));

        dataInteractor.switchAndGetSimpleLocationMode()
                      .test()
                      .assertComplete()
                      .assertValue(true);
    }
}
