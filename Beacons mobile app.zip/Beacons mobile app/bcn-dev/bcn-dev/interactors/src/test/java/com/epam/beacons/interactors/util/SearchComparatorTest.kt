package com.epam.beacons.interactors.util

import com.epam.beacons.Coordinate
import com.epam.beacons.Place
import org.hamcrest.CoreMatchers.equalTo
import org.junit.Assert.assertThat
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.Parameterized

@RunWith(Parameterized::class)
class SearchComparatorTest(private val biggerPlace: Place, private val smallerPlace: Place) {

    private val comparator = SearchComparator()

    companion object {
        @JvmStatic
        @Parameterized.Parameters
        fun initializeParameters(): Collection<Array<Place>> {
            return listOf(
                    arrayOf(
                            Place(0, "", "", Coordinate(0.0, 0.0), 1).setFav(true),
                            Place(0, "", "", Coordinate(0.0, 0.0), 1)
                    ),
                    arrayOf(
                            Place(0, "", "", Coordinate(0.0, 0.0), 1).setFav(true).setHist(true),
                            Place(0, "", "", Coordinate(0.0, 0.0), 1).setFav(true)
                    ),
                    arrayOf(
                            Place(0, "", "1", Coordinate(0.0, 0.0), 1),
                            Place(0, "", "first", Coordinate(0.0, 0.0), 1)
                    ),
                    arrayOf(
                            Place(0, "", "B", Coordinate(0.0, 0.0), 1),
                            Place(0, "", "A", Coordinate(0.0, 0.0), 1)
                    )
            )
        }
    }

    @Test
    fun `test comparing not equal places`() {
        assertThat(comparator.compare(biggerPlace, smallerPlace), equalTo(1))
        assertThat(comparator.compare(smallerPlace, biggerPlace), equalTo(-1))
    }
}

private fun Place.setFav(isFav: Boolean) = apply { isFavorite = isFav }

private fun Place.setHist(isHist: Boolean) = apply { isInHistory = isHist }
