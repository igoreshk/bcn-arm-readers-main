package com.epam.beacons.smoothers;

import com.epam.beacons.Beacon;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;

public class AverageSmootherTest {

    private AverageSmoother    averageSmoother;
    private Observable<Beacon> input;
    private List<Beacon>       expectedResult;

    @Before
    public void setUp() {
        averageSmoother = new AverageSmoother(300, TimeUnit.MILLISECONDS);
        input = Observable.just(
                new Beacon("b1", 1, 1, -55, -55),
                new Beacon("b2", 2, 2, -60, -61),
                new Beacon("b1", 1, 1, -55, -57),
                new Beacon("b2", 2, 2, -60, -60),
                new Beacon("b2", 2, 2, -60, -62),
                new Beacon("b1", 1, 1, -55, -56)
        );
        expectedResult = Arrays.asList(
                new Beacon("b1", 1, 1, -55, -56),
                new Beacon("b2", 2, 2, -60, -61)
        );
    }

    @Test
    public void testAverageSmoother() {
        averageSmoother.smoothBeaconData(input)
                       .test()
                       .assertValue(expectedResult)
                       .assertValue(beacons -> Double.compare(beacons.get(0).getTxPower(), expectedResult.get(0).getTxPower()) == 0 &&
                               beacons.get(0).getRssi() == expectedResult.get(0).getRssi() &&
                               Double.compare(beacons.get(1).getTxPower(), expectedResult.get(1).getTxPower()) == 0 &&
                               beacons.get(1).getRssi() == expectedResult.get(1).getRssi());
    }
}
