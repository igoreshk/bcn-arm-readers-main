package com.epam.beacons.interactors

import com.epam.beacons.Coordinate
import com.epam.beacons.KotlinMockito.anyNonNull
import com.epam.beacons.KotlinMockito.whn
import com.epam.beacons.Place
import com.epam.beacons.interactors.util.SearchComparator
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.repository.SearchRepo
import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.plugins.RxJavaPlugins
import io.reactivex.schedulers.TestScheduler
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito.times
import org.mockito.Mockito.verify
import org.mockito.junit.MockitoJUnitRunner
import java.util.concurrent.TimeUnit

@RunWith(MockitoJUnitRunner::class)
class SearchInteractorTest {

    private val scheduler = TestScheduler()
    private val history = listOf(
            Place(0, "type0", "description0", Coordinate(0.0, 0.0), 0),
            Place(1, "type1", "description1", Coordinate(1.0, 1.0), 1),
            Place(2, "type2", "description2", Coordinate(2.0, 2.0), 2))
    private val favorites = listOf(
            Place(2, "type2", "description2", Coordinate(2.0, 2.0), 2),
            Place(3, "type3", "description3", Coordinate(3.0, 3.0), 3),
            Place(4, "type4", "description4", Coordinate(4.0, 4.0), 4))

    init {
        favorites.forEach {
            it.isFavorite = true
            it.isInHistory = history.contains(it)
        }
        history.forEach {
            it.isFavorite = favorites.contains(it)
            it.isInHistory = true
        }
    }

    private val places = (history + favorites + Place(5, "type5", "description5", Coordinate(5.0, 5.0), 5)).distinct()

    @Mock
    private lateinit var searchRepo: SearchRepo
    @Mock
    private lateinit var stateHelper: StateHelper
    @Mock
    private lateinit var searchComparator: SearchComparator
    @InjectMocks
    private lateinit var searchInteractor: SearchInteractor

    @Before
    fun setUp() {
        whn(stateHelper.buildingId).thenReturn(BUILDING_ID)
    }

    @After
    fun tearDown() {
        RxJavaPlugins.setComputationSchedulerHandler(null)
    }

    @Test
    fun testGetRecentItems() {
        whn(searchRepo.getHistory(BUILDING_ID)).thenReturn(Maybe.fromCallable { history })

        searchInteractor.getRecentItems()
                .test()
                .assertComplete()
                .assertValue(history)
                .assertValue { it.all { it.isInHistory } }
                .assertValue { it.filter { favorites.contains(it) }.all { it.isFavorite } }
                .assertValue { it.filterNot { favorites.contains(it) }.none { it.isFavorite } }
    }

    @Test
    fun testSearch() {
        whn(searchRepo.getPlaces(BUILDING_ID)).thenReturn(Maybe.fromCallable { places })

        RxJavaPlugins.setComputationSchedulerHandler { scheduler }

        val observer = searchInteractor.search()
                .test()
        val filter1 = "description"
        val filter2 = "description3"

        searchInteractor.filters.onNext("description1")
        scheduler.advanceTimeBy(SearchInteractor.DEBOUNCE_MILLISECONDS / 2, TimeUnit.MILLISECONDS)
        searchInteractor.filters.onNext(filter1)

        observer.assertNoValues()
        scheduler.advanceTimeBy(SearchInteractor.DEBOUNCE_MILLISECONDS, TimeUnit.MILLISECONDS)
        observer.assertValueCount(1)
                .assertValue { it.sortedBy { it.id } == places.sortedBy { it.id } }
                .assertValue { it.filter { favorites.contains(it) }.all { it.isFavorite } }
                .assertValue { it.filterNot { favorites.contains(it) }.none { it.isFavorite } }
                .assertValue { it.filter { history.contains(it) }.all { it.isInHistory } }
                .assertValue { it.filterNot { history.contains(it) }.none { it.isInHistory } }

        searchInteractor.filters.onNext(filter2)
        observer.assertValueCount(1)
        scheduler.advanceTimeBy(SearchInteractor.DEBOUNCE_MILLISECONDS, TimeUnit.MILLISECONDS)
        observer.assertValueCount(2)
                .assertValueAt(1, listOf(places[3]))
                .assertValueAt(1, { it[0].isFavorite == places[3].isFavorite && it[0].isInHistory == places[3].isInHistory })

        verify(searchComparator).query = filter1
        verify(searchComparator).query = filter2
        verify(searchComparator, times(5)).compare(anyNonNull(), anyNonNull())
    }

    @Test
    fun testMoveToPlaceAndAddToHistory() {
        val placeId = 3L
        val place = places[placeId.toInt()]
        whn(searchRepo.getPlace(BUILDING_ID, placeId)).thenReturn(Maybe.fromCallable { place })
        whn(searchRepo.addToHistory(BUILDING_ID, placeId)).thenReturn(Completable.complete())

        searchInteractor.moveToPlaceAndAddToHistory(placeId)
                .test()
                .assertComplete()
                .assertValue(place)

        verify(stateHelper).visibleFloor = place.floorNumber
        verify(searchRepo).addToHistory(BUILDING_ID, placeId)
    }

    companion object {
        private const val BUILDING_ID = 42L
    }
}
