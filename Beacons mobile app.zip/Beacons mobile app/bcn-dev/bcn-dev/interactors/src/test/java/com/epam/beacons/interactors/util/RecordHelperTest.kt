package com.epam.beacons.interactors.util

import com.epam.beacons.Beacon
import com.epam.beacons.Coordinate
import com.epam.beacons.DataUnit
import com.epam.beacons.KotlinMockito.whn
import com.epam.beacons.RecordedData
import io.reactivex.Completable
import io.reactivex.Maybe
import io.reactivex.Single
import io.reactivex.observers.TestObserver
import io.reactivex.plugins.RxJavaPlugins
import io.reactivex.schedulers.TestScheduler
import junit.framework.TestCase.assertEquals
import org.hamcrest.CoreMatchers.`is`
import org.hamcrest.MatcherAssert.assertThat
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.anyString
import org.mockito.Mock
import org.mockito.Mockito.anyList
import org.mockito.Mockito.mock
import org.mockito.Mockito.verify
import org.mockito.junit.MockitoJUnitRunner
import java.io.File
import java.io.FileNotFoundException
import java.util.concurrent.TimeUnit

@RunWith(MockitoJUnitRunner::class)
class RecordHelperTest {

    @Mock
    private lateinit var fileHandler: FileHandler

    private lateinit var recordHelper: RecordHelper

    private val beacons = listOf(Beacon("1", 1, 1, 1.0, 1), Beacon("2", 2, 2, 2.0, 2), Beacon("3", 3, 3, 3.0, 3))
    private val dataUnits = mutableListOf(DataUnit(beacons[0], 0), DataUnit(beacons[1], DELTA_TIME), DataUnit(beacons[2], 0))
    private val data = listOf(RecordedData(dataUnits, null, null))

    private val scheduler = TestScheduler()

    @Before
    fun setUp() {
        recordHelper = RecordHelper(fileHandler, DELTA_TIME)
        RxJavaPlugins.setComputationSchedulerHandler { scheduler }
    }

    @After
    fun resetScheduler() {
        RxJavaPlugins.setComputationSchedulerHandler(null)
    }

    @Test
    fun testStartRecording() {
        addDataToTestClearing()

        recordHelper.startRecording()
                .test()
                .assertComplete()

        assertPlayingAndRecording(false, true)
        assertDataIsCleared()
    }

    @Test
    fun testStartPlaying() {
        recordHelper.startPlaying()
                .test()
                .assertComplete()

        assertPlayingAndRecording(true, false)
    }

    @Test
    fun testSetDataFromFile() {
        addDataToTestClearing()

        recordHelper.setDataFromFile(data)
        assertBufferIsEmpty(true)
        assertThat(recordHelper.dataForLoad.size, `is`(3))

        testLoadObserver(getLoadObserver())

        assertPlayingAndRecording(false, false)
    }

    @Test
    fun testSetDataFromEmptyFile() {
        recordHelper.setDataFromFile(emptyList())

        val observer = getLoadObserver()

        observer.assertNoValues()
                .assertComplete()

        assertPlayingAndRecording(false, false)
    }

    @Test
    fun testReadDataFromFile() {
        val path = "path"

        whn(fileHandler.readData(anyString())).thenReturn(Single.fromCallable { data })

        recordHelper.readDataFromFile(path)
                .test()
                .assertValue(data)
                .assertComplete()

        verify(fileHandler).readData(path)
    }

    @Test
    fun testGetFile() {
        val file = mock(File::class.java)

        whn(fileHandler.getFile()).thenReturn(Maybe.fromCallable { file })

        recordHelper.getFile()
                .test()
                .assertValue(file)
                .assertComplete()
    }

    @Test
    fun testGetFileFail() {
        val exception = FileNotFoundException()

        whn(fileHandler.getFile()).thenReturn(Maybe.error(exception))

        recordHelper.getFile()
                .test()
                .assertError(exception)
                .assertNotComplete()
    }

    @Test
    fun testSaveFile() {
        recordHelper.data.addAll(data)

        whn(fileHandler.writeData(anyList())).thenReturn(Completable.complete())

        recordHelper.saveFile()
                .test()
                .assertComplete()

        verify(fileHandler).writeData(data)
    }

    @Test
    fun testResetRecordHelper() {
        addDataToTestClearing()

        recordHelper.resetRecordHelper()
                .test()
                .assertComplete()

        assertPlayingAndRecording(false, false)
        assertDataIsCleared()
    }

    @Test
    fun testSetRecordingFalse() {
        recordHelper.data.addAll(data)

        setRecording(false)

        testLoadObserver(getLoadObserver())

        assertPlayingAndRecording(false, false)
    }

    @Test
    fun testSetRecordingTrue() {
        setRecording(true)

        getLoadObserver().assertNoValues()
                .assertComplete()

        assertPlayingAndRecording(false, true)
    }

    @Test
    fun testSaveBeaconWhileNotRecording() {
        recordHelper.save(beacons[0])

        assertBufferIsEmpty(true)
    }

    @Test
    fun testSaveBeacon() {
        setRecording(true)

        recordHelper.save(beacons[0])

        assertBufferIsEmpty(false)
        assertEquals(recordHelper.buffer.peek(), dataUnits[0])
    }

    @Test
    fun testSaveAvgRssiWhileNotRecording() {
        setRecording(true)

        recordHelper.save(beacons[0])

        setRecording(false)

        recordHelper.saveAvgRssi(beacons)

        assertThat(recordHelper.recordedData.dataUnits.isEmpty(), `is`(true))
    }

    @Test
    fun testSaveAvgRssi() {
        setRecording(true)

        saveBeaconAndAvgRssi(beacons[0], beacons)

        assertThat(recordHelper.recordedData.dataUnits.size, `is`(1))
        assertEquals(recordHelper.recordedData.dataUnits[0], DataUnit(beacons[0], deltaTime = 0, avgRssi = beacons[0].rssi))

        saveBeaconAndAvgRssi(beacons[1], beacons)

        assertThat(recordHelper.recordedData.dataUnits.size, `is`(2))
        assertEquals(recordHelper.recordedData.dataUnits[1], DataUnit(beacons[1], deltaTime = DELTA_TIME, avgRssi = beacons[1].rssi))
    }

    @Test
    fun testSaveDistanceToBeaconWhileNotRecording() {
        setRecording(true)

        saveBeaconAndAvgRssi(beacons[0], beacons)

        setRecording(false)

        recordHelper.saveDistanceToBeacon(beacons[0], 2.0)

        assertThat(recordHelper.recordedData.dataUnits[0].distance, `is`(0.0))
    }

    @Test
    fun testSaveDistanceToBeacon() {
        setRecording(true)

        saveBeaconAndAvgRssi(beacons[0], beacons)

        recordHelper.saveDistanceToBeacon(beacons[0], 2.0)

        assertThat(recordHelper.recordedData.dataUnits[0].distance, `is`(2.0))
    }

    @Test
    fun testSaveTrilaterationCoordinateWhileNotRecording() {
        setRecording(true)

        saveBeaconAndAvgRssi(beacons[0], beacons)

        setRecording(false)

        val savedCoordinate = Coordinate(1.0, 1.0)
        recordHelper.recordedData.trilaterationCoordinate = savedCoordinate

        recordHelper.saveTrilaterationCoordinate(Coordinate(2.0, 2.0))

        assertEquals(recordHelper.recordedData.trilaterationCoordinate, savedCoordinate)
    }

    @Test
    fun testSaveTrilaterationNullCoordinate() {
        setRecording(true)

        saveBeaconAndAvgRssi(beacons[0], beacons)

        val savedCoordinate = Coordinate(1.0, 1.0)
        recordHelper.recordedData.trilaterationCoordinate = savedCoordinate

        recordHelper.saveTrilaterationCoordinate(null)

        assertEquals(recordHelper.recordedData.trilaterationCoordinate, null)
    }

    @Test
    fun testSaveTrilaterationCoordinate() {
        setRecording(true)

        saveBeaconAndAvgRssi(beacons[0], beacons)

        recordHelper.recordedData.trilaterationCoordinate = Coordinate(1.0, 1.0)

        val newCoordinate = Coordinate(2.0, 2.0)
        recordHelper.saveTrilaterationCoordinate(newCoordinate)

        assertEquals(recordHelper.recordedData.trilaterationCoordinate, newCoordinate)
    }

    @Test
    fun testSaveBoundedCoordinateWhileNotRecording() {
        setRecording(true)

        saveBeaconAndAvgRssi(beacons[0], beacons)

        setRecording(false)

        recordHelper.saveBoundAndFinishCycle(Coordinate(1.0, 1.0))

        assertThat(recordHelper.data.isEmpty(), `is`(true))
    }

    @Test
    fun testSaveNullBoundedCoordinate() {
        setRecording(true)

        saveBeaconAndAvgRssi(beacons[0], beacons)

        recordHelper.saveBoundAndFinishCycle(null)

        assertEquals(recordHelper.data[0].boundCoord, null)
    }

    @Test
    fun testSaveBoundedCoordinate() {
        setRecording(true)

        saveBeaconAndAvgRssi(beacons[0], beacons)

        val newCoordinate = Coordinate(2.0, 2.0)
        recordHelper.saveBoundAndFinishCycle(newCoordinate)

        assertRecordedDataIsCleared()
        assertThat(recordHelper.data.size, `is`(1))
        assertEquals(recordHelper.data[0].boundCoord, newCoordinate)
    }

    private fun getLoadObserver(): TestObserver<Beacon> {
        val observer = recordHelper.load()
                .subscribeOn(scheduler)
                .test()
                .assertNoValues()
                .assertNotComplete()

        scheduler.advanceTimeBy(DELAY_TIME, TimeUnit.MILLISECONDS)

        return observer
    }

    private fun testLoadObserver(observer: TestObserver<Beacon>) {
        observer.assertValueCount(1)
                .assertValue(beacons[0])
                .assertNotComplete()
        scheduler.advanceTimeBy(DELAY_TIME, TimeUnit.MILLISECONDS)
        observer.assertValueCount(1)
                .assertValue(beacons[0])
                .assertNotComplete()
        scheduler.advanceTimeBy(DELAY_TIME, TimeUnit.MILLISECONDS)
        observer.assertValues(beacons[0], beacons[1], beacons[2])
                .assertValueCount(3)
                .assertComplete()
    }

    private fun assertPlayingAndRecording(isPlaying: Boolean, isRecording: Boolean) {
        assertThat(recordHelper.isPlaying, `is`(isPlaying))
        assertThat(recordHelper.isRecording, `is`(isRecording))
    }

    private fun assertBufferIsEmpty(isEmpty: Boolean) {
        assertThat(recordHelper.buffer.isEmpty(), `is`(isEmpty))
    }

    private fun assertRecordedDataIsCleared() {
        assertThat(recordHelper.recordedData.dataUnits.isEmpty(), `is`(true))
        assertEquals(recordHelper.recordedData.boundCoord, null)
        assertEquals(recordHelper.recordedData.trilaterationCoordinate, null)
    }

    private fun assertDataIsCleared() {
        assertBufferIsEmpty(true)
        assertRecordedDataIsCleared()
        assertThat(recordHelper.dataForLoad.isEmpty(), `is`(true))
        assertThat(recordHelper.data.isEmpty(), `is`(true))
    }

    private fun addDataToTestClearing() {
        recordHelper.data.addAll(data)
        recordHelper.buffer.add(dataUnits[0])
        recordHelper.dataForLoad.add(RecordHelper.LoadDataUnit(beacons[0], 0L))
        recordHelper.recordedData.dataUnits.add(dataUnits[1])
        recordHelper.recordedData.boundCoord = Coordinate(1.0, 1.0)
        recordHelper.recordedData.trilaterationCoordinate = Coordinate(2.0, 2.0)
    }

    private fun setRecording(recording: Boolean) {
        recordHelper.setRecordingState(recording)
                .test()
                .assertComplete()
    }

    private fun saveBeaconAndAvgRssi(beacon: Beacon, beacons: List<Beacon>) {
        recordHelper.save(beacon)
        recordHelper.saveAvgRssi(beacons)
    }

    companion object {
        private const val DELTA_TIME = 3000L
        private const val DELAY_TIME = 1000L
    }
}
