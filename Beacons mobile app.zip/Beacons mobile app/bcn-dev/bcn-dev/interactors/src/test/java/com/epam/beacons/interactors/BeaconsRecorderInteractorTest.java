package com.epam.beacons.interactors;

import com.epam.beacons.RecordedData;
import com.epam.beacons.interactors.util.RecordHelper;
import com.epam.beacons.notification.NotificationHelper;
import com.epam.beacons.tools.Logger;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collections;
import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Maybe;
import io.reactivex.Single;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BeaconsRecorderInteractorTest {
    @Mock
    private RecordHelper              recordHelper;
    @Mock
    private NotificationHelper        notificationHelper;
    @Mock
    private Logger                    logger;
    @InjectMocks
    private BeaconsRecorderInteractor beaconsRecorderInteractor;

    @Test
    public void testStartRecording() {
        when(recordHelper.startRecording()).thenReturn(Completable.complete());
        beaconsRecorderInteractor.startRecording()
                                 .test()
                                 .assertComplete();
    }

    @Test
    public void testStopRecording() {
        when(recordHelper.setRecordingState(false)).thenReturn(Completable.complete());
        beaconsRecorderInteractor.stopRecording()
                                 .test()
                                 .assertComplete();
    }

    @Test
    public void testStopRecordingIllegalStateException() {
        final Throwable exception = new IllegalStateException();

        when(recordHelper.setRecordingState(false)).thenReturn(Completable.error(exception));
        beaconsRecorderInteractor.stopRecording()
                                 .test()
                                 .assertError(exception);

        verify(logger).i(anyString(), isNull());
    }

    @Test
    public void testStopRecordingException() {
        final Throwable exception = new Exception();

        when(recordHelper.setRecordingState(false)).thenReturn(Completable.error(exception));
        beaconsRecorderInteractor.stopRecording()
                                 .test()
                                 .assertError(exception);

        verify(logger).e(anyString(), anyString(), eq(exception));
    }

    @Test
    public void testStartPlaying() {
        when(recordHelper.startPlaying()).thenReturn(Completable.complete());
        beaconsRecorderInteractor.startPlaying()
                                 .test()
                                 .assertComplete();
    }

    @Test
    public void testSaveToFile() {
        when(recordHelper.saveFile()).thenReturn(Completable.complete());
        when(notificationHelper.showFileSavedNotification()).thenReturn(Completable.complete());
        beaconsRecorderInteractor.saveToFile()
                                 .test()
                                 .assertComplete();
    }

    @Test
    public void testGetFile() {
        final File fakeFile = new File("");

        when(recordHelper.getFile()).thenReturn(Maybe.fromCallable(() -> fakeFile));

        beaconsRecorderInteractor.getFile()
                                 .test()
                                 .assertValue(fakeFile)
                                 .assertComplete();
    }

    @Test
    public void testGetFileError() {
        final Throwable exception = new FileNotFoundException();

        when(recordHelper.getFile()).thenReturn(Maybe.error(exception));

        beaconsRecorderInteractor.getFile()
                                 .test()
                                 .assertError(exception);
    }

    @Test
    public void testUpdateData() {
        final String path = "path";
        final List<RecordedData> recordedData = Collections.singletonList(new RecordedData());

        when(recordHelper.readDataFromFile(anyString())).thenReturn(Single.fromCallable(() -> recordedData));

        beaconsRecorderInteractor.updateData(path)
                                 .test()
                                 .assertComplete();

        verify(recordHelper).setDataFromFile(recordedData);
    }
}
