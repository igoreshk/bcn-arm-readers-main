package com.epam.beacons.interactors.util

import com.epam.beacons.Coordinate
import com.epam.beacons.Place
import org.hamcrest.CoreMatchers.equalTo
import org.junit.Assert.assertThat
import org.junit.Test

class SearchComparatorAdditionalTest {

    private val comparator = SearchComparator()

    @Test
    fun `test comparing places with case insensitive description`() {
        val place1 = Place(0, "", "AAA", Coordinate(0.0, 0.0), 1)
        val place2 = Place(0, "", "aaa", Coordinate(0.0, 0.0), 1)
        assertThat(comparator.compare(place1, place2), equalTo(0))
    }

    @Test
    fun `test comparing with oneself`() {
        val place = Place(0, "", "", Coordinate(0.0, 0.0), 1)
        assertThat(comparator.compare(place, place), equalTo(0))
    }

    @Test
    fun `test comparing places by query`() {
        comparator.query = "some query"
        val place1 = Place(0, "", "some query", Coordinate(0.0, 0.0), 1)
        val place2 = Place(0, "", "aaa some query", Coordinate(0.0, 0.0), 1)
        assertThat(comparator.compare(place1, place2) < 0, equalTo(true))
    }
}
