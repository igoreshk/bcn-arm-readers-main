package com.epam.beacons.interactors

import com.epam.beacons.Coordinate
import com.epam.beacons.KotlinMockito.whn
import com.epam.beacons.Place
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.repository.FavoritesRepo
import io.reactivex.Completable
import io.reactivex.Maybe
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito.verify
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class FavoritesInteractorTest {

    private val favorites = listOf(
            Place(0, "type0", "description0", Coordinate(0.0, 0.0), 0),
            Place(1, "type1", "description1", Coordinate(1.0, 1.0), 1),
            Place(2, "type2", "description2", Coordinate(2.0, 2.0), 2))
    private val favoritesIds = favorites.map { it.id }

    @Mock
    private lateinit var favoritesRepo: FavoritesRepo
    @Mock
    private lateinit var stateHelper: StateHelper
    @InjectMocks
    private lateinit var favoritesInteractor: FavoritesInteractor

    @Before
    fun setUp() {
        whn(stateHelper.buildingId).thenReturn(BUILDING_ID)
    }

    @Test
    fun testGetFavorites() {
        whn(favoritesRepo.getFavorites(BUILDING_ID)).thenReturn(Maybe.fromCallable { favorites })

        favoritesInteractor.getFavorites()
                .test()
                .assertComplete()
                .assertValue(favorites)
    }

    @Test
    fun testGetFavoritesEmpty() {
        whn(favoritesRepo.getFavorites(BUILDING_ID)).thenReturn(Maybe.fromCallable { emptyList<Place>() })

        favoritesInteractor.getFavorites()
                .test()
                .assertComplete()
                .assertValue(emptyList())
    }

    @Test
    fun testSwitchFavoriteOn() {
        val notFavoriteId = 5L
        whn(favoritesRepo.getFavoritesIds(BUILDING_ID)).thenReturn(Maybe.fromCallable { favoritesIds })
        whn(favoritesRepo.addToFavorites(BUILDING_ID, notFavoriteId)).thenReturn(Completable.complete())

        favoritesInteractor.switchFavorite(notFavoriteId)
                .test()
                .assertComplete()

        verify(favoritesRepo).addToFavorites(BUILDING_ID, notFavoriteId)
    }

    @Test
    fun testSwitchFavoriteOff() {
        val favoriteId = 1L
        whn(favoritesRepo.getFavoritesIds(BUILDING_ID)).thenReturn(Maybe.fromCallable { favoritesIds })
        whn(favoritesRepo.removeFromFavorites(BUILDING_ID, favoriteId)).thenReturn(Completable.complete())

        favoritesInteractor.switchFavorite(favoriteId)
                .test()
                .assertComplete()

        verify(favoritesRepo).removeFromFavorites(BUILDING_ID, favoriteId)
    }

    @Test
    fun testSwitchFavoriteWhenNoFavorites() {
        val notFavoriteId = 5L
        whn(favoritesRepo.getFavoritesIds(BUILDING_ID)).thenReturn(Maybe.fromCallable { emptyList<Long>() })
        whn(favoritesRepo.addToFavorites(BUILDING_ID, notFavoriteId)).thenReturn(Completable.complete())

        favoritesInteractor.switchFavorite(notFavoriteId)
                .test()
                .assertComplete()

        verify(favoritesRepo).addToFavorites(BUILDING_ID, notFavoriteId)
    }

    companion object {
        private const val BUILDING_ID = 42L
    }
}
