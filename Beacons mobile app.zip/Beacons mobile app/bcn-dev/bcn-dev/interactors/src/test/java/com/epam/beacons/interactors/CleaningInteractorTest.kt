package com.epam.beacons.interactors

import com.epam.beacons.KotlinMockito.whn
import com.epam.beacons.graphbinder.GraphBinderData
import com.epam.beacons.interactors.util.RecordHelper
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.kalman.KalmanData
import com.epam.beacons.repository.DataRepo
import com.epam.beacons.repository.FavoritesRepo
import com.epam.beacons.repository.LocationRepo
import com.epam.beacons.repository.RoutingRepo
import com.epam.beacons.repository.SearchRepo
import com.epam.beacons.tools.CornerHelper
import io.reactivex.Completable
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito.times
import org.mockito.Mockito.verify
import org.mockito.Mockito.verifyNoMoreInteractions
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class CleaningInteractorTest {

    private val exception = Exception("broken")

    @Mock
    private lateinit var stateHelper: StateHelper
    @Mock
    private lateinit var locationRepo: LocationRepo
    @Mock
    private lateinit var dataRepo: DataRepo
    @Mock
    private lateinit var routingRepo: RoutingRepo
    @Mock
    private lateinit var searchRepo: SearchRepo
    @Mock
    private lateinit var favoritesRepo: FavoritesRepo
    @Mock
    private lateinit var recordHelper: RecordHelper
    @Mock
    private lateinit var kalmanData: KalmanData
    @Mock
    private lateinit var graphBinderData: GraphBinderData
    @Mock
    private lateinit var cornerHelper: CornerHelper

    @InjectMocks
    private lateinit var cleaningInteractor: CleaningInteractor

    @Before
    fun setUp() {
        whn(locationRepo.clearUserFloorBeaconsCache()).thenReturn(Completable.complete())
        whn(locationRepo.clearBeaconsCache()).thenReturn(Completable.complete())
        whn(dataRepo.clearGatesCache()).thenReturn(Completable.complete())
        whn(dataRepo.clearFloorNumbersCache()).thenReturn(Completable.complete())
        whn(routingRepo.clearGraphsCache()).thenReturn(Completable.complete())
        whn(searchRepo.clearPlacesCaches()).thenReturn(Completable.complete())
        whn(favoritesRepo.clearCache()).thenReturn(Completable.complete())
        whn(recordHelper.resetRecordHelper()).thenReturn(Completable.complete())
        whn(kalmanData.reset()).thenReturn(Completable.complete())
        whn(graphBinderData.clearGraph()).thenReturn(Completable.complete())
        whn(graphBinderData.clearRoute()).thenReturn(Completable.complete())
        whn(cornerHelper.clear()).thenReturn(Completable.complete())
    }

    @Test
    fun testClearBuildingData() {
        cleaningInteractor.clearBuildingData()
                .test()
                .assertComplete()
        verifyStateHelper()
    }

    @Test
    fun testClearBuildingDataIfClearUserFloorBeaconsCacheThrowsError() {
        whn(locationRepo.clearUserFloorBeaconsCache()).thenReturn(Completable.error(exception))
        cleaningInteractor.clearBuildingData()
                .test()
                .assertError(exception)
        verifyStateHelper()
    }

    @Test
    fun testClearBuildingDataIfClearBeaconsCacheThrowsError() {
        whn(locationRepo.clearBeaconsCache()).thenReturn(Completable.error(exception))
        cleaningInteractor.clearBuildingData()
                .test()
                .assertError(exception)
        verifyStateHelper()
    }

    @Test
    fun testClearBuildingDataIfDataRepoThrowsError() {
        whn(dataRepo.clearGatesCache()).thenReturn(Completable.error(exception))
        whn(dataRepo.clearFloorNumbersCache()).thenReturn(Completable.error(exception))
        cleaningInteractor.clearBuildingData()
                .test()
                .assertError(exception)
        verifyStateHelper()

        verify(dataRepo, times(1)).clearGatesCache()
        verify(dataRepo, times(1)).clearFloorNumbersCache()
    }

    @Test
    fun testClearBuildingDataIfRoutingRepoThrowsError() {
        whn(routingRepo.clearGraphsCache()).thenReturn(Completable.error(exception))
        cleaningInteractor.clearBuildingData()
                .test()
                .assertError(exception)
    }

    @Test
    fun testClearBuildingDataIfSearchRepoThrowsError() {
        whn(searchRepo.clearPlacesCaches()).thenReturn(Completable.error(exception))
        cleaningInteractor.clearBuildingData()
                .test()
                .assertError(exception)
        verifyStateHelper()
    }

    @Test
    fun testClearBuildingDataIfFavoritesRepoThrowsError() {
        whn(favoritesRepo.clearCache()).thenReturn(Completable.error(exception))
        cleaningInteractor.clearBuildingData()
                .test()
                .assertError(exception)
        verifyStateHelper()
    }

    @Test
    fun testClearBuildingDataIfRecordHelperThrowsError() {
        whn(recordHelper.resetRecordHelper()).thenReturn(Completable.error(exception))
        cleaningInteractor.clearBuildingData()
                .test()
                .assertError(exception)
        verifyStateHelper()
    }

    @Test
    fun testClearBuildingDataIfKalmanDataThrowsError() {
        whn(kalmanData.reset()).thenReturn(Completable.error(exception))
        cleaningInteractor.clearBuildingData()
                .test()
                .assertError(exception)
        verifyStateHelper()
    }

    @Test
    fun testClearBuildingDataIfGraphBinderDataThrowsError() {
        whn(graphBinderData.clearRoute()).thenReturn(Completable.error(exception))
        whn(graphBinderData.clearGraph()).thenReturn(Completable.error(exception))
        cleaningInteractor.clearBuildingData()
                .test()
                .assertError(exception)
        verifyStateHelper()
    }

    @Test
    fun testClearBuildingDataIfCornerHelperThrowsError() {
        whn(cornerHelper.clear()).thenReturn(Completable.error(exception))
        cleaningInteractor.clearBuildingData()
                .test()
                .assertError(exception)
        verifyStateHelper()
    }

    private fun verifyStateHelper() {
        verify(stateHelper, times(1)).userFloor = StateHelper.UNDEFINED
        verifyNoMoreInteractions(stateHelper)
    }
}
