package com.epam.beacons.interactors.shared

import com.epam.beacons.Beacon
import com.epam.beacons.Coordinate
import com.epam.beacons.KotlinMockito.whn
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.repository.LocationRepo
import io.reactivex.Completable
import io.reactivex.Maybe
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito.verify
import org.mockito.Mockito.verifyNoMoreInteractions
import org.mockito.Mockito.verifyZeroInteractions
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class FloorDeterminatorTest {

    private val floorNumber = 1
    private val knownBeacons = listOf(
            Beacon("uuid1", 1, 1, 2, Coordinate(1.0, 1.0)),
            Beacon("uuid2", 2, 2, 2, Coordinate(2.0, 2.0)),
            Beacon("uuid3", 3, 3, floorNumber, Coordinate(3.0, 3.0))
    )
    private val scannedBeacons = listOf(
            Beacon("uuid1", 1, 1, -55.0, -57),
            Beacon("uuid2", 2, 2, -60.0, -62),
            Beacon("uuid3", 3, 3, -63.0, -64),
            Beacon("uuid4", 4, 4, -65.0, -67)
    )

    @Mock
    private lateinit var locationRepo: LocationRepo
    @Mock
    private lateinit var stateHelper: StateHelper

    @InjectMocks
    private lateinit var floorDeterminator: FloorDeterminator

    @Before
    fun setUp() {
        whn(locationRepo.clearUserFloorBeaconsCache()).thenReturn(Completable.complete())
    }

    @Test
    fun testDetermineAndChangeFloor() {
        floorDeterminator.determineAndChangeFloor(
                Maybe.fromCallable { scannedBeacons },
                Maybe.fromCallable { knownBeacons }
        )
                .test()
                .assertComplete()
        verify(stateHelper).userFloor = 2
        verifyNoMoreInteractions(stateHelper)
        verify(locationRepo).clearUserFloorBeaconsCache()
    }

    @Test
    fun testDetermineAndChangeFloorIfNoKnownBeacons() {
        floorDeterminator.determineAndChangeFloor(
                Maybe.fromCallable { scannedBeacons },
                Maybe.fromCallable { emptyList<Beacon>() }
        )
                .test()
                .assertComplete()
        verifyNoMoreInteractions(stateHelper)
        verifyZeroInteractions(locationRepo)
    }

    @Test
    fun testDetermineAndChangeFloorIfNoScannedBeacons() {
        floorDeterminator.determineAndChangeFloor(
                Maybe.fromCallable { emptyList<Beacon>() },
                Maybe.fromCallable { knownBeacons }
        )
                .test()
                .assertComplete()
        verifyNoMoreInteractions(stateHelper)
        verifyZeroInteractions(locationRepo)
    }

    @Test
    fun testDetermineAndChangeFloorIfAllBeaconsUnknown() {
        floorDeterminator.determineAndChangeFloor(
                Maybe.fromCallable { scannedBeacons.subList(0, 2) },
                Maybe.fromCallable { listOf(knownBeacons[2]) }
        )
                .test()
                .assertComplete()
        verifyNoMoreInteractions(stateHelper)
        verifyZeroInteractions(locationRepo)
    }
}
