package com.epam.beacons.interactors

import com.epam.beacons.Coordinate
import com.epam.beacons.KotlinMockito.whn
import com.epam.beacons.bounders.DistanceBounder
import com.epam.beacons.calibrator.BeaconCalibrator
import com.epam.beacons.distance.BeaconDistanceCalculator
import com.epam.beacons.distance.BeaconDistanceCalibrator
import com.epam.beacons.filter.BeaconFilter
import com.epam.beacons.graphbinder.GraphBinder
import com.epam.beacons.interactors.shared.BeaconsGetter
import com.epam.beacons.interactors.shared.FloorDeterminator
import com.epam.beacons.interactors.util.MeasurementHelper
import com.epam.beacons.interactors.util.RecordHelper
import com.epam.beacons.interactors.util.StateHelper
import com.epam.beacons.locator.TrilaterationSolver
import com.epam.beacons.repository.LocationRepo
import com.epam.beacons.smoothers.AverageSmoother
import com.epam.beacons.tools.Logger
import com.epam.beacons.tools.debug.DebugStorage
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.ScaleFactorCalculator
import io.reactivex.Completable
import io.reactivex.subjects.CompletableSubject
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class LocationInteractorPeripheralTest {

    private val coordinate = Coordinate(5.0, 5.0)

    @Mock
    private lateinit var beaconsGetter: BeaconsGetter
    @Mock
    private lateinit var floorDeterminator: FloorDeterminator
    @Mock
    private lateinit var averageSmoother: AverageSmoother
    @Mock
    private lateinit var beaconFilter: BeaconFilter
    @Mock
    private lateinit var beaconCalibrator: BeaconCalibrator
    @Mock
    private lateinit var distanceCalibrator: BeaconDistanceCalibrator
    @Mock
    private lateinit var distanceCalculator: BeaconDistanceCalculator
    @Mock
    private lateinit var trilaterationSolver: TrilaterationSolver
    @Mock
    private lateinit var distanceBounder: DistanceBounder
    @Mock
    private lateinit var locationRepo: LocationRepo
    @Mock
    private lateinit var stateHelper: StateHelper
    @Mock
    private lateinit var debugStorage: DebugStorage
    @Mock
    private lateinit var recordHelper: RecordHelper
    @Mock
    private lateinit var measurementHelper: MeasurementHelper
    @Mock
    private lateinit var graphBinder: GraphBinder
    @Mock
    private lateinit var scaleFactorCalculator: ScaleFactorCalculator
    @Mock
    private lateinit var coordinateDistanceCalculator: CoordinateDistanceCalculator
    @Mock
    private lateinit var logger: Logger

    private lateinit var locationInteractor: LocationInteractor

    @Before
    fun setUp() {
        locationInteractor = LocationInteractor(beaconsGetter, floorDeterminator, averageSmoother, beaconFilter, beaconCalibrator,
                distanceCalibrator, distanceCalculator, trilaterationSolver, distanceBounder, locationRepo, stateHelper, debugStorage, recordHelper,
                measurementHelper, graphBinder, scaleFactorCalculator, coordinateDistanceCalculator, logger, ONE_METER_AT_EQUATOR)
    }

    @Test
    fun testGetRecordStateNew() {
        val recordState = CompletableSubject.create()
        whn(beaconsGetter.playFinished).thenReturn(recordState)
        whn(beaconCalibrator.resetApproximation()).thenReturn(Completable.complete())

        val recordStateObserver = locationInteractor.isPlayFinished
                .test()

        recordState.onComplete()

        recordStateObserver.assertComplete()
    }

    @Test
    fun testIsDestinationReached() {
        val shortDist = 2.5 * SCALE_COEFF / ONE_METER_AT_EQUATOR
        whn(coordinateDistanceCalculator.calcDistance(coordinate, coordinate)).thenReturn(shortDist)
        whn(scaleFactorCalculator.scaleCoef).thenReturn(SCALE_COEFF)

        locationInteractor.isDestinationReached(coordinate, coordinate)
                .test()
                .assertComplete()
                .assertValue(shortDist)
    }

    @Test
    fun testIsDestinationReachedIfNot() {
        val longDist = 3.5 * SCALE_COEFF / ONE_METER_AT_EQUATOR
        whn(coordinateDistanceCalculator.calcDistance(coordinate, coordinate)).thenReturn(longDist)
        whn(scaleFactorCalculator.scaleCoef).thenReturn(SCALE_COEFF)

        locationInteractor.isDestinationReached(coordinate, coordinate)
                .test()
                .assertComplete()
                .assertNoValues()
    }

    companion object {
        const val ONE_METER_AT_EQUATOR = 111320
        const val SCALE_COEFF = 2.0
    }
}
