package com.epam.beacons.graphbinder

import com.epam.beacons.Coordinate
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GraphBinder @Inject constructor(
        private val data: GraphBinderData,
        private val processor: GraphBinderProcessor
) {

    fun bind(coord: Coordinate): Coordinate {
        data.route?.let { return processor.bindToGraph(it, coord) }
        return processor.bindToGraph(data.graph, coord)
    }
}
