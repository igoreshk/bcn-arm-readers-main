package com.epam.beacons.graphbinder

import com.epam.beacons.Coordinate
import com.epam.beacons.Graph
import io.reactivex.Completable
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GraphBinderData @Inject constructor() {

    var route: List<Coordinate>? = null
    var graph: Graph? = null

    fun clearRoute(): Completable = Completable.fromAction { route = null }

    fun clearGraph(): Completable = Completable.fromAction { graph = null }
}
