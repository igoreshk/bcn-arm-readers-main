package com.epam.beacons.graphbinder

import com.epam.beacons.Coordinate
import com.epam.beacons.Graph
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.ScaleFactorCalculator
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GraphBinderProcessor @Inject constructor(
        private val distanceCalculator: CoordinateDistanceCalculator,
        private val scaleFactorCalculator: ScaleFactorCalculator,
        private val graphBinderData: GraphBinderData,
        private val oneMeterAtEquator: Int
) {

    private var minimalRadius = DEFAULT_DISTANCE
    private var minimalDistanceToEdge = DEFAULT_DISTANCE
    private var lastUserCoordinate: Coordinate? = null
    private var finalUserCoordinate: Coordinate? = null
    private val closestCoordinates: MutableList<Coordinate> = ArrayList()

    internal fun bindToGraph(route: List<Coordinate>, userCoord: Coordinate): Coordinate {
        val size = route.size
        if (size <= 1) {
            return userCoord
        }

        prepareData()

        route.forEach { findClosestCoordinates(it, userCoord) }

        lastUserCoordinate = lastClosestCoordinate() ?: closestCoordinates[0]

        for (i in 0 until size - 1) {
            findClosestIntersectionPoint(userCoord, minimalRadius, route[i], route[i + 1])
        }

        if (isUserLost()) return bindToGraph(graphBinderData.graph, userCoord)

        calcErrorRadius(userCoord)

        return finalUserCoordinate ?: lastUserCoordinate ?: userCoord
    }

    internal fun bindToGraph(graph: Graph?, userCoord: Coordinate): Coordinate {
        if (graph == null || graph.edges!!.isEmpty() || graph.vertices!!.size < 2) {
            return userCoord
        }

        prepareData()

        graph.vertices!!.forEach { findClosestCoordinates(it.coordinate!!, userCoord) }

        lastUserCoordinate = lastClosestCoordinate() ?: closestCoordinates[0]

        graph.edges!!.forEach { findClosestIntersectionPoint(userCoord, minimalRadius, it.source!!.coordinate!!, it.destination!!.coordinate!!) }

        calcErrorRadius(userCoord)

        return finalUserCoordinate ?: lastUserCoordinate ?: userCoord
    }

    private fun findClosestCoordinates(candidate: Coordinate, userCoord: Coordinate) {
        val distance = distanceCalculator.calcDistance(candidate, userCoord)

        if (distance < minimalRadius) {
            minimalRadius = distance
            closestCoordinates.clear()
            closestCoordinates.add(candidate)
        } else if (distance == minimalRadius) {
            closestCoordinates.add(candidate)
        }
    }

    private fun lastClosestCoordinate(): Coordinate? {
        closestCoordinates.forEach {
            if (it == lastUserCoordinate) {
                return it
            }
        }
        return null
    }

    private fun findClosestIntersectionPoint(userCoord: Coordinate, radius: Double, source: Coordinate, dest: Coordinate) {
        val candidate = intersectionPoint(userCoord.latitude, userCoord.longitude, radius,
                source.latitude, source.longitude, dest.latitude, dest.longitude)

        candidate?.let {
            val distance = distanceCalculator.calcDistance(userCoord, candidate)
            if (distance < minimalDistanceToEdge) {
                minimalDistanceToEdge = distance
                finalUserCoordinate = candidate
            }
        }
    }

    private fun maxUserDistance() = MAX_USER_RADIUS * scaleFactorCalculator.scaleCoef / oneMeterAtEquator

    private fun isUserLost() = when {
        minimalDistanceToEdge != DEFAULT_DISTANCE && minimalDistanceToEdge > maxUserDistance() -> true
        minimalDistanceToEdge == DEFAULT_DISTANCE && minimalRadius != DEFAULT_DISTANCE && minimalRadius > maxUserDistance() -> true
        else -> false
    }

    private fun calcErrorRadius(userCoord: Coordinate) {
        if (minimalDistanceToEdge != DEFAULT_DISTANCE) {
            finalUserCoordinate?.errorRadius = userCoord.errorRadius + minimalDistanceToEdge
        } else if (minimalRadius != DEFAULT_DISTANCE) {
            lastUserCoordinate?.errorRadius = userCoord.errorRadius + minimalRadius
        }
    }

    @Suppress("LongParameterList", "ComplexCondition", "ReturnCount")
    private fun intersectionPoint(x: Double, y: Double, r: Double, x01: Double, y01: Double, x02: Double, y02: Double): Coordinate? {
        // Are x-coordinates of two vertices on the same axis
        if (x01 == x02) {

            // does intersection point belong to line segment and is located inside circle
            if ((y01 < y && y02 > y || y01 > y && y02 < y) && Math.abs(x01 - x) <= r) {
                return Coordinate(x01, y)
            }
        }

        // Are y-coordinates of two vertices on the same axis
        if (y01 == y02) {

            // does intersection point belong to line segment and is located inside circle
            if ((x01 < x && x02 > x || x01 > x && x02 < x) && Math.abs(y01 - y) <= r) {
                return Coordinate(x, y01)
            }
        }

        // Find intersection point (xp, yp) of perpendicular from the center of the circle to the line
        val a = (y01 - y02) / (x01 - x02)
        val b = y01 - a * x01
        val xp = (y - b + x / a) / (a + 1 / a)
        val yp = a * xp + b

        // Does the point belong to line segment
        if (x01 < xp && x02 > xp || x02 < xp && x01 > xp) {

            // and is located inside the circle
            if (Math.pow(xp - x, 2.0) + Math.pow(yp - y, 2.0) <= r * r) {
                return Coordinate(xp, yp)
            }
        }

        return null
    }

    private fun prepareData() {
        minimalRadius = DEFAULT_DISTANCE
        minimalDistanceToEdge = DEFAULT_DISTANCE
        closestCoordinates.clear()
        finalUserCoordinate = null
    }

    companion object {
        private val DEFAULT_DISTANCE = Double.MAX_VALUE
        private const val MAX_USER_RADIUS = 10.0
    }
}
