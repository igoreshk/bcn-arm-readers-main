package com.epam.beacons.graphbinder

import com.epam.beacons.Coordinate
import com.epam.beacons.Edge
import com.epam.beacons.Graph
import com.epam.beacons.Vertex
import com.epam.beacons.graphbinder.KotlinMockito.whn
import com.epam.beacons.tools.utils.CoordinateDistanceCalculator
import com.epam.beacons.tools.utils.ScaleFactorCalculator
import junit.framework.TestCase.assertEquals
import org.junit.Before
import org.junit.Test
import org.mockito.ArgumentMatchers.any
import org.mockito.Mock
import org.mockito.Mockito.verify
import org.mockito.MockitoAnnotations

class GraphBinderProcessorTest {

    private val userCoordinate = Coordinate(2.0, 0.5)
    private val vertices: MutableList<Vertex> = ArrayList()
    private val edges: MutableList<Edge> = ArrayList()
    private val graph: Graph? = Graph(1, 1, vertices, edges)
    private val route: MutableList<Coordinate> = ArrayList()
    private val firstCoordinateOnCircle = Coordinate(3.0, 1.0)
    private val secondCoordinateOnCircle = Coordinate(1.0, 0.0)

    @Mock
    private lateinit var scaleFactorCalculator: ScaleFactorCalculator
    @Mock
    private lateinit var distanceCalculator: CoordinateDistanceCalculator
    @Mock
    private lateinit var graphBinderData: GraphBinderData

    private lateinit var graphBinderProcessor: GraphBinderProcessor

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        whn(distanceCalculator.calcDistance(any(), any())).thenCallRealMethod()
        whn(scaleFactorCalculator.scaleCoef).thenReturn(100000.0)
        clearData()
        graphBinderProcessor = GraphBinderProcessor(distanceCalculator, scaleFactorCalculator, graphBinderData, METER_AT_EQUATOR)
    }

    @Test
    fun testOneLineIntersection() {
        addFirstEdge()

        val graphCoord = graphBinderProcessor.bindToGraph(graph, userCoordinate)
        val routeCoord = graphBinderProcessor.bindToGraph(route, userCoordinate)

        assertEquals(2.4, graphCoord.latitude, DELTA)
        assertEquals(2.4, routeCoord.latitude, DELTA)

        assertEquals(1.3, graphCoord.longitude, DELTA)
        assertEquals(1.3, routeCoord.longitude, DELTA)
    }

    @Test
    fun testTwoLinesIntersection() {
        addFirstEdge()
        addSecondEdge()

        val graphCoord = graphBinderProcessor.bindToGraph(graph, userCoordinate)
        val routeCoord = graphBinderProcessor.bindToGraph(route, userCoordinate)

        assertEquals(1.65, graphCoord.latitude, DELTA)
        assertEquals(1.65, routeCoord.latitude, DELTA)

        assertEquals(0.41, graphCoord.longitude, DELTA)
        assertEquals(0.41, routeCoord.longitude, DELTA)
    }

    @Test
    fun testThreeLinesIntersection() {
        addFirstEdge()
        addSecondEdge()
        addThirdEdge()

        val graphCoord = graphBinderProcessor.bindToGraph(graph, userCoordinate)
        val routeCoord = graphBinderProcessor.bindToGraph(route, userCoordinate)

        assertEquals(1.8, graphCoord.latitude, DELTA)
        assertEquals(1.8, routeCoord.latitude, DELTA)

        assertEquals(0.5, graphCoord.longitude, DELTA)
        assertEquals(0.5, routeCoord.longitude, DELTA)
    }

    @Test
    fun testFourLinesIntersection() {
        addFirstEdge()
        addSecondEdge()
        addThirdEdge()
        addFourthEdge()

        val graphCoord = graphBinderProcessor.bindToGraph(graph, userCoordinate)
        val routeCoord = graphBinderProcessor.bindToGraph(route, userCoordinate)

        assertEquals(2.0, graphCoord.latitude, DELTA)
        assertEquals(2.0, routeCoord.latitude, DELTA)

        assertEquals(0.6, graphCoord.longitude, DELTA)
        assertEquals(0.6, routeCoord.longitude, DELTA)
    }

    @Test
    fun testChooseEdgeNotVertex() {
        addFirstEdge()
        addFirstEdgeOutsideCircle()

        val graphCoord = graphBinderProcessor.bindToGraph(graph, userCoordinate)
        val routeCoord = graphBinderProcessor.bindToGraph(route, userCoordinate)

        assertEquals(2.4, graphCoord.latitude, DELTA)
        assertEquals(2.4, routeCoord.latitude, DELTA)

        assertEquals(1.3, graphCoord.longitude, DELTA)
        assertEquals(1.3, routeCoord.longitude, DELTA)
    }

    @Test
    fun testEdgeOutsideCircle() {
        addFirstEdgeOutsideCircle()

        assertEquals(firstCoordinateOnCircle, graphBinderProcessor.bindToGraph(graph, userCoordinate))
    }

    @Test
    fun testEdgeOutsideCircleInRouteMode() {
        addFirstEdgeOutsideCircle()

        assertEquals(firstCoordinateOnCircle, graphBinderProcessor.bindToGraph(route, userCoordinate))
    }

    @Test
    fun testFindClosestCoordinate() {
        addFirstEdgeOutsideCircle()
        addSecondEdgeOutsideCircle()

        assertEquals(firstCoordinateOnCircle, graphBinderProcessor.bindToGraph(graph, userCoordinate))
        assertEquals(firstCoordinateOnCircle, graphBinderProcessor.bindToGraph(route, userCoordinate))
    }

    @Test
    fun testMultipleCoordsOnCircleChoosePrevious() {
        addFirstEdgeOutsideCircle()
        addSecondEdgeOutsideCircle()
        graphBinderProcessor.bindToGraph(graph, userCoordinate)
        graphBinderProcessor.bindToGraph(route, userCoordinate)

        addThirdEdgeOutsideCircle()

        assertEquals(firstCoordinateOnCircle, graphBinderProcessor.bindToGraph(graph, userCoordinate))
        assertEquals(firstCoordinateOnCircle, graphBinderProcessor.bindToGraph(route, userCoordinate))
    }

    @Test
    fun testNullGraph() {
        assertEquals(graphBinderProcessor.bindToGraph(null, userCoordinate), userCoordinate)
    }

    @Test
    fun testEmptyGraph() {
        assertEquals(graphBinderProcessor.bindToGraph(Graph(0, 0, vertices, edges), userCoordinate), userCoordinate)
    }

    @Test
    fun testBrokenGraph() {
        edges.add(Edge(Vertex(2, Coordinate(2.5, 2.0)), Vertex(1, Coordinate(2.5, -1.0)), 0f))
        assertEquals(graphBinderProcessor.bindToGraph(Graph(0, 0, vertices, edges), userCoordinate), userCoordinate)
    }

    @Test
    fun testBrokenRoute() {
        assertEquals(graphBinderProcessor.bindToGraph(mutableListOf(Coordinate(0.0, 0.0)), userCoordinate), userCoordinate)
    }

    @Test
    fun edgeOnSameLatitudeAdditionalTest() {
        vertices.add(Vertex(2, Coordinate(2.5, 2.0)))
        vertices.add(Vertex(1, Coordinate(2.5, -1.0)))
        edges.add(Edge(vertices[0], vertices[1], 0f))
        route.add(vertices[0].coordinate)
        route.add(vertices[1].coordinate)

        val graphCoord = graphBinderProcessor.bindToGraph(graph, userCoordinate)
        val routeCoord = graphBinderProcessor.bindToGraph(route, userCoordinate)

        assertEquals(2.5, graphCoord.latitude, DELTA)
        assertEquals(2.5, routeCoord.latitude, DELTA)

        assertEquals(0.5, graphCoord.longitude, DELTA)
        assertEquals(0.5, routeCoord.longitude, DELTA)
    }

    @Test
    fun edgeOnSameLongitudeAdditionalTest() {
        vertices.add(Vertex(2, Coordinate(3.5, 0.3)))
        vertices.add(Vertex(1, Coordinate(0.8, 0.3)))
        edges.add(Edge(vertices[0], vertices[1], 0f))
        route.add(vertices[0].coordinate)
        route.add(vertices[1].coordinate)

        val graphCoord = graphBinderProcessor.bindToGraph(graph, userCoordinate)
        val routeCoord = graphBinderProcessor.bindToGraph(route, userCoordinate)

        assertEquals(2.0, graphCoord.latitude, DELTA)
        assertEquals(2.0, routeCoord.latitude, DELTA)

        assertEquals(0.3, graphCoord.longitude, DELTA)
        assertEquals(0.3, routeCoord.longitude, DELTA)
    }

    @Test
    fun testErrorRadiusToEdge() {
        addFirstEdge()

        assertEquals(0.89, graphBinderProcessor.bindToGraph(graph, userCoordinate).errorRadius, DELTA)
        assertEquals(0.89, graphBinderProcessor.bindToGraph(route, userCoordinate).errorRadius, DELTA)

        userCoordinate.errorRadius = 2.0

        assertEquals(2.89, graphBinderProcessor.bindToGraph(graph, userCoordinate).errorRadius, DELTA)
        assertEquals(2.89, graphBinderProcessor.bindToGraph(route, userCoordinate).errorRadius, DELTA)
    }

    @Test
    fun testErrorRadiusToVertex() {
        addFirstEdgeOutsideCircle()

        assertEquals(1.11, graphBinderProcessor.bindToGraph(graph, userCoordinate).errorRadius, DELTA)
        assertEquals(1.11, graphBinderProcessor.bindToGraph(route, userCoordinate).errorRadius, DELTA)

        userCoordinate.errorRadius = 2.0

        assertEquals(3.11, graphBinderProcessor.bindToGraph(graph, userCoordinate).errorRadius, DELTA)
        assertEquals(3.11, graphBinderProcessor.bindToGraph(route, userCoordinate).errorRadius, DELTA)
    }

    @Test
    fun testUserFarFromEdgeInRouteMode() {
        addFirstEdge()

        whn(scaleFactorCalculator.scaleCoef).thenReturn(10.0)
        whn(graphBinderData.graph).thenReturn(graph)

        val coord = graphBinderProcessor.bindToGraph(route, userCoordinate)

        assertEquals(2.4, coord.latitude, DELTA)
        assertEquals(1.3, coord.longitude, DELTA)

        verify(scaleFactorCalculator).scaleCoef
        verify(graphBinderData).graph
    }

    @Test
    fun testUserFarFromVertexInRouteMode() {
        addFirstEdgeOutsideCircle()

        whn(scaleFactorCalculator.scaleCoef).thenReturn(10.0)
        whn(graphBinderData.graph).thenReturn(graph)

        assertEquals(firstCoordinateOnCircle, graphBinderProcessor.bindToGraph(route, userCoordinate))

        verify(scaleFactorCalculator).scaleCoef
        verify(graphBinderData).graph
    }

    private fun addFirstEdge() {
        vertices.add(Vertex(1, Coordinate(1.0, 2.0)))
        vertices.add(Vertex(2, firstCoordinateOnCircle))
        edges.add(Edge(vertices[0], vertices[1], 0f))

        route.add(vertices[0].coordinate)
        route.add(vertices[1].coordinate)
    }

    private fun addSecondEdge() {
        vertices.add(Vertex(3, Coordinate(1.0, 3.0)))
        vertices.add(Vertex(4, Coordinate(2.0, -1.0)))
        edges.add(Edge(vertices[2], vertices[3], 0f))

        route.add(vertices[2].coordinate)
        route.add(vertices[3].coordinate)
    }

    private fun addThirdEdge() {
        vertices.add(Vertex(5, Coordinate(1.8, -1.0)))
        vertices.add(Vertex(6, Coordinate(1.8, 2.0)))
        edges.add(Edge(vertices[4], vertices[5], 0f))

        route.add(vertices[4].coordinate)
        route.add(vertices[5].coordinate)
    }

    private fun addFourthEdge() {
        vertices.add(Vertex(7, Coordinate(0.8, 0.6)))
        vertices.add(Vertex(8, Coordinate(3.5, 0.6)))
        edges.add(Edge(vertices[6], vertices[7], 0f))

        route.add(vertices[6].coordinate)
        route.add(vertices[7].coordinate)
    }

    private fun addFirstEdgeOutsideCircle() {
        vertices.add(Vertex(1, firstCoordinateOnCircle))
        vertices.add(Vertex(2, Coordinate(3.5, 1.5)))
        edges.add(Edge(vertices[0], vertices[1], 0f))

        route.add(vertices[0].coordinate)
        route.add(vertices[1].coordinate)
    }

    private fun addSecondEdgeOutsideCircle() {
        vertices.add(Vertex(3, Coordinate(4.0, 0.0)))
        vertices.add(Vertex(4, Coordinate(4.0, -1.0)))
        edges.add(Edge(vertices[2], vertices[3], 0f))

        route.add(vertices[2].coordinate)
        route.add(vertices[3].coordinate)
    }

    private fun addThirdEdgeOutsideCircle() {
        vertices.add(Vertex(5, Coordinate(0.5, -0.5)))
        vertices.add(Vertex(6, secondCoordinateOnCircle))
        edges.add(Edge(vertices[4], vertices[5], 0f))

        route.add(vertices[4].coordinate)
        route.add(vertices[5].coordinate)
    }

    private fun clearData() {
        vertices.clear()
        edges.clear()
        route.clear()
    }

    companion object {
        const val DELTA = 0.01
        const val METER_AT_EQUATOR = 111320
    }
}
