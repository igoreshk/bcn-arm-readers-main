package com.epam.beacons.graphbinder

import com.epam.beacons.Coordinate
import com.epam.beacons.Graph
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

class GraphBinderDataTest {

    private val route = mutableListOf(Coordinate(1.0, 1.0), Coordinate(2.0, 2.0))
    private val graph = Graph(42, 5, emptyList(), emptyList())

    private lateinit var graphBinderData: GraphBinderData

    @Before
    fun setUp() {
        graphBinderData = GraphBinderData()
    }

    @Test
    fun testGetRouteWhenNoRoute() {
        assertEquals(null, graphBinderData.route)
    }

    @Test
    fun testGetGraphWhenNoGraph() {
        assertEquals(null, graphBinderData.graph)
    }

    @Test
    fun testSetAndGetRoute() {
        graphBinderData.route = route
        assertEquals(route, graphBinderData.route)
    }

    @Test
    fun testSetAndGetGraph() {
        graphBinderData.graph = graph
        assertEquals(graph, graphBinderData.graph)
    }

    @Test
    fun testClearRoute() {
        graphBinderData.route = route
        graphBinderData.clearRoute()
                .test()
        assertEquals(null, graphBinderData.route)
    }

    @Test
    fun testClearGraph() {
        graphBinderData.graph = graph
        graphBinderData.clearGraph()
                .test()
        assertEquals(null, graphBinderData.graph)
    }
}
