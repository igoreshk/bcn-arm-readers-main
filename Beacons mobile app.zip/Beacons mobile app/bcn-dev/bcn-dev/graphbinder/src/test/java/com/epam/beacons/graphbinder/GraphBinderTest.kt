package com.epam.beacons.graphbinder

import com.epam.beacons.Coordinate
import com.epam.beacons.Graph
import com.epam.beacons.graphbinder.KotlinMockito.whn
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class GraphBinderTest {

    private val inputCoord = Coordinate(0.0, 0.0)
    private val resultCoord = Coordinate(5.0, 5.0)
    private val route = mutableListOf(Coordinate(1.0, 1.0), Coordinate(2.0, 2.0))
    private val graph = Graph(42, 5, emptyList(), emptyList())

    @Mock
    private lateinit var data: GraphBinderData
    @Mock
    private lateinit var processor: GraphBinderProcessor
    @InjectMocks
    private lateinit var graphBinder: GraphBinder

    @Test
    fun testBindToRoute() {
        whn(data.route).thenReturn(route)
        whn(processor.bindToGraph(route, inputCoord)).thenReturn(resultCoord)

        assertEquals(resultCoord, graphBinder.bind(inputCoord))
    }

    @Test
    fun testBindToGraph() {
        whn(data.route).thenReturn(null)
        whn(data.graph).thenReturn(graph)
        whn(processor.bindToGraph(graph, inputCoord)).thenReturn(resultCoord)

        assertEquals(resultCoord, graphBinder.bind(inputCoord))
    }
}
