package com.epam.beacons

data class Track(val idUser: String,
                 val latitude: Double,
                 val longitude: Double,
                 val time: String,
                 val buildingId: Int,
                 val floorId: Int)
