package com.epam.beacons

data class Pivot(val coordinate: Coordinate, var distance: Double)
