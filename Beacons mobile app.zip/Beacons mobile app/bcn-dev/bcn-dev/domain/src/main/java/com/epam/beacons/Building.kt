package com.epam.beacons

data class Building(val entityId: String,
                    val address:  String?,
                    val coordinate: Coordinate,
                    val width: Double?,
                    val height: Double?,
                    val name: String?,
                    val phoneNumber: String?,
                    val workingHours: String?,
                    val createdBy: String?,
                    val icon:String?)
