package com.epam.beacons

object PlaceTypes {
    const val ROOM = "Room"
    const val RESTROOM = "Restroom"
    const val REST_AREA = "Rest area"
    const val CAFE = "Cafe"
    const val UNKNOWN = "Unknown type"
}
