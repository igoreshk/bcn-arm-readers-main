package com.epam.beacons

data class Vertex(val id: String?, val coordinate: Coordinate?) {
    constructor(id: String, latitude: Double, longitude: Double) : this(id, Coordinate(latitude, longitude))
}
