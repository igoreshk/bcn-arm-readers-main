package com.epam.beacons

data class Coordinate constructor(var latitude: Double, var longitude: Double) {

    @JvmOverloads
    constructor(latitude: Double, longitude: Double, errorRadius: Double, timestamp: Long = 0) : this(latitude, longitude) {
        this.errorRadius = errorRadius
        this.timestamp = timestamp
    }

    var errorRadius: Double = 0.0
    var timestamp: Long = 0
}
