package com.epam.beacons;

import androidx.annotation.NonNull;

public class Measurement {
    private int        rssi;
    private double     distance;
    private long       timestamp;
    @NonNull
    private Coordinate coordinate;

    public Measurement(int rssi, double distance, long timestamp) {
        this.rssi = rssi;
        this.distance = distance;
        this.timestamp = timestamp;
    }

    public Measurement(int rssi, long timestamp, @NonNull Coordinate coordinate) {
        this.rssi = rssi;
        this.timestamp = timestamp;
        this.coordinate = coordinate;
    }

    @NonNull
    public Coordinate getCoordinate() {
        return coordinate;
    }

    public int getRssi() {
        return rssi;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public long getTimestamp() {
        return timestamp;
    }
}
