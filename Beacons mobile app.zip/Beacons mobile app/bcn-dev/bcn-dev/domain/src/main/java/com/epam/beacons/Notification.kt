package com.epam.beacons

data class Notification(
        val id: Int,
        val smallIcon: ImageType,
        val largeIcon: ImageType,
        val title: String,
        val text: String,
        val channelId: String,
        val intentData: IntentData?
) {
    private constructor(builder: Builder) : this(
            builder.id,
            builder.smallIcon,
            builder.largeIcon,
            builder.title,
            builder.text,
            builder.channelId,
            builder.intentData
    )

    class Builder (var smallIcon: ImageType = ImageType.LAUNCHER_ROUND) {
        var id: Int = 0
            private set
        var largeIcon: ImageType = ImageType.LAUNCHER_ROUND
            private set
        var title: String = ""
            private set
        var text: String = ""
            private set
        var channelId: String = ""
            private set
        var intentData: IntentData? = null
            private set

        fun build() = Notification(this)
        fun setId(id: Int) = apply { this.id = id }
        fun setLargeIcon(largeIcon: ImageType) = apply { this.largeIcon = largeIcon }
        fun setTitle(title: String) = apply { this.title = title }
        fun setText(text: String) = apply { this.text = text }
        fun setChannelId(channelId: String) = apply { this.channelId = channelId }
        fun setIntentData(intentData: IntentData) = apply { this.intentData = intentData }
    }

    enum class ImageType {
        FILE_DOWNLOAD, LAUNCHER_ROUND
    }
}
