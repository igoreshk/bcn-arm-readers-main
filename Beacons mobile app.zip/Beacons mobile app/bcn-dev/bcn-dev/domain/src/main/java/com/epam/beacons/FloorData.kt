package com.epam.beacons

data class FloorData(val floor: Floor, val graph: Graph)
