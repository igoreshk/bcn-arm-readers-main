package com.epam.beacons

data class Graph(val buildingId: String, val floorNumber: Int, val vertices: List<Vertex>?, val edges: List<Edge>?)
