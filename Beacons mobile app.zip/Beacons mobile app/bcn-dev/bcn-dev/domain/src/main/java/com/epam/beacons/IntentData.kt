package com.epam.beacons

data class IntentData(val extraString: String?, val actionType: ActionType, val intentType: IntentType) {

    enum class IntentType {
        ACTIVITY, SERVICE, BROADCAST_RECEIVER
    }

    enum class ActionType {
        SHARE_SAVED_FILE
    }
}
