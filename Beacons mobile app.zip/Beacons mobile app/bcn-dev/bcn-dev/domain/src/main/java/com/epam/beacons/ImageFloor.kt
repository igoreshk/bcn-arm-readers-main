package com.epam.beacons

class ManageImage(
    private val urlBegin: String,
    private val levelId: String,
    private val imageEnd: String
) {
    override fun toString(): String {
        return urlBegin + levelId + imageEnd
    }
}
