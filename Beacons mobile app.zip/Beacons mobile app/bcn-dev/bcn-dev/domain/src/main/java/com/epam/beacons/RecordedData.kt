package com.epam.beacons

class RecordedData(
        val dataUnits: MutableList<DataUnit> = mutableListOf(),
        var trilaterationCoordinate: Coordinate? = null,
        var boundCoord: Coordinate? = null
)
