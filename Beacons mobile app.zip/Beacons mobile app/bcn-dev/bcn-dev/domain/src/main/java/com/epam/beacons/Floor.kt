package com.epam.beacons

data class Floor(val entityId: String,
                 val number: Int,
                 val buildingId:String,
                 var beacons: List<Beacon>?,
                 val places: List<Place>?,
                 val image:String,
                 val distance:Double,
                 val overlaySouthWestBound: Coordinate,
                 val overlayNorthEastBound: Coordinate) {

    override fun equals(other: Any?): Boolean {
        if (other !is Floor) {
            return false
        }

        return other.entityId == entityId && other.number == number
    }

    override fun hashCode(): Int {
        var result = entityId.hashCode()
        result = 31 * result + number
        return result
    }
}
