package com.epam.beacons

data class Place constructor(
        val id: String,
        val type: String?,
        val description: String,
        val coordinate: Coordinate,
        val floorNumber: Int
) {
    var isFavorite: Boolean = false
    var isInHistory: Boolean = false
}
