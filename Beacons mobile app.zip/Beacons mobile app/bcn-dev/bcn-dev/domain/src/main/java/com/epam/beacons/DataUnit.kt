package com.epam.beacons

data class DataUnit @JvmOverloads constructor(val beacon: Beacon, var deltaTime: Long = 0, var avgRssi: Int = 0, var distance: Double = 0.0)
