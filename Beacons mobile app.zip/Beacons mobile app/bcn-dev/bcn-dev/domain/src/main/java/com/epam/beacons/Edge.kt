package com.epam.beacons

data class Edge(val source: Vertex?, val destination: Vertex?, val weight: Float?) {

    override fun equals(other: Any?): Boolean {
        if (other !is Edge) {
            return false
        }

        return other.destination == destination && other.source == source
    }

    override fun hashCode() = 31 * source.hashCode() + destination.hashCode()
}
