package com.epam.beacons

data class BuildIcon(val url: String?)
