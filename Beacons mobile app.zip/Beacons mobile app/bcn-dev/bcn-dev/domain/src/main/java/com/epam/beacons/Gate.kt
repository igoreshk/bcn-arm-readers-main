package com.epam.beacons

data class Gate(
    val id: Long,
    val buildingId: String,
    val image: String?,
    val type: String,
    val bounds: Map<Int, Coordinate>
)
