package com.epam.beacons

enum class Urls(val url: String) {
    ImageFloorUrl("http://bcn-dev.lab.epam.com/api/v1/levels/"),
    ImageBuildingUrl("http://bcn-dev.lab.epam.com/api/v1/buildings/")
}

enum class EndUrlImage(val url:String){
    Image("/image")
}
