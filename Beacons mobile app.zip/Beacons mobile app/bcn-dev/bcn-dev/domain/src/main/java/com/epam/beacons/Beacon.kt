package com.epam.beacons

data class Beacon @JvmOverloads constructor(
        /**
         * A 16 byte UUID that typically represents the company owning a number of beacons
         * Example: E2C56DB5-DFFB-48D2-B060-D0F5A71096E0.
         */
        val uuid: String,
        /**
         * A 16 bit integer typically used to represent a group of beacons.
         */
        val major: Int,
        /**
         * A 16 bit integer that identifies a specific beacon within a group.
         */
        val minor: Int,
        /**
         * The calibrated measured Tx power of the beacon in RSSI
         * This value is baked into an beacon when it is manufactured, and
         * it is transmitted with each packet to aid in the distance estimate.
         */
        var txPower: Double = 0.0,
        /**
         * The measured signal strength of the Bluetooth packet that led do this beacon detection.
         */
        var rssi: Int = 0,

        var floorNumber:Int = 0,
        var coordinate: Coordinate? = null,
        var levelId: String? = null
) : Comparable<Beacon> {

    constructor(beacon: Beacon) : this(beacon.uuid, beacon.major, beacon.minor, beacon.txPower, beacon.rssi, beacon.floorNumber, beacon.coordinate, beacon.levelId)

    constructor(uuid: String, major: Int, minor: Int, levelId: String?, coordinate: Coordinate)
            : this(uuid = uuid, major = major, minor = minor, coordinate = coordinate, txPower = 0.0, rssi = 0, levelId = levelId, floorNumber = 0)

    constructor(uuid: String, major: Int, minor: Int, levelId: String?, floorNumber: Int, coordinate: Coordinate)
            : this(uuid = uuid, major = major, minor = minor, coordinate = coordinate, txPower = 0.0, rssi = 0, levelId = levelId, floorNumber = floorNumber)

    override fun equals(other: Any?): Boolean {
        if (other !is Beacon) {
            return false
        }

        return other.major == major && other.minor == minor && other.uuid == uuid
    }

    override fun hashCode(): Int {
        var result = uuid.hashCode()
        result = 31 * result + major
        result = 31 * result + minor
        return result
    }

    override fun compareTo(other: Beacon) = when {
        this.rssi < other.rssi -> 1
        this.rssi > other.rssi -> -1
        else -> 0
    }
}
