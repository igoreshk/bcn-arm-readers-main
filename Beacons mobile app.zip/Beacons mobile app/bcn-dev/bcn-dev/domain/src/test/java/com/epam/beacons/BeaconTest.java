package com.epam.beacons;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class BeaconTest {

    @Test
    public void empty() {
        // empty test to enable test coverage
    }
}
