package com.rest.api.model;

import androidx.annotation.NonNull;

public class NetworkBeacon {

    @NonNull
    private final String            uuid;
    private final int               major;
    private final int               minor;
    @NonNull
    private final NetworkCoordinate coordinate;
    @NonNull
    private final String levelId;

    public NetworkBeacon(@NonNull String uuid, int major, int minor,
                         @NonNull NetworkCoordinate coordinate, String levelId) {
        this.uuid = uuid;
        this.major = major;
        this.minor = minor;
        this.coordinate = coordinate;
        this.levelId = levelId;
    }

    @NonNull
    public String getUuid() {
        return uuid;
    }

    public int getMajor() {
        return major;
    }

    public int getMinor() {
        return minor;
    }

    @NonNull
    public NetworkCoordinate getCoordinate() {
        return coordinate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final NetworkBeacon beacon = (NetworkBeacon) o;

        return major == beacon.major
                && minor == beacon.minor
                && uuid.equals(beacon.uuid)
                && coordinate.equals(beacon.coordinate);
    }

    @Override
    public int hashCode() {
        int result = uuid.hashCode();
        result = 31 * result + major;
        result = 31 * result + minor;
        result = 31 * result + coordinate.hashCode();
        return result;
    }

    @NonNull
    public String getLevelId() {
        return levelId;
    }
}
