package com.rest.api;

import androidx.annotation.NonNull;

import com.epam.beacons.Building;
import com.epam.beacons.EndUrlImage;
import com.epam.beacons.FloorData;
import com.epam.beacons.Gate;
import com.epam.beacons.ManageImage;
import com.epam.beacons.Urls;
import com.rest.api.mapper.NetworkBeaconToBeaconMapper;
import com.rest.api.mapper.NetworkBuildingToBuildingMapper;
import com.rest.api.mapper.NetworkFloorToFloorDataMapper;
import com.rest.api.mapper.NetworkGateToGateMapper;
import com.epam.beacons.Track;
import com.rest.api.model.NetworkBeacon;
import com.rest.api.model.NetworkEdge;
import com.rest.api.model.NetworkFloor;
import com.rest.api.model.NetworkPlace;
import com.rest.api.model.NetworkScale;
import com.rest.api.model.NetworkVertex;
import com.rest.api.service.RestService;


import java.io.IOException;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;
import javax.inject.Singleton;

import io.reactivex.Completable;
import io.reactivex.Maybe;
import retrofit2.Call;
import retrofit2.Response;


@Singleton
public class RestLayerImpl implements RestLayer {
    @NonNull
    private final RestService restService;
    @NonNull
    private final NetworkFloorToFloorDataMapper floorDataMapper;
    @NonNull
    private final NetworkBuildingToBuildingMapper buildingMapper;
    @NonNull
    private final NetworkGateToGateMapper gatesMapper;

    @Inject
    RestLayerImpl(@NonNull RestService restService,
                  @NonNull NetworkBuildingToBuildingMapper buildingMapper,
                  @NonNull NetworkFloorToFloorDataMapper floorDataMapper,
                  @NonNull NetworkGateToGateMapper gatesMapper) {
        this.restService = restService;
        this.buildingMapper = buildingMapper;
        this.floorDataMapper = floorDataMapper;
        this.gatesMapper = gatesMapper;
    }

    @SuppressWarnings("CheckResult")
    @Override
    public @NonNull
    Maybe<List<Building>> getBuildings() {
        return restService.getBuildings()
                .doOnSuccess(networkBuildings -> {
                    for (int i = 0; i < networkBuildings.size(); i++) {
                        networkBuildings.get(i).setIcon(new ManageImage(Urls.ImageBuildingUrl.getUrl(),
                                networkBuildings.get(i).getEntityId(),
                                EndUrlImage.Image.getUrl()).toString());
                    }
                })
                .map(buildingMapper::map);
    }

    @NonNull
    @Override
    public Maybe<List<Gate>> getGates(String buildingId) {
        return restService.getGates(buildingId)
                .map(networkGates -> gatesMapper.map(buildingId, networkGates));
    }

    @SuppressWarnings("CheckResult")
    @NonNull
    @Override
    public Maybe<List<FloorData>> getFloorsWithGraphs(String buildingId) {
        return restService.getFloors(buildingId)
                .doOnSuccess(networkFloors -> {
                    for (int i = 0; i < networkFloors.size(); i++) {
                        installEdges(networkFloors.get(i));
                        installBeacons(networkFloors.get(i), buildingId);
                        installVertices(networkFloors.get(i), buildingId);
                        installPlaces(networkFloors.get(i), buildingId);
                        installImage(networkFloors.get(i));
                        installScale(networkFloors.get(i), buildingId);
                    }
                })
                .map(networkFloors -> floorDataMapper.map(buildingId, networkFloors))
                .doOnSuccess(floorData -> System.out.println("HIIIII " + Objects.requireNonNull(floorData.get(0).getFloor().getPlaces()).size()));
    }


    public void installEdges(NetworkFloor networkFloor) throws IOException {
        Call<List<NetworkEdge>> edges = restService.getEdges(networkFloor.getEntityId());
        Response<List<NetworkEdge>> response = edges.execute();
        assert response.body() != null;
        networkFloor.setEdges(response.body());
    }

    public void installBeacons(NetworkFloor networkFloor, String buildingId) throws IOException {
        Call<List<NetworkBeacon>> beacons = restService.getBeacons(buildingId, networkFloor.getEntityId());
        Response<List<NetworkBeacon>> responseBeacon = beacons.execute();
        assert responseBeacon.body() != null;
        networkFloor.setBeacons(responseBeacon.body());
    }

    public void installVertices(NetworkFloor networkFloor, String buildingId) throws IOException {
        Call<List<NetworkVertex>> vertices = restService.getVertex(buildingId, networkFloor.getEntityId());
        Response<List<NetworkVertex>> responseVertex = vertices.execute();
        assert responseVertex.body() != null;
        networkFloor.setVertices(responseVertex.body());
    }

    public void installPlaces(NetworkFloor networkFloor, String buildingId) throws IOException {
        Call<List<NetworkPlace>> places = restService.getPlaces(buildingId, networkFloor.getEntityId());
        Response<List<NetworkPlace>> responsePlaces = places.execute();
        assert responsePlaces.body() != null;
        networkFloor.setPlaces(responsePlaces.body());
    }

    public void installImage(NetworkFloor networkFloor) {
        networkFloor.setImage(new ManageImage(Urls.ImageFloorUrl.getUrl(),
                networkFloor.getEntityId(),
                EndUrlImage.Image.getUrl()).toString());
    }

    public void installScale(NetworkFloor networkFloor, String buildingId) throws IOException {
        Call<List<NetworkScale>> scale = restService.getScale(buildingId, networkFloor.getEntityId());
        Response<List<NetworkScale>> responseScale = scale.execute();
        if (responseScale.body().size() > 0 && responseScale.body().get(0).getDistance() > 0) {
            networkFloor.setDistance(responseScale.body().get(0).getDistance());
        }
    }

    @NonNull
    @Override
    public Completable postTracks(List<Track> tracks) {
        return restService.postTracks(tracks);
    }
}
