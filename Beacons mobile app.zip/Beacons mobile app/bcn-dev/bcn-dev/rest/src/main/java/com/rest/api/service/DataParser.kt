package com.rest.api.service

import com.epam.beacons.BuildIcon
import com.rest.api.model.NetworkBeacon
import com.rest.api.model.NetworkBuilding
import com.rest.api.model.NetworkFloor
import com.rest.api.model.NetworkGate

interface DataParser {

    fun provideBuildings(): MutableList<NetworkBuilding>

    fun provideIcon(id: String): MutableList<NetworkBeacon>

    fun provideEdge(id: String): MutableList<NetworkGate>

    fun provideFloors(id: String): MutableList<NetworkFloor>

    fun provideGates(id: String): MutableList<NetworkGate>
}
