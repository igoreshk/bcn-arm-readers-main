package com.rest.api.model;

import androidx.annotation.NonNull;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class NetworkFloor {
    private final String entityId;
    private final int number;
    @NonNull
    private List<NetworkBeacon> beacons;
    @NonNull
    private List<NetworkEdge> edges;
    @NonNull
    private List<NetworkPlace> places;
    @NonNull
    private String image;
    @NonNull
    private List<NetworkVertex> vertices;
    private double distance;
    private final NetworkCoordinate southWestBoundary;
    private final NetworkCoordinate northEastBoundary;

    public NetworkFloor(String entityId,
                        int number,
                        @NonNull List<NetworkBeacon> beacons,
                        @NonNull List<NetworkEdge> edges,
                        @NonNull List<NetworkPlace> places,
                        @NonNull List<NetworkVertex> vertices,
                        double distance,
                        String image,
                        NetworkCoordinate southWestBoundary,
                        NetworkCoordinate northEastBoundary) {
        this.number = number;
        this.beacons = beacons;
        this.edges = edges;
        this.places = places;
        this.entityId = entityId;
        this.vertices = vertices;
        this.distance = distance;
        this.southWestBoundary = southWestBoundary;
        this.northEastBoundary = northEastBoundary;
        this.distance = 10.0;
        this.image = image;
    }

    public int getNumber() {
        return number;
    }

    @NonNull
    public List<NetworkBeacon> getBeacons() {
        return beacons;
    }

    @NonNull
    public List<NetworkEdge> getEdges() {
        return edges;
    }

    public void setEdges(@NotNull List<NetworkEdge> edges) {
        this.edges = edges;
    }

    public void setBeacons(@NotNull List<NetworkBeacon> beacons) {
        this.beacons = beacons;
    }

    public void setVertices(@NotNull List<NetworkVertex> vertices) {
        this.vertices = vertices;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public void setPlaces(@NotNull List<NetworkPlace> places) {
        this.places = places;
    }

    @NonNull
    public List<NetworkPlace> getPlaces() {
        return places;
    }


    @NonNull
    public List<NetworkVertex> getVertices() {
        return vertices;
    }


    public NetworkCoordinate getSouthWestBoundary() {
        return southWestBoundary;
    }

    public NetworkCoordinate getNorthEastBoundary() {
        return northEastBoundary;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final NetworkFloor that = (NetworkFloor) o;

        return number == that.number
                && Double.compare(that.distance, distance) == 0
                && beacons.equals(that.beacons)
                && edges.equals(that.edges)
                && places.equals(that.places)
                && vertices.equals(that.vertices);
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = number;
        result = 31 * result + beacons.hashCode();
        result = 31 * result + edges.hashCode();
        result = 31 * result + places.hashCode();
        result = 31 * result + vertices.hashCode();
        temp = Double.doubleToLongBits(distance);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    public String getEntityId() {
        return entityId;
    }

    public double getDistance() {
        return distance;
    }

    @NonNull
    public String getImage() {
        return image;
    }

    public void setImage(@NonNull String image) {
        this.image = image;
    }
}

