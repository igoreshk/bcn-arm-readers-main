package com.rest.api.model;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class NetworkGate {
    private final long        id;
    @Nullable
    private final String      image;
    @NonNull
    private final String      type;
    @NonNull
    private final List<Bound> bounds;

    public NetworkGate(long id, @Nullable String image, @NonNull String type, @NonNull List<Bound> bounds) {
        this.id = id;
        this.image = image;
        this.type = type;
        this.bounds = bounds;
    }

    public long getId() {
        return id;
    }

    @Nullable
    public String getImage() {
        return image;
    }

    @NonNull
    public String getType() {
        return type;
    }

    @NonNull
    public List<Bound> getBounds() {
        return bounds;
    }

    public static class Bound {
        private int               floorNumber;
        @NonNull
        private NetworkCoordinate coordinate;

        public Bound(int floorNumber, NetworkCoordinate coordinate) {
            this.floorNumber = floorNumber;
            this.coordinate = coordinate;
        }

        public int getFloorNumber() {
            return floorNumber;
        }

        public NetworkCoordinate getCoordinate() {
            return coordinate;
        }

    }
}
