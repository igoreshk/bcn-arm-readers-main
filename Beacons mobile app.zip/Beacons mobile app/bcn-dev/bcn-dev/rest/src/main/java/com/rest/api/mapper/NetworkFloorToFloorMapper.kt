package com.rest.api.mapper

import com.epam.beacons.Coordinate
import com.epam.beacons.Floor
import com.epam.beacons.tools.MapperWithBuildingId
import com.rest.api.model.NetworkFloor

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkFloorToFloorMapper @Inject constructor(
    private val beaconMapper: NetworkBeaconToBeaconMapper,
    private val placeMapper: NetworkPlaceToPlaceMapper
) : MapperWithBuildingId<NetworkFloor, Floor>() {

    override fun map(buildingId: String, from: NetworkFloor) = Floor(
        from.entityId,
        from.number,
        buildingId,
        beaconMapper.map(from.beacons),
        placeMapper.map(from.places, from.number),
        from.image,
        from.distance,
        Coordinate(from.southWestBoundary.latitude, from.southWestBoundary.longitude),
        Coordinate(from.northEastBoundary.latitude, from.northEastBoundary.longitude)
    )
}
