package com.rest.api.mapper

import com.epam.beacons.Coordinate
import com.epam.beacons.tools.Mapper
import com.rest.api.model.NetworkCoordinate

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkCoordinateToCoordinateMapper @Inject constructor() : Mapper<NetworkCoordinate, Coordinate>() {

    override fun map(from: NetworkCoordinate) = Coordinate(from.latitude, from.longitude)
}
