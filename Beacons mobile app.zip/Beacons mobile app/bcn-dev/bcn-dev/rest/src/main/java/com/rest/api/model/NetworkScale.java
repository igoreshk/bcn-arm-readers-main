package com.rest.api.model;

public class NetworkScale {

    private final String entityId;

    private final String levelId;

    private final double distance;

    private final String startVertexId;

    private final String endVertexId;

    public NetworkScale(String entityId, String levelId, double distance, String startVertexId, String endVertexId) {
        this.entityId = entityId;
        this.levelId = levelId;
        this.distance = distance;
        this.startVertexId = startVertexId;
        this.endVertexId = endVertexId;
    }

    public String getEndVertexId() {
        return endVertexId;
    }

    public String getStartVertexId() {
        return startVertexId;
    }

    public double getDistance() {
        return distance;
    }

    public String getLevelId() {
        return levelId;
    }

    public String getEntityId() {
        return entityId;
    }
}
