package com.rest.api.mapper

import com.epam.beacons.Building
import com.epam.beacons.tools.Mapper
import com.rest.api.model.NetworkBuilding

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkBuildingToBuildingMapper @Inject constructor(
    private val coordinateMapper: NetworkCoordinateToCoordinateMapper
) : Mapper<NetworkBuilding, Building>() {

    override fun map(from: NetworkBuilding) = Building(
        from.entityId,
        from.address,
        coordinateMapper.map(from.coordinate),
        from.width,
        from.height,
        from.name,
        from.phoneNumber,
        from.workingHours,
        from.createdBy,
        from.icon
    )
}
