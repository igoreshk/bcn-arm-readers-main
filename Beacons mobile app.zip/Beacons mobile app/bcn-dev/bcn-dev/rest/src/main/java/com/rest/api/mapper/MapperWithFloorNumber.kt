package com.rest.api.mapper

abstract class MapperWithFloorNumber<in From, out To> {
    abstract fun map(from: From, floorNumber: Int): To

    fun map(from: List<From>?, floorNumber: Int) = from?.map { map(it, floorNumber) }
}
