package com.rest.api.model;

import androidx.annotation.NonNull;

public class NetworkPlace {

    private final String entityId;
    @NonNull
    private final String placeType;
    @NonNull
    private final String description;
    @NonNull
    private final NetworkCoordinate coordinate;

    public NetworkPlace(String entityId, @NonNull String type, @NonNull String description,
                        @NonNull NetworkCoordinate coordinate) {
        this.entityId = entityId;
        this.placeType = type;
        this.description = description;
        this.coordinate = coordinate;
    }

    public String getEntityId() {
        return entityId;
    }

    @NonNull
    public String getPlaceType() {
        return placeType;
    }

    @NonNull
    public String getDescription() {
        return description;
    }

    @NonNull
    public NetworkCoordinate getCoordinate() {
        return coordinate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final NetworkPlace that = (NetworkPlace) o;

        return entityId.equals(that.entityId)
                && placeType.equals(that.placeType)
                && description.equals(that.description)
                && coordinate.equals(that.coordinate);
    }

    @Override
    public int hashCode() {
        int result = entityId.hashCode();
        result = 31 * result + placeType.hashCode();
        result = 31 * result + description.hashCode();
        result = 31 * result + coordinate.hashCode();
        return result;
    }
}
