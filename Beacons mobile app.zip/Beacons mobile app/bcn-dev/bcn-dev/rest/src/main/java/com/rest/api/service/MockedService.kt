package com.rest.api.service

import com.epam.beacons.BuildIcon
import com.epam.beacons.Track
import com.rest.api.model.*
import io.reactivex.Completable
import io.reactivex.Maybe
import retrofit2.Call
import retrofit2.mock.BehaviorDelegate
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MockedService @Inject constructor(
    private val delegate: BehaviorDelegate<RestService>,
    private val parser: DataParser
) : RestService {

    override fun getBuildings(): Maybe<MutableList<NetworkBuilding>> =
        delegate.returningResponse(parser.provideBuildings()).buildings

    override fun getFloors(id: String): Maybe<MutableList<NetworkFloor>> =
        delegate.returningResponse(parser.provideFloors(id)).getFloors(id)

    override fun getBeacons(id: String, levelId: String): Call<MutableList<NetworkBeacon>> {
        TODO("not implemented")
    }

    override fun getVertex(id: String?, levelId: String?): Call<MutableList<NetworkVertex>> {
        TODO("Not yet implemented")
    }

    override fun getGates(id: String): Maybe<MutableList<NetworkGate>> =
        delegate.returningResponse(parser.provideGates(id)).getGates(id)

    override fun getEdges(levelId: String): Call<MutableList<NetworkEdge>> {
        TODO("not implemented")
    }

    override fun getImageLevel(levelId: String?): Call<MutableList<NetworkEdge>> {
        TODO("Not yet implemented")
    }

    override fun getPlaces(id: String?, levelId: String?): Call<MutableList<NetworkPlace>> {
        TODO("Not yet implemented")
    }

    override fun getScale(id: String?, levelId: String?): Call<MutableList<NetworkScale>> {
        TODO("Not yet implemented")
    }

    override fun postTracks(body: MutableList<Track>?): Completable {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}
