package com.rest.api.mapper

import com.epam.beacons.Beacon
import com.epam.beacons.tools.Mapper
import com.rest.api.model.NetworkBeacon
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkBeaconToBeaconMapper @Inject constructor(
        private val coordinateMapper: NetworkCoordinateToCoordinateMapper,
        private val locale: Locale
) : Mapper<NetworkBeacon, Beacon>() {

    override fun map(from: NetworkBeacon) =
            Beacon(from.uuid.toLowerCase(locale),
                    from.major, from.minor, from.levelId,
                    coordinateMapper.map(from.coordinate))
}
