package com.rest.api.mapper

import com.epam.beacons.Place
import com.rest.api.model.NetworkPlace

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkPlaceToPlaceMapper @Inject constructor(
        private val coordinateMapper: NetworkCoordinateToCoordinateMapper
) : MapperWithFloorNumber<NetworkPlace, Place>() {

    override fun map(from: NetworkPlace, floorNumber: Int) =
            Place(from.entityId, from.placeType, from.description, coordinateMapper.map(from.coordinate), floorNumber)
}
