package com.rest.api.model;

import androidx.annotation.NonNull;

public class NetworkVertex {

    private final String              entityId;
    @NonNull
    private final NetworkCoordinate coordinate;

    public NetworkVertex(String id, @NonNull NetworkCoordinate coordinate) {
        this.entityId = id;
        this.coordinate = coordinate;
    }

    public String getEntityId() {
        return entityId;
    }

    @NonNull
    public NetworkCoordinate getCoordinate() {
        return coordinate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final NetworkVertex that = (NetworkVertex) o;

        return entityId.equals(that.entityId)
                && coordinate.equals(that.coordinate);
    }

    @Override
    public int hashCode() {
        int result = (int) (entityId.hashCode() ^ (entityId.hashCode() >>> 32));
        result = 31 * result + coordinate.hashCode();
        return result;
    }
}
