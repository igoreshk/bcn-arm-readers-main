package com.rest.api.mapper

import com.epam.beacons.Vertex
import com.epam.beacons.tools.Mapper
import com.rest.api.model.NetworkVertex

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkVertexToVertexMapper @Inject constructor(
        private val coordinateMapper: NetworkCoordinateToCoordinateMapper
) : Mapper<NetworkVertex, Vertex>() {

    override fun map(from: NetworkVertex) = Vertex(from.entityId, coordinateMapper.map(from.coordinate))
}
