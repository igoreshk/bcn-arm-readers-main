package com.rest.api.mapper

import com.epam.beacons.Edge
import com.epam.beacons.Vertex
import com.rest.api.model.NetworkEdge
import com.rest.api.model.NetworkVertex
import com.rest.api.service.RestService

import java.util.ArrayList
import java.util.HashMap

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkEdgesToEdgesMapper @Inject constructor(private val vertexMapper: NetworkVertexToVertexMapper, private val restService: RestService) {

    fun map(networkEdges: List<NetworkEdge>?, networkVertices: List<NetworkVertex>?): List<Edge> {

        val vertexMap = HashMap<String, Vertex>()
        networkVertices?.forEach { vertex -> vertexMap[vertex.entityId] = vertexMapper.map(vertex) }

        val edges = ArrayList<Edge>()
        networkEdges?.forEach { networkEdge ->
            edges.add(Edge(
                    vertexMap.getValue(networkEdge.startVertexId),
                    vertexMap.getValue(networkEdge.endVertexId),
                    networkEdge.weight)
            )
        }
        return edges
    }
}
