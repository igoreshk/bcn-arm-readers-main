package com.rest.api.mapper

import com.epam.beacons.Graph
import com.epam.beacons.tools.MapperWithBuildingId
import com.rest.api.model.NetworkFloor
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkGraphToGraphMapper @Inject constructor(
        private val vertexMapper: NetworkVertexToVertexMapper,
        private val edgesMapper: NetworkEdgesToEdgesMapper
) : MapperWithBuildingId<NetworkFloor, Graph>() {

    override fun map(buildingId: String, from: NetworkFloor) = Graph(
            buildingId,
            from.number,
            vertexMapper.map(from.vertices),
            edgesMapper.map(from.edges, from.vertices))
}
