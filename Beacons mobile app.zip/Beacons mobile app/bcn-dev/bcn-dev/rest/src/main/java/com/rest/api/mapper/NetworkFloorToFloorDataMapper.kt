package com.rest.api.mapper

import com.epam.beacons.FloorData
import com.epam.beacons.tools.MapperWithBuildingId
import com.rest.api.model.NetworkFloor
import com.rest.api.service.RestService
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkFloorToFloorDataMapper @Inject constructor(
        private val floorMapper: NetworkFloorToFloorMapper,
        private val graphMapper: NetworkGraphToGraphMapper
) : MapperWithBuildingId<NetworkFloor, FloorData>() {
    override fun map(buildingId: String, from: NetworkFloor): FloorData {

        return FloorData(
            floorMapper.map(buildingId, from),
            graphMapper.map(buildingId, from)
        )
    }
}
