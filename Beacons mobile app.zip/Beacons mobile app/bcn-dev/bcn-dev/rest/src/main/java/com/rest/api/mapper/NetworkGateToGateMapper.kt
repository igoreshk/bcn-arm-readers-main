package com.rest.api.mapper

import com.epam.beacons.Coordinate
import com.epam.beacons.Gate
import com.epam.beacons.tools.MapperWithBuildingId
import com.rest.api.model.NetworkGate
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkGateToGateMapper @Inject constructor(private val coordinateMapper: NetworkCoordinateToCoordinateMapper)
    : MapperWithBuildingId<NetworkGate, Gate>() {

    override fun map(buildingId: String, from: NetworkGate): Gate {
        val bounds = HashMap<Int, Coordinate>()
        from.bounds.forEach { bound -> bounds[bound.floorNumber] = coordinateMapper.map(bound.coordinate) }
        return Gate(from.id, buildingId, from.image, from.type, bounds)
    }
}
