package com.rest.api.model

data class NetworkBuilding(val entityId: String,
                           val address:  String?,
                           val coordinate: NetworkCoordinate,
                           val width: Double?,
                           val height: Double?,
                           val name: String?,
                           val phoneNumber: String?,
                           val workingHours: String?,
                           val createdBy: String?,
                           var icon:String?)
