package com.rest.api.service;

import com.epam.beacons.BuildIcon;
import com.rest.api.model.NetworkBeacon;
import com.rest.api.model.NetworkBuilding;
import com.rest.api.model.NetworkEdge;
import com.rest.api.model.NetworkFloor;
import com.rest.api.model.NetworkGate;
import com.epam.beacons.Track;
import com.rest.api.model.NetworkPlace;
import com.rest.api.model.NetworkScale;
import com.rest.api.model.NetworkVertex;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Maybe;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface RestService {
    @Headers({"Accept: application/json"})
    @GET("buildings")
    Maybe<List<NetworkBuilding>> getBuildings();

    @Headers({"Accept: application/json"})
    @GET("buildings/{id}/levels")
    Maybe<List<NetworkFloor>> getFloors(@Path("id") String id);

    @Headers({"Accept: application/json"})
    @GET("buildings/{id}/levels/{levelId}/beacons")
    Call<List<NetworkBeacon>> getBeacons(@Path("id") String id, @Path("levelId") String levelId);

    @Headers({"Accept: application/json"})
    @GET("buildings/{id}/levels/{levelId}/vertices")
    Call<List<NetworkVertex>> getVertex(@Path("id") String id, @Path("levelId") String levelId);

    @Headers({"Accept: application/json"})
    @GET("buildings/{id}/gates")
    Maybe<List<NetworkGate>> getGates(@Path("id") String id);

    @Headers({"Accept: application/json"})
    @GET("edges/byLevel/{levelId}")
    Call<List<NetworkEdge>> getEdges(@Path("levelId") String levelId);

    @Headers({"Accept: application/json"})
    @GET("levels/{levelId}/image")
    Call<List<NetworkEdge>> getImageLevel(@Path("levelId") String levelId);

    @Headers({"Accept: application/json"})
    @GET("buildings/{id}/levels/{levelId}/places")
    Call<List<NetworkPlace>> getPlaces(@Path("id") String id, @Path("levelId") String levelId);

    @Headers({"Accept: application/json"})
    @GET("buildings/{id}/levels/{levelId}/scale")
    Call<List<NetworkScale>> getScale(@Path("id") String id, @Path("levelId") String levelId);

    @Headers("Content-Type: application/json")
    @POST("saveTracks")
    Completable postTracks(@Body List<Track> body);
}
