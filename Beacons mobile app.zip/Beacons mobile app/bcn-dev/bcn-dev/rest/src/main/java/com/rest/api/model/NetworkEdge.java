package com.rest.api.model;


public class NetworkEdge {

    private final String  startVertexId;
    private final String  endVertexId;
    private final float weight;

    public NetworkEdge(String startVertexId, String destinationVertexId, float weight) {
        this.startVertexId = startVertexId;
        this.endVertexId = destinationVertexId;
        this.weight = weight;
    }

    public String getStartVertexId() {
        return startVertexId;
    }

    public String getEndVertexId() {
        return endVertexId;
    }

    public float getWeight() {
        return weight;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final NetworkEdge that = (NetworkEdge) o;

        return startVertexId.equals(that.startVertexId)
                && endVertexId.equals(that.endVertexId)
                && Float.compare(that.weight, weight) == 0;
    }

    @Override
    public int hashCode() {
        int result = (int) (startVertexId.hashCode());
        result = 31 * result + (int) (endVertexId.hashCode() ^ (endVertexId.hashCode() >>> 32));
        result = 31 * result + (Float.compare(weight, +0.0f) != 0 ? Float.floatToIntBits(weight) : 0);
        return result;
    }
}
