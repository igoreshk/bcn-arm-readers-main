package com.rest.api;

import androidx.annotation.NonNull;

import com.epam.beacons.Beacon;
import com.epam.beacons.Building;
import com.epam.beacons.Edge;
import com.epam.beacons.FloorData;
import com.epam.beacons.Gate;
import com.epam.beacons.Track;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Maybe;

public interface RestLayer {

    @NonNull
    Maybe<List<Building>> getBuildings();

    @NonNull
    Maybe<List<Gate>> getGates(String buildingId);

    @NonNull
    Maybe<List<FloorData>> getFloorsWithGraphs(String buildingId);

    @NonNull
    Completable postTracks(List<Track> tracks);
}
